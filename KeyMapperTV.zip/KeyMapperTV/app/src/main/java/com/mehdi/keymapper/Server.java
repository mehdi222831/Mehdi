package com.mehdi.keymapper;

import android.os.SystemClock;
import android.view.InputEvent;
import android.view.KeyEvent;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * ADB shell (uid 2000) icazəsi ilə app_process vasitəsilə işləyir.
 * Düymə hadisələrini birbaşa InputManager-ə yeridir (input keyevent kimi proses açmır) -> gecikmə yoxdur.
 */
public class Server {
    private static final int FLAG_LONG_PRESS = 0x80;
    private static final int SOURCE_KEYBOARD = 0x101;
    private static final long REPEAT_DELAY = 400;
    private static final long REPEAT_INTERVAL = 50;
    private static final long LONG_MS = 400;
    private static final long MAX_HOLD = 120000;

    private static Object im;
    private static Method injectM;
    private static final ScheduledExecutorService ex = Executors.newScheduledThreadPool(2);
    private static final HashMap<Integer, Held> held = new HashMap<>();

    private static class Held {
        long downTime;
        int repeat;
        ScheduledFuture<?> task;
    }

    public static void main(String[] args) throws Exception {
        final String token = args[0];
        int port = Integer.parseInt(args[1]);
        initInput();
        ServerSocket ss = new ServerSocket(port, 4, InetAddress.getByName("127.0.0.1"));
        while (true) {
            final Socket s = ss.accept();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    handle(s, token);
                }
            }).start();
        }
    }

    private static void initInput() throws Exception {
        Object m = null;
        try {
            Class<?> g = Class.forName("android.hardware.input.InputManagerGlobal");
            m = g.getMethod("getInstance").invoke(null);
        } catch (Throwable ignored) {
        }
        if (m == null) {
            Class<?> c = Class.forName("android.hardware.input.InputManager");
            m = c.getDeclaredMethod("getInstance").invoke(null);
        }
        injectM = m.getClass().getMethod("injectInputEvent", InputEvent.class, int.class);
        im = m;
    }

    private static void handle(Socket s, String token) {
        try {
            s.setTcpNoDelay(true);
            DataInputStream in = new DataInputStream(new BufferedInputStream(s.getInputStream()));
            DataOutputStream out = new DataOutputStream(s.getOutputStream());
            String t = in.readUTF();
            if (!token.equals(t)) {
                s.close();
                return;
            }
            out.writeInt(Bridge.VERSION);
            out.flush();
            while (true) {
                int cmd = in.readUnsignedByte();
                int key = in.readInt();
                switch (cmd) {
                    case Bridge.CMD_DOWN:
                        down(key);
                        break;
                    case Bridge.CMD_UP:
                        up(key);
                        break;
                    case Bridge.CMD_CLICK:
                        click(key);
                        break;
                    case Bridge.CMD_LONG:
                        longPress(key);
                        break;
                    case Bridge.CMD_RELEASE_ALL:
                        releaseAll();
                        break;
                    case Bridge.CMD_QUIT:
                        releaseAll();
                        System.exit(0);
                        break;
                    default:
                        break;
                }
            }
        } catch (IOException ignored) {
        } finally {
            releaseAll();
            try {
                s.close();
            } catch (IOException ignored) {
            }
        }
    }

    private static synchronized void inject(int action, int key, int repeat, int flags, long downTime) {
        try {
            long now = SystemClock.uptimeMillis();
            KeyEvent ev = new KeyEvent(downTime, now, action, key, repeat, 0, -1, 0, flags, SOURCE_KEYBOARD);
            injectM.invoke(im, ev, 0);
        } catch (Throwable ignored) {
        }
    }

    private static synchronized void down(final int key) {
        if (held.containsKey(key)) return;
        final Held h = new Held();
        h.downTime = SystemClock.uptimeMillis();
        held.put(key, h);
        inject(KeyEvent.ACTION_DOWN, key, 0, 0, h.downTime);
        h.task = ex.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                tick(key, h);
            }
        }, REPEAT_DELAY, REPEAT_INTERVAL, TimeUnit.MILLISECONDS);
    }

    private static void tick(int key, Held h) {
        try {
            synchronized (Server.class) {
                if (held.get(key) != h) return;
                if (SystemClock.uptimeMillis() - h.downTime > MAX_HOLD) {
                    up(key);
                    return;
                }
                h.repeat++;
                inject(KeyEvent.ACTION_DOWN, key, h.repeat, h.repeat == 1 ? FLAG_LONG_PRESS : 0, h.downTime);
            }
        } catch (Throwable ignored) {
        }
    }

    private static synchronized void up(int key) {
        Held h = held.remove(key);
        if (h == null) return;
        if (h.task != null) h.task.cancel(false);
        inject(KeyEvent.ACTION_UP, key, 0, 0, h.downTime);
    }

    private static synchronized void click(int key) {
        long t = SystemClock.uptimeMillis();
        inject(KeyEvent.ACTION_DOWN, key, 0, 0, t);
        inject(KeyEvent.ACTION_UP, key, 0, 0, t);
    }

    private static void longPress(final int key) {
        final long t0 = SystemClock.uptimeMillis();
        inject(KeyEvent.ACTION_DOWN, key, 0, 0, t0);
        ex.schedule(new Runnable() {
            @Override
            public void run() {
                inject(KeyEvent.ACTION_DOWN, key, 1, FLAG_LONG_PRESS, t0);
            }
        }, LONG_MS, TimeUnit.MILLISECONDS);
        ex.schedule(new Runnable() {
            @Override
            public void run() {
                inject(KeyEvent.ACTION_UP, key, 0, 0, t0);
            }
        }, LONG_MS + 60, TimeUnit.MILLISECONDS);
    }

    private static synchronized void releaseAll() {
        for (Integer k : new ArrayList<>(held.keySet())) up(k);
    }
}
