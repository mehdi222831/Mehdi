package az.tvlauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings

/** TV box açılanda launcher-i avtomatik başladır. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val a = intent.action ?: return
        if (a != Intent.ACTION_BOOT_COMPLETED && a != "android.intent.action.QUICKBOOT_POWERON" &&
            a != "com.htc.intent.action.QUICKBOOT_POWERON" && a != Intent.ACTION_LOCKED_BOOT_COMPLETED) return
        // Android 10+ fonda activity açmaq üçün "Digər tətbiqlərin üzərində göstər" icazəsi lazımdır
        if (Build.VERSION.SDK_INT >= 29 && !Settings.canDrawOverlays(ctx)) return
        try {
            ctx.startActivity(Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
        } catch (e: Exception) {}
    }
}
