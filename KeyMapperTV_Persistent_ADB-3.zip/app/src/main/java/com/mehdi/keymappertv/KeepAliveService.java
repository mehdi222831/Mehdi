package com.mehdi.keymappertv;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Foreground keep-alive service. Reconnects to the local authenticated adbd and reapplies policy. */
public class KeepAliveService extends Service {
    private static final String CHANNEL_ID = "keymapper_tv_running";
    private static final int NOTIFICATION_ID = 7431;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private volatile boolean running;
    private PowerManager.WakeLock wakeLock;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(NOTIFICATION_ID, buildNotification());
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "KeyMapperTV:KeepAlive");
                wakeLock.setReferenceCounted(false);
                wakeLock.acquire();
            }
        } catch (Exception ignored) { }
        running = true;
        scheduleWatchdog(this);
        worker.execute(this::adbWatchLoop);
        worker.execute(this::accessibilityGuardLoop);
    }

    /** Every 60 s an exact alarm re-launches this service even if the system killed it. */
    static void scheduleWatchdog(Context c) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            Intent i = new Intent(c, BootReceiver.class).setAction(BootReceiver.ACTION_WATCHDOG);
            int flag = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 23) flag |= PendingIntent.FLAG_IMMUTABLE;
            PendingIntent pi = PendingIntent.getBroadcast(c, 77, i, flag);
            long at = System.currentTimeMillis() + 60000L;
            if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.setExact(AlarmManager.RTC_WAKEUP, at, pi);
        } catch (Exception ignored) { }
    }

    /** If WRITE_SECURE_SETTINGS was granted via adb, re-enable the accessibility service whenever it gets switched off. */
    private void accessibilityGuardLoop() {
        final String me = new ComponentName(this, KeyMapAccessibilityService.class).flattenToString();
        while (running && !Thread.currentThread().isInterrupted()) {
            try {
                String cur = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
                if (cur == null || !cur.contains(me)) {
                    String next = (cur == null || cur.isEmpty()) ? me : cur + ":" + me;
                    Settings.Secure.putString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, next);
                }
                Settings.Secure.putInt(getContentResolver(), Settings.Secure.ACCESSIBILITY_ENABLED, 1);
            } catch (Exception ignored) { /* permission not granted yet */ }
            try { Thread.sleep(3000L); } catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    private void adbWatchLoop() {
        while (running && !Thread.currentThread().isInterrupted()) {
            AdbShellClient client = null;
            try {
                client = AdbShellClient.connect(getApplicationContext());
                // Apply on every successful connection; this is safe to repeat.
                client.applyKeepAliveCommands();
                // Keep the authenticated shell alive and check the transport periodically.
                while (running && client.isConnected()) {
                    Thread.sleep(30000L);
                    if (!client.isConnected()) break;
                    // Reapply exemptions periodically in case a system component reset them.
                    client.applyKeepAliveCommands();
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            } catch (Exception ignored) {
                // adbd may be unavailable or awaiting the one-time RSA authorization.
            } finally {
                if (client != null) client.close();
            }
            if (running) {
                try { Thread.sleep(10000L); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
            }
        }
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        // stopWithTask=false also keeps this service independent from the activity task.
        super.onTaskRemoved(rootIntent);
        BootReceiver.start(this);
    }

    @Override public void onDestroy() {
        BootReceiver.start(this);
        running = false;
        worker.shutdownNow();
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); }
        catch (Exception ignored) { }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        int flag = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flag |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, flag);
        if (Build.VERSION.SDK_INT >= 26) {
            return new Notification.Builder(this, CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.ic_media_play)
                    .setContentTitle("Key Mapper TV işləyir")
                    .setContentText("Daimi xidmət və lokal ADB nəzarəti aktivdir")
                    .setContentIntent(pi).setOngoing(true).build();
        }
        return new Notification.Builder(this)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("Key Mapper TV işləyir")
                .setContentText("Daimi xidmət və lokal ADB nəzarəti aktivdir")
                .setContentIntent(pi).setOngoing(true).build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(new NotificationChannel(
                    CHANNEL_ID, "Key Mapper TV", NotificationManager.IMPORTANCE_LOW));
        }
    }
}
