package com.mehdi.keymapper;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Minimal ADB protokolu müştərisi (TCP). Özünə (127.0.0.1 və ya öz IP-sinə) :5555 ilə qoşulur. */
public class Adb implements Closeable {
    private static final int A_CNXN = 0x4e584e43;
    private static final int A_AUTH = 0x48545541;
    private static final int A_OPEN = 0x4e45504f;
    private static final int A_OKAY = 0x59414b4f;
    private static final int A_CLSE = 0x45534c43;
    private static final int A_WRTE = 0x45545257;

    private static final byte[] SHA1_PREFIX = {0x30, 0x21, 0x30, 0x09, 0x06, 0x05, 0x2b, 0x0e, 0x03, 0x02, 0x1a, 0x05, 0x00, 0x04, 0x14};

    private Socket socket;
    private DataInputStream in;
    private OutputStream out;
    private int nextId = 1;

    private static class Msg {
        int cmd, arg0, arg1;
        byte[] data;
    }

    // ---------------------------------------------------------------- qoşulma

    public static Adb connect(Context ctx, String host, int port) throws Exception {
        Adb a = new Adb();
        try {
            a.open(ctx, host, port);
        } catch (Exception e) {
            a.close();
            throw e;
        }
        return a;
    }

    public static Adb connectAuto(Context c) throws Exception {
        int port = Store.adbPort(c);
        List<String> hosts = new ArrayList<>();
        String custom = Store.adbHost(c);
        if (custom != null && custom.length() > 0) hosts.add(custom);
        hosts.add("127.0.0.1");
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) {
                        String ip = a.getHostAddress();
                        if (!hosts.contains(ip)) hosts.add(ip);
                    }
                }
            }
        } catch (Exception ignored) {
        }
        Exception last = null;
        for (String h : hosts) {
            try {
                Status.adb = h + ":" + port + " ünvanına qoşulur...";
                Adb a = connect(c, h, port);
                Status.adb = "qoşuldu (" + h + ":" + port + ")";
                return a;
            } catch (Exception e) {
                last = e;
            }
        }
        Status.adb = "qoşulmaq alınmadı";
        throw new IOException("ADB-yə qoşulmaq alınmadı (port " + port + ")" + (last != null ? ": " + last.getMessage() : ""));
    }

    private void open(Context ctx, String host, int port) throws Exception {
        socket = new Socket();
        socket.connect(new InetSocketAddress(host, port), 2500);
        socket.setTcpNoDelay(true);
        socket.setSoTimeout(70000); // istifadəçi TV-də "İcazə ver" düyməsini basana qədər gözləmək üçün
        in = new DataInputStream(socket.getInputStream());
        out = socket.getOutputStream();

        KeyPair kp = loadKeys(ctx);
        send(A_CNXN, 0x01000000, 256 * 1024, "host::\0".getBytes("UTF-8"));
        boolean sentSig = false, sentKey = false;
        while (true) {
            Msg m = read();
            if (m.cmd == A_CNXN) {
                socket.setSoTimeout(8000);
                return;
            }
            if (m.cmd == A_AUTH && m.arg0 == 1) {
                if (!sentSig) {
                    send(A_AUTH, 2, 0, sign(kp.getPrivate(), m.data));
                    sentSig = true;
                } else if (!sentKey) {
                    send(A_AUTH, 3, 0, pubKeyBytes(kp));
                    sentKey = true;
                } else {
                    throw new IOException("ADB icazəsi verilmədi");
                }
            } else {
                throw new IOException("Gözlənilməz ADB cavabı");
            }
        }
    }

    // ---------------------------------------------------------------- shell

    public synchronized String shell(String cmd) throws IOException {
        int localId = nextId++;
        send(A_OPEN, localId, 0, ("shell:" + cmd + "\0").getBytes("UTF-8"));
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        while (true) {
            Msg m;
            try {
                m = read();
            } catch (SocketTimeoutException e) {
                break;
            }
            if (m.arg1 != localId) continue;
            if (m.cmd == A_WRTE) {
                bo.write(m.data, 0, m.data.length);
                send(A_OKAY, localId, m.arg0, null);
            } else if (m.cmd == A_CLSE) {
                try {
                    send(A_CLSE, localId, m.arg0, null);
                } catch (IOException ignored) {
                }
                break;
            }
        }
        return bo.toString("UTF-8");
    }

    /** İzinləri verir, arxa planda işləməyi təmin edir və (lazımsa) Server prosesini işə salır. */
    public static void bootstrap(Context c, boolean startServer) throws Exception {
        Adb a = connectAuto(c);
        try {
            String pkg = c.getPackageName();
            a.shell("pm grant " + pkg + " android.permission.WRITE_SECURE_SETTINGS");
            a.shell("pm grant " + pkg + " android.permission.POST_NOTIFICATIONS");
            a.shell("dumpsys deviceidle whitelist +" + pkg);
            a.shell("cmd appops set " + pkg + " RUN_IN_BACKGROUND allow");
            a.shell("cmd appops set " + pkg + " RUN_ANY_IN_BACKGROUND allow");
            a.shell("am set-standby-bucket " + pkg + " active");
            if (startServer) {
                a.shell("pkill -f '[k]eymapper_server'; sleep 1");
                String cmd = "(CLASSPATH='" + c.getPackageCodePath() + "' nohup app_process /system/bin"
                        + " --nice-name=keymapper_server com.mehdi.keymapper.Server "
                        + Store.token(c) + " " + Bridge.PORT + " </dev/null >/dev/null 2>&1 &)";
                a.shell(cmd);
            }
        } finally {
            a.close();
        }
    }

    // ---------------------------------------------------------------- protokol

    private synchronized void send(int cmd, int a0, int a1, byte[] data) throws IOException {
        int len = data == null ? 0 : data.length;
        int crc = 0;
        if (data != null) for (byte x : data) crc += (x & 0xff);
        ByteBuffer b = ByteBuffer.allocate(24 + len).order(ByteOrder.LITTLE_ENDIAN);
        b.putInt(cmd).putInt(a0).putInt(a1).putInt(len).putInt(crc).putInt(cmd ^ 0xffffffff);
        if (data != null) b.put(data);
        out.write(b.array());
        out.flush();
    }

    private Msg read() throws IOException {
        byte[] h = new byte[24];
        in.readFully(h);
        ByteBuffer b = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN);
        Msg m = new Msg();
        m.cmd = b.getInt();
        m.arg0 = b.getInt();
        m.arg1 = b.getInt();
        int len = b.getInt();
        if (len < 0 || len > 1024 * 1024) throw new IOException("Yanlış ADB paketi");
        m.data = new byte[len];
        if (len > 0) in.readFully(m.data);
        return m;
    }

    @Override
    public void close() {
        try {
            if (socket != null) socket.close();
        } catch (IOException ignored) {
        }
    }

    // ---------------------------------------------------------------- açarlar

    private static KeyPair loadKeys(Context c) throws Exception {
        SharedPreferences sp = c.getApplicationContext().getSharedPreferences("adbkey", Context.MODE_PRIVATE);
        String priv = sp.getString("priv", null);
        String pub = sp.getString("pub", null);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        if (priv != null && pub != null) {
            try {
                PrivateKey pr = kf.generatePrivate(new PKCS8EncodedKeySpec(Base64.decode(priv, Base64.NO_WRAP)));
                PublicKey pu = kf.generatePublic(new X509EncodedKeySpec(Base64.decode(pub, Base64.NO_WRAP)));
                return new KeyPair(pu, pr);
            } catch (Exception ignored) {
            }
        }
        KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
        g.initialize(2048);
        KeyPair kp = g.generateKeyPair();
        sp.edit()
                .putString("priv", Base64.encodeToString(kp.getPrivate().getEncoded(), Base64.NO_WRAP))
                .putString("pub", Base64.encodeToString(kp.getPublic().getEncoded(), Base64.NO_WRAP))
                .commit();
        return kp;
    }

    private static byte[] sign(PrivateKey key, byte[] token) throws Exception {
        Signature s = Signature.getInstance("NONEwithRSA");
        s.initSign(key);
        byte[] d = new byte[SHA1_PREFIX.length + token.length];
        System.arraycopy(SHA1_PREFIX, 0, d, 0, SHA1_PREFIX.length);
        System.arraycopy(token, 0, d, SHA1_PREFIX.length, token.length);
        s.update(d);
        return s.sign();
    }

    private static void putWords(ByteBuffer bb, BigInteger x) {
        for (int i = 0; i < 64; i++) bb.putInt(x.shiftRight(32 * i).intValue());
    }

    /** Android "adb_auth" RSAPublicKey strukturu + base64 + " ad\0" */
    private static byte[] pubKeyBytes(KeyPair kp) throws Exception {
        RSAPublicKey pk = (RSAPublicKey) kp.getPublic();
        BigInteger n = pk.getModulus();
        BigInteger r32 = BigInteger.ONE.shiftLeft(32);
        int n0inv = r32.subtract(n.mod(r32).modInverse(r32)).intValue();
        BigInteger rr = BigInteger.ONE.shiftLeft(4096).mod(n);
        ByteBuffer bb = ByteBuffer.allocate(4 + 4 + 256 + 256 + 4).order(ByteOrder.LITTLE_ENDIAN);
        bb.putInt(64);
        bb.putInt(n0inv);
        putWords(bb, n);
        putWords(bb, rr);
        bb.putInt(pk.getPublicExponent().intValue());
        String s = Base64.encodeToString(bb.array(), Base64.NO_WRAP) + " keymapper@tv\0";
        return s.getBytes("UTF-8");
    }
}
