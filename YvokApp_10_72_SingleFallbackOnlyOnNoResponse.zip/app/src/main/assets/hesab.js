(function(){
  var t=(document.body&&document.body.innerText)||'';
  var lines=t.split('\n').map(function(s){return s.trim();}).filter(function(s){return s.length>0;});
  function find(re){
    for(var i=lines.length-1;i>=0;i--){
      if(re.test(lines[i])){
        var rest=lines[i].replace(re,'').replace(/^[\s:\-–]+/,'').trim();
        if(rest) return rest;
        if(i+1<lines.length && !/^(abonent|yv[öo]k|balans)/i.test(lines[i+1])) return lines[i+1];
      }
    }
    return '';
  }
  if(!window.__tried){
    var btns=document.querySelectorAll('button, input[type=submit], a.btn');
    for(var j=0;j<btns.length;j++){
      var bt=(btns[j].innerText||btns[j].value||'').trim();
      if(/^(davam|yoxla|axtar|sorğu|göstər|növbəti)/i.test(bt) && !btns[j].disabled){
        window.__tried=true; btns[j].click(); break;
      }
    }
  }
  var notFound = /tapılmad[ıi]|tapılmay[ıi]b|mövcud deyil|məlumat yoxdur|düzgün deyil|abonent\s+tapılmad|nəticə\s+tapılmad|heç bir nəticə|sorğuya uyğun nəticə yoxdur/i.test(t);
  return JSON.stringify({
    abonent:find(/^abonent\b/i),
    yvok:find(/^yv[öo]k\b/i),
    balans:find(/^balans\b/i),
    nf:notFound
  });
})()
