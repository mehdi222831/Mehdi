package az.mehdi.iptvplayer

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.view.SurfaceHolder
import android.view.SurfaceView
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.interfaces.IVLCVout

/**
 * Ehtiyat mühərrik: libVLC.
 *
 * Sabitlik qaydaları (çökmə və "yüklənmədə qalma" problemlərinə qarşı):
 *  1) libVLC-nin BÜTÜN native çağırışları (yaratma, stop, media, play, pause, release) əsas thread-də yox,
 *     tək ayrı thread-də ("vlc-ctl") ardıcıl icra olunur: UI donmur, release/stop/play bir-biri ilə toqquşmur.
 *  2) Kanal sürətlə dəyişdirilərkən yalnız SON istək icra olunur (hər əmr "generation" nömrəsi daşıyır,
 *     köhnəlmiş əmrlər atlanır).
 *  3) Əvvəlki yayımdan gecikmiş hadisələr (Playing/Error...) yeni kanala aid edilmir: yeni media başladılandan
 *     sonra "acceptToken" qoyulur, ondan əvvəlki hadisələr ignor olunur.
 *  4) Yeni media verilməzdən əvvəl həmişə mp.stop() çağırılır.
 *  5) Hadisə gəlməsə belə, vaxt aşımında real vəziyyət (isPlaying/time) yoxlanılır; səth gözlənilərkən də vaxt aşımı işləyir.
 *  6) ƏSAS THREAD HEÇ VAXT MediaPlayer obyektinə toxunmur (stats, position, isPlaying, aspect ratio...): worker
 *     stop()/play() zamanı şəbəkədə bloklana bilər və obyektin kilidini saxlayır, əsas thread gözləsə tətbiq donar.
 *     Əsas thread yalnız hadisələrdən yığılmış keş dəyərlərini oxuyur.
 */
class VlcEngine(
    context: Context,
    private val view: SurfaceView,
    private val callback: PlayerCallback
) : SurfaceHolder.Callback {

    companion object {
        private const val OPEN_TIMEOUT_MS = 10_000L
        // VLC şəbəkə buferi kiçik saxlanır: gecikmə/RAM azalır, donmada kanal dəyişmə sürətlənir.
        private const val NETWORK_CACHING_MS = 4_000
        // Səth/libVLC hazırlığı üçün əlavə gözləmə (açılış vaxt aşımına əlavə olunur).
        private const val SURFACE_WAIT_MS = 4_000L
        private const val MAX_INIT_FAILURES = 2
        // Worker bu müddətdən uzun native əmrdə ilişibsə (donmuş yayımda stop() bloklanır) pleyer yenilənir.
        private const val WEDGE_MS = 2_500L
        private const val RECOVERY_DETACH_WAIT_MS = 3_000L
        // Açılış gec gedir, amma bufer/hadisə irəliləyişi var: pleyer dəyişmədən bu qədər əlavə gözlənilir.
        private const val EXTEND_MAX_MS = 10_000L
    }

    private val appContext = context.applicationContext
    private val ui = Handler(Looper.getMainLooper())

    // Native əməliyyatlar yalnız bu thread-də.
    @Volatile private var workerThread = HandlerThread("vlc-ctl").apply { start() }
    @Volatile private var worker = Handler(workerThread.looper)
    // Worker-də native əmr (stop/play) şəbəkə donması səbəbindən ilişə bilər. Belə olanda worker + pleyer atılıb yenisi yaradılır.
    // epoch: köhnə worker-in gec qayıdan əmrləri yeni pleyerə toxunmasın deyə yoxlanılır.
    @Volatile private var epoch = 0
    @Volatile private var busySince = 0L
    @Volatile private var recovering = false
    private var workerSeq = 0

    /** Əmri worker-də icra edir; işləmə müddəti izlənir (ilişmə aşkarı üçün). Köhnə epoch-un əmri atılır. */
    private fun post(block: () -> Unit) {
        val ep = epoch
        worker.post {
            if (ep != epoch) return@post
            busySince = SystemClock.elapsedRealtime()
            try { block() } finally { if (ep == epoch) busySince = 0L }
        }
    }

    // libVlc/player yalnız worker-də yaradılır və boşaldılır; əsas thread yalnız oxuyur (runCatching ilə).
    @Volatile private var libVlc: LibVLC? = null
    @Volatile private var player: MediaPlayer? = null
    // vlcVout Java obyektidir (kilid tutmur); əsas thread səthi qoşub-ayırmaq üçün onu birbaşa istifadə edir.
    @Volatile private var vout: IVLCVout? = null
    // Hadisələrdən/worker-dən yığılan keş: əsas thread yalnız bunları oxuyur.
    @Volatile private var lastTimeMs = -1L
    @Volatile private var cachedBitrate = 0L
    @Volatile private var statsPending = false
    private var initFailures = 0
    @Volatile private var released = false

    private var surfaceAvailable = false
    private var viewsAttached = false
    private var wantsSurface = false
    private var url: String? = null
    private var userAgent: String? = null
    private var referer: String? = null
    @Volatile private var generation = 0
    // Bu generation üçün start əmri artıq verilib (səth + play ikiqat başlatmasın).
    private var startedGen = -1
    // Yalnız bu generation-a aid hadisələr qəbul edilir (-1 = hələ yeni media başlamayıb, hamısı ignor).
    private var acceptToken = -1
    private var playing = false
    private var pausedByUser = false
    private var buffering = false
    private var lastBufferingAt = 0L
    private var videoWidth = 0
    private var videoHeight = 0
    private var surfaceW = 0
    private var surfaceH = 0
    private var openTimeout: Runnable? = null
    private var openStartAt = 0L
    private var lastProgressAt = 0L
    private var timeoutMs = OPEN_TIMEOUT_MS
    private val speed = SpeedMeter()

    init {
        view.holder.addCallback(this)
    }

    // ---------- Worker: libVLC yaratma / boşaltma ----------
    private fun createOnWorker(): MediaPlayer? {
        player?.let { return it }
        if (released || initFailures >= MAX_INIT_FAILURES) return null
        return try {
            // 2 GB RAM TV box üçün sıfırdan seçilmiş libVLC parametrləri:
            val options = arrayListOf(
                // şəbəkə buferi + qırılanda təkrar qoşulma
                "--network-caching=$NETWORK_CACHING_MS",
                "--live-caching=$NETWORK_CACHING_MS",
                "--file-caching=1000",
                "--http-reconnect",
                "--rtsp-tcp",
                // adaptiv (HLS/DASH) yayımda 1080p-dən yuxarı variant seçilmir
                "--adaptive-maxwidth=1920",
                "--adaptive-maxheight=1080",
                // dekoder: HW əsas (media.setHWDecoderEnabled), SW ehtiyatda 2 thread, loop filter yüngülləşdirilib
                "--avcodec-threads=2",
                "--avcodec-skiploopfilter=1",
                // CPU/RAM qənaəti: deinterlace, altyazı, OSD, statistika söndürülüb.
                "--deinterlace=0",
                "--no-spu",
                "--no-sub-autodetect-file",
                "--no-osd",
                "--no-stats",
                "--no-video-title-show",
                "--no-snapshot-preview",
                // səs: time-stretch yoxdur (CPU), gec qalan kadrlar atılır
                "--no-audio-time-stretch",
                "--drop-late-frames",
                "--skip-frames"
            )
            val lib = LibVLC(appContext, options)
            val mp = MediaPlayer(lib)
            mp.setEventListener { ev -> onVlcEvent(ev) }
            libVlc = lib
            player = mp
            vout = mp.vlcVout
            mp
        } catch (t: Throwable) {
            android.util.Log.e("IPTV-VLC", "VLC başladılmadı", t)
            initFailures++
            player = null
            libVlc = null
            vout = null
            null
        }
    }

    /** Yalnız worker-də: player və libVLC ardıcıl boşaldılır. */
    private fun releaseOnWorker() {
        val mp = player
        val lib = libVlc
        player = null
        libVlc = null
        vout = null
        if (mp != null) {
            runCatching { mp.setEventListener(null) }
            runCatching { mp.stop() }
            runCatching { mp.release() }
        }
        runCatching { lib?.release() }
    }

    /** VLC-ni yaddaşdan tam boşaldır (lazım olsa yenidən yaradılacaq). */
    fun unload() {
        if (released || player == null) return
        stop()
        detachViews()
        post { releaseOnWorker() }
    }

    // ---------- VLC hadisələri (istənilən thread-dən gələ bilər) ----------
    private fun runOnUi(block: () -> Unit) {
        if (Looper.myLooper() === Looper.getMainLooper()) block() else ui.post { block() }
    }

    private fun onVlcEvent(ev: MediaPlayer.Event) {
        val type = ev.type
        val bufferPct = if (type == MediaPlayer.Event.Buffering) ev.buffering else 100f
        val timeMs = if (type == MediaPlayer.Event.TimeChanged) ev.timeChanged else -1L
        runOnUi {
            val g = generation
            if (released || acceptToken != g || url == null) return@runOnUi
            when (type) {
                MediaPlayer.Event.Opening -> { lastProgressAt = SystemClock.elapsedRealtime() }
                MediaPlayer.Event.Playing, MediaPlayer.Event.Vout, MediaPlayer.Event.ESAdded -> {
                    lastProgressAt = SystemClock.elapsedRealtime()
                    markPlaying(g)
                    applyStretch()
                }
                // Oynama başlayıb, amma Playing hadisəsi itibsə: vaxt irəliləyirsə yüklənmə ekranı bağlanır.
                MediaPlayer.Event.TimeChanged -> {
                    if (timeMs >= 0) lastTimeMs = timeMs
                    if (!playing) markPlaying(g)
                }
                MediaPlayer.Event.Buffering -> {
                    val active = bufferPct < 100f
                    if (bufferPct > 0f) lastProgressAt = SystemClock.elapsedRealtime()
                    buffering = active
                    if (active) lastBufferingAt = SystemClock.elapsedRealtime()
                    if (playing) callback.onBuffering(active)
                }
                MediaPlayer.Event.EncounteredError -> failNow(g, "Yayım açıla bilmədi")
                MediaPlayer.Event.EndReached -> if (playing) {
                    playing = false
                    buffering = false
                    callback.onFailed("Yayım dayandı")
                }
                else -> Unit
            }
        }
    }

    // ---------- Surface ----------
    override fun surfaceCreated(holder: SurfaceHolder) {
        surfaceAvailable = true
        if (released) return
        attachViewsIfNeeded()
        if (url != null && !playing) tryStart(generation)
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        surfaceW = width
        surfaceH = height
        val v = vout ?: return
        if (!released && viewsAttached) {
            runCatching { v.setWindowSize(width, height) }
            applyStretch()
        }
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        surfaceAvailable = false
        if (!playing) startedGen = -1 // səth qayıdanda yükləmə təzədən başlasın
        detachViews()
    }

    /** Stretch: nisbət səthə bərabər edilir. MediaPlayer çağırışı worker-də icra olunur (əsas thread bloklanmasın). */
    private fun applyStretch() {
        val w = surfaceW
        val h = surfaceH
        post {
            val mp = player ?: return@post
            runCatching {
                if (w > 0 && h > 0) {
                    mp.setAspectRatio("$w:$h")
                    mp.setScale(0f)
                } else {
                    mp.videoScale = MediaPlayer.ScaleType.SURFACE_FILL
                }
            }
        }
    }

    private fun attachViewsIfNeeded() {
        val v = vout ?: return
        if (released || recovering || !wantsSurface || !surfaceAvailable || viewsAttached) return
        try {
            if (!v.areViewsAttached()) {
                // detachViews()-dan sonra video səthi sıfırlanır; hər qoşulmadan əvvəl yenidən verilməlidir.
                v.setVideoView(view)
                v.attachViews()
            }
            viewsAttached = true
            if (surfaceW > 0 && surfaceH > 0) v.setWindowSize(surfaceW, surfaceH)
            applyStretch()
        } catch (t: Throwable) {
            android.util.Log.e("IPTV-VLC", "Video səthi qoşula bilmədi", t)
            failNow(generation, "Video səthi qoşula bilmədi")
        }
    }

    private fun detachViews() {
        val v = vout
        if (v != null && viewsAttached) {
            runCatching { if (v.areViewsAttached()) v.detachViews() }
        }
        viewsAttached = false
    }

    fun attach() {
        if (released) return
        wantsSurface = true
        if (surfaceAvailable) attachViewsIfNeeded()
    }

    // ---------- Oynatma ----------
    fun play(
        newUrl: String, ua: String? = null, ref: String? = null,
        openTimeoutMs: Long = OPEN_TIMEOUT_MS
    ) {
        if (released) return
        generation++
        val g = generation
        timeoutMs = openTimeoutMs
        url = newUrl
        userAgent = ua
        referer = ref
        playing = false
        pausedByUser = false
        buffering = false
        videoWidth = 0
        videoHeight = 0
        acceptToken = -1
        startedGen = -1
        lastTimeMs = -1L
        cachedBitrate = 0L
        openStartAt = SystemClock.elapsedRealtime()
        lastProgressAt = 0L
        speed.reset()
        callback.onLoading()
        // Səth/libVLC hazır olmasa belə "sonsuz yükləmə" olmasın.
        armTimeout(g, openTimeoutMs + SURFACE_WAIT_MS)

        post {
            if (g != generation || released) return@post
            val ok = createOnWorker() != null
            ui.post {
                if (released || g != generation) return@post
                if (ok) tryStart(g)
                else failNow(g, "VLC işə salına bilmədi. Kitabxana və cihaz uyğunluğunu yoxlayın.")
            }
        }
        ui.postDelayed({ checkWedge(g, 0) }, 700L)
    }

    /** Əsas thread: yayım açılmayıb və worker uzun müddətdir native əmrdə ilişibsə, pleyer yenilənir. */
    private fun checkWedge(g: Int, attempt: Int) {
        if (released || g != generation || playing || url == null || recovering) return
        val since = busySince
        if (since == 0L || SystemClock.elapsedRealtime() - since < WEDGE_MS - 300L) {
            // İlk yoxlama çox tez baş veribsə, ilişmə aşkarlanmasını yenidən yoxla.
            ui.postDelayed({ checkWedge(g, attempt) }, 700L)
            return
        }
        if (attempt >= 2) return
        recoverWedged(attempt)
    }

    /**
     * Worker ilişib (adətən donmuş şəbəkədə mp.stop() bloklanır, sonrakı kanallar da növbədə qalır).
     * Köhnə worker/pleyer ayrıca thread-də boşaldılır (əsas thread heç vaxt gözləmir), yeni worker və pleyer yaradılır.
     */
    private fun recoverWedged(attempt: Int) {
        android.util.Log.w("IPTV-VLC", "Worker ilişib: VLC pleyeri yenilənir (cəhd ${attempt + 1})")
        val oldThread = workerThread
        val oldPlayer = player
        val oldLib = libVlc
        val oldVout = vout
        val wasAttached = viewsAttached
        epoch++
        busySince = 0L
        recovering = true
        player = null
        libVlc = null
        vout = null
        viewsAttached = false
        startedGen = -1
        workerThread = HandlerThread("vlc-ctl-${++workerSeq}").apply { start() }
        worker = Handler(workerThread.looper)
        // Səth ayrılana qədər (maks. RECOVERY_DETACH_WAIT_MS) gözlənilir, sonra davam edilir.
        ui.postDelayed({ finishRecovery(attempt) }, RECOVERY_DETACH_WAIT_MS)
        Thread({
            runCatching { oldPlayer?.setEventListener(null) }
            if (wasAttached) runCatching { if (oldVout != null && oldVout.areViewsAttached()) oldVout.detachViews() }
            ui.post { finishRecovery(attempt) }
            // Bunlar ilişmiş şəbəkə əməli qurtarana qədər bloklana bilər; yalnız bu thread gözləyir.
            runCatching { oldPlayer?.stop() }
            runCatching { oldPlayer?.release() }
            runCatching { oldLib?.release() }
            runCatching { oldThread.quitSafely() }
        }, "vlc-reaper").apply { isDaemon = true }.start()
    }

    private fun finishRecovery(attempt: Int) {
        if (!recovering) return
        recovering = false
        if (released) return
        val g = generation
        if (url == null || playing) return
        post {
            val ok = createOnWorker() != null
            ui.post {
                if (released || g != generation) return@post
                if (ok) { tryStart(g); ui.postDelayed({ checkWedge(g, attempt + 1) }, 700L) }
                else failNow(g, "VLC işə salına bilmədi. Kitabxana və cihaz uyğunluğunu yoxlayın.")
            }
        }
    }

    /** Əsas thread: səth hazırdırsa start əmrini worker-ə verir. */
    private fun tryStart(g: Int) {
        if (released || g != generation || !wantsSurface) return
        val u = url ?: return
        if (player == null || !surfaceAvailable) return // səth yaranınca surfaceCreated yenidən çağıracaq
        attachViewsIfNeeded()
        if (!viewsAttached || startedGen == g) return
        startedGen = g
        val ua = userAgent
        val rf = referer
        post { startOnWorker(g, u, ua, rf) }
    }

    /** Yalnız worker-də. */
    private fun startOnWorker(g: Int, u: String, ua: String?, rf: String?) {
        if (g != generation || released) return
        val mp = player ?: return
        val lib = libVlc ?: return
        try {
            // Əvvəlki yayım tam dayansın (yeni media dayanmamış pleyerə verilmir).
            runCatching { mp.stop() }
            // stop() uzun çəkibsə və bu arada başqa kanal seçilibsə, bu köhnəlmiş istək atılır.
            if (g != generation || released) return

            val media = Media(lib, Uri.parse(u))
            media.setHWDecoderEnabled(true, false)
            media.addOption(":network-caching=$NETWORK_CACHING_MS")
            media.addOption(":live-caching=$NETWORK_CACHING_MS")
            ua?.takeIf { it.isNotBlank() }?.let { media.addOption(":http-user-agent=$it") }
            rf?.takeIf { it.isNotBlank() }?.let { media.addOption(":http-referrer=$it") }
            mp.media = media
            media.release()
            mp.play()

            ui.post {
                if (released || g != generation) return@post
                acceptToken = g              // bu andan yeni mediaya aid hadisələr qəbul edilir
                openStartAt = SystemClock.elapsedRealtime()
                armTimeout(g, timeoutMs)     // vaxt aşımı həqiqi başlanğıcdan sayılır
                applyStretch()
            }
        } catch (t: Throwable) {
            android.util.Log.e("IPTV-VLC", "Yayım açıla bilmədi", t)
            ui.post { failNow(g, "VLC yayımı aça bilmədi") }
        }
    }

    private fun armTimeout(g: Int, ms: Long) {
        openTimeout?.let { ui.removeCallbacks(it) }
        val r = Runnable {
            openTimeout = null
            if (released || g != generation || playing || url == null) return@Runnable
            // Gec yüklənir, amma irəliləyiş var (Opening/Buffering): pleyer dəyişmədən məhdud müddət əlavə gözlə.
            val nowMs = SystemClock.elapsedRealtime()
            if (nowMs - lastProgressAt < 4_000L && nowMs - openStartAt < timeoutMs + EXTEND_MAX_MS) {
                armTimeout(g, 3_000L)
                return@Runnable
            }
            // Hadisə itibsə də yayım əslində gedirsə uğursuz sayılmır. Yoxlama worker-dədir; worker bloklanıbsa
            // (şəbəkə) cavab gəlməz — onda 1,5 s sonra kanal uğursuz sayılır. Əsas thread heç vaxt gözləmir.
            var answered = false
            post {
                val mp = player
                val really = mp != null && runCatching { mp.isPlaying && mp.time > 0 }.getOrDefault(false)
                ui.post {
                    if (answered) return@post
                    answered = true
                    if (released || g != generation || playing) return@post
                    if (really) { acceptToken = g; markPlaying(g) } else timeoutFail(g)
                }
            }
            ui.postDelayed({
                if (answered) return@postDelayed
                answered = true
                if (released || g != generation || playing) return@postDelayed
                timeoutFail(g)
            }, 1_500L)
        }
        openTimeout = r
        ui.postDelayed(r, ms)
    }

    private fun timeoutFail(g: Int) {
        if (released || g != generation || playing) return
        haltState()
        val stopGen = generation
        post {
            if (stopGen == generation && !released) player?.let { runCatching { it.stop() } }
        }
        callback.onFailed("VLC ${timeoutMs / 1_000L} saniyə ərzində açmadı")
    }

    private fun markPlaying(expectedGeneration: Int) {
        if (released || expectedGeneration != generation || url == null) return
        if (!playing) {
            playing = true
            openTimeout?.let { ui.removeCallbacks(it) }
            openTimeout = null
            val g = generation
            applyStretch()
            // Video çıxışı gec hazır olarsa, nisbət yenidən tətbiq olunur.
            for (d in longArrayOf(500L, 1_500L, 3_000L)) {
                ui.postDelayed({
                    if (!released && g == generation && playing) applyStretch()
                }, d)
            }
            callback.onPlaying()
            if (buffering) callback.onBuffering(true)
        }
    }

    private fun failNow(expectedGeneration: Int, message: String) {
        if (released || expectedGeneration != generation) return
        openTimeout?.let { ui.removeCallbacks(it) }
        openTimeout = null
        callback.onFailed(message)
    }

    fun stats(): PlayerStats? {
        if (released || !playing || player == null) return null
        val now = SystemClock.elapsedRealtime()
        // Trek məlumatı worker-də oxunub keşlənir; əsas thread MediaPlayer-ə toxunmur (bloklanma/donma olmasın).
        if (!statsPending) {
            statsPending = true
            post {
                try {
                    val mp = player
                    if (mp != null) runCatching {
                        val track = mp.currentVideoTrack
                        if (track != null && track.width > 0 && track.height > 0) {
                            videoWidth = track.width
                            videoHeight = track.height
                        }
                        cachedBitrate = if (track != null && track.bitrate > 0) track.bitrate.toLong() else 0L
                    }
                } finally {
                    statsPending = false
                }
            }
        }
        val level = when {
            buffering -> 2
            now - lastBufferingAt < 12_000L -> 1
            else -> 0
        }
        val bps = speed.sample(uidRxBytes(), now)
        // Bitrate: trekdə bildirilən dəyər; canlı yayımda çox vaxt 0-dır, onda son ~5 s-in orta sürəti götürülür.
        val tb = cachedBitrate
        val br = if (tb > 0) tb else bps
        return PlayerStats(videoWidth, videoHeight, -1L, level, bps, "", br)
    }

    /** Oynatma mövqeyi (ms): TimeChanged hadisələrindən keşlənir; MediaPlayer-ə toxunulmur. */
    fun position(): Long = lastTimeMs

    fun togglePause() {
        val mp = player ?: return
        if (released || !playing) return
        pausedByUser = !pausedByUser
        val pause = pausedByUser
        post { runCatching { if (pause) mp.pause() else mp.play() } }
    }

    /** Əsas thread vəziyyətini sıfırlayır və bütün gözləyən əmrləri/hadisələri köhnəlmiş edir. */
    private fun haltState() {
        generation++
        openTimeout?.let { ui.removeCallbacks(it) }
        openTimeout = null
        url = null
        playing = false
        buffering = false
        pausedByUser = false
        acceptToken = -1
        startedGen = -1
        lastTimeMs = -1L
    }

    /** Oynatmanı tam dayandırır (səth qoşulu qalır). Native stop worker-də icra olunur. */
    fun stop() {
        if (released) return
        haltState()
        val g = generation
        post {
            // Arxasınca yeni play() gəlibsə, o özü stop edəcək — bu əmr atlanır.
            if (g != generation || released) return@post
            player?.let { runCatching { it.stop() } }
        }
    }

    fun stopForBackground() {
        if (released) return
        wantsSurface = false
        stop()
        detachViews()
    }

    fun release() {
        if (released) return
        released = true
        generation++
        openTimeout?.let { ui.removeCallbacks(it) }
        openTimeout = null
        view.holder.removeCallback(this)
        detachViews()
        worker.post {
            releaseOnWorker()
            workerThread.quitSafely()
        }
    }
}
