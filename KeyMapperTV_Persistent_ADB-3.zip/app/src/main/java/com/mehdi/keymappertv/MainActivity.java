package com.mehdi.keymappertv;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(16, 24, 32);
    private static final int PANEL = Color.rgb(27, 42, 52);
    private static final int TEXT = Color.rgb(245, 248, 250);
    private static final int MUTED = Color.rgb(180, 196, 204);
    private static final int ACCENT = Color.rgb(128, 203, 196);

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService adbWorker = Executors.newSingleThreadExecutor();
    private LinearLayout root;
    private LinearLayout ruleContainer;
    private TextView statusText;
    private TextView serviceText;
    private TextView repeatValue;
    private Spinner appSpinner;
    private SeekBar repeatSeek;
    private List<MappingRule> rules;
    private List<AppChoice> appChoices;
    private int captureRow = -1;
    private Runnable captureTimeout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        if (!ConfigStore.prefs(this).contains(ConfigStore.KEY_RULES)) {
            ConfigStore.saveRules(this, ConfigStore.defaults());
        }
        rules = ConfigStore.loadRules(this);
        startKeepAliveService();
        buildUi();
        refreshStatuses();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (serviceText != null) refreshStatuses();
        startKeepAliveService();
    }

    @Override
    protected void onDestroy() {
        if (captureTimeout != null) handler.removeCallbacks(captureTimeout);
        ConfigStore.prefs(this).edit().putBoolean(ConfigStore.KEY_CAPTURE_MODE, false).apply();
        adbWorker.shutdownNow();
        super.onDestroy();
    }

    private void startKeepAliveService() {
        try {
            Intent i = new Intent(this, KeepAliveService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
        } catch (Exception ignored) { }
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(20), dp(22), dp(32));
        root.setBackgroundColor(BG);
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));
        setContentView(scroll);

        TextView title = text("KEY MAPPER TV", 29, TEXT, true);
        root.addView(title);
        TextView intro = text("Xiaomi TV Box • pult/gamepad düymələrinin xəritələnməsi", 16, MUTED, false);
        addGap(root, 5);
        root.addView(intro);

        addSection("XİDMƏT VƏ ADB");
        serviceText = text("Əlçatanlıq xidməti: yoxlanılır…", 17, MUTED, false);
        root.addView(serviceText);
        statusText = text("ADB: yoxlanılmayıb", 17, MUTED, false);
        addGap(root, 4);
        root.addView(statusText);

        LinearLayout topButtons = row();
        Button checkAdb = button("ADB bağlantısını yoxla");
        checkAdb.setOnClickListener(v -> testAdb());
        topButtons.addView(checkAdb, weighted());
        addGap(topButtons, 8);
        Button enableService = button("Əlçatanlığı aç");
        enableService.setOnClickListener(v -> {
            try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
            catch (Exception e) { toast("Əlçatanlıq ayarları açıla bilmədi."); }
        });
        topButtons.addView(enableService, weighted());
        root.addView(topButtons);

        TextView adbNote = text("Qeyd: USB debugging təkbaşına 5555 portunu açmır. ADB TCP/5555 aktiv olmalı və ilk dəfə cihazda RSA təsdiqi verilə bilər.", 14, MUTED, false);
        addGap(root, 7);
        root.addView(adbNote);

        addSection("UZUN BASMA İLƏ AÇILACAQ TƏTBİQ");
        TextView appHint = text("BUTTON_5 uzun basıldıqda aşağıdakı tətbiq açılır.", 15, MUTED, false);
        root.addView(appHint);
        appChoices = loadApps();
        List<String> appLabels = new ArrayList<>();
        for (AppChoice choice : appChoices) appLabels.add(choice.label);
        appSpinner = new Spinner(this);
        ArrayAdapter<String> appAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, appLabels);
        appAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        appSpinner.setAdapter(appAdapter);
        String savedPackage = ConfigStore.launchPackage(this);
        int selectedApp = 0;
        for (int i = 0; i < appChoices.size(); i++) if (appChoices.get(i).packageName.equals(savedPackage)) selectedApp = i;
        appSpinner.setSelection(selectedApp);
        appSpinner.setMinimumHeight(dp(52));
        appSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                if (position >= 0 && position < appChoices.size()) {
                    ConfigStore.prefs(MainActivity.this).edit().putString(ConfigStore.KEY_LAUNCH_PACKAGE, appChoices.get(position).packageName).apply();
                }
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        });
        root.addView(appSpinner, new LinearLayout.LayoutParams(-1, -2));

        addSection("TƏKRAR SÜRƏTİ");
        repeatValue = text("Basılı saxlandıqda təkrar intervalı: " + ConfigStore.repeatInterval(this) + " ms", 16, TEXT, false);
        root.addView(repeatValue);
        repeatSeek = new SeekBar(this);
        repeatSeek.setMax(230); // 20..250 ms
        repeatSeek.setProgress((int) ConfigStore.repeatInterval(this) - 20);
        repeatSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                long ms = 20L + progress;
                repeatValue.setText("Basılı saxlandıqda təkrar intervalı: " + ms + " ms");
                ConfigStore.prefs(MainActivity.this).edit().putLong(ConfigStore.KEY_REPEAT_MS, ms).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
        root.addView(repeatSeek);
        TextView repeatNote = text("Kiçik rəqəm daha sürətlidir. 0 ms mümkün deyil: Android və ADB əmrləri real vaxt planlaşdırılmasına tabedir.", 14, MUTED, false);
        root.addView(repeatNote);

        addSection("DÜYMƏ XƏRİTƏLƏRİ");
        TextView examples = text("Standart: BUTTON_7 (194) → DPAD_RIGHT (22); BUTTON_6 (193) → DPAD_LEFT (21); BUTTON_5 (192) → DPAD_CENTER (23).", 15, MUTED, false);
        root.addView(examples);
        TextView tableHint = text("Mənbə kodunu və hədəf kodunu dəyiş, fiziki düyməni ‘Tut’ ilə tanı, siyahının sırasını yuxarı/aşağı dəyiş.", 14, MUTED, false);
        addGap(root, 5);
        root.addView(tableHint);

        ruleContainer = new LinearLayout(this);
        ruleContainer.setOrientation(LinearLayout.VERTICAL);
        addGap(root, 8);
        root.addView(ruleContainer, new LinearLayout.LayoutParams(-1, -2));
        renderRules();

        LinearLayout controls = row();
        Button add = button("+ Düymə əlavə et");
        add.setOnClickListener(v -> {
            rules.add(new MappingRule(0, 23, MappingRule.SINGLE));
            renderRules();
        });
        controls.addView(add, weighted());
        addGap(controls, 8);
        Button save = button("Yadda saxla");
        save.setOnClickListener(v -> saveRulesAndShowToast());
        controls.addView(save, weighted());
        addGap(root, 12);
        root.addView(controls);

        Button saveAndRestart = button("Yadda saxla və xidməti yenilə");
        saveAndRestart.setOnClickListener(v -> {
            saveRulesAndShowToast();
            refreshStatuses();
            if (serviceText.getText().toString().contains("aktiv deyil")) {
                try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); } catch (Exception ignored) { }
            }
        });
        addGap(root, 8);
        root.addView(saveAndRestart);

        addSection("DÜYMƏ DAVRANIŞLARI");
        root.addView(text("• Basıldıqca təkrar: düyməni saxladıqda hədəf kodu ardıcıl göndərilir.\n• Bir klik: buraxıldıqda bir hədəf düyməsi göndərilir.\n• Tək/ikiqat/uzun: tək klik hədəf kodu; ikiqat klik uzun DPAD basması; uzun basma seçilmiş tətbiqi açır.", 15, TEXT, false));
        addGap(root, 10);
        root.addView(text("Vacib: Android düymə filtri üçün bu tətbiqin Əlçatanlıq xidmətini aktiv et. ADB/5555 işləmirsə, düymə əmrləri göndərilə bilməyəcək.", 14, MUTED, false));
    }

    private void renderRules() {
        if (ruleContainer == null) return;
        ruleContainer.removeAllViews();
        for (int index = 0; index < rules.size(); index++) {
            final int rowIndex = index;
            MappingRule rule = rules.get(index);
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12), dp(12), dp(12), dp(12));
            card.setBackgroundColor(PANEL);
            LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, -2);
            cardLp.bottomMargin = dp(10);
            ruleContainer.addView(card, cardLp);

            TextView heading = text("Xəritə #" + (index + 1), 17, ACCENT, true);
            card.addView(heading);
            LinearLayout codeRow = row();
            EditText source = numberInput(String.valueOf(rule.sourceKeyCode), "Mənbə kodu");
            EditText target = numberInput(String.valueOf(rule.targetKeyCode), "Hədəf kodu");
            source.setHint("Mənbə");
            target.setHint("Hədəf");
            source.addTextChangedListener(watcher(value -> rules.get(rowIndex).sourceKeyCode = parseCode(value, 0)));
            target.addTextChangedListener(watcher(value -> rules.get(rowIndex).targetKeyCode = parseCode(value, 23)));
            codeRow.addView(source, weighted());
            addGap(codeRow, 8);
            codeRow.addView(target, weighted());
            addGap(card, 8);
            card.addView(codeRow);

            LinearLayout quick = row();
            String[] qLabels = {"Mənbə=GERİ", "Mənbə=HOME", "Hədəf=GERİ", "Hədəf=HOME"};
            for (int q = 0; q < 4; q++) {
                final int qi = q;
                Button b = button(qLabels[q]);
                b.setTextSize(12);
                b.setOnClickListener(v -> {
                    if (rowIndex >= rules.size()) return;
                    MappingRule r = rules.get(rowIndex);
                    if (qi == 0) r.sourceKeyCode = KeyEvent.KEYCODE_BACK;
                    else if (qi == 1) r.sourceKeyCode = KeyEvent.KEYCODE_HOME;
                    else if (qi == 2) r.targetKeyCode = KeyEvent.KEYCODE_BACK;
                    else r.targetKeyCode = KeyEvent.KEYCODE_HOME;
                    renderRules();
                });
                quick.addView(b, weighted());
                if (q < 3) addGap(quick, 4);
            }
            addGap(card, 7);
            card.addView(quick);

            LinearLayout actions = row();
            Button capture = button("Tut");
            capture.setOnClickListener(v -> beginCapture(rowIndex));
            actions.addView(capture, new LinearLayout.LayoutParams(0, dp(48), 0.7f));
            addGap(actions, 5);
            Spinner mode = new Spinner(this);
            List<String> modeLabels = new ArrayList<>();
            modeLabels.add("Basılı saxla → təkrar");
            modeLabels.add("Tək klik");
            modeLabels.add("Tək/ikiqat/uzun");
            ArrayAdapter<String> modeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, modeLabels);
            modeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            mode.setAdapter(modeAdapter);
            int selected = MappingRule.REPEAT.equals(rule.mode) ? 0 : MappingRule.MULTI.equals(rule.mode) ? 2 : 1;
            mode.setSelection(selected);
            mode.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
                @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                    if (rowIndex >= rules.size()) return;
                    rules.get(rowIndex).mode = position == 0 ? MappingRule.REPEAT : position == 2 ? MappingRule.MULTI : MappingRule.SINGLE;
                }
                @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
            });
            actions.addView(mode, new LinearLayout.LayoutParams(0, dp(48), 2.1f));
            addGap(card, 7);
            card.addView(actions);

            LinearLayout order = row();
            Button up = button("↑ Yuxarı");
            up.setOnClickListener(v -> moveRule(rowIndex, -1));
            order.addView(up, weighted());
            addGap(order, 5);
            Button down = button("↓ Aşağı");
            down.setOnClickListener(v -> moveRule(rowIndex, 1));
            order.addView(down, weighted());
            addGap(order, 5);
            Button remove = button("Sil");
            remove.setOnClickListener(v -> {
                if (rowIndex < rules.size()) { rules.remove(rowIndex); renderRules(); }
            });
            order.addView(remove, weighted());
            addGap(card, 7);
            card.addView(order);
        }
    }

    private void beginCapture(int row) {
        captureRow = row;
        ConfigStore.prefs(this).edit().putBoolean(ConfigStore.KEY_CAPTURE_MODE, true).apply();
        statusText.setText("Düymə tutma aktivdir: indi pult/gamepad düyməsini bas…");
        if (captureTimeout != null) handler.removeCallbacks(captureTimeout);
        captureTimeout = () -> {
            if (captureRow >= 0) {
                captureRow = -1;
                ConfigStore.prefs(this).edit().putBoolean(ConfigStore.KEY_CAPTURE_MODE, false).apply();
                statusText.setText("Düymə tutma vaxtı bitdi. Yenidən ‘Tut’ seç.");
            }
        };
        handler.postDelayed(captureTimeout, 10000L);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (captureRow >= 0 && event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) {
            int code = event.getKeyCode();
            if (code != KeyEvent.KEYCODE_POWER && code != KeyEvent.KEYCODE_UNKNOWN) {
                if (captureRow < rules.size()) {
                    rules.get(captureRow).sourceKeyCode = code;
                    int captured = code;
                    captureRow = -1;
                    ConfigStore.prefs(this).edit().putBoolean(ConfigStore.KEY_CAPTURE_MODE, false).apply();
                    if (captureTimeout != null) handler.removeCallbacks(captureTimeout);
                    ConfigStore.saveRules(this, rules);
                    renderRules();
                    statusText.setText("Düymə tutuldu: " + KeyEvent.keyCodeToString(captured) + " = " + captured);
                }
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    private void moveRule(int index, int direction) {
        int next = index + direction;
        if (index < 0 || index >= rules.size() || next < 0 || next >= rules.size()) return;
        Collections.swap(rules, index, next);
        renderRules();
    }

    private void saveRulesAndShowToast() {
        ConfigStore.saveRules(this, rules);
        ConfigStore.prefs(this).edit().putBoolean(ConfigStore.KEY_CAPTURE_MODE, false).apply();
        toast("Düymə xəritələri yadda saxlanıldı.");
    }

    private void testAdb() {
        statusText.setText("ADB yoxlanılır: localhost:5555, sonra cihazın IP-si:5555…");
        adbWorker.execute(() -> {
            AdbShellClient client = null;
            String result;
            try {
                client = AdbShellClient.connect(getApplicationContext());
                client.sendLineForStatus("echo KEYMAPPER_TV_OK");
                result = "ADB: qoşuldu (TCP/5555).";
            } catch (Exception e) {
                result = "ADB: qoşulmadı. TCP/5555 aktiv olmalıdır; səbəb: " + safeMessage(e);
            } finally {
                if (client != null) client.close();
            }
            final String finalResult = result;
            runOnUiThread(() -> statusText.setText(finalResult));
        });
    }

    private String safeMessage(Exception e) {
        String m = e.getMessage();
        return (m == null || m.trim().isEmpty()) ? e.getClass().getSimpleName() : m;
    }

    private void refreshStatuses() {
        boolean enabled = isAccessibilityEnabled(this, KeyMapAccessibilityService.class);
        serviceText.setText(enabled ? "Əlçatanlıq xidməti: aktivdir" : "Əlçatanlıq xidməti: aktiv deyil — ayarlardan aç");
        serviceText.setTextColor(enabled ? ACCENT : Color.rgb(255, 193, 120));
    }

    static boolean isAccessibilityEnabled(Context context, Class<?> serviceClass) {
        String enabled = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        String target = new ComponentName(context, serviceClass).flattenToString();
        for (String item : enabled.split(":")) if (item.equalsIgnoreCase(target)) return true;
        return false;
    }

    private List<AppChoice> loadApps() {
        List<AppChoice> choices = new ArrayList<>();
        choices.add(new AppChoice("— Tətbiq seçilməyib —", ""));
        PackageManager pm = getPackageManager();
        try {
            for (ApplicationInfo info : pm.getInstalledApplications(PackageManager.GET_META_DATA)) {
                String packageName = info.packageName;
                if (getPackageName().equals(packageName)) continue;
                Intent launch = pm.getLaunchIntentForPackage(packageName);
                if (launch == null) continue;
                String label;
                try { label = pm.getApplicationLabel(info).toString(); }
                catch (Exception e) { label = packageName; }
                choices.add(new AppChoice(label + "  ·  " + packageName, packageName));
            }
        } catch (Exception ignored) { }
        if (choices.size() > 1) {
            List<AppChoice> rest = new ArrayList<>(choices.subList(1, choices.size()));
            rest.sort(Comparator.comparing(a -> a.label.toLowerCase()));
            choices.subList(1, choices.size()).clear();
            choices.addAll(rest);
        }
        return choices;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(android.view.Gravity.CENTER_VERTICAL);
        return l;
    }

    private void addSection(String text) {
        TextView t = text(text, 18, ACCENT, true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(22);
        lp.bottomMargin = dp(8);
        root.addView(t, lp);
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(0, dp(3), 0, dp(3));
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setMinHeight(dp(48));
        b.setPadding(dp(9), dp(6), dp(9), dp(6));
        return b;
    }

    private EditText numberInput(String value, String hint) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setText(value);
        e.setHint(hint);
        e.setTextSize(17);
        e.setSelectAllOnFocus(true);
        e.setPadding(dp(8), 0, dp(8), 0);
        e.setMinHeight(dp(48));
        return e;
    }

    private TextWatcher watcher(java.util.function.Consumer<String> consumer) {
        return new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { consumer.accept(s.toString()); }
            @Override public void afterTextChanged(Editable s) { }
        };
    }

    private int parseCode(String text, int fallback) {
        try { return Math.max(0, Math.min(1000, Integer.parseInt(text.trim()))); }
        catch (Exception e) { return fallback; }
    }

    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(0, dp(48), 1f);
    }

    private void addGap(LinearLayout parent, int dp) {
        View gap = new View(this);
        if (parent.getOrientation() == LinearLayout.HORIZONTAL) {
            parent.addView(gap, new LinearLayout.LayoutParams(this.dp(dp), 1));
        } else {
            parent.addView(gap, new LinearLayout.LayoutParams(1, this.dp(dp)));
        }
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }

    private static final class AppChoice {
        final String label, packageName;
        AppChoice(String label, String packageName) { this.label = label; this.packageName = packageName; }
    }
}
