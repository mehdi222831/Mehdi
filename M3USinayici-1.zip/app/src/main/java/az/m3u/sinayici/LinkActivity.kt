package az.m3u.sinayici

import android.app.Activity
import android.app.ActivityManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle

/**
 * Brauzer rolu: başqa tətbiqdən gələn http(s) linki.
 * - .m3u8 / .m3u / .ts linki → əvvəlki məntiq (yayımdırsa playerdə, siyahıdırsa playlist kimi).
 * - Adi sayt → daxili (Mini) brauzerdə açılır; səhifədəki m3u8 linkləri 📡 ilə tapılıb playerdə oynadılır.
 */
class LinkActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val i = intent
        if (i?.action == Intent.ACTION_SEND) {
            // "Paylaş" menyusundan: mətndəki ilk http(s) linki tapılır
            val txt = i.getStringExtra(Intent.EXTRA_TEXT) ?: ""
            val link = Regex("https?://[^\\s<>\"']+").find(txt)?.value?.trimEnd(')', ',', '.', ';', ']', '}')
            if (link != null) route(link)
            else if (i.hasExtra(Intent.EXTRA_STREAM)) {
                // mətn deyil, fayl paylaşılıb → əsas ekran (M3U faylı kimi oxunur)
                startActivity(Intent(i).setComponent(android.content.ComponentName(this, MainActivity::class.java)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } else android.widget.Toast.makeText(this, "Paylaşılan mətndə link tapılmadı", android.widget.Toast.LENGTH_LONG).show()
            finish(); return
        }
        val u = i?.data
        if (u != null && (u.scheme == "http" || u.scheme == "https")) route(u.toString())
        finish()
    }

    private fun route(url: String) {
        val path = url.substringBefore('?').substringBefore('#').lowercase()
        val ext = path.substringAfterLast('.', "")
        val media = ext == "m3u8" || ext == "m3u" || ext == "ts" || url.lowercase().contains(".m3u8")
        if (media) {
            startActivity(Intent(this, MainActivity::class.java).setAction(Intent.ACTION_VIEW)
                .setData(Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        if (MiniBrowser.load(url)) {
            try { (getSystemService(ACTIVITY_SERVICE) as ActivityManager).moveTaskToFront(MiniBrowser.taskId(), 0) } catch (e: Exception) { }
            return
        }
        startActivity(Intent(this, BrowserActivity::class.java)
            .putExtra("mini", true).putExtra("start", url).putExtra("external", true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
