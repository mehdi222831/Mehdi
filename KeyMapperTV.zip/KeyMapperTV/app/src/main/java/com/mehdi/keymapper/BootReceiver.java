package com.mehdi.keymapper;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            Store.reload(context);
        } catch (Throwable ignored) {
        }
        KeepAliveService.start(context);
    }
}
