package az.keymapper;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.Cipher;

final class AdbKey {
    private static final byte[] SHA1_PREFIX = {0x30, 0x21, 0x30, 0x09, 0x06, 0x05, 0x2b, 0x0e,
            0x03, 0x02, 0x1a, 0x05, 0x00, 0x04, 0x14};
    private static AdbKey inst;

    private final PrivateKey priv;
    private final RSAPublicKey pub;

    private AdbKey(PrivateKey priv, RSAPublicKey pub) {
        this.priv = priv;
        this.pub = pub;
    }

    static synchronized AdbKey get(Context c) throws Exception {
        if (inst != null) return inst;
        SharedPreferences p = c.getSharedPreferences("km_adb", Context.MODE_PRIVATE);
        String s1 = p.getString("priv", null);
        String s2 = p.getString("pub", null);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        PrivateKey priv;
        RSAPublicKey pub;
        if (s1 != null && s2 != null) {
            priv = kf.generatePrivate(new PKCS8EncodedKeySpec(Base64.decode(s1, Base64.NO_WRAP)));
            pub = (RSAPublicKey) kf.generatePublic(new X509EncodedKeySpec(Base64.decode(s2, Base64.NO_WRAP)));
        } else {
            KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
            g.initialize(2048);
            KeyPair kp = g.generateKeyPair();
            priv = kp.getPrivate();
            pub = (RSAPublicKey) kp.getPublic();
            p.edit().putString("priv", Base64.encodeToString(priv.getEncoded(), Base64.NO_WRAP))
                    .putString("pub", Base64.encodeToString(pub.getEncoded(), Base64.NO_WRAP)).apply();
        }
        inst = new AdbKey(priv, pub);
        return inst;
    }

    byte[] sign(byte[] token) throws Exception {
        try {
            Signature s = Signature.getInstance("NONEwithRSA");
            s.initSign(priv);
            s.update(SHA1_PREFIX);
            s.update(token);
            return s.sign();
        } catch (Exception e) {
            Cipher c = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            c.init(Cipher.ENCRYPT_MODE, priv);
            c.update(SHA1_PREFIX);
            return c.doFinal(token);
        }
    }

    /** ADB-nin gözlədiyi "Android RSA public key" formatı. */
    byte[] androidPublicKey() throws Exception {
        BigInteger n = pub.getModulus();
        BigInteger r32 = BigInteger.ONE.shiftLeft(32);
        int n0inv = r32.subtract(n.mod(r32).modInverse(r32)).intValue();
        BigInteger rr = BigInteger.ONE.shiftLeft(4096).mod(n);
        ByteBuffer bb = ByteBuffer.allocate(4 + 4 + 256 + 256 + 4).order(ByteOrder.LITTLE_ENDIAN);
        bb.putInt(64);
        bb.putInt(n0inv);
        for (int i = 0; i < 64; i++) bb.putInt(n.shiftRight(32 * i).intValue());
        for (int i = 0; i < 64; i++) bb.putInt(rr.shiftRight(32 * i).intValue());
        bb.putInt(pub.getPublicExponent().intValue());
        String b64 = Base64.encodeToString(bb.array(), Base64.NO_WRAP);
        return (b64 + " keymapper@android\u0000").getBytes("UTF-8");
    }
}
