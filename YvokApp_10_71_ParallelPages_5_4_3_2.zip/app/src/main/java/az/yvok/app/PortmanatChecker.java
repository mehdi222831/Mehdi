package az.yvok.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Locale;

/**
 * Dördüncü yoxlama mənbəyi: portmanat.az (Bələdiyyə bölməsi).
 * HesabChecker ilə eyni qaydada işləyir: gizli səhifələr, növbə, callback-lər UI axınında çağırılır.
 * Müştəri adı -> Ad Soyad Ata adı; "Ödəniş üçün seçin" məbləği (AZN) -> Borc (mənfi dəyər 0 sayılır).
 */
public class PortmanatChecker {
    public interface Callback {
        void onResult(String name, String debt);
        void onFail();                                  // sayt cavab vermədi (açılmadı / vaxt bitdi)
        default void onNotFound() { onFail(); }         // sayt cavab verdi, lakin "tapılmadı" dedi (cavab verməməkdən fərqli)
    }

    private static final String URL = "https://portmanat.az/project/belediyye";
    private static final int FIRST_POLL_MS = 120;
    private static final int WARM_FIRST_POLL_MS = 30;   // səhifə əvvəlcədən açılıbsa ilk yoxlama dərhal
    private static final long WARM_STALE_MS = 15000;    // hazır səhifə bu qədər gözləyibsə "köhnə ola bilər" sayılır
    private static final long WARM_STALL_MS = 3000;     // köhnə ola bilən hazır səhifə bu müddətdə işə düşməsə bir dəfə təzələnir
    private static final int POLL_MS = 60;
    private static final int MAX_JOBS_PER_VIEW = 10;   // bu qədər sorğudan sonra gizli səhifə təzələnir

    private static class Req {
        final String code; final Callback cb; final long id;
        Req(String code, Callback cb, long id) { this.code = code; this.cb = cb; this.id = id; }
    }

    private class Slot {
        WebView wv; Req cur; int session = 0; int jobs = 0; long startedAt = 0; int nfHits = 0; long readyAt = 0;
        boolean pageReady = false, pageLoading = false;
        boolean suspect = false, reloaded = false;
        String lastSt = ""; int mmHits = 0;   // lastSt: səhifənin son vəziyyəti (diaqnostika); mmHits: səhifədə yad YVÖK görünən yoxlama sayı
    }

    private final Activity act;
    private final FrameLayout host;
    private final int index, width, height;
    private int maxParallel;
    private long maxWaitMs = 40000;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final ArrayDeque<Req> queue = new ArrayDeque<>();
    private long requestSequence = 0; // hər sorğuya unikal ID: eyni YVÖK təkrar yazılanda köhnə JS vəziyyəti işləməsin
    private final ArrayList<Slot> slots = new ArrayList<>();
    private final String js;
    private boolean destroyed = false;
    private volatile String lastReason = "";   // son uğursuzluğun səbəbi (jurnal / diaqnostika üçün)
    private boolean armed = false;     // YVÖK xanasına toxunuşdan sonra true: səhifələr arxada hazır saxlanılır

    public PortmanatChecker(Activity act, FrameLayout host, int index, int width, int height, int maxParallel) {
        this.act = act; this.host = host; this.index = index; this.width = width; this.height = height;
        this.maxParallel = Math.max(1, maxParallel);
        this.js = readAsset("portmanat.js");
    }

    private String readAsset(String name) {
        try (InputStream in = act.getAssets().open(name)) {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] b = new byte[4096]; int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            return bo.toString("UTF-8");
        } catch (Exception e) { return "''"; }
    }

    /** nəticə gözləmə həddi: bu müddətdə cavab gəlmirsə onFail() çağırılır */
    public void setMaxWait(long ms) { maxWaitMs = Math.max(5000, ms); }

    /** növbədə gözləyən + hazırda işləyən sorğu sayı (yük bölüşdürmək üçün) */
    public int load() {
        int n = queue.size();
        for (Slot s : slots) if (s.cur != null) n++;
        return n;
    }

    public void check(String code, Callback cb) {
        if (destroyed) { cb.onFail(); return; }
        queue.addLast(new Req(code, cb, ++requestSequence));
        pump();
    }

    /** növbəni və işləyənləri ləğv edir (callback çağırılmır) */
    public void clear() {
        queue.clear();
        for (Slot s : new ArrayList<>(slots)) {
            if (s.cur == null) continue;                    // boş (hazır) səhifəyə toxunulmur
            s.session++; s.cur = null; s.readyAt = 0; s.pageReady = false; s.pageLoading = false;
            // işlənmiş səhifə çirklidir: növbəti sorğuda yeni sənəd yüklənəcək
            try { s.wv.stopLoading(); s.wv.evaluateJavascript("window.__pS=null;", null); } catch (Exception ignored) { }
            if (armed) rewarm(s);                           // növbəti kod üçün arxada təzəsi hazırlanır
        }
    }

    /**
     * YVÖK xanasına toxunanda çağırılır. İlk toxunuşdan sonra rejim aktiv olur: səhifə öncədən yüklənir,
     * bağlanmır və vaxtla köhnəlmir; hər istifadədən sonra növbəti kod üçün arxada təzəsi yüklənir.
     */
    public void warmUp() {
        if (destroyed) return;
        armed = true;
        for (Slot x : slots) if (x.cur == null && (x.readyAt > 0 || x.pageLoading)) return;   // hazırdır və ya artıq yüklənir
        Slot s = null;
        for (Slot x : slots) if (x.cur == null) { s = x; break; }
        if (s == null) {
            if (slots.size() >= maxParallel) return;        // hamısı məşğuldur: iş bitəndə finish() təzəsini hazırlayacaq
            s = newSlot();
        }
        rewarm(s);
    }

    /** son uğursuzluğun səbəbi (onFail çağırılanda oxunur) */
    public String lastReason() { return lastReason; }

    /**
     * YVÖK xanasındakı rejim: maxParallel qədər səhifə öncədən açılıb hazır gözləyir, hər istifadədən sonra təzəsi
     * arxada yüklənir. Toplu yoxlama və Bələdiyyə Bazası da eyni rejimdə işləsin deyə yaradılanda çağırılır.
     */
    public void arm() {
        if (destroyed) return;
        armed = true;
        while (slots.size() < maxParallel) newSlot();
        for (Slot s : new ArrayList<>(slots)) if (s.cur == null && s.readyAt == 0) rewarm(s);
    }

    /** boş səhifəni saytın başlanğıcına yükləyib "hazır" işarələyir (gözləyir, bağlanmır) */
    private void rewarm(Slot s) {
        if (destroyed) return;
        if (s.jobs >= MAX_JOBS_PER_VIEW) {                  // köhnə səhifə yaddaşı doldurmasın: təzəsi ilə əvəz olunur
            slots.remove(s); destroyView(s);
            s = newSlot();
        }
        s.session++; s.cur = null; s.reloaded = false; s.suspect = false; s.mmHits = 0; s.lastSt = "";
        reloadPage(s);
    }

    public void destroy() {
        destroyed = true;
        queue.clear();
        h.removeCallbacksAndMessages(null);
        for (Slot s : slots) destroyView(s);
        slots.clear();
    }

    private void destroyView(Slot s) {
        try { s.wv.stopLoading(); host.removeView(s.wv); s.wv.destroy(); } catch (Exception ignored) { }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private Slot newSlot() {
        final Slot s = new Slot();
        WebView wv = new WebView(act);
        wv.setVisibility(android.view.View.INVISIBLE); // gizli yoxlama səhifəsi
        wv.setFocusable(false);
        wv.setFocusableInTouchMode(false);
        WebSettings settings = wv.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT); // WebView-in HTTP keş qaydasını saxla; API cavablarını zorla keşləmə
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        wv.getSettings().setLoadsImagesAutomatically(false);
        wv.getSettings().setBlockNetworkImage(true);
        wv.getSettings().setMediaPlaybackRequiresUserGesture(true);
        wv.getSettings().setSupportMultipleWindows(false);
        wv.getSettings().setGeolocationEnabled(false);
        wv.getSettings().setAllowFileAccess(false);
        wv.getSettings().setAllowContentAccess(false);
        wv.getSettings().setSaveFormData(false);
        wv.getSettings().setSupportZoom(false);
        wv.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        wv.getSettings().setMediaPlaybackRequiresUserGesture(true);
        wv.getSettings().setUseWideViewPort(true);
        wv.getSettings().setLoadWithOverviewMode(true);
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                if (view == s.wv && isPortmanatPage(url)) {
                    s.pageReady = false;
                    s.pageLoading = true;
                    s.readyAt = 0;
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (view == s.wv && isPortmanatPage(url)) {
                    s.pageReady = true;
                    s.pageLoading = false;
                    if (s.cur == null) s.readyAt = android.os.SystemClock.elapsedRealtime();
                }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (view == s.wv && request.isForMainFrame() && isPortmanatPage(request.getUrl().toString())) {
                    s.pageReady = false;
                    s.pageLoading = false;
                    s.readyAt = 0;
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // portmanat.az-dan kənara hər yönləndirmə/link bloklanır
                return request == null || request.getUrl() == null || !SiteBlocker.allowPortmanatNavigation(request.getUrl().toString());
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) { return SiteBlocker.interceptPortmanat(r); }
        });
        host.addView(wv, index, new FrameLayout.LayoutParams(width, height));
        s.wv = wv;
        slots.add(s);
        return s;
    }

    private static boolean isPortmanatPage(String url) {
        return url != null && url.startsWith(URL);
    }

    /** Hər yeni/retry sorğusu üçün əvvəlki DOM və JavaScript vəziyyətini sıfırla. */
    private void reloadPage(Slot s) {
        s.readyAt = 0;
        s.pageReady = false;
        s.pageLoading = true;
        try { s.wv.stopLoading(); s.wv.evaluateJavascript("window.__pS=null;", null); } catch (Exception ignored) { }
        s.wv.loadUrl(URL);
    }

    private void pump() {
        while (!queue.isEmpty() && !destroyed) {
            Slot s = null;
            for (Slot x : slots) if (x.cur == null) { s = x; break; }
            if (s == null && slots.size() < maxParallel) s = newSlot();
            if (s == null) return;
            start(s, queue.pollFirst());
        }
    }

    private void start(final Slot s, final Req r) {
        if (s.jobs >= MAX_JOBS_PER_VIEW) {
            slots.remove(s); destroyView(s);
            start(newSlot(), r);
            return;
        }
        s.jobs++;
        s.cur = r; s.nfHits = 0; s.mmHits = 0; s.lastSt = ""; s.startedAt = android.os.SystemClock.elapsedRealtime();
        final boolean warm = s.pageReady && s.readyAt > 0;                             // yalnız tam yüklənmiş təmiz səhifə
        final boolean alreadyLoading = s.pageLoading;
        s.suspect = warm && s.startedAt - s.readyAt >= WARM_STALE_MS;                  // uzun gözləyib: işləməyə bilər
        s.reloaded = false;
        s.readyAt = 0;
        final int ses = ++s.session;
        if (!warm && !alreadyLoading) {
            reloadPage(s);                              // əvvəlki nəticə/JS vəziyyəti mütləq sıfırlanır
        }
        h.postDelayed(() -> poll(s, ses, r.code), warm ? WARM_FIRST_POLL_MS : FIRST_POLL_MS);
    }

    private void poll(final Slot s, final int ses, final String code) {
        if (s.session != ses || destroyed) return;
        // WebView köhnə sənədin DOM-unda kod daxil etməsin; yeni Portmanat səhifəsinin tam yüklənməsini gözlə.
        if (!s.pageReady) {
            if (android.os.SystemClock.elapsedRealtime() - s.startedAt >= maxWaitMs) {
                Req timedOut = s.cur;
                s.pageLoading = false; s.pageReady = false; s.readyAt = 0;
                if (timedOut != null) finish(s, timedOut, null, null);
            } else {
                h.postDelayed(() -> poll(s, ses, code), POLL_MS);
            }
            return;
        }
        final Req activeReq = s.cur;
        if (activeReq == null) return;
        String pollJs = js.replace("'__CODE__'", JSONObject.quote(code))
                .replace("'__REQ_ID__'", JSONObject.quote(Long.toString(activeReq.id)));
        s.wv.evaluateJavascript(pollJs, raw -> {
            if (s.session != ses || destroyed) return;
            String payer = "", amount = "", st = "", customer = ""; boolean nf = false;
            try {
                Object v = new JSONTokener(raw == null ? "null" : raw).nextValue();
                if (v instanceof String) {
                    JSONObject o = new JSONObject((String) v);
                    payer = o.optString("name").trim();
                    amount = o.optString("amount").trim();
                    nf = o.optBoolean("nf");
                    st = o.optString("st");
                    customer = o.optString("customer").trim();
                }
            } catch (Exception ignored) { }
            final Req r = s.cur;
            if (r == null) return;
            s.lastSt = st;
            if (!payer.isEmpty() && !amount.isEmpty()) {
                // saytda "Müştəri adı" sətri YVÖK-dür: başqa kodun nəticəsi (səhifə/sessiya qarışması) qəbul edilmir
                String cn = customer.replaceAll("[^A-Za-z0-9]", "").toUpperCase(Locale.ROOT);
                String want = code.replaceAll("[^A-Za-z0-9]", "").toUpperCase(Locale.ROOT);
                boolean foreign = cn.matches("^10011[A-Z0-9]{7}$") && !cn.equals(want);
                String debt = foreign ? null : debtFromAmounts(amount);
                if (foreign) {
                    s.lastSt = "yad YVÖK: " + cn;
                    if (++s.mmHits == 6 && !s.reloaded) { s.reloaded = true; reloadPage(s); }   // səhifə başqa kodda ilişib: bir dəfə təzələnir
                } else if (debt != null) { finish(s, r, payer.replaceAll("\\s+", " "), debt); return; }
            }
            // uzun gözləmiş hazır səhifə işə düşmürsə (sayt sessiyası bitib / yüklənməyib) bir dəfə təzədən açılır
            if (s.suspect && !s.reloaded && "wait".equals(st)
                    && android.os.SystemClock.elapsedRealtime() - s.startedAt >= WARM_STALL_MS) {
                s.reloaded = true; reloadPage(s);
            }
            if (nf) { if (++s.nfHits >= 3) { finish(s, r, null, null, true); return; } } else s.nfHits = 0;
            if (android.os.SystemClock.elapsedRealtime() - s.startedAt >= maxWaitMs) {
                finish(s, r, null, null);
            } else {
                h.postDelayed(() -> poll(s, ses, code), POLL_MS);
            }
        });
    }

    private void finish(Slot s, Req r, String name, String debt) { finish(s, r, name, debt, false); }

    private void finish(Slot s, Req r, String name, String debt, boolean notFound) {
        s.session++; s.cur = null;
        if (name == null) lastReason = notFound ? "sayt \"tapılmadı\" dedi"
                : "vaxt bitdi (" + (android.os.SystemClock.elapsedRealtime() - s.startedAt) / 1000 + " san), son addım: " + (s.lastSt == null || s.lastSt.isEmpty() ? "səhifə açılmadı" : s.lastSt);
        if (name != null) r.cb.onResult(name, debt); else if (notFound) r.cb.onNotFound(); else r.cb.onFail();
        pump();
        if (armed && s.cur == null && s.readyAt == 0 && slots.contains(s)) rewarm(s);   // növbəti kod üçün arxada təzə səhifə
    }

    /**
     * Portmanat məbləğləri ("12.50 | 12.50") -> Borc: ilk oxunan məbləğ götürülür; mənfi dəyər 0 qeydə alınır
     * (yelo.az ilə eyni qayda); tam ədəd olanda kəsrsiz. Rəqəm oxunmursa null.
     */
    static String debtFromAmounts(String amount) {
        for (String p : amount.split("\\|")) {
            String t = p.trim().replace('\u2212', '-').replace('\u2013', '-').replaceAll("[\\s\\u00A0]", "").replace(',', '.');
            if (t.isEmpty()) continue;
            try {
                double d = Double.parseDouble(t);
                if (d < 0) d = 0;
                return fmt(d);
            } catch (Exception ignored) { }
        }
        return null;
    }

    private static String fmt(double d) {
        if (d == Math.floor(d)) return String.valueOf((long) d);
        return String.format(Locale.US, "%.2f", d);
    }
}
