package com.mehdi.keymapper;

public class Status {
    public static volatile String adb = "—";
    public static volatile String error = "";

    public static String summary() {
        StringBuilder sb = new StringBuilder();
        sb.append("ADB: ").append(adb);
        sb.append("\nServer: ").append(Bridge.isConnected() ? "işləyir ✔" : "işləmir ✘");
        sb.append("\nƏlçatanlıq xidməti: ").append(KeyService.instance != null ? "aktiv ✔" : "qapalı ✘");
        if (error != null && error.length() > 0) sb.append("\nSon xəta: ").append(error);
        return sb.toString();
    }
}
