package az.keymapper;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.SparseArray;
import android.view.KeyEvent;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

final class Prefs {
    static volatile List<Rule> rules = new ArrayList<>();
    static volatile SparseArray<Rule> map = new SparseArray<>();
    static volatile boolean selfRepeat = true;
    static volatile int dblMs = 220;      // ikiqat klik pəncərəsi
    static volatile int longMs = 500;     // uzun basma
    static volatile int holdDelay = 350;  // təkrarın başlama gecikməsi
    static volatile int holdInt = 45;     // təkrar intervalı
    private static volatile boolean loaded;

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("km", Context.MODE_PRIVATE);
    }

    static synchronized void load(Context c) {
        if (loaded) return;
        SharedPreferences p = sp(c);
        selfRepeat = p.getBoolean("selfRepeat", true);
        dblMs = p.getInt("dbl", 220);
        longMs = p.getInt("long", 500);
        holdDelay = p.getInt("delay", 350);
        holdInt = p.getInt("int", 45);
        String js = p.getString("rules", null);
        List<Rule> l = new ArrayList<>();
        if (js == null) {
            l.add(Rule.make(KeyEvent.KEYCODE_BUTTON_7, Rule.KEY, KeyEvent.KEYCODE_DPAD_RIGHT));
            l.add(Rule.make(KeyEvent.KEYCODE_BUTTON_6, Rule.KEY, KeyEvent.KEYCODE_DPAD_LEFT));
            l.add(Rule.make(KeyEvent.KEYCODE_BUTTON_5, Rule.MULTI, KeyEvent.KEYCODE_DPAD_CENTER));
            loaded = true;
            setRules(c, l);
            return;
        }
        try {
            JSONArray a = new JSONArray(js);
            for (int i = 0; i < a.length(); i++) l.add(Rule.fromJson(a.getJSONObject(i)));
        } catch (Exception ignored) { }
        apply(l);
        loaded = true;
    }

    static synchronized void setRules(Context c, List<Rule> l) {
        apply(l);
        try {
            JSONArray a = new JSONArray();
            for (Rule r : l) a.put(r.toJson());
            sp(c).edit().putString("rules", a.toString()).apply();
        } catch (Exception ignored) { }
    }

    private static void apply(List<Rule> l) {
        rules = l;
        SparseArray<Rule> m = new SparseArray<>();
        for (Rule r : l) m.put(r.source, r);
        map = m;
    }

    static synchronized void saveSettings(Context c, boolean rep, int dbl, int lng, int delay, int interval) {
        selfRepeat = rep;
        dblMs = Math.max(0, dbl);
        longMs = Math.max(150, lng);
        holdDelay = Math.max(0, delay);
        holdInt = Math.max(10, interval);
        sp(c).edit().putBoolean("selfRepeat", selfRepeat).putInt("dbl", dblMs).putInt("long", longMs)
                .putInt("delay", holdDelay).putInt("int", holdInt).apply();
    }

    static Rule find(int code) {
        return map.get(code);
    }
}
