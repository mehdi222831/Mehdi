package az.axtaris.baza

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.Build

/** Mənzil qeydləri üçün xatırlatma bildirişi (alarm vaxtı) və telefon yenidən yandıqda alarmların bərpası */
class ReminderReceiver : BroadcastReceiver() {

    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) { rescheduleAll(ctx); return }
        val skey = intent.getStringExtra("skey") ?: return
        notifyNow(ctx, skey, intent.getStringExtra("label") ?: "", intent.getStringExtra("note") ?: "")
    }

    companion object {
        private const val CH = "reminders"

        private fun pi(ctx: Context, skey: String, label: String, note: String): PendingIntent {
            val i = Intent(ctx, ReminderReceiver::class.java).setAction("az.axtaris.baza.REMIND")
            i.data = android.net.Uri.parse("baza://note/" + android.net.Uri.encode(skey))
            i.putExtra("skey", skey).putExtra("label", label).putExtra("note", note)
            return PendingIntent.getBroadcast(ctx, skey.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }

        fun cancel(ctx: Context, skey: String) {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(pi(ctx, skey, "", ""))
            (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(skey.hashCode())
        }

        fun schedule(ctx: Context, skey: String, whenMs: Long, label: String, note: String) {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val p = pi(ctx, skey, label, note)
            try {
                if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, p)
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, p)
            } catch (e: Exception) {
                try { am.set(AlarmManager.RTC_WAKEUP, whenMs, p) } catch (e2: Exception) { }
            }
        }

        private fun notifyNow(ctx: Context, skey: String, label: String, note: String) {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CH) == null)
                nm.createNotificationChannel(NotificationChannel(CH, "Xatırlatmalar", NotificationManager.IMPORTANCE_HIGH))
            val open = PendingIntent.getActivity(ctx, skey.hashCode(), Intent(ctx, BazaActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val b = if (Build.VERSION.SDK_INT >= 26) Notification26.builder(ctx, CH) else @Suppress("DEPRECATION") android.app.Notification.Builder(ctx)
            b.setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle("⏰ " + label.ifEmpty { "Xatırlatma" })
                .setContentText(note)
                .setStyle(android.app.Notification.BigTextStyle().bigText(note))
                .setContentIntent(open).setAutoCancel(true)
            try { nm.notify(skey.hashCode(), b.build()) } catch (e: Exception) { }
        }

        /** edits.db-dəki gələcək xatırlatmalar yenidən quraşdırılır (telefon yenidən yandıqda) */
        fun rescheduleAll(ctx: Context) {
            try {
                val f = ctx.getDatabasePath("edits.db")
                if (!f.exists()) return
                val d = SQLiteDatabase.openDatabase(f.path, null, SQLiteDatabase.OPEN_READONLY)
                d.use {
                    it.rawQuery("SELECT skey, note, remind, label FROM notes WHERE remind > ?", arrayOf(System.currentTimeMillis().toString())).use { c ->
                        while (c.moveToNext()) schedule(ctx, c.getString(0), c.getLong(2), c.getString(3) ?: "", c.getString(1) ?: "")
                    }
                }
            } catch (e: Exception) { }
        }
    }
}

/** API 26+ üçün Notification.Builder (kanal ilə) */
@android.annotation.TargetApi(26)
private object Notification26 {
    fun builder(ctx: Context, ch: String): android.app.Notification.Builder = android.app.Notification.Builder(ctx, ch)
}
