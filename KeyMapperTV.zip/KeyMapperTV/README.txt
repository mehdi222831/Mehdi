KeyMapperTV - TV Box üçün pult düymələrini yenidən təyin edən tətbiq

QURAŞDIRMA
1) Layihəni GitHub-a yükləyin (KeyMapperTV.zip + .github/workflows/build.yml) -> Actions APK yaradır.
2) APK-nı TV Box-a qurun, tətbiqi açın.
3) TV-də Developer options -> "USB debugging" və "ADB over network" (port 5555) aktiv olsun.
   (Olmursa, bir dəfə kompüterdən:  adb tcpip 5555 )
4) İlk qoşulmada TV-də "USB debugging-ə icazə ver?" çıxacaq -> "Həmişə icazə ver" -> OK.
5) Qalanını tətbiq özü edir: icazələri verir, Server-i işə salır, əlçatanlıq xidmətini yandırır.

DEFOLT QAYDALAR
BUTTON_7 -> DPAD_RIGHT (basıb saxla = sonsuz sağa)
BUTTON_6 -> DPAD_LEFT  (basıb saxla = sonsuz sola)
BUTTON_5 -> DPAD_CENTER (tək klik = klik, 2x klik = uzun basış)
