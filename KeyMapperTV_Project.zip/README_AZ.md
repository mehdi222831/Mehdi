# Key Mapper TV — Android TV Box üçün layihə

Bu, Android Studio/Gradle layihəsidir. Hazır APK bu arxivə daxil deyil; GitHub Actions vasitəsilə `app-debug.apk` yaradılır.

## Daxil olan funksiyalar

- `KEYCODE_BUTTON_7` (194) basılı saxlananda `KEYCODE_DPAD_RIGHT` (22) əmrlərini sürətli təkrar göndərir.
- `KEYCODE_BUTTON_6` (193) basılı saxlananda `KEYCODE_DPAD_LEFT` (21) əmrlərini sürətli təkrar göndərir.
- `KEYCODE_BUTTON_5` (192) tək klikdə `KEYCODE_DPAD_CENTER` (23), ikiqat klikdə uzun DPAD_CENTER basması, uzun basmada seçilmiş tətbiqin açılması üçün qurulub.
- Düymə xəritələri əlavə/silmək, mənbə və hədəf keycode-ları dəyişmək, xəritələrin sırasını yuxarı/aşağı dəyişmək mümkündür.
- Pult/gamepad düyməsini “Tut” düyməsi ilə tanımaq olar; istəyə görə kodu rəqəm ilə də yazmaq mümkündür.
- ADB əvvəl `127.0.0.1:5555`, sonra cihazın öz aktiv IPv4 ünvanlarına `:5555` qoşulmağa çalışır.
- Ön plan xidməti və açılışdan sonra xidmətin yenidən başlaması üçün receiver əlavə olunub.

## Quraşdırma

1. Layihəni GitHub repozitoriyasının kökünə açın. `settings.gradle`, `build.gradle` və `app/` repozitoriyanın kökündə olmalıdır.
2. `.github/workflows/keymapper-tv.yml` faylını da repozitoriyaya daxil edin.
3. GitHub → **Actions** → **Build Key Mapper TV APK** → **Run workflow** seçin. Həmçinin uyğun fayllara push edəndə avtomatik işləyir.
4. Workflow bitdikdə `KeyMapperTV-debug-APK` adlı artifact-i endirin və içindəki `app-debug.apk` faylını TV Box-a quraşdırın.
5. Tətbiqi açın → **Əlçatanlığı aç** → Android Accessibility ayarlarında **Key Mapper TV — düymə xidməti** xidmətini aktivləşdirin.
6. ADB cihazın özündə artıq `5555` portunda işləyirsə, **ADB bağlantısını yoxla** düyməsini seçin. İlk qoşulmada Android ADB/RSA təsdiq pəncərəsi çıxa bilər; TV Box-da təsdiqləyin.
7. “Uzun basma ilə açılacaq tətbiq” siyahısından tətbiq seçin və xəritələri yadda saxlayın.

## ADB barədə vacib qeyd

USB debugging-in aktiv olması tətbiqin özünün USB host kimi özünə bağlanması demək deyil. Android tətbiqi USB ADB kanalını özbaşına açıb özünü ADB host edə bilməz. Bu layihə ADB host bağlantısını cihazda artıq dinləyən `adbd` TCP/5555 xidmətinə edir. Əgər `127.0.0.1:5555` və cihazın öz IPv4 ünvanı `:5555` əlçatmazdırsa, həmin port cihazda aktiv deyil və tətbiqin içindən onu adi tətbiq icazələri ilə açmaq mümkün olmaya bilər.

## Gecikmə və davamlılıq barədə

- DPAD təkrar intervalı 20–250 ms arasında dəyişir; standart 40 ms-dir. “0 ms” texniki baxımdan mümkün deyil.
- Tək və ikiqat klik fərqləndirilməlidir; buna görə tək klik əmri təxminən 220 ms gecikdirilir. Bu, ikiqat klik davranışının qaçılmaz kompromisidir.
- Təkrar əmrlər müstəqil DPAD klikləri kimi göndərilir; bu, adi tətbiqlərin əksəriyyətində davamlı sürüşmə hissi yaradır, lakin bütün tətbiqlərdə sistem səviyyəli fiziki düymə basılı qalmasını tam təqlid etmir.
- Android-in batareya/istehsalçı siyasəti tətbiqi dayandıra bilər. Ön plan xidməti və açılış receiver-i dayanmaya qarşı kömək edir, amma “heç vaxt ölməsin” zəmanəti vermir. Accessibility xidməti Android ayarlarında ayrıca aktiv edilməlidir.

## Layihənin texniki parametrləri

- Package: `com.mehdi.keymappertv`
- Min SDK: 23
- Compile SDK: 35
- Target SDK: 32
- Java 17, Android Gradle Plugin 8.7.3, Gradle 8.9

Bu versiya tərtib edilməzdən əvvəl hədəf Xiaomi TV Box-da sınaqdan keçirilməyib. Xüsusilə cihazın ADB TCP/5555 ayarı və konkret pultun `KEYCODE_BUTTON_*` kodlarını göndərməsi real cihazda təsdiqlənməlidir.
