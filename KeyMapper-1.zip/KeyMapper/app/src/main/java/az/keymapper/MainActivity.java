package az.keymapper;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    interface IntCb { void on(int v); }

    static class AppInfo {
        String pkg, label;
    }

    private LinearLayout list;
    private TextView status;
    private CheckBox cRep;
    private EditText eDbl, eLong, eDelay, eInt;
    private final Handler h = new Handler(Looper.getMainLooper());
    private List<AppInfo> apps = new ArrayList<>();
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            refresh();
            h.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Prefs.load(this);
        CoreService.begin(this);
        apps = loadApps();
        setContentView(build());
    }

    @Override protected void onResume() {
        super.onResume();
        CoreService.begin(this);
        h.post(tick);
    }

    @Override protected void onPause() {
        super.onPause();
        h.removeCallbacks(tick);
    }

    // ------------------------------------------------------------ UI

    private View build() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF121212);
        LinearLayout root = vert();
        root.setPadding(dp(32), dp(24), dp(32), dp(40));
        sv.addView(root);

        TextView title = tv("Key Mapper", 26);
        root.addView(title);
        status = tv("", 15);
        status.setPadding(0, dp(8), 0, dp(8));
        root.addView(status);

        LinearLayout r1 = new LinearLayout(this);
        r1.addView(btn("ADB-ni yenidən qoş", new View.OnClickListener() {
            @Override public void onClick(View v) { Core.kick(); }
        }), wrap());
        r1.addView(btn("Əlçatanlıq ayarları", new View.OnClickListener() {
            @Override public void onClick(View v) {
                try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); } catch (Exception ignored) { }
            }
        }), wrap());
        root.addView(r1);

        root.addView(tv("Parametrlər", 20, 20));
        cRep = new CheckBox(this);
        cRep.setText("Öz təkrarlama (basılı saxlayanda sonsuz sürüşmə)");
        cRep.setTextColor(0xFFFFFFFF);
        cRep.setChecked(Prefs.selfRepeat);
        root.addView(cRep);
        eDbl = num(Prefs.dblMs);
        eLong = num(Prefs.longMs);
        eDelay = num(Prefs.holdDelay);
        eInt = num(Prefs.holdInt);
        root.addView(labeled("İkiqat klik pəncərəsi, ms (0 = tək klik dərhal)", eDbl));
        root.addView(labeled("Uzun basma, ms", eLong));
        root.addView(labeled("Təkrarın başlama gecikməsi, ms", eDelay));
        root.addView(labeled("Təkrar intervalı, ms", eInt));
        root.addView(btn("Parametrləri saxla", new View.OnClickListener() {
            @Override public void onClick(View v) {
                Prefs.saveSettings(MainActivity.this, cRep.isChecked(), toInt(eDbl, 220), toInt(eLong, 500),
                        toInt(eDelay, 350), toInt(eInt, 45));
                Toast.makeText(MainActivity.this, "Saxlandı", Toast.LENGTH_SHORT).show();
            }
        }), wrap());

        root.addView(tv("Düymələr", 20, 20));
        list = vert();
        root.addView(list);
        root.addView(btn("+ Düymə əlavə et", new View.OnClickListener() {
            @Override public void onClick(View v) { editRule(-1); }
        }), wrap());
        rebuild();
        return sv;
    }

    private void refresh() {
        boolean acc = accOn();
        status.setText("ADB / server: " + Core.status + "\nƏlçatanlıq xidməti: "
                + (acc ? "aktiv ✓" : "söndürülüb (ADB qoşulanda avtomatik açılır)")
                + "\nDüymə qaydası: " + Prefs.rules.size());
    }

    private boolean accOn() {
        String s = Settings.Secure.getString(getContentResolver(), "enabled_accessibility_services");
        return s != null && s.contains(new ComponentName(this, KeyService.class).flattenToString());
    }

    private void rebuild() {
        list.removeAllViews();
        final List<Rule> rs = Prefs.rules;
        for (int i = 0; i < rs.size(); i++) {
            final int idx = i;
            Rule r = rs.get(i);
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(6), 0, dp(6));
            TextView t = tv(describe(r), 15);
            row.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(btn("Dəyiş", new View.OnClickListener() {
                @Override public void onClick(View v) { editRule(idx); }
            }), wrap());
            row.addView(btn("Yuxarı", new View.OnClickListener() {
                @Override public void onClick(View v) { move(idx, -1); }
            }), wrap());
            row.addView(btn("Aşağı", new View.OnClickListener() {
                @Override public void onClick(View v) { move(idx, 1); }
            }), wrap());
            row.addView(btn("Sil", new View.OnClickListener() {
                @Override public void onClick(View v) {
                    List<Rule> n = new ArrayList<>(Prefs.rules);
                    n.remove(idx);
                    Prefs.setRules(MainActivity.this, n);
                    rebuild();
                }
            }), wrap());
            list.addView(row);
        }
    }

    private void move(int idx, int d) {
        List<Rule> n = new ArrayList<>(Prefs.rules);
        int j = idx + d;
        if (j < 0 || j >= n.size()) return;
        Collections.swap(n, idx, j);
        Prefs.setRules(this, n);
        rebuild();
    }

    private String nm(int c) { return KeyEvent.keyCodeToString(c); }

    private String describe(Rule r) {
        if (r.type == Rule.KEY) {
            return nm(r.source) + "  →  " + nm(r.target) + "   (basılı saxla = davamlı)";
        }
        String a = r.pkg.isEmpty() ? "(seçilməyib)" : labelOf(r.pkg);
        if (r.type == Rule.APP) {
            return nm(r.source) + ":  tək klik → aç: " + a + ";  məcburi dayandır: "
                    + (r.kill.isEmpty() ? "(yoxdur)" : labelOf(r.kill));
        }
        return nm(r.source) + ":  tək → " + nm(r.target) + ";  ikiqat → " + nm(r.target)
                + " uzun;  uzun basma → " + a;
    }

    private String labelOf(String pkg) {
        for (AppInfo a : apps) if (a.pkg.equals(pkg)) return a.label;
        return pkg;
    }

    // ------------------------------------------------------------ qayda redaktoru

    private void editRule(final int index) {
        final Rule w = index >= 0 ? Prefs.rules.get(index).copy()
                : Rule.make(0, Rule.KEY, KeyEvent.KEYCODE_DPAD_CENTER);

        LinearLayout v = vert();
        v.setBackgroundColor(0xFF263238);
        v.setPadding(dp(24), dp(16), dp(24), dp(16));

        final TextView src = tv(w.source == 0 ? "Mənbə düymə: (seçilməyib)" : "Mənbə düymə: " + nm(w.source), 16);
        v.addView(src);
        v.addView(btn("Mənbə düyməni öyrən (düyməni basın)", new View.OnClickListener() {
            @Override public void onClick(View x) {
                learnKey(new IntCb() {
                    @Override public void on(int code) {
                        w.source = code;
                        src.setText("Mənbə düymə: " + nm(code));
                    }
                });
            }
        }), wrap());

        v.addView(tv("Davranış:", 16, 12));
        final Spinner sType = new Spinner(this);
        sType.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new String[]{
                "Başqa düymə kimi apar (basılı saxla = davamlı)",
                "Çoxfunksiyalı: tək / ikiqat / uzun basma",
                "Tək klik: tətbiq aç + digərini məcburi dayandır"}));
        sType.setSelection(w.type);
        v.addView(sType);

        v.addView(tv("Hədəf düymə:", 16, 12));
        final List<Integer> codes = new ArrayList<>();
        List<String> names = new ArrayList<>();
        for (int i = 1; i < 320; i++) {
            String n = KeyEvent.keyCodeToString(i);
            if (!n.equals(Integer.toString(i))) {
                codes.add(i);
                names.add(n);
            }
        }
        final Spinner sT = new Spinner(this);
        sT.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names));
        if (codes.contains(w.target)) sT.setSelection(codes.indexOf(w.target));
        v.addView(sT);
        v.addView(btn("Hədəf düyməni öyrən", new View.OnClickListener() {
            @Override public void onClick(View x) {
                learnKey(new IntCb() {
                    @Override public void on(int code) {
                        if (codes.contains(code)) sT.setSelection(codes.indexOf(code));
                    }
                });
            }
        }), wrap());

        v.addView(tv("Uzun basanda açılacaq tətbiq (çoxfunksiyalı üçün):", 16, 12));
        final Spinner sA = new Spinner(this);
        List<String> an = new ArrayList<>();
        an.add("(yoxdur)");
        int sel = 0;
        for (int i = 0; i < apps.size(); i++) {
            an.add(apps.get(i).label + "  [" + apps.get(i).pkg + "]");
            if (apps.get(i).pkg.equals(w.pkg)) sel = i + 1;
        }
        sA.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, an));
        sA.setSelection(sel);
        v.addView(sA);

        v.addView(tv("Məcburi dayandırılacaq tətbiq (yalnız 3-cü davranış üçün):", 16, 12));
        final Spinner sK = new Spinner(this);
        List<String> kn = new ArrayList<>();
        kn.add("(yoxdur)");
        int ksel = 0;
        for (int i = 0; i < apps.size(); i++) {
            kn.add(apps.get(i).label + "  [" + apps.get(i).pkg + "]");
            if (apps.get(i).pkg.equals(w.kill)) ksel = i + 1;
        }
        sK.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, kn));
        sK.setSelection(ksel);
        v.addView(sK);

        ScrollView sc = new ScrollView(this);
        sc.addView(v);

        new AlertDialog.Builder(this)
                .setTitle(index >= 0 ? "Düyməni dəyiş" : "Yeni düymə")
                .setView(sc)
                .setNegativeButton("Ləğv", null)
                .setPositiveButton("Saxla", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        if (w.source == 0) {
                            Toast.makeText(MainActivity.this, "Mənbə düymə seçilməyib", Toast.LENGTH_LONG).show();
                            return;
                        }
                        w.type = sType.getSelectedItemPosition();
                        w.target = codes.get(sT.getSelectedItemPosition());
                        int ai = sA.getSelectedItemPosition();
                        w.pkg = ai > 0 ? apps.get(ai - 1).pkg : "";
                        int ki = sK.getSelectedItemPosition();
                        w.kill = ki > 0 ? apps.get(ki - 1).pkg : "";
                        List<Rule> old = Prefs.rules;
                        List<Rule> n = new ArrayList<>();
                        boolean placed = false;
                        for (int i = 0; i < old.size(); i++) {
                            if (i == index) { n.add(w); placed = true; }
                            else if (old.get(i).source != w.source) n.add(old.get(i));
                        }
                        if (!placed) n.add(w);
                        Prefs.setRules(MainActivity.this, n);
                        rebuild();
                    }
                }).show();
    }

    private void learnKey(final IntCb cb) {
        KeyService.capture = true;
        final AlertDialog d = new AlertDialog.Builder(this)
                .setMessage("Düyməni basın…  (Geri düyməsi – ləğv)").create();
        d.setOnKeyListener(new DialogInterface.OnKeyListener() {
            @Override public boolean onKey(DialogInterface di, int keyCode, KeyEvent ev) {
                if (keyCode == KeyEvent.KEYCODE_BACK) return false;
                if (ev.getAction() == KeyEvent.ACTION_DOWN && ev.getRepeatCount() == 0) {
                    cb.on(keyCode);
                    di.dismiss();
                }
                return true;
            }
        });
        d.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface di) { KeyService.capture = false; }
        });
        d.show();
    }

    private List<AppInfo> loadApps() {
        PackageManager pm = getPackageManager();
        List<AppInfo> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        String[] cats = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER, Intent.CATEGORY_HOME};
        for (String cat : cats) {
            Intent i = new Intent(Intent.ACTION_MAIN).addCategory(cat);
            for (ResolveInfo r : pm.queryIntentActivities(i, 0)) {
                String p = r.activityInfo.packageName;
                if (p.equals(getPackageName()) || !seen.add(p)) continue;
                AppInfo a = new AppInfo();
                a.pkg = p;
                a.label = String.valueOf(r.loadLabel(pm));
                out.add(a);
            }
        }
        Collections.sort(out, new Comparator<AppInfo>() {
            @Override public int compare(AppInfo a, AppInfo b) { return a.label.compareToIgnoreCase(b.label); }
        });
        return out;
    }

    // ------------------------------------------------------------ köməkçilər

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    private LinearLayout vert() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout.LayoutParams wrap() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(dp(4), dp(4), dp(4), dp(4));
        return p;
    }

    private TextView tv(String t, int sp) { return tv(t, sp, 0); }

    private TextView tv(String t, int sp, int topDp) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(0xFFFFFFFF);
        v.setPadding(0, dp(topDp), 0, 0);
        return v;
    }

    private EditText num(int val) {
        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setText(String.valueOf(val));
        e.setTextColor(0xFFFFFFFF);
        e.setSingleLine(true);
        return e;
    }

    private View labeled(String label, EditText e) {
        LinearLayout l = new LinearLayout(this);
        l.setGravity(Gravity.CENTER_VERTICAL);
        l.addView(tv(label, 15), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        l.addView(e, new LinearLayout.LayoutParams(dp(120), ViewGroup.LayoutParams.WRAP_CONTENT));
        return l;
    }

    private int toInt(EditText e, int def) {
        try { return Integer.parseInt(e.getText().toString().trim()); } catch (Exception x) { return def; }
    }

    private GradientDrawable rect(int c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(c);
        g.setCornerRadius(dp(8));
        return g;
    }

    private Button btn(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextColor(0xFFFFFFFF);
        b.setFocusable(true);
        StateListDrawable sd = new StateListDrawable();
        sd.addState(new int[]{android.R.attr.state_focused}, rect(0xFFFF9800));
        sd.addState(new int[]{android.R.attr.state_pressed}, rect(0xFFFF9800));
        sd.addState(new int[]{}, rect(0xFF37474F));
        b.setBackground(sd);
        b.setOnClickListener(l);
        return b;
    }
}
