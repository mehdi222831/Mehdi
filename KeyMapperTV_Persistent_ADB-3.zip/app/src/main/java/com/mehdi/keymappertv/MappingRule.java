package com.mehdi.keymappertv;

import org.json.JSONException;
import org.json.JSONObject;

final class MappingRule {
    static final String REPEAT = "REPEAT";
    static final String SINGLE = "SINGLE";
    static final String MULTI = "MULTI";

    int sourceKeyCode;
    int targetKeyCode;
    String mode;

    MappingRule(int sourceKeyCode, int targetKeyCode, String mode) {
        this.sourceKeyCode = sourceKeyCode;
        this.targetKeyCode = targetKeyCode;
        this.mode = mode;
    }

    JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("source", sourceKeyCode);
        o.put("target", targetKeyCode);
        o.put("mode", mode);
        return o;
    }

    static MappingRule fromJson(JSONObject o) throws JSONException {
        int source = o.optInt("source", 0);
        int target = o.optInt("target", 23);
        String mode = o.optString("mode", SINGLE);
        if (!REPEAT.equals(mode) && !SINGLE.equals(mode) && !MULTI.equals(mode)) mode = SINGLE;
        return new MappingRule(source, target, mode);
    }
}
