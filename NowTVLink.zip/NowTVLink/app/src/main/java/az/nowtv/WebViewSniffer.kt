package az.nowtv

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONTokener
import java.util.Collections

/**
 * Gizli WebView səhifəni brauzer kimi açır, JS-in yaratdığı dinamik tokenli
 * m3u8 sorğusunu şəbəkə səviyyəsində tutur.
 */
class WebViewSniffer(private val ctx: Context) {

    private val clickJs = """
        (function(){
          var sel=['.jw-icon-display','.vjs-big-play-button','.plyr__control--overlaid',
                   'button[aria-label*="Play"]','.play','#play','.btn-play','.play-button'];
          for(var i=0;i<sel.length;i++){var e=document.querySelector(sel[i]);if(e){try{e.click();}catch(x){}}}
          var v=document.querySelectorAll('video');
          for(var j=0;j<v.length;j++){try{v[j].muted=true;v[j].play();}catch(x){}}
        })();
    """.trimIndent()

    private val domJs = """
        (function(){
          var o=[];
          document.querySelectorAll('video,source,iframe').forEach(function(e){o.push(e.currentSrc||e.src||'');});
          return o.join('\n')+'\n'+document.documentElement.outerHTML;
        })();
    """.trimIndent()

    @SuppressLint("SetJavaScriptEnabled")
    suspend fun sniff(pageUrl: String, timeoutMs: Long, log: (String) -> Unit): List<String> =
        withContext(Dispatchers.Main) {
            val found = Collections.synchronizedList(ArrayList<String>())
            val done = CompletableDeferred<Unit>()
            val handler = Handler(Looper.getMainLooper())
            val wv = WebView(ctx.applicationContext)

            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
            with(wv.settings) {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                userAgentString = LinkExtractor.UA
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            }

            fun add(u: String, fromNet: Boolean) {
                if (found.contains(u)) return
                found.add(u)
                log("   ${if (fromNet) "şəbəkə" else "DOM"}: ${LinkExtractor.short(u)}")
                if (u.lowercase().contains(".m3u8")) handler.postDelayed({ done.complete(Unit) }, 600)
            }

            wv.webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView?, request: WebResourceRequest?
                ): WebResourceResponse? {
                    val u = request?.url?.toString() ?: return null
                    val l = u.lowercase()
                    if (l.contains(".m3u8") || (l.contains("tkn=") && !l.contains(".js"))) add(u, true)
                    return null
                }
            }

            val poker = object : Runnable {
                override fun run() {
                    if (done.isCompleted) return
                    wv.evaluateJavascript(clickJs, null)
                    wv.evaluateJavascript(domJs) { r ->
                        if (done.isCompleted || r == null || r == "null") return@evaluateJavascript
                        val s = runCatching { JSONTokener(r).nextValue() as? String }.getOrNull() ?: return@evaluateJavascript
                        LinkExtractor.scan(s).forEach { add(it, false) }
                    }
                    handler.postDelayed(this, 3000)
                }
            }

            wv.loadUrl(pageUrl)
            handler.postDelayed(poker, 4000)
            // 15 san sonra nəsə tapılıbsa gözləmə
            handler.postDelayed({ if (found.isNotEmpty()) done.complete(Unit) }, 15_000)

            withTimeoutOrNull(timeoutMs) { done.await() }

            handler.removeCallbacksAndMessages(null)
            runCatching { wv.stopLoading(); wv.destroy() }
            found.toList()
        }
}
