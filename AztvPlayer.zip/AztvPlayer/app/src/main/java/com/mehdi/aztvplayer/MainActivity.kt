package com.mehdi.aztvplayer

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.TypedValue
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Channel(
    val name: String,
    val page: String,
    val referer: String,
    val origin: String,
    val rule: String,
    val match: (String) -> Boolean
)

data class Hook(val kind: String, val url: String, val stack: String)

class MainActivity : AppCompatActivity() {

    companion object {
        const val FIND_TIMEOUT_MS = 20000L
        const val MAX_RETRIES = 5

        // Səhifədəki pleyeri avtomatik başladır (səssiz), ki stream sorğusu getsin
        const val AUTOPLAY_JS = """
(function(){
  function go(){
    try{ document.querySelectorAll('video').forEach(function(v){ v.muted=true; var p=v.play(); if(p&&p.catch)p.catch(function(){}); }); }catch(e){}
    try{ var b=document.querySelector('.vjs-big-play-button,.jw-icon-display,.plyr__control--overlaid,.play-button,[class*="big-play"],[class*="PlayButton"]'); if(b) b.click(); }catch(e){}
  }
  go(); setTimeout(go,1500); setTimeout(go,4000); setTimeout(go,8000);
})();
"""

        // Səhifənin JS-i fetch / XHR / video.src ilə link istəyəndə çağırış stack-ini (hansı JS fayl) yazır
        const val HOOK_JS = """
(function(){
  if (window.__aztvHook) return; window.__aztvHook = true;
  function stack(){ try{ return (new Error()).stack || ''; }catch(e){ return ''; } }
  function send(kind, url){ try{ if (window.AztvBridge) AztvBridge.log(kind, String(url), stack()); }catch(e){} }
  try{
    var of = window.fetch;
    if (of) window.fetch = function(i, o){ try{ send('fetch', (i && i.url) ? i.url : i); }catch(e){} return of.apply(this, arguments); };
  }catch(e){}
  try{
    var oo = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(m, u){ try{ send('XHR', u); }catch(e){} return oo.apply(this, arguments); };
  }catch(e){}
  try{
    var d = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, 'src');
    if (d && d.set) Object.defineProperty(HTMLMediaElement.prototype, 'src', {
      get: d.get, configurable: true,
      set: function(v){ try{ send('video.src', v); }catch(e){} return d.set.call(this, v); }
    });
  }catch(e){}
  try{
    var sa = Element.prototype.setAttribute;
    Element.prototype.setAttribute = function(n, v){
      try{ if (String(n).toLowerCase() === 'src' && /m3u8|token=/.test(String(v))) send('setAttribute(src)', v); }catch(e){}
      return sa.apply(this, arguments);
    };
  }catch(e){}
})();
"""
    }

    private fun yoda(name: String, page: String) = Channel(
        name,
        page,
        "https://yoda.az/",
        "https://yoda.az",
        "Yolu .m3u8 ilə bitən ilk sorğu"
    ) { it.substringBefore("?").endsWith(".m3u8") }

    // Azərbaycan əlifbası sırası: A B C Ç D E Ə F G Ğ H X I İ J K Q L M N O Ö P R S Ş T U Ü V Y Z
    private val channels = listOf(
        yoda("APA TV", "https://yoda.az/tv/apatv/"),
        yoda("ARB", "https://yoda.az/tv/arb/"),
        yoda("ARB 24", "https://yoda.az/tv/arb24/"),
        yoda("ARB Günəş", "https://yoda.az/arbgunesh/"),
        yoda("ATV", "https://yoda.az/tv/atv/"),
        Channel(
            "AZ TV",
            "https://yodaplayer.yodacdn.net/aztv/index.php",
            "https://yodaplayer.yodacdn.net/",
            "https://yodaplayer.yodacdn.net",
            "URL-də str.yodacdn.net/azertv/index.m3u8 və token= olan ilk sorğu"
        ) { it.contains("str.yodacdn.net/azertv/index.m3u8") && it.contains("token=") },
        yoda("AZ TV (yoda.az)", "https://yoda.az/tv/azertv/"),
        yoda("Baku TV", "https://yoda.az/tv/bakutv/"),
        yoda("Biznes TV", "https://yoda.az/tv/biznestv/"),
        yoda("Dünya TV", "https://yoda.az/tv/dunyatv/"),
        yoda("El TV", "https://yoda.az/tv/eltv/"),
        yoda("Xəzər TV", "https://yoda.az/tv/xazartv/"),
        yoda("İctimai TV", "https://yoda.az/tv/ictimaitele/"),
        yoda("İdman TV", "https://yoda.az/tv/idmantele/"),
        yoda("Kanal 35", "https://yoda.az/tv/kanal35/"),
        yoda("Qafqaz TV", "https://yoda.az/tv/qafkaz/"),
        yoda("Mədəniyyət TV", "https://yoda.az/tv/medeniyyettele/"),
        yoda("NTV", "https://yoda.az/tv/ntv/"),
        yoda("Real TV", "https://yoda.az/tv/real/"),
        yoda("Space TV", "https://yoda.az/tv/space/")
    )
    private var current = 0

    private lateinit var webView: WebView
    private lateinit var playerView: PlayerView
    private lateinit var status: TextView
    private lateinit var menu: LinearLayout
    private lateinit var btnChannels: Button
    private lateinit var btnInfo: Button
    private lateinit var btnLog: Button
    private lateinit var btnReload: Button

    private val handler = Handler(Looper.getMainLooper())
    private var player: ExoPlayer? = null

    @Volatile
    private var captured = false
    private var fetchId = 0
    private var userAgent = ""
    private var retries = 0
    private var tokenExpMs = 0L
    private var lastUrl = ""
    private var lastChannel = ""
    private var lastTimeMs = 0L
    private var lastReferer = ""
    private var playReferer = ""
    private var playOrigin = ""

    @Volatile
    private var sourceJs = ""

    @Volatile
    private var scanHits = ""

    private val logLines = ArrayList<String>()
    private val logFmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())
    private val jsUrls = ArrayList<String>()
    private val hooks = ArrayList<Hook>()

    private val timeoutRunnable = Runnable {
        if (!captured) {
            log("Vaxt bitdi: ${FIND_TIMEOUT_MS / 1000} saniyədə stream sorğusu tapılmadı, yenidən cəhd")
            status.text = "Link tapılmadı, yenidən cəhd edilir..."
            status.visibility = View.VISIBLE
            handler.postDelayed({ fetchLink() }, 3000)
        }
    }
    private val hideMenuRunnable = Runnable { menu.visibility = View.GONE }

    // ---------------- LOG ----------------

    private fun log(msg: String) {
        synchronized(logLines) {
            if (logLines.size > 700) logLines.removeAt(0)
            logLines.add(logFmt.format(Date()) + "  " + msg)
        }
    }

    private fun fmt(ms: Long): String =
        SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault()).format(Date(ms))

    inner class Bridge {
        @JavascriptInterface
        fun log(kind: String, url: String, stack: String) {
            synchronized(hooks) {
                if (hooks.size > 300) hooks.removeAt(0)
                hooks.add(Hook(kind, url, stack))
            }
            val scripts = scriptsIn(stack)
            this@MainActivity.log(
                "JS çağırışı [" + kind + "]: " + url +
                    "\n      JS fayllar (stack): " + (if (scripts.isEmpty()) "(yoxdur)" else scripts.joinToString("  <-  "))
            )
        }
    }

    private fun scriptsIn(stack: String): List<String> =
        Regex("""https?://[^\s)]+""").findAll(stack).map { it.value }.distinct().take(8).toList()

    // ---------------- LIFECYCLE ----------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        webView = findViewById(R.id.webView)
        playerView = findViewById(R.id.playerView)
        status = findViewById(R.id.status)
        menu = findViewById(R.id.menu)
        btnChannels = findViewById(R.id.btnChannels)
        btnInfo = findViewById(R.id.btnInfo)
        btnLog = findViewById(R.id.btnLog)
        btnReload = findViewById(R.id.btnReload)

        val savedName = getSharedPreferences("prefs", MODE_PRIVATE).getString("chName", "AZ TV")
        current = channels.indexOfFirst { it.name == savedName }.let { if (it < 0) 0 else it }

        btnChannels.setOnClickListener { showChannelList() }
        btnInfo.setOnClickListener { showInfo() }
        btnLog.setOnClickListener { showLog() }
        btnReload.setOnClickListener {
            retries = 0
            hideMenu()
            log("İstifadəçi: Yenilə düyməsi")
            fetchLink()
        }
        playerView.setOnClickListener { showMenu() }
        updateMenu()

        log("Tətbiq açıldı, kanal: ${channels[current].name}")
        setupWebView()
        fetchLink()
    }

    private fun setupWebView() {
        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.cacheMode = WebSettings.LOAD_NO_CACHE
        // Token User-Agent-ə bağlı ola bilər: pleyer də eyni UA-nı istifadə edəcək
        userAgent = s.userAgentString
        log("WebView hazırlandı. User-Agent: $userAgent")

        webView.addJavascriptInterface(Bridge(), "AztvBridge")
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(webView, HOOK_JS, setOf("*"))
            log("Hook JS səhifə açılan kimi (document-start) quraşdırıldı")
        } else {
            log("DOCUMENT_START_SCRIPT dəstəklənmir, hook onPageStarted-də yeridiləcək")
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(m: ConsoleMessage?): Boolean {
                if (m != null) {
                    log("Konsol [" + m.messageLevel() + "]: " + m.message() + "  (" + m.sourceId() + ":" + m.lineNumber() + ")")
                }
                return true
            }
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val req = request ?: return null
                val url = req.url.toString()
                logRequest(url, req)
                if (!captured && channels[current].match(url)) {
                    captured = true
                    val ref = req.requestHeaders?.get("Referer") ?: "(yoxdur)"
                    log("TUTULDU: filtrə uyğun sorğu tapıldı\n      URL: $url\n      sorğunun Referer-i: $ref")
                    runOnUiThread { onLinkFound(url, ref) }
                }
                return null
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                log("Səhifə açılmağa başladı: $url")
                if (url != null && url != "about:blank") {
                    status.text = "Səhifə yüklənir..."
                    view?.evaluateJavascript(HOOK_JS, null)
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                log("Səhifə yükləndi: $url")
                if (!captured && url != null && url != "about:blank") {
                    status.text = "Səhifə yükləndi, stream sorğusu gözlənilir..."
                    log("Avtomatik oxutma JS-i işə salındı (video səssiz, play düyməsinə klik)")
                    view?.evaluateJavascript(AUTOPLAY_JS, null)
                }
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                if (request != null && request.isForMainFrame) {
                    log("Səhifə xətası: ${request.url} (${error?.errorCode} ${error?.description})")
                }
            }
        }
    }

    private fun logRequest(url: String, req: WebResourceRequest) {
        val clean = url.substringBefore("?").lowercase(Locale.ROOT)
        when {
            clean.endsWith(".js") -> {
                synchronized(jsUrls) { if (!jsUrls.contains(url)) jsUrls.add(url) }
                log("JS fayl yüklənir: $url")
            }
            clean.endsWith(".m3u8") -> log("M3U8 sorğusu: $url")
            clean.endsWith(".ts") || clean.endsWith(".m4s") || clean.endsWith(".aac") ||
                clean.endsWith(".mp4") || clean.endsWith(".css") || clean.endsWith(".png") ||
                clean.endsWith(".jpg") || clean.endsWith(".jpeg") || clean.endsWith(".gif") ||
                clean.endsWith(".svg") || clean.endsWith(".webp") || clean.endsWith(".ico") ||
                clean.endsWith(".woff") || clean.endsWith(".woff2") || clean.endsWith(".ttf") -> {
                // seqment, şəkil və şrift sorğuları loga yazılmır
            }
            else -> log("Sorğu [" + req.method + (if (req.isForMainFrame) ", əsas səhifə" else "") + "]: " + url)
        }
    }

    private fun setChannel(i: Int) {
        current = (i + channels.size) % channels.size
        getSharedPreferences("prefs", MODE_PRIVATE).edit().putString("chName", channels[current].name).apply()
        retries = 0
        tokenExpMs = 0L
        log("İstifadəçi: kanal dəyişdi → ${channels[current].name}")
        player?.stop()
        updateMenu()
        hideMenu()
        fetchLink()
    }

    private fun updateMenu() {
        btnChannels.text = "📺 " + channels[current].name
    }

    private fun fetchLink() {
        captured = false
        fetchId++
        sourceJs = ""
        scanHits = ""
        synchronized(jsUrls) { jsUrls.clear() }
        synchronized(hooks) { hooks.clear() }
        val ch = channels[current]
        log("---- Yeni cəhd: ${ch.name} ----")
        log("Filtr: ${ch.rule}")
        log("Gizli WebView səhifəni açır: ${ch.page}")
        status.text = "${ch.name}: link alınır..."
        status.visibility = View.VISIBLE
        handler.removeCallbacks(timeoutRunnable)
        handler.postDelayed(timeoutRunnable, FIND_TIMEOUT_MS)
        webView.loadUrl(ch.page)
    }

    private fun onLinkFound(url: String, referer: String) {
        handler.removeCallbacks(timeoutRunnable)
        tokenExpMs = parseExpMs(url)
        lastUrl = url
        lastChannel = channels[current].name
        lastTimeMs = System.currentTimeMillis()
        lastReferer = referer
        status.text = "Link tutuldu, oxudulur..."
        if (tokenExpMs > 0) log("Token bitmə vaxtı: ${fmt(tokenExpMs)}")
        play(url, referer)

        val id = fetchId
        // JS hook mesajlarının çatması üçün qısa gözləyib səhifəni dayandırır və mənbəni təhlil edir
        handler.postDelayed({
            if (id == fetchId) {
                webView.loadUrl("about:blank")
                log("Gizli WebView dayandırıldı (about:blank), səs ikiqat olmasın")
                analyzeSource(url)
            }
        }, 800)
    }

    // Linkin hansı JS fayldan gəldiyini müəyyən edir
    private fun analyzeSource(url: String) {
        val noScheme = url.substringBefore("?").removePrefix("https://").removePrefix("http://")
        val hit: Hook? = synchronized(hooks) {
            hooks.lastOrNull { h ->
                val key = h.url.substringBefore("?").removePrefix("https:").removePrefix("http:")
                key.length > 5 && (url.contains(key) || h.url.contains(noScheme))
            }
        }
        if (hit != null) {
            val scripts = scriptsIn(hit.stack)
            sourceJs = "Çağırış növü: " + hit.kind + "\nÇağırılan URL: " + hit.url + "\nJS fayllar (içdən çölə):\n" +
                (if (scripts.isEmpty()) "(stack-də fayl yoxdur, inline skript ola bilər)" else scripts.joinToString("\n"))
            log("MƏNBƏ (stack): " + hit.kind + " çağırışı\n      " + sourceJs.replace("\n", "\n      "))
        } else {
            sourceJs = "Stack tapılmadı (sorğu JS hook-dan keçməyib, pleyer yerli ola bilər)"
            log("MƏNBƏ: " + sourceJs)
        }

        // Əlavə üsul: yüklənmiş JS faylların mətnində linkin hissəsini axtarır
        val list = synchronized(jsUrls) { jsUrls.toList() }.take(25)
        val host = url.substringAfter("://").substringBefore("/")
        val file = noScheme.substringAfterLast('/')
        val page = channels[current].page
        log("JS fayllarda axtarış başlayır (${list.size} fayl): host=$host, fayl=$file")
        Thread {
            val found = ArrayList<String>()
            for (js in list) {
                try {
                    val c = URL(js).openConnection() as HttpURLConnection
                    c.setRequestProperty("User-Agent", userAgent)
                    c.setRequestProperty("Referer", page)
                    c.connectTimeout = 8000
                    c.readTimeout = 8000
                    val text = c.inputStream.bufferedReader().use { it.readText() }
                    val hits = ArrayList<String>()
                    if (host.isNotEmpty() && text.contains(host)) hits.add("host")
                    if (file.isNotEmpty() && text.contains(file)) hits.add("fayl adı")
                    if (hits.isEmpty()) {
                        log("JS skan: $js (${text.length} simvol) → uyğunluq yoxdur")
                    } else {
                        log("JS skan: $js (${text.length} simvol) → TAPILDI: ${hits.joinToString()}")
                        found.add(js + "  [" + hits.joinToString() + "]")
                    }
                } catch (e: Exception) {
                    log("JS skan: oxunmadı $js (${e.javaClass.simpleName})")
                }
            }
            scanHits = if (found.isEmpty()) "Heç bir yüklənmiş JS faylın mətnində tapılmadı (link API cavabından və ya yığılaraq gələ bilər)" else found.joinToString("\n")
            log("JS skan bitdi. Nəticə:\n      " + scanHits.replace("\n", "\n      "))
        }.start()
    }

    private fun parseExpMs(url: String): Long {
        if (!url.contains("token=")) return 0L
        return try {
            val token = url.substringAfter("token=").substringBefore("&")
            val payload = token.split(".")[1]
            val json = String(
                Base64.decode(payload, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
            )
            JSONObject(json).optLong("exp", 0L) * 1000L
        } catch (e: Exception) {
            0L
        }
    }

    private fun play(url: String, capturedReferer: String) {
        player?.release()
        val ch = channels[current]
        // Brauzerin göndərdiyi Referer varsa onu, yoxdursa kanalın standart Referer-ini işlədir
        playReferer = if (capturedReferer.startsWith("http")) capturedReferer else ch.referer
        playOrigin = try {
            val u = URL(playReferer)
            u.protocol + "://" + u.host + (if (u.port != -1) ":" + u.port else "")
        } catch (e: Exception) {
            ch.origin
        }
        log("ExoPlayer başladılır (WebView ilə eyni User-Agent)\n      Referer: $playReferer\n      Origin: $playOrigin")

        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent(userAgent)
            .setAllowCrossProtocolRedirects(true)
            .setDefaultRequestProperties(
                mapOf(
                    "Referer" to playReferer,
                    "Origin" to playOrigin
                )
            )

        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(httpFactory))
            .build()
        player = p
        playerView.player = p

        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                val name = when (state) {
                    Player.STATE_IDLE -> "IDLE"
                    Player.STATE_BUFFERING -> "BUFFERING"
                    Player.STATE_READY -> "READY"
                    Player.STATE_ENDED -> "ENDED"
                    else -> state.toString()
                }
                log("ExoPlayer vəziyyəti: $name")
                when (state) {
                    Player.STATE_BUFFERING -> {
                        status.text = "Yüklənir..."
                        status.visibility = View.VISIBLE
                    }
                    Player.STATE_READY -> {
                        status.visibility = View.GONE
                        retries = 0
                    }
                    else -> {}
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                log("ExoPlayer XƏTASI: " + error.errorCodeName + " | " + error.message + " | " + error.cause)
                retries++
                if (retries <= MAX_RETRIES) {
                    log("Link yenilənəcək ($retries/$MAX_RETRIES)")
                    status.text = "Xəta, link yenilənir ($retries/$MAX_RETRIES)..."
                    status.visibility = View.VISIBLE
                    handler.postDelayed({ fetchLink() }, 1500)
                } else {
                    log("Maksimum cəhd sayı bitdi")
                    status.text = "Xəta: ${error.errorCodeName}\nYenilə düyməsini basın"
                    status.visibility = View.VISIBLE
                    showMenu()
                }
            }
        })

        p.setMediaItem(
            MediaItem.Builder()
                .setUri(url)
                .setMimeType(MimeTypes.APPLICATION_M3U8)
                .build()
        )
        p.playWhenReady = true
        p.prepare()
    }

    // ---------------- DIALOGS ----------------

    private fun copy(label: String, text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, text))
        Toast.makeText(this, "Kopyalandı", Toast.LENGTH_SHORT).show()
    }

    private fun showChannelList() {
        handler.removeCallbacks(hideMenuRunnable)
        val names = channels.map { it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Kanallar (" + names.size + ")")
            .setSingleChoiceItems(names, current) { d, which ->
                d.dismiss()
                setChannel(which)
            }
            .setNegativeButton("Bağla", null)
            .show()
    }

    private fun showInfo() {
        handler.removeCallbacks(hideMenuRunnable)
        val infoText = if (lastUrl.isEmpty()) {
            "Hələ link tutulmayıb."
        } else {
            val c = channels.firstOrNull { it.name == lastChannel } ?: channels[current]
            buildString {
                append("Kanal: ").append(lastChannel).append("\n\n")
                append("Haradan: ").append(c.page).append("\n\n")
                append("Necə: gizli WebView bu səhifəni açır. Səhifənin pleyeri stream sorğusu ")
                append("göndərəndə shouldInterceptRequest həmin sorğunun URL-ni tutur. ")
                append("Seçilən sorğu: ").append(c.rule).append(".\n")
                append("Sorğunun Referer-i: ").append(lastReferer).append("\n\n")
                append("Hansı JS fayldan:\n")
                append(if (sourceJs.isEmpty()) "(təhlil gedir...)" else sourceJs).append("\n\n")
                append("JS fayl mətnlərində axtarış:\n")
                append(if (scanHits.isEmpty()) "(gedir...)" else scanHits).append("\n\n")
                append("Tutulma vaxtı: ").append(fmt(lastTimeMs)).append("\n")
                if (tokenExpMs > 0) append("Token bitir: ").append(fmt(tokenExpMs)).append("\n")
                append("\nTutulan link:\n").append(lastUrl).append("\n\n")
                append("Oynatma başlıqları:\n")
                append("User-Agent: ").append(userAgent).append("\n")
                append("Referer: ").append(playReferer).append("\n")
                append("Origin: ").append(playOrigin)
            }
        }
        showTextDialog("Link haqqında", infoText, if (lastUrl.isNotEmpty()) lastUrl else null, "Linki kopyala")
    }

    private fun showLog() {
        handler.removeCallbacks(hideMenuRunnable)
        val logText = synchronized(logLines) { logLines.joinToString("\n") }.ifEmpty { "Log boşdur." }
        showTextDialog("Proseslər (log)", logText, logText, "Logu kopyala")
    }

    private fun showTextDialog(title: String, body: String, copyText: String?, copyLabel: String) {
        val tv = TextView(this)
        tv.text = body
        tv.setTextIsSelectable(true)
        tv.typeface = Typeface.MONOSPACE
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        tv.setTextColor(0xFFDDDDDD.toInt())
        tv.setPadding(32, 24, 32, 24)
        val sv = ScrollView(this)
        sv.addView(tv)
        val b = AlertDialog.Builder(this)
            .setTitle(title)
            .setView(sv)
            .setNegativeButton("Bağla", null)
        if (copyText != null) {
            b.setPositiveButton(copyLabel) { _, _ -> copy(title, copyText) }
        }
        b.show()
    }

    private fun showMenu() {
        menu.visibility = View.VISIBLE
        btnChannels.requestFocus()
        handler.removeCallbacks(hideMenuRunnable)
        handler.postDelayed(hideMenuRunnable, 6000)
    }

    private fun hideMenu() {
        handler.removeCallbacks(hideMenuRunnable)
        menu.visibility = View.GONE
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val menuVisible = menu.visibility == View.VISIBLE
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_MENU -> {
                if (!menuVisible) {
                    showMenu()
                    return true
                }
            }
            KeyEvent.KEYCODE_CHANNEL_UP -> {
                setChannel(current + 1)
                return true
            }
            KeyEvent.KEYCODE_CHANNEL_DOWN -> {
                setChannel(current - 1)
                return true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> if (!menuVisible) {
                setChannel(current + 1)
                return true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> if (!menuVisible) {
                setChannel(current - 1)
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onStart() {
        super.onStart()
        val expired = tokenExpMs > 0 && System.currentTimeMillis() > tokenExpMs - 5 * 60 * 1000
        if (expired) {
            log("Token bitmək üzrədir, link yenilənir")
            retries = 0
            fetchLink()
        } else {
            player?.let {
                it.seekToDefaultPosition()
                it.playWhenReady = true
            }
        }
    }

    override fun onStop() {
        super.onStop()
        player?.playWhenReady = false
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
        webView.destroy()
        super.onDestroy()
    }
}
