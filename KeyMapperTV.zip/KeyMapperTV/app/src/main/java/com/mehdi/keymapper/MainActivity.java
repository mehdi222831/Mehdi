package com.mehdi.keymapper;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private LinearLayout listBox;
    private TextView statusTv;
    private EditText hostEt, portEt, winEt;
    private List<Mapping> mappings;
    private static List<Integer> CODES;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            statusTv.setText(Status.summary());
            h.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Store.reload(this);
        mappings = Store.load(this);
        buildUi();
        refreshList();
        KeepAliveService.start(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        h.post(ticker);
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(ticker);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private Button btn(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private TextView label(String t) {
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setTextSize(15);
        tv.setPadding(0, dp(10), 0, dp(2));
        return tv;
    }

    private int parseInt(EditText et, int def) {
        try {
            return Integer.parseInt(et.getText().toString().trim());
        } catch (Exception e) {
            return def;
        }
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private static List<Integer> codes() {
        if (CODES == null) {
            CODES = new ArrayList<>();
            for (int i = 1; i <= 320; i++) {
                if (KeyEvent.keyCodeToString(i).startsWith("KEYCODE_")) CODES.add(i);
            }
        }
        return CODES;
    }

    private void buildUi() {
        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(32), dp(24), dp(32), dp(24));
        sv.addView(root);

        TextView title = new TextView(this);
        title.setText("Key Mapper TV");
        title.setTextSize(26);
        root.addView(title);

        statusTv = new TextView(this);
        statusTv.setTextSize(16);
        statusTv.setPadding(0, dp(8), 0, dp(8));
        root.addView(statusTv);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(btn("ADB ilə yenidən qoş", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                KeepAliveService.start(MainActivity.this);
                KeepAliveService.kick = true;
            }
        }));
        row.addView(btn("Əlçatanlıq ayarları", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        }));
        root.addView(row);

        root.addView(label("ADB ünvanı (boş = avtomatik: 127.0.0.1, sonra öz IP-si)"));
        hostEt = new EditText(this);
        hostEt.setSingleLine(true);
        hostEt.setText(Store.adbHost(this));
        root.addView(hostEt);

        root.addView(label("ADB portu"));
        portEt = new EditText(this);
        portEt.setInputType(InputType.TYPE_CLASS_NUMBER);
        portEt.setSingleLine(true);
        portEt.setText(String.valueOf(Store.adbPort(this)));
        root.addView(portEt);

        root.addView(label("İkiqat klik müddəti (ms, 100–800)"));
        winEt = new EditText(this);
        winEt.setInputType(InputType.TYPE_CLASS_NUMBER);
        winEt.setSingleLine(true);
        winEt.setText(String.valueOf(Store.window(this)));
        root.addView(winEt);

        root.addView(btn("Ayarları saxla", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int win = Math.max(100, Math.min(800, parseInt(winEt, 250)));
                Store.setAdb(MainActivity.this, hostEt.getText().toString().trim(), parseInt(portEt, 5555));
                Store.setWindow(MainActivity.this, win);
                winEt.setText(String.valueOf(win));
                KeepAliveService.kick = true;
                toast("Saxlandı");
            }
        }));

        TextView hdr = label("Düymə qaydaları (toxunun / OK basın = dəyiş)");
        hdr.setTextSize(20);
        hdr.setPadding(0, dp(24), 0, dp(6));
        root.addView(hdr);

        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(listBox);

        root.addView(btn("+ Düymə əlavə et", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit(null);
            }
        }));

        setContentView(sv);
    }

    private void refreshList() {
        listBox.removeAllViews();
        for (final Mapping m : mappings) {
            Button b = btn(m.label(), new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    edit(m);
                }
            });
            b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            listBox.addView(b);
        }
    }

    private Spinner spinner() {
        List<String> names = new ArrayList<>();
        for (int c : codes()) names.add(Mapping.name(c));
        Spinner sp = new Spinner(this);
        sp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names));
        return sp;
    }

    private void select(Spinner sp, int code) {
        int idx = codes().indexOf(code);
        if (idx >= 0) sp.setSelection(idx);
    }

    private int selected(Spinner sp) {
        return codes().get(sp.getSelectedItemPosition());
    }

    /** Pultda basılan düyməni tanıyır (bu zaman xidmət düymələri udmur). */
    private void capture(final Spinner sp) {
        Store.capturing = true;
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("Düyməni basın")
                .setMessage("İndi pultda istədiyiniz düyməni basın...")
                .create();
        d.setOnKeyListener(new DialogInterface.OnKeyListener() {
            @Override
            public boolean onKey(DialogInterface di, int keyCode, KeyEvent ev) {
                if (ev.getAction() == KeyEvent.ACTION_DOWN && ev.getRepeatCount() == 0) {
                    select(sp, keyCode);
                    di.dismiss();
                }
                return true;
            }
        });
        d.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface di) {
                Store.capturing = false;
            }
        });
        d.show();
    }

    private void edit(final Mapping existing) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(10), dp(20), dp(10));

        final Spinner src = spinner();
        final Spinner dst = spinner();
        final CheckBox dbl = new CheckBox(this);
        dbl.setText("İkiqat klik = hədəfin uzun basışı");

        box.addView(label("Mənbə (pultda basılan düymə)"));
        box.addView(src);
        box.addView(btn("Mənbə düyməni pultdan tanı", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                capture(src);
            }
        }));
        box.addView(label("Hədəf (sistemə göndəriləcək düymə)"));
        box.addView(dst);
        box.addView(btn("Hədəf düyməni pultdan tanı", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                capture(dst);
            }
        }));
        box.addView(dbl);

        select(src, existing != null ? existing.source : KeyEvent.KEYCODE_BUTTON_5);
        select(dst, existing != null ? existing.target : KeyEvent.KEYCODE_DPAD_CENTER);
        dbl.setChecked(existing != null && existing.doubleLong);

        ScrollView wrap = new ScrollView(this);
        wrap.addView(box);

        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle(existing == null ? "Yeni düymə qaydası" : "Qaydanı dəyiş")
                .setView(wrap)
                .setPositiveButton("Yadda saxla", null)
                .setNegativeButton("Ləğv et", null);
        if (existing != null) {
            b.setNeutralButton("Sil", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface d, int w) {
                    mappings.remove(existing);
                    Store.save(MainActivity.this, mappings);
                    refreshList();
                }
            });
        }
        final AlertDialog dialog = b.create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int s = selected(src);
                int t = selected(dst);
                if (s == t) {
                    toast("Mənbə və hədəf eyni ola bilməz");
                    return;
                }
                for (Mapping o : mappings) {
                    if (o == existing) continue;
                    if (o.source == s) {
                        toast("Bu mənbə düymə artıq başqa qaydada var");
                        return;
                    }
                    if (o.source == t || o.target == s) {
                        toast("Qaydalar bir-birini zəncirləyir, bunu etmək olmaz");
                        return;
                    }
                }
                if (existing != null) {
                    existing.source = s;
                    existing.target = t;
                    existing.doubleLong = dbl.isChecked();
                } else {
                    mappings.add(new Mapping(s, t, dbl.isChecked()));
                }
                Store.save(MainActivity.this, mappings);
                refreshList();
                dialog.dismiss();
            }
        });
    }
}
