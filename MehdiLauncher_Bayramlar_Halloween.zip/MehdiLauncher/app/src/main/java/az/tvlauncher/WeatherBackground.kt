package az.tvlauncher

import android.animation.ArgbEvaluator
import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import java.util.Calendar
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * Saata VƏ havaya görə birləşmiş animasiyalı fon:
 * günəş/ay səmada saata görə hərəkət edir, ulduzlar gecə görünür (bulud artdıqca azalır),
 * buludlar, duman, yağış, qar və şimşək hava koduna görə əlavə olunur.
 */
class WeatherBackground @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ev = ArgbEvaluator()
    private val rnd = Random(7)
    private val n = 90
    private val rx = FloatArray(n) { rnd.nextFloat() }
    private val ry = FloatArray(n) { rnd.nextFloat() }
    private val rs = FloatArray(n) { 0.6f + rnd.nextFloat() }
    private val d = resources.displayMetrics.density
    private val season = SeasonEffects(d)
    private val t0 = SystemClock.uptimeMillis()
    private var code = 0
    private var night = false
    private var hf = 12f
    private var c1 = 0xFF24507F.toInt()
    private var c2 = 0xFF060A12.toInt()
    private var grad: LinearGradient? = null
    private var flash = 0f

    private fun unit(c: Int) = RadialGradient(0f, 0f, 1f, c, c and 0x00FFFFFF, Shader.TileMode.CLAMP)
    private val cloudDay = unit(0xFFFFFFFF.toInt())
    private val cloudNight = unit(0xFF8FA0C0.toInt())
    private val cloudDark = unit(0xFF59606B.toInt())
    private val sunGlow = unit(0xFFFFB347.toInt())
    private val moonGlow = unit(0xFFAEC6FF.toInt())
    // Ayın real fazası (0 = yeni ay, 0.25 = ilk dördlük, 0.5 = dolunay, 0.75 = son dördlük)
    private var phase = -1f
    private var waning = false
    private var illum = 1f
    private var moonPath = Path()

    private fun updatePhase() {
        val days = System.currentTimeMillis() / 86400000.0 + 2440587.5 - 2451550.26   // son istinad yeni aydan bəri
        val syn = 29.530588853
        val f = (((days % syn) + syn) % syn / syn).toFloat()
        if (abs(f - phase) < 0.002f) return
        phase = f
        waning = f > 0.5f
        val k = cos(2.0 * PI * (if (waning) 1f - f else f)).toFloat()   // terminator mövqeyi
        illum = ((1.0 - cos(2.0 * PI * f)) / 2.0).toFloat()
        moonPath = Path().apply {                   // vahid dairədə işıqlı hissə (sağ tərəf = artan ay)
            moveTo(0f, -1f)
            arcTo(RectF(-1f, -1f, 1f, 1f), -90f, 180f)
            val a = abs(k)
            if (a < 0.002f) lineTo(0f, -1f) else arcTo(RectF(-a, -1f, a, 1f), 90f, if (k > 0f) -180f else 180f)
            close()
        }
    }
    private val ccx = floatArrayOf(0.1f, 0.35f, 0.6f, 0.85f, 0.5f)
    private val ccy = floatArrayOf(0.12f, 0.25f, 0.08f, 0.3f, 0.18f)
    private val csz = floatArrayOf(0.28f, 0.22f, 0.3f, 0.2f, 0.25f)
    private val csp = floatArrayOf(0.006f, 0.009f, 0.005f, 0.011f, 0.008f)

    private fun cover(c: Int) = when {
        c == 0 -> 0f
        c == 1 -> 0.15f
        c == 2 -> 0.45f
        c == 3 -> 0.9f
        c == 45 || c == 48 -> 0.8f
        else -> 1f
    }

    fun previewFx(name: String?) = season.preview(name)
    fun greeting(): String? = season.greeting
    fun mourning(): Boolean = season.mourning

    fun set(code: Int, day: Boolean, hourF: Float) {
        hf = hourF
        season.refresh(Calendar.getInstance())
        updatePhase()
        val (a, b) = when (hourF.toInt()) {
            in 5..7 -> 0xFF4A2B3A.toInt() to 0xFF0A0608.toInt()
            in 8..16 -> 0xFF24507F.toInt() to 0xFF060A12.toInt()
            in 17..19 -> 0xFF4D2A1E.toInt() to 0xFF0A0504.toInt()
            else -> 0xFF0E1630.toInt() to 0xFF000000.toInt()
        }
        val g = when {
            code == 0 -> 0f
            code == 1 -> 0.15f
            code == 2 -> 0.3f
            code == 3 -> 0.55f
            code in 95..99 -> 0.75f
            else -> 0.6f
        }
        val gray = if (day) 0xFF3A4048.toInt() else 0xFF1A1D24.toInt()
        val n1 = ev.evaluate(g, a, gray) as Int
        val nt = !day
        if (n1 == c1 && b == c2 && code == this.code && nt == night) return
        c1 = n1; c2 = b; this.code = code; night = nt
        rebuild()
    }

    private fun rebuild() {
        if (width == 0) return
        grad = LinearGradient(0f, 0f, width.toFloat(), height.toFloat(), c1, c2, Shader.TileMode.CLAMP)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) = rebuild()

    private fun blob(cv: Canvas, x: Float, y: Float, rx: Float, ry: Float) {
        cv.save(); cv.translate(x, y); cv.scale(rx, ry); cv.drawCircle(0f, 0f, 1f, p); cv.restore()
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val t = (SystemClock.uptimeMillis() - t0) / 1000f
        val cov = cover(code)
        p.style = Paint.Style.FILL

        // 1) səma
        p.shader = grad; p.alpha = 255
        cv.drawRect(0f, 0f, w, h, p)
        p.shader = null

        // 2) ulduzlar (gecə; bulud artdıqca solğunlaşır, amma yox olmur)
        if (night) {
            val k = 1f - 0.75f * cov
            for (i in 0 until 60) {
                p.color = Color.WHITE
                p.alpha = ((110 + 100 * sin(t * rs[i] * 2f + i)) * k).toInt().coerceIn(0, 255)
                cv.drawCircle(rx[i] * w, ry[i] * h * 0.55f, (0.7f + rs[i]) * d, p)
            }
        }

        // 3) günəş / ay: saata görə səmada hərəkət edir
        val prog = if (!night) ((hf - 6f) / 13f) else ((if (hf >= 19f) hf - 19f else hf + 5f) / 11f)
        val pr = prog.coerceIn(0f, 1f)
        val sx = w * (0.08f + 0.84f * pr)
        val sy = h * (0.46f - 0.34f * sin(PI.toFloat() * pr))
        val low = 1f - sin(PI.toFloat() * pr)       // üfüqə yaxın -> 1
        val glowK = 1f - 0.75f * cov
        val disc = 1f - cov * 1.2f
        if (!night) {
            p.shader = sunGlow; p.alpha = ((70 + 90 * low) * glowK).toInt().coerceIn(0, 255)
            blob(cv, sx, sy, 170 * d, 170 * d)
            if (disc > 0f) {
                p.shader = null
                p.color = ev.evaluate(low, 0xFFFFE08A.toInt(), 0xFFFF8A3D.toInt()) as Int
                p.alpha = (200 * disc).toInt()
                cv.drawCircle(sx, sy, 24 * d, p)
            }
        } else {
            p.shader = moonGlow; p.alpha = (70 * glowK * (0.25f + 0.75f * illum)).toInt()
            blob(cv, sx, sy, 120 * d, 120 * d)
            if (disc > 0f) {
                p.shader = null
                cv.save(); cv.translate(sx, sy); cv.scale(22 * d, 22 * d)
                p.color = 0xFF8FA0C0.toInt(); p.alpha = (55 * disc).toInt()          // qaranlıq tərəf
                cv.drawCircle(0f, 0f, 1f, p)
                p.color = 0xFFF5E6A8.toInt(); p.alpha = (235 * disc).toInt()         // işıqlı tərəf
                if (waning) cv.scale(-1f, 1f)                                         // azalan ay: sol tərəf işıqlı
                cv.drawPath(moonPath, p)
                cv.restore()
            }
        }
        p.shader = null

        // 4) buludlar (sayı və qalınlığı hava koduna, rəngi gündüz/gecəyə görə)
        val nc = when (code) { 0 -> 0; 1 -> 2; 2 -> 3; else -> 5 }
        if (nc > 0) {
            val dark = code in 51..67 || code in 80..82 || code >= 95
            p.shader = if (dark) cloudDark else if (night) cloudNight else cloudDay
            p.alpha = ((45 + 85 * cov) * (if (night) 0.85f else 1f)).toInt()
            for (i in 0 until nc) {
                val x = (((ccx[i] + t * csp[i]) % 1.5f) - 0.25f) * w
                blob(cv, x, ccy[i] * h, csz[i] * w, csz[i] * w * 0.4f)
            }
            p.shader = null
        }

        // 5) duman
        if (code == 45 || code == 48) cv.drawColor(if (night) 0x18A0A8C0 else 0x18C8D0D8)

        // 6) yağış
        if (code in 51..67 || code in 80..82 || code in 95..99) {
            val cnt = if (code in 61..67 || code in 80..82 || code >= 95) 90 else 50
            p.color = 0xFF9CC4FF.toInt(); p.alpha = 110; p.strokeWidth = 1.6f * d
            for (i in 0 until cnt) {
                val y = ((ry[i] + t * (0.9f + rs[i] * 0.5f)) % 1f) * h
                val x = (rx[i] * w + y * 0.12f) % w
                cv.drawLine(x, y, x + 3 * d, y + 18 * d, p)
            }
        }

        // 7) qar
        if (code in 71..77 || code in 85..86) {
            for (i in 0 until 70) {
                p.color = Color.WHITE; p.alpha = 190
                val y = ((ry[i] + t * 0.06f * (0.5f + rs[i])) % 1f) * h
                val x = rx[i] * w + sin(t * rs[i] + i) * 20 * d
                cv.drawCircle(x, y, (1.5f + rs[i] * 1.5f) * d, p)
            }
        }

        // 8) şimşək
        if (code in 95..99) {
            if (rnd.nextFloat() < 0.012f) flash = 1f
            if (flash > 0f) {
                p.color = Color.WHITE; p.alpha = (flash * 70).toInt().coerceIn(0, 255)
                cv.drawRect(0f, 0f, w, h, p)
                flash -= 0.12f
            }
        }
        // 9) mövsüm və bayram effektləri
        season.draw(cv, w, h, t)
        postInvalidateDelayed(40)
    }
}
