package com.mehdi.keymappertv;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class KeyMapAccessibilityService extends AccessibilityService {
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ScheduledExecutorService repeatScheduler = Executors.newScheduledThreadPool(2);
    private final Map<Integer, ScheduledFuture<?>> repeatJobs = new ConcurrentHashMap<>();
    private final Map<Integer, PressTrack> pressed = new HashMap<>();
    private final Map<Integer, PendingTap> pendingTaps = new HashMap<>();
    private AdbController adb;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        AccessibilityServiceInfo info = getServiceInfo();
        info.flags |= AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS;
        setServiceInfo(info);
        adb = new AdbController(getApplicationContext());
        adb.connectAsync();
        BootReceiver.start(getApplicationContext());
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override
    public void onInterrupt() {
        for (ScheduledFuture<?> job : repeatJobs.values()) job.cancel(true);
        repeatJobs.clear();
        synchronized (pressed) {
            for (PressTrack track : pressed.values()) mainHandler.removeCallbacks(track.longRunnable);
            pressed.clear();
        }
        synchronized (pendingTaps) {
            for (PendingTap tap : pendingTaps.values()) mainHandler.removeCallbacks(tap.action);
            pendingTaps.clear();
        }
    }

    @Override
    protected boolean onKeyEvent(KeyEvent event) {
        if (ConfigStore.prefs(this).getBoolean(ConfigStore.KEY_CAPTURE_MODE, false)) return false;
        List<MappingRule> rules = ConfigStore.loadRules(this);
        MappingRule rule = null;
        for (MappingRule candidate : rules) {
            if (candidate.sourceKeyCode == event.getKeyCode() && candidate.sourceKeyCode > 0) {
                rule = candidate;
                break;
            }
        }
        if (rule == null) return false;

        if (MappingRule.REPEAT.equals(rule.mode)) {
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                if (event.getRepeatCount() == 0) startRepeat(rule);
            } else if (event.getAction() == KeyEvent.ACTION_UP) {
                stopRepeat(rule.sourceKeyCode);
            }
            return true;
        }

        if (MappingRule.SINGLE.equals(rule.mode)) {
            if (event.getAction() == KeyEvent.ACTION_UP) sendKey(rule.targetKeyCode);
            return true;
        }

        if (MappingRule.MULTI.equals(rule.mode)) {
            if (event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) {
                beginMultiPress(rule);
            } else if (event.getAction() == KeyEvent.ACTION_UP) {
                finishMultiPress(rule);
            }
            return true;
        }
        return false;
    }

    private void startRepeat(MappingRule rule) {
        stopRepeat(rule.sourceKeyCode);
        sendKey(rule.targetKeyCode);
        long interval = ConfigStore.repeatInterval(this);
        ScheduledFuture<?> job = repeatScheduler.scheduleAtFixedRate(
                () -> sendKey(rule.targetKeyCode),
                interval, interval, TimeUnit.MILLISECONDS);
        repeatJobs.put(rule.sourceKeyCode, job);
    }

    private void stopRepeat(int source) {
        ScheduledFuture<?> job = repeatJobs.remove(source);
        if (job != null) job.cancel(true);
    }

    private void beginMultiPress(MappingRule rule) {
        final PressTrack track = new PressTrack(rule);
        long now = SystemClock.uptimeMillis();
        PendingTap previous;
        synchronized (pendingTaps) { previous = pendingTaps.get(rule.sourceKeyCode); }
        if (previous != null && now - previous.createdAt <= ConfigStore.DOUBLE_TAP_MS) {
            mainHandler.removeCallbacks(previous.action);
            synchronized (pendingTaps) { pendingTaps.remove(rule.sourceKeyCode); }
            track.doubleCandidate = true;
        }
        synchronized (pressed) {
            PressTrack old = pressed.put(rule.sourceKeyCode, track);
            if (old != null) mainHandler.removeCallbacks(old.longRunnable);
        }
        track.longRunnable = () -> {
            synchronized (track) {
                if (track.released) return;
                track.longTriggered = true;
            }
            String pkg = ConfigStore.launchPackage(KeyMapAccessibilityService.this);
            if (adb != null && pkg != null && !pkg.isEmpty()) adb.launchPackage(pkg);
        };
        mainHandler.postDelayed(track.longRunnable, ConfigStore.LONG_PRESS_MS);
    }

    private void finishMultiPress(MappingRule rule) {
        PressTrack track;
        synchronized (pressed) { track = pressed.remove(rule.sourceKeyCode); }
        if (track == null) return;
        mainHandler.removeCallbacks(track.longRunnable);
        boolean longTriggered;
        synchronized (track) {
            track.released = true;
            longTriggered = track.longTriggered;
        }
        if (longTriggered) return;
        if (track.doubleCandidate) {
            if (!globalKey(rule.targetKeyCode) && adb != null) adb.sendLongKey(rule.targetKeyCode);
            return;
        }

        PendingTap current = new PendingTap(SystemClock.uptimeMillis());
        current.action = () -> {
            synchronized (pendingTaps) {
                if (pendingTaps.get(rule.sourceKeyCode) != current) return;
                pendingTaps.remove(rule.sourceKeyCode);
            }
            sendKey(rule.targetKeyCode);
        };
        synchronized (pendingTaps) { pendingTaps.put(rule.sourceKeyCode, current); }
        mainHandler.postDelayed(current.action, ConfigStore.DOUBLE_TAP_MS);
    }

    /** BACK(4)/HOME(3) go through the accessibility API (instant, no ADB); everything else through ADB. */
    private void sendKey(int targetCode) {
        if (!globalKey(targetCode) && adb != null) adb.sendKey(targetCode);
    }

    private boolean globalKey(int code) {
        if (code == KeyEvent.KEYCODE_BACK) { performGlobalAction(GLOBAL_ACTION_BACK); return true; }
        if (code == KeyEvent.KEYCODE_HOME) { performGlobalAction(GLOBAL_ACTION_HOME); return true; }
        return false;
    }

    @Override
    public void onDestroy() {
        onInterrupt();
        repeatScheduler.shutdownNow();
        if (adb != null) adb.close();
        super.onDestroy();
    }

    private static final class PressTrack {
        final MappingRule rule;
        volatile boolean released;
        volatile boolean longTriggered;
        boolean doubleCandidate;
        Runnable longRunnable;
        PressTrack(MappingRule rule) { this.rule = rule; }
    }

    private static final class PendingTap {
        final long createdAt;
        Runnable action;
        PendingTap(long createdAt) { this.createdAt = createdAt; }
    }

    private static final class AdbController {
        private final Context context;
        private final java.util.concurrent.ExecutorService connector = Executors.newSingleThreadExecutor();
        private final java.util.concurrent.ExecutorService sender = Executors.newSingleThreadExecutor();
        private final AtomicBoolean connecting = new AtomicBoolean(false);
        private final AtomicInteger queued = new AtomicInteger(0);
        private volatile AdbShellClient client;
        private volatile long lastFailedAt = 0;

        AdbController(Context context) { this.context = context.getApplicationContext(); }

        void connectAsync() {
            AdbShellClient current = client;
            if (current != null && current.isConnected()) return;
            if (!connecting.compareAndSet(false, true)) return;
            connector.execute(() -> {
                try {
                    AdbShellClient replacement = AdbShellClient.connect(context);
                    AdbShellClient old = client;
                    client = replacement;
                    if (old != null) old.close();
                    lastFailedAt = 0;
                } catch (Exception e) {
                    lastFailedAt = SystemClock.elapsedRealtime();
                } finally {
                    connecting.set(false);
                }
            });
        }

        void sendKey(int code) { submit(() -> { AdbShellClient c = client; if (c != null) c.sendKey(code); }); }
        void sendLongKey(int code) { submit(() -> { AdbShellClient c = client; if (c != null) c.sendLongKey(code); }); }
        void launchPackage(String pkg) { submit(() -> { AdbShellClient c = client; if (c != null) c.launchPackage(pkg); }); }

        private void submit(Runnable action) {
            AdbShellClient c = client;
            if (c == null || !c.isConnected()) {
                long now = SystemClock.elapsedRealtime();
                // Avoid hammering a closed port while an ADB listener is unavailable.
                if (lastFailedAt > 0 && now - lastFailedAt < 2500) return;
                connectAsync();
            }
            if (queued.incrementAndGet() > 3) { queued.decrementAndGet(); return; }
            sender.execute(() -> {
                try {
                    // A one-off click can arrive just as the asynchronous ADB handshake is finishing.
                    long deadline = SystemClock.elapsedRealtime() + 2500;
                    AdbShellClient current = client;
                    while ((current == null || !current.isConnected()) && connecting.get()
                            && SystemClock.elapsedRealtime() < deadline) {
                        try { Thread.sleep(40); } catch (InterruptedException e) {
                            Thread.currentThread().interrupt(); return;
                        }
                        current = client;
                    }
                    if (current != null && current.isConnected()) action.run();
                } finally { queued.decrementAndGet(); }
            });
        }

        void close() {
            AdbShellClient c = client;
            client = null;
            if (c != null) c.close();
            connector.shutdownNow();
            sender.shutdownNow();
        }
    }
}
