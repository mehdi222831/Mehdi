package az.keymapper;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.provider.Settings;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** ADB-yə qoşulma, server prosesinin işə salınması və nəzarət (watchdog). */
final class Core {
    static volatile Context app;
    static volatile AdbConnection conn;
    static volatile AdbStream server;
    static volatile String status = "Başlayır…";
    private static Thread th;

    static synchronized void start(Context c) {
        app = c.getApplicationContext();
        Prefs.load(app);
        if (th != null && th.isAlive()) return;
        th = new Thread(new Runnable() {
            @Override public void run() { loop(); }
        }, "km-core");
        th.setDaemon(true);
        th.start();
    }

    static boolean ready() {
        AdbStream s = server;
        AdbConnection c = conn;
        return s != null && !s.closed && c != null && c.alive;
    }

    static void kick() {
        reset();
        Thread t = th;
        if (t != null) t.interrupt();
    }

    private static synchronized void reset() {
        AdbStream s = server;
        AdbConnection c = conn;
        server = null;
        conn = null;
        try { if (s != null) s.close(); } catch (Throwable ignored) { }
        try { if (c != null) c.shutdown(); } catch (Throwable ignored) { }
    }

    private static void loop() {
        int tick = 0;
        while (true) {
            try {
                if (!ready()) {
                    connectAll();
                } else {
                    tick++;
                    if (tick % 3 == 0) ensureAccessibility();
                    if (tick % 15 == 0) keepAlive(conn, app.getPackageName());
                }
                Thread.sleep(ready() ? 4000 : 3000);
            } catch (InterruptedException ignored) {
            } catch (Throwable t) {
                status = "Xəta: " + t;
                reset();
                try { Thread.sleep(3000); } catch (InterruptedException ignored) { }
            }
        }
    }

    private static void connectAll() throws Exception {
        reset();
        status = "ADB-yə qoşulur…";
        AdbKey key = AdbKey.get(app);
        List<Integer> ports = ports();
        List<String> hosts = hosts();
        AdbConnection c = null;
        for (int port : ports) {
            for (String h : hosts) {
                try {
                    status = "Qoşulur: " + h + ":" + port + "  (TV-də icazə pəncərəsi çıxsa «Həmişə icazə ver» seçin)";
                    c = AdbConnection.connect(h, port, key);
                    break;
                } catch (Exception ignored) { }
            }
            if (c != null) break;
        }
        if (c == null) {
            status = "ADB tapılmadı (127.0.0.1 və öz IP, port 5555). Developer options-da USB debugging / ADB over network açın.";
            return;
        }
        conn = c;
        String pkg = app.getPackageName();
        keepAlive(c, pkg);
        ensureAccessibility();

        String cmd = "CLASSPATH=" + app.getPackageCodePath() + " exec app_process /system/bin az.keymapper.Server";
        AdbStream s = c.open("exec:" + cmd, 4000);
        if (s == null) s = c.open("shell:" + cmd, 4000);
        if (s == null) {
            status = "Server prosesi açıla bilmədi";
            return;
        }
        if (!s.waitFor("READY", 7000)) {
            status = "Server cavab vermir: " + s.text();
            s.close();
            return;
        }
        server = s;
        status = "Hazırdır ✓  (" + c.peer + ")" + (s.text().contains("fallback") ? "  [ehtiyat rejim]" : "");
    }

    /** Lokal ADB ilə tətbiqi sistemin öldürməsindən qoruyan bütün əmrlər. */
    static void keepAlive(AdbConnection c, String pkg) {
        if (c == null) return;
        String[] cmds = {
            // öz-özünə icazələr (ADB söndürülsə belə Accessibility-ni özü yandıra bilsin)
            "pm grant " + pkg + " android.permission.WRITE_SECURE_SETTINGS",
            "pm grant " + pkg + " android.permission.POST_NOTIFICATIONS",
            // Doze / batareya optimizasiyasından çıxar
            "dumpsys deviceidle whitelist +" + pkg,
            "cmd deviceidle whitelist +" + pkg,
            // arxa fon məhdudiyyətlərini aç
            "cmd appops set " + pkg + " RUN_IN_BACKGROUND allow",
            "cmd appops set " + pkg + " RUN_ANY_IN_BACKGROUND allow",
            "cmd appops set " + pkg + " START_FOREGROUND allow",
            "cmd appops set " + pkg + " WAKE_LOCK allow",
            "cmd appops set " + pkg + " SYSTEM_ALERT_WINDOW allow",
            "cmd appops set " + pkg + " SCHEDULE_EXACT_ALARM allow",
            "cmd appops set " + pkg + " BOOT_COMPLETED allow",
            "cmd appops set " + pkg + " AUTO_REVOKE_PERMISSIONS_IF_UNUSED ignore",
            // App Standby: həmişə "active"
            "am set-standby-bucket " + pkg + " active",
            "am set-inactive " + pkg + " false",
            "am set-bg-restriction-level --user 0 " + pkg + " unrestricted",
            // Android 12+ phantom/child proses öldürücü
            "settings put global settings_enable_monitor_phantom_procs false",
            "device_config set_sync_disabled_for_tests persistent",
            "device_config put activity_manager max_phantom_processes 2147483647",
            // Batareya qənaəti / Doze / Adaptive battery tam söndürülür
            "settings put global low_power 0",
            "settings put global low_power_sticky 0",
            "settings put global app_standby_enabled 0",
            "settings put global adaptive_battery_management_enabled 0",
            "settings put global forced_app_standby_enabled 0",
            "settings put global forced_app_standby_for_small_battery_enabled 0",
            "settings put global background_check_enabled 0",
            "dumpsys deviceidle disable all",
            // Xiaomi/MIUI/HyperOS Autostart (10008) və arxa fon əməliyyatları
            "cmd appops set " + pkg + " 10008 allow",
            "cmd appops set " + pkg + " 10021 allow",
            "cmd appops set " + pkg + " 10020 allow",
            "cmd appops set " + pkg + " 10040 allow",
            "cmd appops set " + pkg + " RECEIVE_BOOT_COMPLETED allow",
            "cmd appops set " + pkg + " SYSTEM_EXEMPT_FROM_DISMISSIBLE_NOTIFICATIONS allow",
            "cmd appops set " + pkg + " FOREGROUND_SERVICE_SPECIAL_USE allow",
            "cmd appops set " + pkg + " USE_FULL_SCREEN_INTENT allow",
            "cmd appops set " + pkg + " GET_USAGE_STATS allow",
            "pm grant " + pkg + " android.permission.PACKAGE_USAGE_STATS",
            "cmd activity set-inactive " + pkg + " false",
            // ADB özü sönməsin
            "settings put global development_settings_enabled 1",
            "settings put global adb_enabled 1",
            "settings put global adb_wifi_enabled 1",
            "settings put global stay_on_while_plugged_in 3"
        };
        for (String cmd : cmds) {
            try { c.run(cmd, 2500); } catch (Throwable ignored) { }
        }
    }

    static void ensureAccessibility() {
        try {
            String cn = new ComponentName(app, KeyService.class).flattenToString();
            String cur = Settings.Secure.getString(app.getContentResolver(), "enabled_accessibility_services");
            int on = Settings.Secure.getInt(app.getContentResolver(), "accessibility_enabled", 0);
            if (cur != null && cur.contains(cn) && on == 1) return;
            String s0 = (cur == null || cur.equals("null")) ? "" : cur;
            String nv0 = s0.contains(cn) ? s0 : (s0.isEmpty() ? cn : s0 + ":" + cn);
            // 1) WRITE_SECURE_SETTINGS verilibsə ADB-siz özü yazır
            try {
                Settings.Secure.putString(app.getContentResolver(), "enabled_accessibility_services", nv0);
                Settings.Secure.putInt(app.getContentResolver(), "accessibility_enabled", 1);
                return;
            } catch (Throwable ignored) { }
            AdbConnection c = conn;
            if (c == null) return;
            String s = (cur == null || cur.equals("null")) ? "" : cur;
            String nv = s.contains(cn) ? s : (s.isEmpty() ? cn : s + ":" + cn);
            c.run("settings put secure enabled_accessibility_services " + nv, 4000);
            c.run("settings put secure accessibility_enabled 1", 4000);
        } catch (Throwable ignored) { }
    }

    private static ComponentName resolve(String pkg) {
        try {
            PackageManager pm = app.getPackageManager();
            Intent in = pm.getLeanbackLaunchIntentForPackage(pkg);
            if (in == null) in = pm.getLaunchIntentForPackage(pkg);
            if (in != null && in.getComponent() != null) return in.getComponent();
            Intent h = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).setPackage(pkg);
            java.util.List<android.content.pm.ResolveInfo> l = pm.queryIntentActivities(h, 0);
            if (l != null && !l.isEmpty()) {
                android.content.pm.ActivityInfo ai = l.get(0).activityInfo;
                return new ComponentName(ai.packageName, ai.name);
            }
        } catch (Throwable ignored) { }
        return null;
    }

    /** Tətbiqi açır, kill paketini məcburi dayandırır (yenidən qalxsa bir də). */
    static void switchApp(String pkg, String kill) {
        try {
            ComponentName cn = pkg == null || pkg.isEmpty() ? null : resolve(pkg);
            if (cn == null) return; // launcher quraşdırılmayıbsa heç nə dayandırma
            String start = "am start -n '" + cn.flattenToShortString() + "' -a android.intent.action.MAIN";
            StringBuilder sb = new StringBuilder();
            boolean k = kill != null && !kill.isEmpty() && !kill.equals(pkg);
            if (k) sb.append("am force-stop ").append(kill).append("; ");
            sb.append(start);
            if (k) sb.append("; sleep 0.7; am force-stop ").append(kill).append("; ").append(start);
            if (ready()) Injector.exec(sb.toString());
        } catch (Throwable ignored) { }
    }

    static void launch(String pkg) {
        try {
            PackageManager pm = app.getPackageManager();
            Intent in = pm.getLeanbackLaunchIntentForPackage(pkg);
            if (in == null) in = pm.getLaunchIntentForPackage(pkg);
            if (in == null) return;
            ComponentName cn = in.getComponent();
            if (ready() && cn != null) {
                Injector.exec("am start -n '" + cn.flattenToShortString() + "' -a android.intent.action.MAIN");
            } else {
                in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                app.startActivity(in);
            }
        } catch (Throwable ignored) { }
    }

    private static List<Integer> ports() {
        List<Integer> l = new ArrayList<>();
        int p = prop("service.adb.tcp.port");
        if (p <= 0) p = prop("persist.adb.tcp.port");
        if (p > 0) l.add(p);
        if (!l.contains(5555)) l.add(5555);
        return l;
    }

    private static int prop(String name) {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"getprop", name});
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String s = r.readLine();
            p.waitFor();
            if (s != null && s.trim().matches("\\d+")) return Integer.parseInt(s.trim());
        } catch (Throwable ignored) { }
        return 0;
    }

    private static List<String> hosts() {
        List<String> l = new ArrayList<>();
        l.add("127.0.0.1");
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) l.add(a.getHostAddress());
                }
            }
        } catch (Throwable ignored) { }
        return l;
    }
}
