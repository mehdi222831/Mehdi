# Azər TV Player

Gizli WebView kanal səhifəsini (AZ TV, ATV) açır, oradan stream linkini (.m3u8) tutur və ExoPlayer ilə oynadır.
Token IP və User-Agent-ə bağlı olduğu üçün link həmin cihazda alınır və həmin UA ilə oynadılır.
Xəta olarsa və ya token bitərsə link avtomatik yenilənir.

Build: GitHub-a yüklə, Actions > Build APK > artifact `AztvPlayer-apk`.
