package az.vakansiya

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/** JobSite kimi saytlarda nəticəni JS-dən qəbul edən körpü. */
class WorkerBridge(private val cb: (String) -> Unit) {
    @JavascriptInterface
    fun done(json: String) { cb(json) }
}

/**
 * Arxa planda saytları yoxlayır. "Yeni" yalnız BU GÜN yerləşdirilən elandır:
 *  - yalnız: bu gün yerləşdirilən "Xüsusi Vakansiya" (İT, çağrı mərkəzi, qeydiyyat...) tapılsa → ayrıca bildiriş
 */
class CheckWorker(ctx: Context, p: WorkerParameters) : Worker(ctx, p) {

    override fun doWork(): Result {
        val c = applicationContext
        val base = Store.load(c).filter { !it.skip && !Store.stajFilter(it.url) }
        if (base.isEmpty()) return Result.success()
        // əlavə səhifələr (məs. Busy.az ?page=2) ayrıca yoxlanılır, nəticə əsas saytın adına yazılır
        val owners = HashMap<String, Site>()
        val sites = base.flatMap { s -> listOf(s) + Store.extraPages(s.url).map { u -> Site(s.name, u).also { owners[u] = s } } }.sortedByDescending { Store.weight(it.url) }
        val main = Handler(Looper.getMainLooper())
        val latch = CountDownLatch(sites.size)
        val results = ConcurrentHashMap<String, JSONObject>()
        val wvs = ConcurrentHashMap<Int, WebView>()
        val done = Array(sites.size) { AtomicBoolean(false) }
        val started = Array(sites.size) { AtomicBoolean(false) }

        val pg = ConcurrentHashMap<String, Int>()
        val empties = ConcurrentHashMap<String, Int>()
        val acc = ConcurrentHashMap<String, JSONArray>()
        val visited = ConcurrentHashMap<String, MutableSet<String>>()

        fun finish(i: Int) {
            if (done[i].compareAndSet(false, true)) {
                try { wvs[i]?.destroy() } catch (e: Exception) { }
                latch.countDown()
            }
        }

        /** Jobing / Jobu: bu gün-dünən-2 gün əvvəlki elanlar bitənə qədər 1, 2, 3… səhifələr ardıcıl açılır, nəticələr birləşdirilir. */
        fun pageEnd(i: Int, s: Site, v: WebView) {
            if (!Store.paged(s.url) || done[i].get()) { finish(i); return }
            val o = results[s.url]
            val a = acc[s.url] ?: JSONArray().also { acc[s.url] = it }
            val keys = HashSet<String>()
            for (k in 0 until a.length()) { val x = a.optJSONObject(k) ?: continue; keys.add(x.optString("h") + "|" + x.optString("n")) }
            var added = 0
            val arr = o?.optJSONArray("s")
            if (arr != null) for (k in 0 until arr.length()) {
                val x = arr.optJSONObject(k) ?: continue
                if (keys.add(x.optString("h") + "|" + x.optString("n"))) { a.put(x); added++ }
            }
            try { o?.put("s", a) } catch (e: Exception) { }
            val n = pg[s.url] ?: 0
            empties[s.url] = if (added == 0) (empties[s.url] ?: 0) + 1 else 0
            if ((empties[s.url] ?: 0) >= 2 || n >= 7) { finish(i); return }
            v.evaluateJavascript(Scan.nextJs()) { r ->
                if (done[i].get()) return@evaluateJavascript
                var href = ""
                var click = false
                try { val j = JSONObject(JSONTokener(r).nextValue() as String); href = j.optString("h"); click = j.optInt("c") == 1 } catch (e: Exception) { }
                val vis = visited.getOrPut(s.url) { java.util.Collections.synchronizedSet(HashSet<String>()) }
                vis.add(v.url ?: "")
                if (href.isNotEmpty() && vis.add(href)) {
                    pg[s.url] = n + 1
                    started[i].set(false)
                    v.loadUrl(href)
                } else if (click) {
                    pg[s.url] = n + 1
                    main.postDelayed({
                        if (!done[i].get()) scanLoop(c, main, v, s, Store.careful(s.url), results, { done[i].get() }, { pageEnd(i, s, v) }, 0)
                    }, 3000)
                } else finish(i)
            }
        }

        main.post {
            sites.forEachIndexed { i, s ->
                try {
                    val detail = Store.detail(s.url)
                    val careful = Store.careful(s.url)
                    val w = WebView(c)
                    if (Store.scrolly(s.url) || Store.telegram(s.url) || s.url.contains("busy.az")) {
                        // ekrana bağlı olmayan WebView-a ölçü ver ki, sürüşdürmə/yükləmə işləsin
                        w.measure(android.view.View.MeasureSpec.makeMeasureSpec(1080, android.view.View.MeasureSpec.EXACTLY),
                            android.view.View.MeasureSpec.makeMeasureSpec(1920, android.view.View.MeasureSpec.EXACTLY))
                        w.layout(0, 0, 1080, 1920)
                    }
                    w.settings.javaScriptEnabled = true
                    w.settings.domStorageEnabled = true
                    w.settings.blockNetworkImage = true
                    if (detail) {
                        w.addJavascriptInterface(WorkerBridge { json ->
                            try { results[s.url] = JSONObject(json) } catch (e: Exception) { }
                            main.post { finish(i) }
                        }, "Bridge")
                    }
                    w.webViewClient = object : WebViewClient() {
                        override fun shouldInterceptRequest(v: WebView, req: android.webkit.WebResourceRequest) = Block.intercept(req)
                        override fun onPageFinished(v: WebView, u: String) {
                            if (!started[i].compareAndSet(false, true)) return
                            main.postDelayed({
                                if (done[i].get()) return@postDelayed
                                if (detail) {
                                    v.evaluateJavascript(Scan.detailScript(c, s.url), null)
                                } else {
                                    scanLoop(c, main, v, s, careful, results, { done[i].get() }, { pageEnd(i, s, v) }, 0)
                                }
                            }, if ((pg[s.url] ?: 0) > 0) 3500L else if (s.url.contains("glorri.az")) 12000L else if (s.url.contains("jooble")) 12000L else if (s.url.contains("jobing.az")) 15000L else if (careful) 11000L else 6500L)
                        }
                    }
                    wvs[i] = w
                    w.loadUrl(Store.scanUrl(s.url))
                    main.postDelayed({ finish(i) }, if (Store.paged(s.url)) 240000L else if (detail) (if (Store.telegram(s.url)) 260000L else 65000L) else if (s.url.contains("glorri.az") || s.url.contains("iseqebul.az")) 150000L else if (Store.boss(s.url)) 150000L else 55000L)
                } catch (e: Exception) { finish(i) }
            }
        }
        latch.await(260L, TimeUnit.SECONDS)
        main.post { sites.indices.forEach { finish(it) } }

        val prefs = c.getSharedPreferences("seen", Context.MODE_PRIVATE)
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val spKey = "sp_$today"
        val spSeen = HashSet<String>(prefs.getStringSet(spKey, emptySet()) ?: emptySet())
        val ed = prefs.edit()
        // köhnə (əvvəlki günlərin / köhnə sistemin) qeydlərini təmizlə
        for (k in prefs.all.keys) if ((k.startsWith("sp_") && k != spKey) || k.startsWith("s_")) ed.remove(k)

        var spCount = 0
        for (s in sites) {
            val o = results[s.url] ?: continue
            val hits = Hit.parse(o.optJSONArray("s")).filter { it.kind > 0 && it.day == 0 }
            val own = owners[s.url] ?: s
            // ana ekrandakı "Xüsusi Vakansiya" bölməsi üçün yadda saxla (baxıldı basılana qədər qalır)
            SpecialStore.add(c, hits.map { own to it })
            for (h in hits) {
                // saytla birlikdə açar: Staj saytının bildirişi adi saytın eyni elanı ilə əvəz olunmur
                if (spCount >= 40) break
                if (spSeen.add(own.url + "||" + h.key)) { spCount++; notifySpecial(c, own, h) }
            }
        }
        ed.putStringSet(spKey, spSeen)
        ed.apply()
        return Result.success()
    }

    /** Adi saytlarda bir dəfə oxuyur; "aşağı sürüşdürən" saytlarda (Glorri qaydası) köhnə elanlara çatana qədər təkrarlayır. */
    private fun scanLoop(c: Context, main: Handler, v: WebView, s: Site, careful: Boolean,
                         results: ConcurrentHashMap<String, JSONObject>, isDone: () -> Boolean, finish: () -> Unit, attempt: Int) {
        if (isDone()) return
        v.evaluateJavascript(Scan.js(c, careful, s.url)) { r ->
            if (isDone()) return@evaluateJavascript
            var g = 0
            var links = 0
            try {
                val str = JSONTokener(r).nextValue() as String
                val o = JSONObject(str)
                results[s.url] = o
                g = o.optInt("g", 0)
                links = o.optJSONArray("l")?.length() ?: 0
            } catch (e: Exception) { }
            if (links < 3 && attempt < 8) {
                // səhifə hələ tam yüklənməyib (elanlar boşdur): bir az gözləyib yenidən oxu
                main.postDelayed({ scanLoop(c, main, v, s, careful, results, isDone, finish, attempt + 1) }, 2000)
            } else if (Store.scrolly(s.url) && g == 1 && attempt < (if (Store.boss(s.url) || s.url.contains("glorri.az") || s.url.contains("iseqebul.az")) 60 else 10)) {
                main.postDelayed({ scanLoop(c, main, v, s, careful, results, isDone, finish, attempt + 1) }, 1500)
            } else finish()
        }
    }

    private fun channel(c: Context, id: String, name: String, imp: Int) {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(id, name, imp)
            (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun open(c: Context, s: Site, start: String, code: Int): PendingIntent {
        val intent = Intent(c, BrowserActivity::class.java)
            .putExtra("base", s.url).putExtra("start", start).putExtra("title", s.name)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return PendingIntent.getActivity(c, code, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun notifySpecial(c: Context, s: Site, h: Hit) {
        val nm = NotificationManagerCompat.from(c)
        if (!nm.areNotificationsEnabled()) return
        channel(c, "vak_special", "Xüsusi vakansiyalar", NotificationManager.IMPORTANCE_HIGH)
        val id = ("sp" + s.url + "||" + h.key).hashCode()
        val title = when (h.kind) { 1 -> "🖥 İT Xüsusi Vakansiya"; 3 -> "👮🏻‍♂️ Mühafizə Xüsusi Vakansiya"; else -> "★ Xüsusi Vakansiya" }
        val text = s.name + ": " + h.title
        val nt = NotificationCompat.Builder(c, "vak_special")
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(open(c, s, h.url, id))
            .setAutoCancel(true)
            .build()
        try { nm.notify(id, nt) } catch (e: SecurityException) { }
    }
}
