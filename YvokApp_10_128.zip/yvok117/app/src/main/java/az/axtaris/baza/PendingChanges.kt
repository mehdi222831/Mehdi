package az.axtaris.baza

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

/**
 * «📝 Dəyişikliklər» düyməsinin məlumatı:
 *  1) gözləyən təkliflər (yeni mənzil, yeni küçə, köçürmə) - bazaya özləri yazılmır, orada «Təsdiq» / «Ləğv» edilir;
 *  2) dəyişikliklər tarixçəsi (bazaya artıq yazılmış əməliyyatlar).
 * Hər ikisi dəyişən kimi avtomatik Supabase-in baza_sync cədvəlinə («pending» sətri) göndərilir və
 * digər cihazda da eyni siyahı görünür.
 */
object PendingChanges {
    const val KIND_MENZIL = "menzil"   // yeni mənzil (mövcud küçə/binada)
    const val KIND_KUCE = "kuce"       // yeni küçə (yeni fayl/küçə/bina) + mənzil
    const val KIND_KOCUR = "kocur"     // YVÖK başqa küçə/binaya köçürülsün

    class Item(val id: String, val ts: Long, val kind: String, val key: String, val descr: String,
               val payload: String, val status: String, val rts: Long, val dev: String, val devName: String)

    class Hist(val ts: Long, val descr: String, val devName: String, val remote: Boolean)

    private const val ROW = "pending"
    private const val TABLE = "baza_sync"
    private const val DEFAULT_URL = "https://ybsncrjwkxwujakbwqay.supabase.co"
    private const val DEFAULT_KEY = "sb_secret_xGBxzxLlCFif9YCmC2iFCA_bXr0FhPN"
    private const val OLD_KEY_PREFIX = "sb_secret_BpeoOIx"
    private const val KEEP_RESOLVED_MS = 14L * 24 * 3600 * 1000

    @Volatile private var appCtx: Context? = null
    private val lock = Any()
    private val exec = Executors.newSingleThreadScheduledExecutor { r -> Thread(r, "pending-sync").apply { isDaemon = true } }
    @Volatile private var scheduled: ScheduledFuture<*>? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    /** Serverdən başqa cihazın dəyişikliyi gələndə çağırılır (əsas axında); açıq «Dəyişikliklər» pəncərəsi təzələnir */
    @Volatile var onRemoteChange: (() -> Unit)? = null

    @JvmStatic fun init(ctx: Context) { appCtx = ctx.applicationContext }

    @JvmStatic fun ensure(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS pending_changes(id TEXT PRIMARY KEY, ts INTEGER, kind TEXT, key TEXT, descr TEXT, payload TEXT, status TEXT, rts INTEGER, dev TEXT, devname TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS remote_log(key TEXT PRIMARY KEY, ts INTEGER, descr TEXT, dev TEXT, devname TEXT)")
    }

    // ---------- yerli məlumat ----------

    private fun devId(ctx: Context): String {
        val p = ctx.getSharedPreferences("sb", Context.MODE_PRIVATE)
        var d = p.getString("dev", "") ?: ""
        if (d.isEmpty()) { d = java.util.UUID.randomUUID().toString().take(8); p.edit().putString("dev", d).apply() }
        return d
    }

    private fun devName(): String = (android.os.Build.MODEL ?: "").ifBlank { "telefon" }

    /**
     * Yeni təklif əlavə edir (MainActivity-dən, WhatsApp göndəriləndə). Eyni növ + eyni YVÖK üçün gözləyən köhnə təklif
     * əvəz olunur, siyahıda təkrar yığılmır. Sonra avtomatik Supabase-ə göndərilir.
     */
    @JvmStatic fun add(ctx: Context, kind: String, key: String, descr: String, payload: String) {
        val c = ctx.applicationContext
        if (appCtx == null) appCtx = c
        val db = c.openOrCreateDatabase("edits.db", Context.MODE_PRIVATE, null)
        try {
            ensure(db)
            val now = System.currentTimeMillis()
            // eyni YVÖK üçün gözləyən köhnə təklif (hansı növ olursa olsun) əvəz olunur
            db.execSQL("UPDATE pending_changes SET status = 'replaced', rts = ? WHERE key = ? AND status = 'pending'", arrayOf<Any>(now, key))
            db.execSQL("INSERT INTO pending_changes(id, ts, kind, key, descr, payload, status, rts, dev, devname) VALUES(?,?,?,?,?,?,?,?,?,?)",
                arrayOf<Any>(java.util.UUID.randomUUID().toString(), now, kind, key, descr, payload, "pending", 0L, devId(c), devName()))
        } finally { try { db.close() } catch (e: Exception) { } }
        syncSoon()
    }

    @JvmStatic fun pending(db: SQLiteDatabase): List<Item> {
        val l = ArrayList<Item>()
        try {
            ensure(db)
            db.rawQuery("SELECT id, ts, kind, key, descr, payload, status, rts, dev, devname FROM pending_changes WHERE status = 'pending' ORDER BY ts DESC", null).use { c ->
                while (c.moveToNext()) l.add(Item(c.getString(0), c.getLong(1), c.getString(2) ?: "", c.getString(3) ?: "", c.getString(4) ?: "",
                    c.getString(5) ?: "{}", c.getString(6) ?: "pending", c.getLong(7), c.getString(8) ?: "", c.getString(9) ?: ""))
            }
        } catch (e: Exception) { }
        return l
    }

    @JvmStatic fun pendingCount(db: SQLiteDatabase): Int {
        return try {
            ensure(db)
            db.rawQuery("SELECT COUNT(*) FROM pending_changes WHERE status = 'pending'", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
        } catch (e: Exception) { 0 }
    }

    /** status: "approved" (təsdiqləndi) və ya "cancelled" (ləğv edildi) */
    @JvmStatic fun resolve(db: SQLiteDatabase, id: String, status: String) {
        ensure(db)
        db.execSQL("UPDATE pending_changes SET status = ?, rts = ? WHERE id = ?", arrayOf<Any>(status, System.currentTimeMillis(), id))
        syncSoon()
    }

    /** Tarixçə: bu telefonun jurnalı + digər cihazlardan gələnlər, yenidən köhnəyə */
    @JvmStatic fun history(db: SQLiteDatabase): List<Hist> {
        val l = ArrayList<Hist>()
        try {
            for (e in ChangeLog.list(db)) l.add(Hist(e.ts, e.descr, "", false))
            ensure(db)
            db.rawQuery("SELECT ts, descr, devname FROM remote_log ORDER BY ts DESC LIMIT 200", null).use { c ->
                while (c.moveToNext()) l.add(Hist(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", true))
            }
        } catch (e: Exception) { }
        l.sortByDescending { it.ts }
        return l
    }

    // ---------- Supabase ----------

    private fun cloudUrl(ctx: Context): String {
        val p = ctx.getSharedPreferences("sb", Context.MODE_PRIVATE)
        var u = (p.getString("url", DEFAULT_URL) ?: DEFAULT_URL).trim().trim('"', '\'', ' ')
        if (u.isEmpty()) return ""
        val dash = Regex("supabase\\.com/dashboard/project/([A-Za-z0-9]+)").find(u)
        if (dash != null) return "https://" + dash.groupValues[1].lowercase(Locale.US) + ".supabase.co"
        if (!u.contains("://")) u = if (u.contains(".")) "https://$u" else "https://" + u.lowercase(Locale.US) + ".supabase.co"
        if (u.startsWith("http://") && u.contains(".supabase.co")) u = "https://" + u.removePrefix("http://")
        if (u.contains(".supabase.co")) {
            val m = Regex("^(https://[^/]+)").find(u)
            if (m != null) u = m.groupValues[1]
        }
        return u.trimEnd('/')
    }

    private fun cloudKey(ctx: Context): String {
        val p = ctx.getSharedPreferences("sb", Context.MODE_PRIVATE)
        if (p.getString("key", null)?.trim()?.trim('"', '\'')?.startsWith(OLD_KEY_PREFIX) == true) p.edit().putString("key", DEFAULT_KEY).apply()
        var k = (p.getString("key", DEFAULT_KEY) ?: DEFAULT_KEY).trim().trim('"', '\'')
        if (k.startsWith("Bearer ", true)) k = k.substring(7)
        return k.replace(Regex("\\s"), "")
    }

    private fun request(url: String, key: String, method: String, path: String, body: ByteArray?, extra: Map<String, String> = emptyMap()): String {
        val conn = java.net.URL(url + path).openConnection() as java.net.HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 10000; conn.readTimeout = 25000
            conn.setRequestProperty("apikey", key)
            if (!key.startsWith("sb_")) conn.setRequestProperty("Authorization", "Bearer $key")
            extra.forEach { (k, v) -> conn.setRequestProperty(k, v) }
            if (body != null) {
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setFixedLengthStreamingMode(body.size)
                conn.outputStream.use { it.write(body) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw java.io.IOException("HTTP $code: ${text.take(200)}")
            return text
        } finally { conn.disconnect() }
    }

    private fun nowIso(): String =
        java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }.format(java.util.Date())

    /** Dəyişiklik olandan 1.5 san sonra (ardıcıl dəyişikliklər bir göndərişdə) arxa planda sinxronlaşdırır */
    @JvmStatic fun syncSoon() {
        if (appCtx == null) return
        try {
            scheduled?.cancel(false)
            scheduled = exec.schedule({ try { syncNow() } catch (t: Throwable) { } }, 1500, TimeUnit.MILLISECONDS)
        } catch (e: Exception) { }
    }

    /** Dərhal (arxa plan axınında çağırılmalıdır): serverlə iki tərəfli birləşdirmə. true - server ilə əlaqə alındı */
    @JvmStatic fun syncNow(): Boolean = synchronized(lock) {
        val ctx = appCtx ?: return false
        val url = cloudUrl(ctx); val key = cloudKey(ctx)
        if (!url.startsWith("http") || key.isEmpty()) return false
        val myDev = devId(ctx)
        val db = ctx.openOrCreateDatabase("edits.db", Context.MODE_PRIVATE, null)
        try {
            ensure(db); ChangeLog.ensure(db)
            val arr = JSONArray(request(url, key, "GET", "/rest/v1/$TABLE?id=eq.$ROW&select=data", null))
            val rdata = if (arr.length() > 0) (arr.getJSONObject(0).optJSONObject("data") ?: JSONObject()) else JSONObject()
            val rItems = rdata.optJSONArray("items") ?: JSONArray()
            val rLog = rdata.optJSONArray("log") ?: JSONArray()
            var changed = false

            db.beginTransaction()
            try {
                for (i in 0 until rItems.length()) {
                    val o = rItems.optJSONObject(i) ?: continue
                    val id = o.optString("id"); if (id.isEmpty()) continue
                    var st: String? = null
                    db.rawQuery("SELECT status FROM pending_changes WHERE id = ?", arrayOf(id)).use { if (it.moveToFirst()) st = it.getString(0) }
                    val rst = o.optString("status", "pending")
                    if (st == null) {
                        // başqa cihazda artıq bağlanmış köhnə təklif lazımsızdır
                        if (rst != "pending" && o.optLong("rts", 0L) < System.currentTimeMillis() - KEEP_RESOLVED_MS) continue
                        db.execSQL("INSERT OR IGNORE INTO pending_changes(id, ts, kind, key, descr, payload, status, rts, dev, devname) VALUES(?,?,?,?,?,?,?,?,?,?)",
                            arrayOf<Any>(id, o.optLong("ts"), o.optString("kind"), o.optString("key"), o.optString("descr"), o.optString("payload", "{}"),
                                rst, o.optLong("rts", 0L), o.optString("dev"), o.optString("devname")))
                        if (rst == "pending") changed = true
                    } else if (st == "pending" && rst != "pending") {
                        db.execSQL("UPDATE pending_changes SET status = ?, rts = ? WHERE id = ?", arrayOf<Any>(rst, o.optLong("rts", 0L), id))
                        changed = true
                    }
                }
                for (i in 0 until rLog.length()) {
                    val o = rLog.optJSONObject(i) ?: continue
                    val dev = o.optString("dev")
                    if (dev.isEmpty() || dev == myDev) continue
                    val k = o.optLong("ts").toString() + "|" + dev + "|" + o.optString("descr")
                    var have = false
                    db.rawQuery("SELECT 1 FROM remote_log WHERE key = ?", arrayOf(k)).use { have = it.moveToFirst() }
                    if (!have) {
                        db.execSQL("INSERT OR IGNORE INTO remote_log(key, ts, descr, dev, devname) VALUES(?,?,?,?,?)",
                            arrayOf<Any>(k, o.optLong("ts"), o.optString("descr"), dev, o.optString("devname")))
                        changed = true
                    }
                }
                db.execSQL("DELETE FROM pending_changes WHERE status != 'pending' AND rts < ?", arrayOf<Any>(System.currentTimeMillis() - KEEP_RESOLVED_MS))
                db.execSQL("DELETE FROM remote_log WHERE key NOT IN (SELECT key FROM remote_log ORDER BY ts DESC LIMIT 300)")
                db.setTransactionSuccessful()
            } finally { db.endTransaction() }

            // serverə gedən birləşmiş nüsxə
            val items = JSONArray()
            db.rawQuery("SELECT id, ts, kind, key, descr, payload, status, rts, dev, devname FROM pending_changes ORDER BY ts DESC LIMIT 300", null).use { c ->
                while (c.moveToNext()) {
                    items.put(JSONObject().put("id", c.getString(0)).put("ts", c.getLong(1)).put("kind", c.getString(2) ?: "")
                        .put("key", c.getString(3) ?: "").put("descr", c.getString(4) ?: "").put("payload", c.getString(5) ?: "{}")
                        .put("status", c.getString(6) ?: "pending").put("rts", c.getLong(7)).put("dev", c.getString(8) ?: "").put("devname", c.getString(9) ?: ""))
                }
            }
            val all = ArrayList<JSONObject>()
            val myName = devName()
            for (e in ChangeLog.list(db).take(150)) all.add(JSONObject().put("ts", e.ts).put("descr", e.descr).put("dev", myDev).put("devname", myName))
            db.rawQuery("SELECT ts, descr, dev, devname FROM remote_log ORDER BY ts DESC LIMIT 150", null).use { c ->
                while (c.moveToNext()) all.add(JSONObject().put("ts", c.getLong(0)).put("descr", c.getString(1) ?: "").put("dev", c.getString(2) ?: "").put("devname", c.getString(3) ?: ""))
            }
            all.sortByDescending { it.optLong("ts") }
            val log = JSONArray(); for (o in all.take(300)) log.put(o)

            val out = JSONObject().put("items", items).put("log", log)
            if (out.toString() != JSONObject().put("items", rItems).put("log", rLog).toString()) {
                val row = JSONObject()
                row.put("id", ROW); row.put("data", out); row.put("updated_at", nowIso())
                request(url, key, "POST", "/rest/v1/$TABLE?on_conflict=id", JSONArray().put(row).toString().toByteArray(Charsets.UTF_8),
                    mapOf("Prefer" to "resolution=merge-duplicates,return=minimal"))
            }
            if (changed) mainHandler.post { try { onRemoteChange?.invoke() } catch (e: Exception) { } }
            true
        } catch (e: Exception) {
            false
        } finally { try { db.close() } catch (e: Exception) { } }
    }
}
