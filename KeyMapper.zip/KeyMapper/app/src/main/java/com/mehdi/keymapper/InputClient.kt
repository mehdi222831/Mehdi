package com.mehdi.keymapper

import android.os.Process
import android.os.SystemClock
import java.io.BufferedOutputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Sends key events to InputServer over a persistent loopback socket.
 * action: 0=down 1=up 2=tap 3=up(cancelled, no click)
 *
 * Key repeat (held key -> endless left/right scrolling, real long-press) is generated here,
 * on the SAME single thread that sends the events, so ordering of repeat/up is always strict.
 */
object InputClient {
    const val PORT = 5556
    const val REPEAT_DELAY_MS = 400L   // hold time before auto-repeat starts
    const val REPEAT_RATE_MS = 40L     // ~25 repeats / second
    const val MAX_HOLD_MS = 60_000L    // safety: a lost "key up" can never repeat forever

    private val ex = Executors.newSingleThreadScheduledExecutor { r ->
        Thread {
            try { Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY) } catch (e: Exception) {}
            r.run()
        }.apply { isDaemon = true; name = "km-input" }
    }
    private val repeats = ConcurrentHashMap<Int, ScheduledFuture<*>>()
    private var sock: Socket? = null
    private var out: DataOutputStream? = null

    fun send(code: Int, action: Int, repeat: Int) { ex.execute { sendBlocking(code, action, repeat) } }

    /** Starts auto-repeat for a key that is currently held down (down event already sent). */
    fun startRepeat(code: Int, firstDelayMs: Long = REPEAT_DELAY_MS) {
        stopRepeat(code)
        val n = AtomicInteger(0)
        val t0 = SystemClock.uptimeMillis()
        val f = ex.scheduleWithFixedDelay({
            if (SystemClock.uptimeMillis() - t0 > MAX_HOLD_MS) {
                stopRepeat(code)
                sendBlocking(code, 1, 0)
            } else if (!sendBlocking(code, 0, n.incrementAndGet())) {
                stopRepeat(code)
            }
        }, firstDelayMs, REPEAT_RATE_MS, TimeUnit.MILLISECONDS)
        repeats[code] = f
    }

    fun stopRepeat(code: Int) { repeats.remove(code)?.cancel(false) }

    fun stopAll() {
        repeats.keys.toList().forEach { stopRepeat(it) }
    }

    fun warmUp() {
        ex.execute {
            if (out == null && !open()) Adb.ensureServerAsync()
        }
    }

    private fun sendBlocking(code: Int, action: Int, repeat: Int): Boolean {
        for (attempt in 0..1) {
            try {
                if (out == null && !open()) break
                val o = out!!
                o.writeInt(code); o.writeByte(action); o.writeInt(repeat); o.flush()
                return true
            } catch (e: Exception) { close() }
        }
        // Slow fallback (plain "input keyevent") only for a fresh press, never for repeats / ups.
        if ((action == 0 || action == 2) && repeat == 0) Adb.inputKey(code, false)
        Adb.ensureServerAsync()
        return false
    }

    private fun open(): Boolean = try {
        val s = Socket()
        s.tcpNoDelay = true
        s.connect(InetSocketAddress("127.0.0.1", PORT), 250)
        val o = DataOutputStream(BufferedOutputStream(s.getOutputStream()))
        o.writeUTF(Adb.token)
        o.flush()
        sock = s; out = o
        true
    } catch (e: Exception) { false }

    private fun close() {
        try { sock?.close() } catch (e: Exception) {}
        sock = null; out = null
    }
}
