package com.mehdi.keymapper;

import android.view.KeyEvent;

import org.json.JSONException;
import org.json.JSONObject;

public class Mapping {
    public int source;
    public int target;
    /** İkiqat klik = hədəf düymənin uzun basışı */
    public boolean doubleLong;

    public Mapping(int source, int target, boolean doubleLong) {
        this.source = source;
        this.target = target;
        this.doubleLong = doubleLong;
    }

    public static String name(int code) {
        String n = KeyEvent.keyCodeToString(code);
        return n.startsWith("KEYCODE_") ? n.substring(8) : n;
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("s", source);
        o.put("t", target);
        o.put("d", doubleLong);
        return o;
    }

    public static Mapping fromJson(JSONObject o) {
        return new Mapping(o.optInt("s"), o.optInt("t"), o.optBoolean("d"));
    }

    public String label() {
        return name(source) + "  →  " + name(target) + (doubleLong ? "   (2× klik = uzun basış)" : "");
    }
}
