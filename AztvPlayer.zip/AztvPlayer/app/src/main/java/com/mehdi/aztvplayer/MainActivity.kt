package com.mehdi.aztvplayer

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    companion object {
        const val PAGE = "https://yodaplayer.yodacdn.net/aztv/index.php"
        const val REFERER = "https://yodaplayer.yodacdn.net/"
        const val STREAM_PREFIX = "str.yodacdn.net/azertv/index.m3u8"
        const val FIND_TIMEOUT_MS = 20000L
        const val MAX_RETRIES = 5
    }

    private lateinit var webView: WebView
    private lateinit var playerView: PlayerView
    private lateinit var status: TextView
    private lateinit var btnReload: Button

    private val handler = Handler(Looper.getMainLooper())
    private var player: ExoPlayer? = null

    @Volatile
    private var captured = false
    private var userAgent = ""
    private var retries = 0
    private var tokenExpMs = 0L

    private val timeoutRunnable = Runnable {
        if (!captured) {
            status.text = "Link tapılmadı, yenidən cəhd edilir..."
            status.visibility = View.VISIBLE
            handler.postDelayed({ fetchLink() }, 3000)
        }
    }
    private val hideBtnRunnable = Runnable { btnReload.visibility = View.GONE }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        webView = findViewById(R.id.webView)
        playerView = findViewById(R.id.playerView)
        status = findViewById(R.id.status)
        btnReload = findViewById(R.id.btnReload)

        btnReload.setOnClickListener {
            retries = 0
            fetchLink()
            btnReload.visibility = View.GONE
        }
        playerView.setOnClickListener { showReloadButton() }

        setupWebView()
        fetchLink()
    }

    private fun setupWebView() {
        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.cacheMode = WebSettings.LOAD_NO_CACHE
        // Token User-Agent-ə bağlıdır: pleyer də eyni UA-nı istifadə edəcək
        userAgent = s.userAgentString

        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val url = request?.url?.toString() ?: return null
                if (!captured && url.contains(STREAM_PREFIX) && url.contains("token=")) {
                    captured = true
                    runOnUiThread { onLinkFound(url) }
                }
                return null
            }
        }
    }

    private fun fetchLink() {
        captured = false
        status.text = "Link alınır..."
        status.visibility = View.VISIBLE
        handler.removeCallbacks(timeoutRunnable)
        handler.postDelayed(timeoutRunnable, FIND_TIMEOUT_MS)
        webView.loadUrl(PAGE)
    }

    private fun onLinkFound(url: String) {
        handler.removeCallbacks(timeoutRunnable)
        // Səhifənin öz pleyerini dayandır (səs ikiqat olmasın)
        webView.loadUrl("about:blank")
        tokenExpMs = parseExpMs(url)
        play(url)
    }

    private fun parseExpMs(url: String): Long {
        return try {
            val token = url.substringAfter("token=").substringBefore("&")
            val payload = token.split(".")[1]
            val json = String(
                Base64.decode(payload, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
            )
            JSONObject(json).optLong("exp", 0L) * 1000L
        } catch (e: Exception) {
            0L
        }
    }

    private fun play(url: String) {
        player?.release()

        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent(userAgent)
            .setAllowCrossProtocolRedirects(true)
            .setDefaultRequestProperties(
                mapOf(
                    "Referer" to REFERER,
                    "Origin" to "https://yodaplayer.yodacdn.net"
                )
            )

        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(httpFactory))
            .build()
        player = p
        playerView.player = p

        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                when (state) {
                    Player.STATE_BUFFERING -> {
                        status.text = "Yüklənir..."
                        status.visibility = View.VISIBLE
                    }
                    Player.STATE_READY -> {
                        status.visibility = View.GONE
                        retries = 0
                    }
                    else -> {}
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                retries++
                if (retries <= MAX_RETRIES) {
                    status.text = "Xəta, link yenilənir ($retries/$MAX_RETRIES)..."
                    status.visibility = View.VISIBLE
                    handler.postDelayed({ fetchLink() }, 1500)
                } else {
                    status.text = "Xəta: ${error.errorCodeName}\nYenilə düyməsini basın"
                    status.visibility = View.VISIBLE
                    showReloadButton()
                }
            }
        })

        p.setMediaItem(
            MediaItem.Builder()
                .setUri(url)
                .setMimeType(MimeTypes.APPLICATION_M3U8)
                .build()
        )
        p.playWhenReady = true
        p.prepare()
    }

    private fun showReloadButton() {
        btnReload.visibility = View.VISIBLE
        btnReload.requestFocus()
        handler.removeCallbacks(hideBtnRunnable)
        handler.postDelayed(hideBtnRunnable, 5000)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
            keyCode == KeyEvent.KEYCODE_ENTER ||
            keyCode == KeyEvent.KEYCODE_MENU
        ) {
            showReloadButton()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onStart() {
        super.onStart()
        val expired = tokenExpMs > 0 && System.currentTimeMillis() > tokenExpMs - 5 * 60 * 1000
        if (expired) {
            retries = 0
            fetchLink()
        } else {
            player?.let {
                it.seekToDefaultPosition()
                it.playWhenReady = true
            }
        }
    }

    override fun onStop() {
        super.onStop()
        player?.playWhenReady = false
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
        webView.destroy()
        super.onDestroy()
    }
}
