package az.axtaris.baza

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.util.Xml
import android.text.Editable
import android.text.SpannableString
import android.text.Spanned
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import az.yvok.app.BazaOps
import az.yvok.app.HesabChecker
import az.yvok.app.YeloChecker
import az.yvok.app.PortmanatChecker
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import org.xmlpull.v1.XmlPullParser
import java.io.*
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

data class Card(val path: String, val title: String, val headers: List<String>, val cells: List<String>, val rowId: Long = -1L, val bname: String = "", val skey: String = "")

/** WhatsApp (yaşıl) və Mesaj (mavi) ikonları — kodla çəkilir */
private class IconView(ctx: Context, private val whatsapp: Boolean) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    var sent = false
    override fun onDraw(c: Canvas) {
        val s = Math.min(width, height).toFloat() / 100f
        c.save()
        c.scale(s, s)
        if (whatsapp) {
            p.style = Paint.Style.FILL; p.color = Color.parseColor("#25D366")
            c.drawCircle(50f, 50f, 50f, p)
            p.style = Paint.Style.STROKE; p.color = Color.WHITE; p.strokeWidth = 6f
            c.drawCircle(50f, 48f, 26f, p)
            p.style = Paint.Style.FILL
            val tail = Path()
            tail.moveTo(22f, 80f); tail.lineTo(28f, 58f); tail.lineTo(43f, 71f); tail.close()
            c.drawPath(tail, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 8f; p.strokeCap = Paint.Cap.ROUND
            val h = Path()
            h.moveTo(41f, 38f); h.cubicTo(39f, 52f, 48f, 60f, 61f, 59f)
            c.drawPath(h, p)
            p.style = Paint.Style.FILL
            c.drawCircle(41f, 38f, 5f, p); c.drawCircle(61f, 59f, 5f, p)
        } else {
            p.style = Paint.Style.FILL; p.color = Color.parseColor("#4F8CFF")
            c.drawCircle(50f, 50f, 50f, p)
            p.color = Color.WHITE
            c.drawRoundRect(RectF(22f, 28f, 78f, 64f), 11f, 11f, p)
            val tail = Path()
            tail.moveTo(34f, 62f); tail.lineTo(31f, 77f); tail.lineTo(49f, 64f); tail.close()
            c.drawPath(tail, p)
            p.color = Color.parseColor("#4F8CFF")
            c.drawCircle(37f, 46f, 4.5f, p); c.drawCircle(50f, 46f, 4.5f, p); c.drawCircle(63f, 46f, 4.5f, p)
        }
        if (sent) {
            // "göndərildi" işarəsi: yaşıl dairə içində ağ ✓
            p.style = Paint.Style.FILL; p.color = Color.WHITE
            c.drawCircle(80f, 20f, 21f, p)
            p.color = Color.parseColor("#2E7D32")
            c.drawCircle(80f, 20f, 17f, p)
            p.style = Paint.Style.STROKE; p.color = Color.WHITE; p.strokeWidth = 5f; p.strokeCap = Paint.Cap.ROUND
            p.strokeJoin = Paint.Join.ROUND
            val ck = Path()
            ck.moveTo(71f, 21f); ck.lineTo(77f, 27f); ck.lineTo(89f, 13f)
            c.drawPath(ck, p)
        }
        c.restore()
    }
}

/** Zəng ikonu (teal dairə içində ağ dəstək) — kodla çəkilir */
private class CallIconView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val s = Math.min(width, height).toFloat() / 100f
        c.save()
        c.scale(s, s)
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#00897B")
        c.drawCircle(50f, 50f, 50f, p)
        // Material "call" ikonu 24x24 şəbəkədə; 100x100 daxilində 2x böyüdülüb ortalanır
        c.translate(26f, 26f); c.scale(2f, 2f)
        p.color = Color.WHITE
        val h = Path()
        h.moveTo(6.62f, 10.79f)
        h.cubicTo(8.06f, 13.62f, 10.38f, 15.93f, 13.21f, 17.38f)
        h.lineTo(15.41f, 15.18f)
        h.cubicTo(15.68f, 14.91f, 16.08f, 14.82f, 16.43f, 14.94f)
        h.cubicTo(17.55f, 15.31f, 18.76f, 15.51f, 20f, 15.51f)
        h.cubicTo(20.55f, 15.51f, 21f, 15.96f, 21f, 16.51f)
        h.lineTo(21f, 20f)
        h.cubicTo(21f, 20.55f, 20.55f, 21f, 20f, 21f)
        h.cubicTo(10.61f, 21f, 3f, 13.39f, 3f, 4f)
        h.cubicTo(3f, 3.45f, 3.45f, 3f, 4f, 3f)
        h.lineTo(7.5f, 3f)
        h.cubicTo(8.05f, 3f, 8.5f, 3.45f, 8.5f, 4f)
        h.cubicTo(8.5f, 5.25f, 8.7f, 6.45f, 9.07f, 7.57f)
        h.cubicTo(9.18f, 7.92f, 9.1f, 8.31f, 8.82f, 8.59f)
        h.lineTo(6.62f, 10.79f)
        h.close()
        c.drawPath(h, p)
        c.restore()
    }
}

private val DEFAULT_HEADERS = listOf("Mənzil", "Soyad, Ad, Atasının adı", "YVÖK", "Borc", "Nömrə", "Ümumi sahəsi", "Otaqların sayı", "Vergidən azad olunanlar")

private const val TAX_URL = "https://e-belediyye.gov.az/tax-debts"
// ======== BƏLƏDİYYƏ BAZASI: 8 GB RAM üçün sabit dəyərlər (cihazın RAM-ından asılı deyil) ========
private const val WORKERS = 16                  // cəmi 16 işçi: Yelo 5 + Portmanat 5 + e-bələdiyyə 3 + hesab.az 3 (pay: 30% / 30% / 20% / 20%)
private const val MAX_WORKERS = WORKERS
private const val RETRY_WORKERS = 6            // xəta verənlərin təkrar yoxlanmasında paralel səhifə sayı
private const val YELO_PAR = 5                // yelo.az-da eyni anda işləyən gizli səhifə sayı (əvvəl 8: yükün bir hissəsi portmanat.az-a verildi)
private const val PORT_PAR = 5                // portmanat.az-da eyni anda işləyən gizli səhifə sayı; əvvəl 2 idi
private const val HESAB_PAR = 3                // hesab.az-da eyni anda işləyən gizli səhifə sayı (toplu yeniləmə)
private const val YELO_WAIT_MS = 15000L        // yelo.az bir kod üçün bu qədər cavab verməsə kod e-belediyyeyə keçir
private const val PORT_WAIT_MS = 25000L        // Portmanat ehtiyat mənbədir; gec cavab verərsə digər aktiv mənbəyə keçir
private const val POOL_SIZE = 14                // əvvəlcədən sayta qoşulmuş (hazır) səhifələrin sayı
private const val PAGE_REUSE_MAX = 15          // bir səhifə bu qədər YVÖK-dən sonra təzədən yüklənir
private const val DOWN_MS = 300000L           // mənbə "dayanıb" sayılır; bu müddət ərzində hər PROBE_MS-dən bir yenidən yoxlanılır, cavab verən kimi pay bərpa olunur
private const val PROBE_MS = 10000L            // dayanmış mənbənin təkrar yoxlanma aralığı
private const val EBEL_PAR = 3                // e-bələdiyyədə eyni anda işləyən səhifə sayı
private const val RETRY_BACKOFF_MS = 400L    // cavab gəlməyəndə təkrar cəhd arasında gözləmə (hər cəhddə artır)
private const val RETRY_BACKOFF_MAX_MS = 4000L // gözləmənin yuxarı həddi
private const val DEFAULT_POLL_MS = 50L        // nəticə yoxlama intervalı
private const val RESULT_LIMIT_MS = 20000L     // forma doldurulandan sonra nəticə gözləmə həddi
private const val RESULT_LIMIT_TAIL_MS = 15000L // növbənin sonunda (qalan az YVÖK) gözləmə həddi
private const val PAGE_LOAD_LIMIT_MS = 20000L  // səhifə açılma həddi
private const val JOB_HARD_MS = 70000L         // bir kodun bir keçiddə mütləq son həddi: heç bir cavab/callback gəlməsə də kod dayandırılır (yeniləmə 69/70-də ilişməsin)
private const val TAIL_HESAB_WAIT_MS = 5000L    // növbənin sonunda hesab.az cavabı gözlənilmir: 5 san-dən sonra kod digər mənbəyə verilir
private const val TAIL_EXT_WAIT_MS = 8000L      // növbənin sonunda (gözləyən kod qalmayıb) yelo.az / portmanat.az-da bir cəhd üçün gözləmə həddi
private const val JOB_BUDGET_MS = 60000L       // toplu yeniləmədə bir YVÖK-ə bir keçiddə ayrılan ümumi vaxt; keçəndə təkrar növbəyə, ikinci dəfə "Yenilənmədi"
private const val READY_POLL_MAX = 300         // səhifə açılıb, amma forma görünmürsə: ~15 san sonra cəhd uğursuz sayılır (əvvəl sonsuz gözləyirdi)
// ===========================================================================================

// ---- saytda YVÖK xanasını doldurub "Yoxla" düyməsinə basan skriptlər ----
private const val JS_FINDER = """
function vis(e){return !!(e&&(e.offsetWidth||e.offsetHeight||(e.getClientRects&&e.getClientRects().length)));}
function findForm(){
  var inp=null,btn=null;
  var inputs=document.querySelectorAll('input');
  for(var i=0;i<inputs.length;i++){var t=(inputs[i].type||'text').toLowerCase();
    if((t==='text'||t==='search'||t==='tel'||t==='')&&!inputs[i].disabled&&vis(inputs[i])){inp=inputs[i];break;}}
  var bs=document.querySelectorAll('button,input[type=submit],input[type=button],a');
  for(var j=0;j<bs.length;j++){var tx=((bs[j].innerText||bs[j].value||'')+'').replace(/\s+/g,' ').trim().toLowerCase();
    if(tx==='yoxla'&&vis(bs[j])){btn=bs[j];break;}}
  return {inp:inp,btn:btn};
}
"""
private const val JS_READY = "(function(){" + JS_FINDER +
    "var f=findForm();return JSON.stringify({ok:!!(f.inp&&f.btn),text:document.body?document.body.innerText:''});})()"
private const val JS_STATE = "(function(){return JSON.stringify({text:document.body?document.body.innerText:''});})()"

private fun jsFill(code: String): String = "(function(code){" + JS_FINDER +
    "var f=findForm();if(!f.inp||!f.btn)return 'noform';" +
    "var set=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;" +
    "f.inp.focus();set.call(f.inp,code);" +
    "f.inp.dispatchEvent(new Event('input',{bubbles:true}));" +
    "f.inp.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true}));" +
    "f.inp.dispatchEvent(new Event('change',{bubbles:true}));" +
    "setTimeout(function(){f.btn.click();},15);return 'ok';})(" + JSONObject.quote(code) + ")"

class BazaActivity : Activity() {

    private lateinit var db: SQLiteDatabase
    private lateinit var editsDb: SQLiteDatabase
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var catSearch: SearchUi
    private lateinit var catPanel: LinearLayout
    private lateinit var webHost: FrameLayout
    private var refresher: Refresher? = null

    // catalog state
    private lateinit var tvPath: TextView
    private lateinit var tvTotal: TextView
    private lateinit var catList: ListView
    private val cardAdapterCat by lazy { CardAdapter() }
    private var level = 0
    private var fileId = 0L
    private var streetId = 0L
    private var buildingId = 0L
    private var fileName = ""
    private var streetName = ""
    private var catIds = ArrayList<Long>()
    private var catNames = ArrayList<String>()
    /** cari faylın hər bina vərəqi üçün son yenilənmə vaxtı */
    private fun sheetUpdMap(): HashMap<String, Long> {
        val m = HashMap<String, Long>()
        editsDb.rawQuery("SELECT sheet, ts FROM sheet_upd WHERE file = ?", arrayOf(fileKeyName(fileId))).use { u -> while (u.moveToNext()) m[u.getString(0) ?: ""] = u.getLong(1) }
        return m
    }
    private var catUpd = ArrayList<Long>()          // küçələr üçün son yenilənmə vaxtı (0 = heç yenilənməyib)
    private var catCounts = ArrayList<Int>()
    private var catBorc = ArrayList<Double>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = openDb()
        buildUi()
        try { az.axtaris.baza.ReminderReceiver.rescheduleAll(this) } catch (e: Exception) { }
        updateNotesBtn()
    }

    // ---------- database ----------
    private fun openDb(): SQLiteDatabase {
        // redaktələr və saytdan çəkilən məlumatlar ayrıca faylda da saxlanılır ki, baza yenilənəndə itməsin
        editsDb = openOrCreateDatabase("edits.db", MODE_PRIVATE, null)
        editsDb.execSQL("CREATE TABLE IF NOT EXISTS edits(file TEXT, sheet TEXT, ord INTEGER, col INTEGER, value TEXT, PRIMARY KEY(file, sheet, ord, col))")
        editsDb.execSQL("CREATE TABLE IF NOT EXISTS imp_sheets(file TEXT, sheet TEXT, title TEXT, headers TEXT, PRIMARY KEY(file, sheet))")
        editsDb.execSQL("CREATE TABLE IF NOT EXISTS imp_rows(file TEXT, sheet TEXT, ord INTEGER, cells TEXT, PRIMARY KEY(file, sheet, ord))")
        editsDb.execSQL("CREATE TABLE IF NOT EXISTS renames(kind TEXT, a TEXT, b TEXT, value TEXT, PRIMARY KEY(kind, a, b))")
        editsDb.execSQL("CREATE TABLE IF NOT EXISTS sent(skey TEXT, kind TEXT, PRIMARY KEY(skey, kind))")
        editsDb.execSQL("CREATE TABLE IF NOT EXISTS added(kind TEXT, a TEXT, b TEXT, name TEXT, PRIMARY KEY(kind, a, b, name))")
        editsDb.execSQL("CREATE TABLE IF NOT EXISTS added_rows(file TEXT, sheet TEXT, ord INTEGER, cells TEXT, PRIMARY KEY(file, sheet, ord))")
        editsDb.execSQL("CREATE TABLE IF NOT EXISTS deleted_rows(file TEXT, sheet TEXT, ord INTEGER, PRIMARY KEY(file, sheet, ord))")
        // WhatsApp sayğacı: hər göndərmə bir sətir; yalnız bu telefonda saxlanır, serverə getmir, "göndərildi" işarəsi kimi silinmir.
        editsDb.execSQL("CREATE TABLE IF NOT EXISTS wa_log(file TEXT, sheet TEXT, ord INTEGER, ts INTEGER)")
        // son yenilənmə tarixi: hər bina (vərəq) üçün saytdan cavab alındığı son an; küçə üçün onun binalarının ən yenisi göstərilir
        editsDb.execSQL("CREATE TABLE IF NOT EXISTS sheet_upd(file TEXT, sheet TEXT, ts INTEGER, PRIMARY KEY(file, sheet))")
        // qeydlər + xatırlatma vaxtı (yalnız bu telefonda) və borc dəyişiklikləri jurnalı
        editsDb.execSQL("CREATE TABLE IF NOT EXISTS notes(skey TEXT PRIMARY KEY, note TEXT, remind INTEGER, label TEXT)")
        editsDb.execSQL("CREATE TABLE IF NOT EXISTS debt_log(skey TEXT, label TEXT, old_v REAL, new_v REAL, ts INTEGER)")
        ChangeLog.ensure(editsDb)
        PendingChanges.init(this)
        PendingChanges.ensure(editsDb)
        PendingChanges.onRemoteChange = {
            // başqa cihazdan yeni təklif/qeyd gəlib: say yenilənir, açıq pəncərə təzələnir
            if (::btnChanges.isInitialized) updateChangesBadge()
            if (changesDlg?.isShowing == true) showChangesDialog()
        }
        try { editsDb.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS debt_log_u ON debt_log(skey, ts, new_v)") } catch (e: Exception) { }
        notesMap.clear()
        editsDb.rawQuery("SELECT skey, note, remind, label FROM notes", null).use { c ->
            while (c.moveToNext()) notesMap[c.getString(0)] = NoteRec(c.getString(1) ?: "", c.getLong(2), c.getString(3) ?: "")
        }
        migrateBarat()
        migrateBaratBack()
        editsDb.rawQuery("SELECT skey, kind FROM sent", null).use { c -> while (c.moveToNext()) sentSet.add(c.getString(0) + "|" + c.getString(1)) }
        val f = File(filesDir, "data.db")
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        val ver = 14
        var fresh = false
        if (!f.exists() || prefs.getInt("dbver", 0) != ver) {
            assets.open("data.db").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            prefs.edit().putInt("dbver", ver).apply()
            fresh = true
        }
        val d = SQLiteDatabase.openDatabase(f.path, null, SQLiteDatabase.OPEN_READWRITE)
        var hasDisp = false
        d.rawQuery("PRAGMA table_info(files)", null).use { c -> while (c.moveToNext()) if (c.getString(1) == "disp") hasDisp = true }
        if (!hasDisp) d.execSQL("ALTER TABLE files ADD COLUMN disp TEXT")
        if (fresh) { replayAll(d) }
        return d
    }

    /** "⭐ BARAT" qrupuna köçürülən binalar: (köhnə kateqoriya, vərəq) */
    private val BARAT_MOVED = arrayOf(
        arrayOf("8-ci Mikrorayon", "Ş.MƏMMƏDOVA-9c  ya83- 85-87-89"),
        arrayOf("9-cu Mikrorayon", "A.MƏMMƏDOV-73"),
        arrayOf("9-cu Mikrorayon", "A.MƏMMƏDOV-77"),
        arrayOf("9-cu Mikrorayon", "A.MƏMMƏDOV-79"),
        arrayOf("9-cu Mikrorayon", "A.MƏMMƏDOV-81"),
        arrayOf("9-cu Mikrorayon", "A.MƏMMƏDOV-83"),
        arrayOf("9-cu Mikrorayon", "A.MƏMMƏDOV-85"),
        arrayOf("9-cu Mikrorayon", "A.MƏMMƏDOV-87"),
        arrayOf("Dərnəgül", "A.GƏRYABƏYLİ-71"),
        arrayOf("Dərnəgül", "C.XƏNDAN 40A"),
        arrayOf("Dərnəgül", "C.XƏNDAN 40B"),
        arrayOf("Dərnəgül", "C.XƏNDAN 54 (Behrud MTK)"),
        arrayOf("Dərnəgül", "C.XƏNDAN-32"),
        arrayOf("Dərnəgül", "C.XƏNDAN-32A"),
        arrayOf("Dərnəgül", "C.XƏNDAN-32B"),
        arrayOf("Dərnəgül", "C.XƏNDAN-32D"),
        arrayOf("Dərnəgül", "C.XƏNDAN-32Q"),
        arrayOf("Dərnəgül", "C.XƏNDAN-32V"),
        arrayOf("Dərnəgül", "C.XƏNDAN-34"),
        arrayOf("Dərnəgül", "C.XƏNDAN-42"),
        arrayOf("Dərnəgül", "Ş.RƏHİMOV 54"),
        arrayOf("Dərnəgül", "Ş.RƏHİMOV 56"),
        arrayOf("Dərnəgül", "Ş.RƏHİMOV-51"),
        arrayOf("Dərnəgül", "Ş.RƏHİMOV-55"),
        arrayOf("Dərnəgül", "Ş.RƏHİMOV-55C. (S.Bəhlulzad 28)"),
        arrayOf("Dərnəgül", "Ş.RƏHİMOV-57"),
        arrayOf("Dərnəgül", "Ş.RƏHİMOV-58"),
        arrayOf("Dərnəgül", "Ş.RƏHİMOV-60"),
        arrayOf("Dərnəgül", "Ş.RƏHİMOV-62"),
        arrayOf("Dərnəgül", "Z.Bünyadov 5A"),
        arrayOf("Dərnəgül", "Z.BÜNYADOV-7"),
        arrayOf("Dərnəgül", "Z.BÜNYADOV-7A"),
        arrayOf("Dərnəgül", "Z.BÜNYADOV-9"),
        arrayOf("Dərnəgül", "Z.BÜNYADOV-9A"),
        arrayOf("Dərnəgül", "Z.BÜNYADOV-11"),
        arrayOf("Dərnəgül", "Z.BÜNYADOV-11B"),
        arrayOf("Naxçivani", "Ə.NAXÇIVANİ 35 (MTK)"),
        arrayOf("Naxçivani", "Ə.NAXÇIVANİ 37 (MTK)"),
        arrayOf("Naxçivani", "Ə.NAXÇIVANİ 39 (MTK)"),
        arrayOf("Naxçivani", "NAXÇIVANİ 44"),
        arrayOf("Naxçivani", "NAXÇIVANİ 49A"),
        arrayOf("Naxçivani", "NAXÇIVANİ 51)"),
        arrayOf("Naxçivani", "NAXÇIVANİ 3068 MƏH BİNA 1"),
        arrayOf("Naxçivani", "NAXÇIVANİ 3068 MƏH BİNA 2"),
        arrayOf("Naxçivani", "NAXÇIVANİ 3068 MƏH BİNA 4"),
        arrayOf("Naxçivani", "NAXÇIVANİ-2"),
        arrayOf("Naxçivani", "NAXÇIVANİ-7"),
        arrayOf("Naxçivani", "NAXÇIVANİ-12"),
        arrayOf("Naxçivani", "NAXÇIVANİ-13C"),
        arrayOf("Naxçivani", "NAXÇIVANİ-14"),
        arrayOf("Naxçivani", "NAXÇIVANİ-18A"),
        arrayOf("Naxçivani", "NAXÇIVANİ-24A"),
        arrayOf("Naxçivani", "NAXÇIVANİ-25"),
        arrayOf("Naxçivani", "NAXÇIVANİ-26"),
        arrayOf("Naxçivani", "NAXÇIVANİ-34B"),
        arrayOf("Naxçivani", "NAXÇİVANİ-26A")
    )

    /** "⭐ BARAT"-dan geri qaytarılan binalar: (kateqoriya, vərəq) */
    private val BARAT_RETURNED = arrayOf(
        arrayOf("Naxçivani", "NAXÇIVANİ-35"),
        arrayOf("Naxçivani", "NAXÇIVANİ-37")
    )

    /** Əvvəl "⭐ BARAT"-a keçmiş redaktə/göndərmə qeydlərini köhnə kateqoriyaya qaytarır (təkrar çağırış zərərsizdir) */
    private fun migrateBaratBack() {
        try {
            editsDb.beginTransaction()
            try {
                for (m in BARAT_RETURNED) {
                    val a = arrayOf<Any>(m[0], "⭐ BARAT", m[1])
                    editsDb.execSQL("UPDATE OR REPLACE edits SET file = ? WHERE file = ? AND sheet = ?", a)
                    editsDb.execSQL("UPDATE OR REPLACE added_rows SET file = ? WHERE file = ? AND sheet = ?", a)
                    editsDb.execSQL("UPDATE OR REPLACE deleted_rows SET file = ? WHERE file = ? AND sheet = ?", a)
                    editsDb.execSQL("UPDATE wa_log SET file = ? WHERE file = ? AND sheet = ?", a)
                    val old = "⭐ BARAT|" + m[1] + "|"
                    editsDb.execSQL(
                        "UPDATE OR REPLACE sent SET skey = ? || substr(skey, ?) WHERE substr(skey, 1, ?) = ?",
                        arrayOf<Any>(m[0] + "|" + m[1] + "|", old.length + 1, old.length, old)
                    )
                }
                editsDb.setTransactionSuccessful()
            } finally { editsDb.endTransaction() }
        } catch (e: Exception) { }
    }

    /** Köhnə kateqoriya adı ilə saxlanmış redaktə/göndərmə qeydlərini "⭐ BARAT"-a köçürür (təkrar çağırış zərərsizdir) */
    private fun migrateBarat() {
        try {
            editsDb.beginTransaction()
            try {
                for (m in BARAT_MOVED) {
                    val a = arrayOf<Any>("⭐ BARAT", m[0], m[1])
                    editsDb.execSQL("UPDATE OR REPLACE edits SET file = ? WHERE file = ? AND sheet = ?", a)
                    editsDb.execSQL("UPDATE OR REPLACE added_rows SET file = ? WHERE file = ? AND sheet = ?", a)
                    editsDb.execSQL("UPDATE OR REPLACE deleted_rows SET file = ? WHERE file = ? AND sheet = ?", a)
                    editsDb.execSQL("UPDATE wa_log SET file = ? WHERE file = ? AND sheet = ?", a)
                    val old = m[0] + "|" + m[1] + "|"
                    editsDb.execSQL(
                        "UPDATE OR REPLACE sent SET skey = ? || substr(skey, ?) WHERE substr(skey, 1, ?) = ?",
                        arrayOf<Any>("⭐ BARAT|" + m[1] + "|", old.length + 1, old.length, old)
                    )
                }
                editsDb.setTransactionSuccessful()
            } finally { editsDb.endTransaction() }
        } catch (e: Exception) { }
    }

    private fun replayDeletes(d: SQLiteDatabase) {
        editsDb.rawQuery("SELECT file, sheet, ord FROM deleted_rows", null).use { c ->
            while (c.moveToNext()) {
                try {
                    d.execSQL(
                        "DELETE FROM rows WHERE ord = ? AND building_id IN (SELECT b.id FROM buildings b JOIN files f ON f.id = b.file_id WHERE f.name = ? AND b.sheet = ?)",
                        arrayOf<Any>(c.getInt(2), c.getString(0), c.getString(1))
                    )
                } catch (e: Exception) { }
            }
        }
    }

    private fun replayEdits(d: SQLiteDatabase) {
        editsDb.rawQuery("SELECT file, sheet, ord, col, value FROM edits", null).use { c ->
            while (c.moveToNext()) {
                d.rawQuery(
                    "SELECT r.id, r.cells, b.headers FROM rows r JOIN buildings b ON b.id = r.building_id " +
                        "JOIN files f ON f.id = b.file_id WHERE f.name = ? AND b.sheet = ? AND r.ord = ?",
                    arrayOf(c.getString(0), c.getString(1), c.getInt(2).toString())
                ).use { r ->
                    if (r.moveToFirst()) {
                        val cells = jsonList(r.getString(1)).toMutableList()
                        val col = c.getInt(3)
                        while (cells.size <= col) cells.add("")
                        cells[col] = c.getString(4)
                        writeRow(d, r.getLong(0), cells, jsonList(r.getString(2)))
                    }
                }
            }
        }
    }

    private fun fold(s: String): String {
        var t = s.replace('İ', 'i').replace('I', 'ı').lowercase(Locale.ROOT)
        t = t.replace('ə', 'e').replace('ı', 'i').replace('ö', 'o').replace('ü', 'u')
            .replace('ş', 's').replace('ç', 'c').replace('ğ', 'g')
        return t.trim().replace(Regex("\\s+"), " ")
    }

    private fun jsonList(s: String): List<String> {
        val a = JSONArray(s); return List(a.length()) { a.getString(it) }
    }

    private fun colIdx(headers: List<String>, prefix: String) = headers.indexOfFirst { fold(it).startsWith(prefix) }

    /** Ad, Soyad, Atasının adı və Borc sütunları əl ilə redaktə olunmur (saytdan yenilənir) */
    private fun isReadOnly(h: String): Boolean {
        val f = fold(h)
        return f.startsWith("soyad") || f.startsWith("ad, soyad") || f.startsWith("ad,soyad") || f == "borc"
    }

    private fun nameIdx(headers: List<String>) = headers.indexOfFirst { isReadOnly(it) && fold(it) != "borc" }

    private fun parseNum(s: String): Double =
        s.replace("\u00A0", "").replace(" ", "").replace(',', '.').toDoubleOrNull() ?: 0.0

    private fun money(v: Double) = String.format(Locale.US, "%.2f", v)
    private fun totalText(borc: Double, count: Int) = "Ümumi Borc (${money(borc)}) / Ümumi Mənzil ($count)"

    private fun writeRow(d: SQLiteDatabase, id: Long, cells: List<String>, headers: List<String>) {
        d.execSQL("UPDATE rows SET cells = ? WHERE id = ?", arrayOf<Any>(JSONArray(cells).toString(), id))
        val mi = colIdx(headers, "menzil")
        if (mi >= 0 && mi < cells.size) d.execSQL("UPDATE rows SET menzil = ?, menzil_n = ? WHERE id = ?", arrayOf<Any>(cells[mi], fold(cells[mi]), id))
        val ni = colIdx(headers, "nomre")
        if (ni >= 0 && ni < cells.size) d.execSQL("UPDATE rows SET nomre_d = ? WHERE id = ?", arrayOf<Any>(cells[ni].filter { it.isDigit() }, id))
        val si = nameIdx(headers)
        if (si >= 0 && si < cells.size) {
            val toks = cells[si].trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
            val so = toks.getOrElse(0) { "" }; val ad = toks.getOrElse(1) { "" }; val at = toks.drop(2).joinToString(" ")
            d.execSQL(
                "UPDATE rows SET soyad = ?, ad = ?, ata = ?, soyad_n = ?, ad_n = ?, ata_n = ? WHERE id = ?",
                arrayOf<Any>(so, ad, at, fold(so), fold(ad), fold(at), id)
            )
        }
        val bi = colIdx(headers, "borc")
        if (bi >= 0 && bi < cells.size) d.execSQL("UPDATE rows SET borc = ? WHERE id = ?", arrayOf<Any>(parseNum(cells[bi]), id))
    }

    private fun rowOf(vararg items: Pair<View, Float>): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            items.forEachIndexed { i, (v, w) ->
                addView(v, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, w).apply {
                    if (i > 0) leftMargin = dp(6)
                })
            }
        }

    // ---------- əl ilə redaktə ----------
    private fun showEditDialog(card: Card, onDeleted: () -> Unit = {}, onSaved: (List<String>) -> Unit) {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val inputs = arrayOfNulls<EditText>(card.headers.size)
        for (i in card.headers.indices) {
            val h = card.headers[i]
            val v = card.cells.getOrNull(i).orEmpty()
            val label = TextView(this)
            label.text = h; label.textSize = 12f; label.setTextColor(Color.parseColor("#B3B3BD")); label.setPadding(0, dp(10), 0, 0)
            col.addView(label)
            if (isReadOnly(h)) {
                val t = TextView(this)
                t.text = (if (v.isEmpty()) "—" else v) + "   🔒"; t.textSize = 15f; t.setTextColor(Color.parseColor("#B3B3BD"))
                col.addView(t)
            } else {
                val e = EditText(this)
                e.setText(v); e.textSize = 15f; e.isSingleLine = true
                inputs[i] = e
                col.addView(e)
            }
        }
        val sv = ScrollView(this)
        sv.setPadding(dp(20), dp(8), dp(20), 0)
        sv.addView(col)
        val dialog = AlertDialog.Builder(this)
            .setTitle("Redaktə et")
            .setView(sv)
            .setPositiveButton("Yadda saxla") { _, _ -> saveEdit(card, inputs, onSaved) }
            .setNegativeButton("Ləğv et", null)
            .setNeutralButton("🗑 Sil") { _, _ -> confirmDelete(card, onDeleted) }
            .create()
        dialog.show()
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL)?.setTextColor(Color.parseColor("#FF6B6B"))
    }

    private fun confirmDelete(card: Card, onDeleted: () -> Unit) {
        val nm = nameOf(card).ifEmpty { cellOf(card, "menzil") }
        AlertDialog.Builder(this)
            .setTitle("Sil")
            .setMessage((if (nm.isNotEmpty()) "«$nm»\n\n" else "") + "Bu mənzil bazadan silinsin?")
            .setPositiveButton("Sil") { _, _ -> deleteRow(card); onDeleted() }
            .setNegativeButton("Ləğv et", null)
            .show()
    }

    private fun deleteRow(card: Card) {
        val clBefore = ChangeLog.snapshot(editsDb)
        try {
            db.rawQuery(
                "SELECT f.name, b.sheet, r.ord FROM rows r JOIN buildings b ON b.id = r.building_id " +
                    "JOIN files f ON f.id = b.file_id WHERE r.id = ?", arrayOf(card.rowId.toString())
            ).use { c ->
                if (c.moveToFirst()) {
                    val fname = c.getString(0); val sheet = c.getString(1) ?: ""; val ord = c.getInt(2)
                    editsDb.execSQL("INSERT OR REPLACE INTO deleted_rows VALUES(?,?,?)", arrayOf<Any>(fname, sheet, ord))
                    editsDb.execSQL("DELETE FROM edits WHERE file = ? AND sheet = ? AND ord = ?", arrayOf<Any>(fname, sheet, ord))
                    editsDb.execSQL("DELETE FROM added_rows WHERE file = ? AND sheet = ? AND ord = ?", arrayOf<Any>(fname, sheet, ord))
                }
            }
            db.execSQL("DELETE FROM rows WHERE id = ?", arrayOf<Any>(card.rowId))
            if (card.skey.isNotEmpty()) {
                sentSet.remove(card.skey + "|sms"); sentSet.remove(card.skey + "|wa")
                editsDb.execSQL("DELETE FROM sent WHERE skey = ?", arrayOf<Any>(card.skey))
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Xəta: ${e.message}", Toast.LENGTH_LONG).show(); return
        }
        Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
        ChangeLog.record(editsDb, "🗑 Mənzil silindi: " + clLabel(card), clBefore)
        scheduleSync()
    }

    private fun clLabel(card: Card): String =
        (if (card.bname.isNotBlank()) card.bname + " · " else "") + nameOf(card).ifEmpty { cellOf(card, "menzil") }

    private fun saveEdit(card: Card, inputs: Array<EditText?>, onSaved: (List<String>) -> Unit) {
        val clBefore = ChangeLog.snapshot(editsDb)
        val clChanges = ArrayList<String>()
        val newCells = card.cells.toMutableList()
        while (newCells.size < card.headers.size) newCells.add("")
        db.rawQuery(
            "SELECT f.name, b.sheet, r.ord FROM rows r JOIN buildings b ON b.id = r.building_id " +
                "JOIN files f ON f.id = b.file_id WHERE r.id = ?", arrayOf(card.rowId.toString())
        ).use { c ->
            if (c.moveToFirst()) {
                val fname = c.getString(0); val sheet = c.getString(1); val ord = c.getInt(2)
                for (i in inputs.indices) {
                    val e = inputs[i] ?: continue
                    val nv = e.text.toString().trim()
                    if (nv != newCells[i]) {
                        clChanges.add(card.headers.getOrElse(i) { "" } + ": " + newCells[i].ifBlank { "—" } + " → " + nv.ifBlank { "—" })
                        newCells[i] = nv
                        editsDb.execSQL("INSERT OR REPLACE INTO edits VALUES(?,?,?,?,?)", arrayOf<Any>(fname, sheet, ord, i, nv))
                    }
                }
            }
        }
        writeRow(db, card.rowId, newCells, card.headers)
        onSaved(newCells)
        Toast.makeText(this, "Yadda saxlanıldı", Toast.LENGTH_SHORT).show()
        if (clChanges.isNotEmpty()) ChangeLog.record(editsDb, "✏️ Redaktə: " + clLabel(card) + "\n" + clChanges.joinToString("; "), clBefore)
        scheduleSync()
    }

    // =====================================================================
    //  Saytdan yeniləmə (Soyad, Ad, Atasının adı və Borc)
    // =====================================================================
    data class Job(val rowId: Long, val yvok: String, val notify: Boolean = false, val barat: Boolean = false, var retried: Boolean = false, var seq: Int = 0, val grp: Long = 0) {
        var t0 = 0L                       // bu keçidin başlama vaxtı (toplu yeniləmədə ümumi vaxt limiti üçün)
        var ebelTried = false             // e-belediyye bu kod üçün sınanıb, cavab gəlməyib
        var yeloTried = false             // yelo.az bu kod üçün artıq sınanıb (uğursuz)
        var hesabTried = false            // hesab.az bu kod üçün artıq sınanıb (uğursuz)
        var portTried = false             // portmanat.az bu kod üçün artıq sınanıb (uğursuz)
        var portTries = 0                 // diaqnostika üçün Portmanat cəhd sayı
        var nf = 0                        // xarici mənbələrin bu kod üçün "tapılmadı" deməsi sayı (2 mənbə tapmadısa kod "tapılmadı" sayılır)
        var race: SingleRace? = null      // tək mənzil yeniləməsi: e-belediyye və hesab.az eyni anda yoxlanılır
    }
    /** Tək mənzil: dörd mənbə (e-belediyye, hesab.az, yelo.az, portmanat.az) yarışır, ilk düzgün cavab qazanır. ebel/hesab: 0 = davam edir, 1 = tapılmadı, 2 = xəta */
    class SingleRace {
        var won = false; var ebel = 0; var hesab = 0; var yelo = 0; var port = 0
        fun claim(): Boolean { if (won) return false; won = true; return true }
    }
    data class Parsed(val name: String?, val borc: String?, val notFound: Boolean, val raw: String)

    private fun validYvok(v: String): Boolean {
        val t = v.trim()
        return t.length == 12 && t.startsWith("10011") && t.none { it.isWhitespace() }
    }

    /** scopeSql/arg və ya ids əsasında yenilənəcək mənzilləri toplayıb (arxa planda) işə salır */
    private fun startRefresh(label: String, scopeSql: String?, arg: String?, ids: List<Long>?) {
        if (refresher != null) { Toast.makeText(this, "Yenilənmə artıq davam edir", Toast.LENGTH_SHORT).show(); return }
        Thread {
            val jobs = ArrayList<Job>()
            val bKeys = ArrayList<Long>()                 // hər işin bina id-si (mənzil sıralaması üçün)
            val aKeys = ArrayList<Pair<Int, String>?>()   // hər işin mənzil nömrəsi: (rəqəm, hərf)
            var noYvok = 0
            val sql: String; val args: Array<String>
            if (ids != null) {
                if (ids.isEmpty()) { sql = ""; args = emptyArray() }
                else {
                    sql = "SELECT r.id, r.cells, b.headers, (SELECT 1 FROM files f WHERE f.id = b.file_id AND UPPER(COALESCE(NULLIF(f.disp, ''), f.name)) LIKE '%BARAT%'), b.street_id, b.id FROM rows r JOIN buildings b ON b.id = r.building_id LEFT JOIN files f2 ON f2.id = b.file_id LEFT JOIN streets s2 ON s2.id = b.street_id WHERE r.id IN (" +
                        ids.joinToString(",") + ") ORDER BY CASE WHEN UPPER(COALESCE(NULLIF(f2.disp, ''), f2.name)) LIKE '%BARAT%' THEN 0 ELSE 1 END, f2.ord, COALESCE(s2.ord, 0), b.ord, r.ord"
                    args = emptyArray()
                }
            } else {
                sql = "SELECT r.id, r.cells, b.headers, (SELECT 1 FROM files f WHERE f.id = b.file_id AND UPPER(COALESCE(NULLIF(f.disp, ''), f.name)) LIKE '%BARAT%'), b.street_id, b.id FROM rows r JOIN buildings b ON b.id = r.building_id LEFT JOIN files f2 ON f2.id = b.file_id LEFT JOIN streets s2 ON s2.id = b.street_id " +
                    (if (scopeSql != null) "WHERE $scopeSql " else "") + "ORDER BY CASE WHEN UPPER(COALESCE(NULLIF(f2.disp, ''), f2.name)) LIKE '%BARAT%' THEN 0 ELSE 1 END, f2.ord, COALESCE(s2.ord, 0), b.ord, r.ord"
                args = if (arg != null) arrayOf(arg) else emptyArray()
            }
            if (sql.isNotEmpty()) {
                try {
                    db.rawQuery(sql, args).use { c ->
                        while (c.moveToNext()) {
                            val headers = jsonList(c.getString(2))
                            val yi = colIdx(headers, "yvok")
                            val cells = jsonList(c.getString(1))
                            val v = if (yi >= 0 && yi < cells.size) cells[yi].trim() else ""
                            if (validYvok(v)) {
                                jobs.add(Job(c.getLong(0), v, false, c.getInt(3) == 1, false, jobs.size, c.getLong(4)))
                                bKeys.add(c.getLong(5))
                                val mi = colIdx(headers, "menzil")
                                val am = if (mi >= 0 && mi < cells.size) Regex("^(\\d+)\\s*([^\\d\\s]*)").find(cells[mi].trim()) else null
                                aKeys.add(if (am != null) Pair(am.groupValues[1].toIntOrNull() ?: 0, am.groupValues[2].lowercase()) else null)
                            } else noYvok++
                        }
                    }
                } catch (e: Exception) { /* ignore */ }
            }
            // YVÖK-lər siyahıdakı sıra ilə götürülür: əvvəl BARAT, sonra fayl → küçə → bina → mənzil sırası
            // hər binada mənzillər 1-ci mənzildən başlayaraq nömrəyə görə düzülür (binada mənzil nömrəsi olmayan sətir varsa bina olduğu sırada qalır)
            val sorted = ArrayList<Job>(jobs.size)
            var i0 = 0
            while (i0 < jobs.size) {
                var i1 = i0
                while (i1 < jobs.size && bKeys[i1] == bKeys[i0]) i1++
                val idx = (i0 until i1).toMutableList()
                if (idx.all { aKeys[it] != null }) idx.sortWith(compareBy<Int>({ aKeys[it]!!.first }, { aKeys[it]!!.second }, { it }))
                for (k in idx) sorted.add(jobs[k])
                i0 = i1
            }
            for ((n, j) in sorted.withIndex()) j.seq = n
            runOnUiThread { confirmRefresh(label, sorted, noYvok) }
        }.start()
    }

    private fun confirmRefresh(label: String, jobs: List<Job>, noYvok: Int) {
        if (jobs.isEmpty()) {
            Toast.makeText(this, "Yenilənəcək YVÖK tapılmadı", Toast.LENGTH_LONG).show(); return
        }
        val go = { launchRefresh(jobs, noYvok) }
        if (jobs.size > 100) {
            val mins = Math.max(1, (jobs.size * 0.05 / 60).toInt())
            AlertDialog.Builder(this)
                .setTitle("Saytdan yenilə")
                .setMessage("$label\n${jobs.size} mənzil yenilənəcək (təxminən $mins dəq). Yenilənmə zamanı tətbiq açıq qalmalıdır.\n\nDavam edilsin?")
                .setPositiveButton("Bəli") { _, _ -> go() }
                .setNegativeButton("Xeyr", null)
                .show()
        } else go()
    }

    private fun launchRefresh(jobs: List<Job>, noYvok: Int, silent: Boolean = false) {
        val r = Refresher(ArrayList(jobs), noYvok, silent)
        refresher = r
        r.start()
    }

    /** Saytın cavabından ad və borcu çıxarır */
    private fun parseResult(base: String, text: String): Parsed {
        val baseLines = base.lines().map { it.trim() }.toSet()
        val lines = text.lines().map { it.trim() }
            .filter { it.isNotEmpty() && it !in baseLines && !it.startsWith("Yoxlanılır") }
        val raw = lines.joinToString("\n")
        val ff = lines.map { fold(it) }

        // ---- borc ----
        val numRe = Regex("""-?\d+(?:[ \u00A0]\d{3})*(?:[.,]\d{1,2})?""")
        fun norm(s: String): String {
            val d = s.replace("\u00A0", "").replace(" ", "").replace(',', '.').toDoubleOrNull() ?: 0.0
            return if (d == Math.floor(d)) d.toLong().toString() else money(d)
        }
        // ---- saytın əsas nəticə formatı:
        // "10011MBM2046 / MUSTAFAYEV BARAT MEHDİ adına Binəqədi bələdiyyəsi üzrə olan vergi borcu: 0 manat." ----
        val joined = lines.joinToString(" ").replace(Regex("\\s+"), " ")
        val mainRe = Regex("""(\S+)\s*/\s*(.+?)\s+ad[ıiİI]na\s.*?borcu\s*:\s*(-?\d[\d\u00A0 ]*(?:[.,]\d{1,2})?)""", RegexOption.IGNORE_CASE)
        val mm = mainRe.find(joined)
        if (mm != null) {
            val fullName = mm.groupValues[2].replace(Regex("\\s+"), " ").trim()
            return Parsed(fullName.ifEmpty { null }, norm(mm.groupValues[3].trim()), false, raw)
        }

        var borc: String? = null
        for (i in lines.indices) {
            if (!ff[i].contains("borc")) continue
            val after = if (lines[i].contains(':')) lines[i].substringAfter(':') else lines[i]
            val m = numRe.find(after)
            if (m != null) { borc = norm(m.value); break }
            if (ff[i].contains("yoxdur") || ff[i].contains("olmayib") || ff[i].contains("qalmayib")) { borc = "0"; break }
            if (i + 1 < lines.size && lines[i + 1].length < 30) {
                val m2 = numRe.find(lines[i + 1])
                if (m2 != null) { borc = norm(m2.value); break }
            }
        }
        if (borc == null) {
            val m = Regex("""(\d+(?:[.,]\d{1,2})?)\s*(?:azn|₼|manat)""", RegexOption.IGNORE_CASE).find(raw)
            if (m != null) borc = norm(m.groupValues[1])
        }

        // ---- ad, soyad, atasının adı ----
        var name: String? = null
        var soyad: String? = null; var ad: String? = null; var ata: String? = null
        for (i in lines.indices) {
            val f = ff[i]
            if (f.contains("borc")) continue
            val label = f.substringBefore(':').trim()
            fun value(): String? {
                val v = if (lines[i].contains(':')) lines[i].substringAfter(':').trim() else ""
                if (v.isNotEmpty()) return v
                if (i + 1 < lines.size && !ff[i + 1].contains("borc")) return lines[i + 1]
                return null
            }
            when {
                label == "soyad" -> soyad = soyad ?: value()
                label == "ad" -> ad = ad ?: value()
                label.startsWith("ata") -> ata = ata ?: value()
                name == null && (label.startsWith("soyad") || label.startsWith("ad, soyad") || label.startsWith("ad soyad") ||
                    label.contains("vetendas") || label.contains("mulkiyyetci") || label.contains("sahibi") || label.contains("ad, ")) -> name = value()
            }
        }
        if (soyad != null || ad != null) {
            name = listOfNotNull(soyad, ad, ata).joinToString(" ")
        }
        if (name == null) {
            // etiketsiz: rəqəmsiz, ən azı 2 sözlü, hərflərdən ibarət ilk sətir
            for (i in lines.indices) {
                val l = lines[i]; val f = ff[i]
                if (f.contains("borc") || f.contains("tapilmadi") || f.contains("yoxdur") || f.contains("deyil") || f.contains("yvok")) continue
                if (l.any { it.isDigit() } || l.contains(':')) continue
                if (l.trim().split(Regex("\\s+")).size >= 2) { name = l.trim(); break }
            }
        }
        val notFound = borc == null && name == null &&
            (ff.any { it.contains("tapilmadi") || it.contains("movcud deyil") || it.contains("duzgun deyil") || it.contains("melumat yoxdur") })
        return Parsed(name?.replace(Regex("\\s+"), " ")?.trim(), borc, notFound, raw)
    }

    /** nəticəni bazaya yazır; redaktə/yeniləmə qeydi ayrıca faylda da saxlanılır */
    /** saytda tapılmadı cavabı da yeniləmə sayılır: mənzilin bina vərəqinin son yenilənmə vaxtı yazılır */
    private fun touchRowSheet(rowId: Long) {
        db.rawQuery("SELECT f.name, b.sheet FROM rows r JOIN buildings b ON b.id = r.building_id JOIN files f ON f.id = b.file_id WHERE r.id = ?", arrayOf(rowId.toString())).use { c ->
            if (c.moveToFirst()) editsDb.execSQL("INSERT OR REPLACE INTO sheet_upd VALUES(?,?,?)", arrayOf<Any>(c.getString(0), c.getString(1) ?: "", System.currentTimeMillis()))
        }
    }

    private fun applyFetched(rowId: Long, name: String?, borc: String?) {
        db.rawQuery(
            "SELECT r.cells, b.headers, f.name, b.sheet, r.ord FROM rows r JOIN buildings b ON b.id = r.building_id " +
                "JOIN files f ON f.id = b.file_id WHERE r.id = ?", arrayOf(rowId.toString())
        ).use { c ->
            if (!c.moveToFirst()) return
            val cells = jsonList(c.getString(0)).toMutableList()
            val headers = jsonList(c.getString(1))
            val fname = c.getString(2); val sheet = c.getString(3); val ord = c.getInt(4)
            try { editsDb.execSQL("INSERT OR REPLACE INTO sheet_upd VALUES(?,?,?)", arrayOf<Any>(fname, sheet ?: "", System.currentTimeMillis())) } catch (e: Exception) { }
            while (cells.size < headers.size) cells.add("")
            var changed = false
            fun setCol(i: Int, v: String) {
                if (i >= 0 && i < cells.size && cells[i] != v) {
                    cells[i] = v
                    editsDb.execSQL("INSERT OR REPLACE INTO edits VALUES(?,?,?,?,?)", arrayOf<Any>(fname, sheet, ord, i, v))
                    changed = true
                }
            }
            val bi = colIdx(headers, "borc")
            val oldB = if (bi >= 0 && bi < cells.size) cells[bi] else ""
            if (name != null) setCol(nameIdx(headers), name)
            if (borc != null) setCol(bi, borc)
            if (borc != null && bi >= 0 && parseNum(oldB) != parseNum(borc)) {
                try {
                    val mi = colIdx(headers, "menzil"); val ni = nameIdx(headers)
                    val mz = if (mi >= 0 && mi < cells.size) cells[mi] else ""
                    val nm = if (ni >= 0 && ni < cells.size) cells[ni] else ""
                    val label = (sheet ?: "") + " · mənzil " + mz + (if (nm.isNotBlank()) " · $nm" else "")
                    editsDb.execSQL("INSERT INTO debt_log VALUES(?,?,?,?,?)",
                        arrayOf<Any>("$fname|${sheet ?: ""}|$ord", label, parseNum(oldB), parseNum(borc), System.currentTimeMillis()))
                } catch (e: Exception) { }
            }
            if (changed) writeRow(db, rowId, cells, headers)
        }
    }

    private val dbWriter = java.util.concurrent.Executors.newSingleThreadExecutor()

    /** Yalnız YVÖK xanası, "Yoxla" düyməsi və nəticə üçün lazım olanlar yüklənir; qalan hər şey (şəkil, şrift, video, fayl, reklam, izləmə) bloklanır */
    private fun blockedResponse(request: WebResourceRequest?): WebResourceResponse? = az.yvok.app.SiteBlocker.intercept(request)

    private fun blockClient() = object : WebViewClient() {
        override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? = blockedResponse(request)
    }

    private fun newHiddenWebView(): WebView {
        val wv = WebView(this)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.blockNetworkImage = true
        wv.settings.loadsImagesAutomatically = false
        wv.settings.mediaPlaybackRequiresUserGesture = true
        wv.settings.setSupportMultipleWindows(false)
        wv.alpha = 0.01f
        wv.webViewClient = blockClient()
        webHost.addView(wv, FrameLayout.LayoutParams(dp(360), dp(640)))
        return wv
    }

    private fun destroyWebView(wv: WebView) {
        try { webHost.removeView(wv); wv.destroy() } catch (e: Exception) { }
    }

    /** gpp.yelo.az üçün ortaq gizli səhifələr (toplu və tək yeniləmə eyni səhifələrdən istifadə edir) */
    private var hesabShared: HesabChecker? = null
    private fun sharedHesab(): HesabChecker? {
        hesabShared?.let { return it }
        if (isFinishing || !::webHost.isInitialized) return null
        val h = try { HesabChecker(this, webHost, 0, dp(360), dp(640), HESAB_PAR) } catch (e: Exception) { return null }
        h.setMaxWait(YELO_WAIT_MS)
        hesabShared = h
        return h
    }
    private var portShared: PortmanatChecker? = null
    private fun sharedPort(): PortmanatChecker? {
        portShared?.let { return it }
        if (isFinishing || !::webHost.isInitialized) return null
        val p = try { PortmanatChecker(this, webHost, 0, dp(360), dp(640), PORT_PAR) } catch (e: Exception) { return null }
        p.setMaxWait(PORT_WAIT_MS)
        p.arm()      // YVÖK xanasındakı kimi: səhifələr öncədən açılır, hər istifadədən sonra təzəsi hazırlanır
        portShared = p
        return p
    }
    private var yeloShared: YeloChecker? = null
    private fun sharedYelo(): YeloChecker? {
        yeloShared?.let { return it }
        if (isFinishing || !::webHost.isInitialized) return null
        val y = try { YeloChecker(this, webHost, 0, dp(360), dp(640), YELO_PAR) } catch (e: Exception) { return null }
        y.setMaxWait(YELO_WAIT_MS)
        yeloShared = y
        return y
    }

    /** təkrar yoxlamadan sonra da yenilənməyən mənzillər: rowId -> səbəb (nəticə kartında "Yenilənmədi" göstərilir) */
    private val failedRows = HashMap<Long, String>()

    inner class Refresher(private val jobs: ArrayList<Job>, private val noYvok: Int, private val silent: Boolean = false) {
        private var total = jobs.size
        // Mənzilin altındakı fərdi "Yenilə" düyməsi: mənbələri sıra ilə yoxla; kütləvi yeniləmə əvvəlki yük bölgüsünü saxlayır.
        private val orderedSingle = jobs.size == 1
        private var done = 0
        private var updated = 0
        private var notFound = 0
        private var failed = 0
        private var cancelled = false
        private var running = 0
        private var pendingWrites = 0     // bazaya hələ yazılmayan nəticələr (yazma arxa planda gedir)
        private val limit = WORKERS
        private var finished = false
        private var retryRound = 0        // 0 = ilk keçid, 1 = xəta verənlərin təkrar yoxlanması
        private val retryQueue = ArrayList<Job>()                 // ilk keçiddə xəta verənlər: sonda təkrar yoxlanılır
        private val failedList = ArrayList<Pair<String, String>>() // təkrar yoxlamadan sonra da alınmayan kodlar: (kod, səbəb)
        private val activeCodes = LinkedHashSet<String>()          // hazırda yoxlanılan kodlar
        private val logLines = java.util.ArrayDeque<String>()      // kod + status siyahısı
        private var logDirty = false
        private val workers = ArrayList<Worker>()
        // küçə-küçə sıra: növbəti küçəyə yalnız cari küçənin bütün YVÖK-ləri cavab alanda keçilir (küçə daxilində 8 işçi paralel, sıra ilə)
        private var curGrp = Long.MIN_VALUE
        private var inFlight = 0
        private val parked = ArrayList<Worker>()
        private fun wakeParked() {
            val l = ArrayList(parked); parked.clear()
            for (w in l) ui.post { if (!finished && !cancelled) w.next() }
        }
        // ---- yük bölüşdürmə: e-belediyye və yelo.az (tək mənzildə yox, toplu yeniləmədə) ----
        private var yelo: YeloChecker? = null
        private var rr = 0                       // növbə ilə bölüşdürmə sayğacı
        private var ebelFails = 0; private var yeloFails = 0           // ardıcıl uğursuzluq sayı
        private var ebelDownUntil = 0L; private var yeloDownUntil = 0L // sayt "dayanıb" sayılır: bu vaxta qədər kodlar digər sayta gedir
        private var ebelCount = 0; private var yeloCount = 0           // hansı saytdan neçə nəticə alınıb
        private fun nowMs() = SystemClock.elapsedRealtime()
        private fun overBudget(j: Job) = !orderedSingle && j.race == null && j.t0 > 0L && nowMs() - j.t0 > JOB_BUDGET_MS
        private fun ebelDown() = nowMs() < ebelDownUntil
        private fun yeloDown() = nowMs() < yeloDownUntil
        private fun yeloChecker(): YeloChecker? {
            yelo?.let { return it }
            val y = sharedYelo() ?: return null
            y.clear()
            y.warmUp()
            yelo = y
            return y
        }
        private fun ebelOk() = srcOk(SRC_E)
        private fun ebelBad() = srcBad(SRC_E)
        private fun yeloOk() = srcOk(SRC_Y)
        private fun yeloBad() = srcBad(SRC_Y)
        // portmanat.az (toplu yeniləmədə dördüncü sayt)
        private var port: PortmanatChecker? = null
        private var portFails = 0; private var portDownUntil = 0L; private var portCount = 0
        private fun portDown() = nowMs() < portDownUntil
        private fun portChecker(): PortmanatChecker? {
            port?.let { return it }
            val p = sharedPort() ?: return null
            p.clear()
            port = p
            return p
        }
        private fun portOk() = srcOk(SRC_P)
        private fun portBad() = srcBad(SRC_P)
        // hesab.az (toplu yeniləmədə üçüncü sayt)
        private var hesab: HesabChecker? = null
        private var hesabFails = 0; private var hesabDownUntil = 0L; private var hesabCount = 0
        private fun hesabDown() = nowMs() < hesabDownUntil
        private fun hesabChecker(): HesabChecker? {
            hesab?.let { return it }
            val h = sharedHesab() ?: return null
            h.clear()
            hesab = h
            return h
        }
        private fun hesabOk() = srcOk(SRC_H)
        private fun hesabBad() = srcBad(SRC_H)

        private val SRC_E = 0; private val SRC_Y = 1; private val SRC_H = 2; private val SRC_P = 3
        // ---- mənbə dayananda: qalan mənbələr 40 / 40 / 30 bölünür, dayanan mənbə isə hər 10 san bir kodla yenidən yoxlanılır ----
        private val probeAt = LongArray(4)
        private val probing = BooleanArray(4)        // dayanmış mənbədə hazırda yoxlama kodu işləyir (eyni anda yalnız biri)
        private val failsArr = IntArray(4)
        private var lastMask = 15
        private fun downUntilOf(s: Int) = when (s) { SRC_Y -> yeloDownUntil; SRC_H -> hesabDownUntil; SRC_P -> portDownUntil; else -> ebelDownUntil }
        private fun setDownUntil(s: Int, v: Long) { when (s) { SRC_Y -> yeloDownUntil = v; SRC_H -> hesabDownUntil = v; SRC_P -> portDownUntil = v; else -> ebelDownUntil = v } }
        private fun hardDown(s: Int) = nowMs() < downUntilOf(s)
        /** mənbə işləyir; ya da dayanıb, amma yoxlama vaxtı çatıb və hazırda yoxlayan kod yoxdur */
        private fun usable(s: Int) = !hardDown(s) || (nowMs() >= probeAt[s] && !probing[s])
        private fun srcOk(s: Int) {
            val was = downUntilOf(s) > 0L
            failsArr[s] = 0; probing[s] = false; setDownUntil(s, 0L)
            if (was) addLog("✓ ${srcName(s)} yenidən cavab verir: pay bərpa olundu")
        }
        private fun srcBad(s: Int) {
            if (probing[s]) {                          // yoxlama kodu da cavab almadı: mənbə dayanmış qalır, 10 san sonra yenə yoxlanılacaq
                probing[s] = false
                setDownUntil(s, nowMs() + DOWN_MS); probeAt[s] = nowMs() + PROBE_MS
                return
            }
            if (++failsArr[s] >= 3) {
                failsArr[s] = 0
                if (!hardDown(s)) addLog("⚠ ${srcName(s)} cavab vermir: yük qalan saytlar arasında 40/40/20 (üç mənbə), 50/50 (iki mənbə) bölünür, mənbə hər 10 san yenidən yoxlanılır")
                setDownUntil(s, nowMs() + DOWN_MS); probeAt[s] = nowMs() + PROBE_MS
            }
        }
        /** Mənbə payı: Yelo 30%, Portmanat 30%, e-bələdiyyə 20%, hesab.az 20%. Mənbələrdən biri işləməyəndə: Yelo 40, Portmanat 40, qalan 20 (digərlər arasında bərabər). */
        private val asg = IntArray(4)            // hər mənbəyə hazırda verilmiş (uğursuz olub geri qaytarılmayan) kod sayı
        /** Pay işləyən mənbələrin sayına görə: 4 -> Yelo 30 / Portmanat 30 / e-bələdiyyə 20 / hesab.az 20; 3 -> Yelo 40 / Portmanat 40 / digəri 20; 2 -> 50 / 50; 1 -> 100. Dayanmış mənbə (yalnız yoxlama kodu) çəki 1 alır. */
        private fun wFor(s: Int, mask: Int): Double {
            if (mask and (1 shl s) == 0) return 1.0
            val n = Integer.bitCount(mask)
            val yp = (mask and (1 shl SRC_Y)) != 0 && (mask and (1 shl SRC_P)) != 0
            val isYP = s == SRC_Y || s == SRC_P
            return when {
                n >= 4 -> if (isYP) 30.0 else 20.0
                n == 3 -> if (yp) (if (isYP) 40.0 else 20.0) else (if (isYP) 40.0 else 30.0)
                n == 2 -> 50.0
                else -> 100.0
            }
        }
        private fun srcName(s: Int) = when (s) { SRC_Y -> "yelo.az"; SRC_H -> "hesab.az"; SRC_P -> "portmanat.az"; else -> "e-belediyye" }
        /** Əlçatan mənbələr arasından hədəf payına ən çox geri qalanı seçir (verilmiş say / pay ən kiçik olan). */
        private fun wpick(c: List<Int>, equal: Boolean = false): Int {
            val mask = (if (hardDown(SRC_E)) 0 else 1 shl SRC_E) or (if (hardDown(SRC_Y)) 0 else 1 shl SRC_Y) or (if (hardDown(SRC_H)) 0 else 1 shl SRC_H) or (if (hardDown(SRC_P)) 0 else 1 shl SRC_P)
            if (mask != lastMask) { lastMask = mask; java.util.Arrays.fill(asg, 0) }   // işləyən mənbələrin tərkibi dəyişdi: pay yenidən hesablanır
            var best = c[0]; var bv = Double.MAX_VALUE
            for (s in c) { val v = asg[s].toDouble() / wFor(s, mask); if (v < bv) { bv = v; best = s } }
            return best
        }
        private fun hesabOut(j: Job) = hesabDown() || j.hesabTried
        /** bu kod üçün yelo.az / hesab.az uyğundurmu: işləyir, bu kod üçün sınanmayıb və növbəsində yer var */
        private fun sourceInUse(src: Int) = workers.count { it.assignedSource == src }
        private fun yeloOkFor(j: Job): Boolean { val y = yeloChecker() ?: return false; return !j.yeloTried && usable(SRC_Y) && sourceInUse(SRC_Y) < YELO_PAR && y.load() < YELO_PAR }
        private fun hesabOkFor(j: Job): Boolean { val h = hesabChecker() ?: return false; return !j.hesabTried && usable(SRC_H) && sourceInUse(SRC_H) < HESAB_PAR && h.load() < HESAB_PAR }
        private fun portOkFor(j: Job): Boolean { val p = portChecker() ?: return false; return !j.portTried && usable(SRC_P) && sourceInUse(SRC_P) < PORT_PAR && p.load() < PORT_PAR }
        /** Xarici mənbələrdən uyğun olanları qaytarır: vaxtı bitmiş/sınanmış sayt ikinci dəfə seçilmir. */
        /** Növbənin sonu: gözləyən kod qalmayıb və bu, sonuncu işlənən YVÖK-dür. Hesab.az yavaş olduğu üçün ona verilmir;
         *  istisna: digər 3 mənbənin hamısı bu kod üçün artıq sınanıbsa, ehtiyat kimi qalır. */
        private fun skipHesabAtTail(j: Job): Boolean {
            if (orderedSingle || jobs.isNotEmpty() || retryQueue.isNotEmpty() || inFlight > 3) return false
            return !(j.ebelTried && j.yeloTried && j.portTried)
        }
        private fun externalSources(j: Job): List<Int> {
            val c = ArrayList<Int>(3)
            if (yeloOkFor(j)) c.add(SRC_Y)
            if (hesabOkFor(j) && !skipHesabAtTail(j)) c.add(SRC_H)
            if (portOkFor(j)) c.add(SRC_P)
            return c
        }
        /** e-belediyye cavab verməyəndə digər aktiv mənbələrdən birinə keçir. */
        private fun altSource(j: Job): Int {
            val c = externalSources(j)
            return if (c.isEmpty()) -1 else wpick(c)
        }
        /** Növbənin sonunda (gözləyən kod yoxdur, işləyən ≤ 3) mənbələrin gözləmə həddi qısalır: artıq işləyən sorğular da bu həddə görə vaxt aşımına düşür və kod digər mənbəyə keçir. */
        private fun applyTailWaits() {
            if (orderedSingle) return
            val tail = jobs.isEmpty() && retryQueue.isEmpty() && inFlight <= 3
            try {
                yelo?.setMaxWait(if (tail) TAIL_EXT_WAIT_MS else YELO_WAIT_MS)
                port?.setMaxWait(if (tail) TAIL_EXT_WAIT_MS else PORT_WAIT_MS)
                hesab?.setMaxWait(if (tail) TAIL_HESAB_WAIT_MS else YELO_WAIT_MS)
            } catch (e: Exception) { }
        }
        /** Fərdi mənzildə mənbə ardıcıllığı sabitdir; çoxmənzilli yeniləmədə əvvəlki yük bölgüsü qalır. */
        private fun pickSource(j: Job): Int {
            if (orderedSingle) return when {
                !j.yeloTried -> SRC_Y
                !j.ebelTried -> SRC_E
                !j.hesabTried -> SRC_H
                !j.portTried -> SRC_P
                else -> -1
            }
            val tail = jobs.isEmpty() && retryQueue.isEmpty() && inFlight <= 3
            applyTailWaits()
            if (tail) {                                   // son 1-3 YVÖK: hamısı bir sayta yığılmır, ən az məşğul olan mənbəyə (yelo.az / portmanat.az / e-bələdiyyə) verilir; hesab.az gözlənilmir
                var best = -1; var bu = Int.MAX_VALUE
                if (yeloOkFor(j)) { val u = sourceInUse(SRC_Y); if (u < bu) { bu = u; best = SRC_Y } }
                if (portOkFor(j)) { val u = sourceInUse(SRC_P); if (u < bu) { bu = u; best = SRC_P } }
                if (!j.ebelTried && usable(SRC_E) && sourceInUse(SRC_E) < EBEL_PAR) { val u = sourceInUse(SRC_E); if (u < bu) { bu = u; best = SRC_E } }
                if (best >= 0) return best
            }
            val c = ArrayList<Int>(4)
            if (!j.ebelTried && usable(SRC_E) && sourceInUse(SRC_E) < EBEL_PAR) c.add(SRC_E)
            c.addAll(externalSources(j))
            if (c.isNotEmpty()) return wpick(c)
            // Bütün mənbələr qısa müddətlik doludursa, uyğun səhifəsi olan mənbəni növbəyə ver.
            return when {
                !j.ebelTried -> SRC_E
                !j.yeloTried -> SRC_Y
                !j.hesabTried && !skipHesabAtTail(j) -> SRC_H
                !j.portTried -> SRC_P
                !j.hesabTried -> SRC_H
                else -> -1          // hamısı sınanıb: e-bələdiyyədə sonsuz təkrar yoxdur
            }
        }

        private lateinit var dialog: AlertDialog
        private lateinit var tvStatus: TextView
        private lateinit var tvActive: TextView
        private lateinit var tvFail: TextView
        private lateinit var failScroll: ScrollView
        private lateinit var logView: TextView
        private lateinit var logScroll: ScrollView
        private lateinit var bar: ProgressBar

        fun start() {
            if (silent) {   // tək mənzil: pəncərəsiz, nəticə Toast ilə göstərilir
                startWorkers(Math.min(limit, total))
                return
            }
            val box = LinearLayout(this@BazaActivity)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(dp(20), dp(16), dp(20), dp(4))
            tvStatus = TextView(this@BazaActivity)
            tvStatus.text = "Sayta qoşulur…"; tvStatus.textSize = 15f
            bar = ProgressBar(this@BazaActivity, null, android.R.attr.progressBarStyleHorizontal)
            bar.max = total
            tvActive = TextView(this@BazaActivity).apply { textSize = 12f; setTextColor(Color.parseColor("#9FB8FF")); maxLines = 2 }
            logView = TextView(this@BazaActivity).apply {
                textSize = 12f; typeface = Typeface.MONOSPACE; setTextColor(Color.parseColor("#D8D8E0")); setTextIsSelectable(true)
                setPadding(dp(8), dp(6), dp(8), dp(6))
            }
            logScroll = ScrollView(this@BazaActivity).apply {
                addView(logView)
                background = GradientDrawable().apply { setColor(Color.parseColor("#0B0B0D")); cornerRadius = dp(8).toFloat(); setStroke(dp(1), Color.parseColor("#232328")) }
            }
            tvFail = TextView(this@BazaActivity).apply {
                textSize = 12f; setTextColor(Color.parseColor("#FF6B6B")); setTextIsSelectable(true); setPadding(dp(4), dp(4), dp(4), dp(4))
            }
            failScroll = ScrollView(this@BazaActivity).apply { addView(tvFail); visibility = View.GONE }
            box.addView(tvStatus)
            box.addView(bar, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
            box.addView(tvActive, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
            box.addView(logScroll, LinearLayout.LayoutParams(-1, dp(230)).apply { topMargin = dp(8) })
            box.addView(failScroll, LinearLayout.LayoutParams(-1, dp(110)).apply { topMargin = dp(8) })
            dialog = AlertDialog.Builder(this@BazaActivity)
                .setTitle("Saytdan yenilənir")
                .setView(box)
                .setCancelable(false)
                .setNegativeButton("Bitti", null)
                .create()
            dialog.show()
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener { stopNow(); try { dialog.dismiss() } catch (e: Exception) { } }   // "Bitti": işləyirsə dayandırır, pəncərəni bağlayır
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            startWorkers(Math.min(limit, total))
        }

        /** hesab.az əvvəl cavab verəndə e-belediyye sorğusu səssizcə dayandırılır */
        fun cancelQuiet() { if (!finished) stopNow() }

        /** "Dayandır": heç nə gözləmədən — növbə boşaldılır, bütün gizli səhifələr dərhal bağlanır, pəncərə nəticəni göstərir */
        private fun stopNow() {
            if (finished) { try { dialog.dismiss() } catch (e: Exception) { }; return }
            cancelled = true
            jobs.clear(); retryQueue.clear(); parked.clear()
            for (w in workers.toList()) w.abort()
            workers.clear()
            running = 0
            addLog("■ Dayandırıldı")
            finish()
        }

        /** n paralel işçi yaradır; səhifələr 10 ms aralıqla başlayır */
        private fun startWorkers(n: Int) {
            val fresh = ArrayList<Worker>()
            for (i in 0 until n) { val w = Worker(); workers.add(w); fresh.add(w); running++ }
            var cold = 0
            fresh.forEach { w ->
                val d = cold * 10L; cold++
                if (d == 0L) w.next() else ui.postDelayed({ if (!finished && !cancelled) w.next() }, d)
            }
        }

        private fun addLog(line: String) {
            if (silent) return
            // pəncərədə yalnız nəticə sətirləri qalır (✓ ✗ ∅ ■); “cavab vermədi”, “başqa sayta verildi”, “bölünür” kimi aralıq xəbərlər göstərilmir
            if (!(line.startsWith("✓") || line.startsWith("✗") || line.startsWith("∅") || line.startsWith("■"))) return
            logLines.addLast(line)
            if (logLines.size > 400) logLines.removeFirst()
            if (!logDirty) { logDirty = true; ui.postDelayed({ logDirty = false; renderLog() }, 100) }
        }

        // ---- nəticə sətirləri yalnız yerləşmə sırası ilə (1-ci mənzildən başlayaraq) jurnala düşür: gec bitən kod özündən sonrakıları gözlədir ----
        private val resBuf = HashMap<Int, String>()      // seq -> nəticə sətri (öz növbəsini gözləyir)
        private val resSkip = HashSet<Int>()             // ilk keçiddə xəta verib təkrara gedənlər: sıra bunları gözləmir
        private var nextSeq = 0
        private fun resultLine(j: Job, line: String) {
            if (silent) return
            if (j.seq < nextSeq) { addLog(line); return }   // təkrar keçid: öz sırası artıq keçib
            resBuf[j.seq] = line
            flushResults(false)
        }
        private fun skipResult(j: Job) {
            if (silent || j.seq < nextSeq) return
            resSkip.add(j.seq)
            flushResults(false)
        }
        private fun flushResults(all: Boolean) {
            while (true) {
                val l = resBuf.remove(nextSeq)
                if (l != null) { addLog(l); nextSeq++; continue }
                if (resSkip.remove(nextSeq)) { nextSeq++; continue }
                break
            }
            if (all && resBuf.isNotEmpty()) {                // yeniləmə bitdi: qalanlar yenə də sıra ilə yazılır
                for (k in resBuf.keys.sorted()) addLog(resBuf[k]!!)
                resBuf.clear()
            }
        }

        private fun renderLog() {
            if (silent) return
            try {
                val red = Color.parseColor("#FF6B6B")
                val sb = android.text.SpannableStringBuilder()
                var first = true
                for (line in logLines) {
                    if (!first) sb.append('\n')
                    first = false
                    val st = sb.length
                    sb.append(line)
                    if (line.startsWith("✗") || line.startsWith("∅")) {
                        sb.setSpan(ForegroundColorSpan(red), st, st + line.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)   // tapılmadı / yenilənmədi
                    } else if (line.startsWith("✓")) {
                        val bi = line.indexOf("(borc:")
                        if (bi >= 0) {
                            val be = line.indexOf(')', bi)
                            val num = line.substring(bi + 6, if (be > 0) be else line.length).trim().replace(',', '.').toDoubleOrNull()
                            if (num != null && num <= 0.0) sb.setSpan(ForegroundColorSpan(red), st, st + line.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)   // borcu 0 olan: YVÖK və borc qırmızı
                        }
                    }
                }
                logView.text = sb
                logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
            } catch (e: Exception) { }
        }

        private fun progress() {
            if (silent) return
            val phase = if (retryRound > 0 && !finished) "Təkrar yoxlama: " else "Yenilənir: "
            tvStatus.text = phase + "$done / $total   (yeniləndi: $updated, tapılmadı: $notFound, yenilənmədi: $failed" +
                (if (retryQueue.isNotEmpty()) ", təkrar gözləyir: ${retryQueue.size}" else "") + ")" +
                (if (yeloCount > 0 || ebelCount > 0 || hesabCount > 0 || portCount > 0) "\nyelo.az: $yeloCount, portmanat.az: $portCount, e-belediyye: $ebelCount, hesab.az: $hesabCount" else "")
            bar.progress = done
            tvActive.text = if (activeCodes.isEmpty() || finished) "" else
                "Yoxlanılan YVÖK: " + activeCodes.take(6).joinToString(", ") + (if (activeCodes.size > 6) " …" else "")
        }

        /** kod uğurla yeniləndi */
        private fun markOk(j: Job, borc: String?, src: String = "") {
            activeCodes.remove(j.yvok)
            failedRows.remove(j.rowId)
            resultLine(j, "✓ ${j.yvok} — Yeniləndi" + (if (borc != null) " (borc: $borc)" else "") + (if (src.isNotEmpty()) " [$src]" else ""))
        }

        /** kod xəta verdi: ilk dəfə — təkrar yoxlama növbəsinə; ikinci dəfə — "Yenilənmədi" */
        private fun markFail(j: Job, reason: String) {
            activeCodes.remove(j.yvok)
            if (cancelled) { progress(); return }
            if (!j.retried) {
                j.retried = true
                j.ebelTried = false; j.yeloTried = false; j.hesabTried = false; j.portTried = false; j.nf = 0   // təkrar keçiddə bütün mənbələr yenidən sınanır
                retryQueue.add(j)
                addLog("⟳ ${j.yvok} — xəta ($reason), təkrar yoxlanılacaq")
                skipResult(j)
                if (j.notify && j.race == null) Toast.makeText(this@BazaActivity, "Xəta, təkrar yoxlanılır…", Toast.LENGTH_SHORT).show()
            } else {
                failed++; done++
                failedList.add(Pair(j.yvok, reason))
                failedRows[j.rowId] = reason
                resultLine(j, "✗ ${j.yvok} — Yenilənmədi ($reason)")
                val rc = j.race
                if (rc != null) { rc.ebel = 2; raceFailToast(rc, j.yvok) }
                else if (j.notify) Toast.makeText(this@BazaActivity, "Yenilənmədi: ${j.yvok}\n$reason", Toast.LENGTH_LONG).show()
            }
            progress()
        }

        /** hər şey bitibsə: xəta verənlər varsa təkrar yoxlama başlayır, yoxsa yeniləmə tamamlanır */
        private fun checkDone() {
            if (finished || running > 0 || pendingWrites > 0) return
            if (retryQueue.isNotEmpty() && !cancelled) startRetry() else finish()
        }

        /** xəta verən kodlar daha az paralel işçi ilə, təzə səhifələrlə yenidən yoxlanılır */
        private fun startRetry() {
            retryRound++
            retryQueue.sortBy { it.seq }; jobs.addAll(retryQueue); retryQueue.clear()   // təkrar yoxlama də yerləşmə sırası ilə
            addLog("⟳ Təkrar yoxlama: ${jobs.size} YVÖK")
            progress()
            startWorkers(Math.min(RETRY_WORKERS, jobs.size))
        }

        /** xəta verənlər dərhal növbəyə qaytarılır və boş işçilər onları paralel götürür */
        private fun pullRetryNow() {
            if (retryRound == 0) { retryRound = 1; addLog("⟳ Təkrar yoxlama: ${retryQueue.size} YVÖK") }
            retryQueue.sortBy { it.seq }; jobs.addAll(retryQueue); retryQueue.clear()   // təkrar yoxlama də yerləşmə sırası ilə
            val extra = Math.min(RETRY_WORKERS - running, jobs.size - 1)   // təkrar yoxlama az paralellə (sayt məhdudlaşdırmasın)
            if (extra > 0) ui.post { if (!finished && !cancelled) startWorkers(Math.min(extra, jobs.size)) }
        }

        /** işçi işini bitirdi: səhifəsi hovuza qayıdır, hamı bitibsə yeniləmə tamamlanır */
        private fun workerFinished(w: Worker) {
            if (workers.remove(w)) {
                running--
                try { w.release(true) } catch (e: Exception) { }
            }
            checkDone()
        }

        private fun finish() {
            if (finished) return
            finished = true
            activeCodes.clear()
            flushResults(true)
            try { yelo?.setMaxWait(YELO_WAIT_MS); port?.setMaxWait(PORT_WAIT_MS); hesab?.setMaxWait(YELO_WAIT_MS) } catch (e: Exception) { }   // sonluq gözləmə həddləri qaytarılır
            try { yelo?.clear(); hesab?.clear(); port?.clear() } catch (e: Exception) { }   // ortaq yelo.az / hesab.az / portmanat.az səhifələri bağlanmır, yalnız sorğular dayandırılır
            yelo = null; hesab = null; port = null
            refresher = null
            // nəticələrin bazaya yazılması bitəndən sonra siyahı təzələnir və server sinxronizasiyası başlayır
            try { dbWriter.execute { ui.post { afterRefresh(); scheduleSync(false) } } } catch (e: Exception) { afterRefresh(); scheduleSync(false) }
            if (silent) return
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            tvStatus.text = "Yeniləndi: $updated, tapılmadı: $notFound, Yenilənmədi: $failed" +
                (if (noYvok > 0) ", YVÖK-sü olmayan: $noYvok" else "") + (if (cancelled) "  (dayandırıldı)" else "")
            bar.progress = done
            tvActive.text = ""
            if (failedList.isNotEmpty()) {
                tvFail.text = "Yenilənməyən YVÖK-lər (${failedList.size}):\n" + failedList.joinToString("\n") { "${it.first} — ${it.second}" }
                failScroll.visibility = View.VISIBLE
            }
            renderLog()
            try {
                dialog.setTitle(if (cancelled) "Dayandırıldı" else "Yeniləmə bitdi")
                dialog.setCancelable(true)
                val nb = dialog.getButton(AlertDialog.BUTTON_NEGATIVE)
                nb.text = "Bitti"
                nb.setOnClickListener { try { dialog.dismiss() } catch (e: Exception) { } }
            } catch (e: Exception) { }
        }

        inner class Worker {
            private val wv: WebView = newHiddenWebView()
            private var released = false
            private var job: Job? = null
            private var attempt = 0
            private var token = 0
            private var base = ""
            private var last = ""
            private var stable = 0
            private var loading = false
            private var pageReady = false         // səhifə yüklənib, forma var: növbəti mənzil üçün yenidən yüklənmir
            private var served = 0           // bu səhifədə neçə YVÖK yoxlanıb
            private var reuse = false        // cari cəhd yüklənmiş səhifədə aparılır
            private var sawLoading = false
            private var cleanBase = ""                  // səhifənin nəticəsiz ilkin mətni (parsing üçün)
            var assignedSource: Int = -1                 // cari YVÖK-ün mənbəsi; paralel səhifə limitləri üçün

            init {
                wv.webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? = blockedResponse(request)
                    override fun onPageFinished(view: WebView?, url: String?) {
                        if (job != null && loading) { loading = false; pollReady(token, 0) }
                    }
                    override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                        if (request?.isForMainFrame == true && job != null && loading) { loading = false; failAttempt(true) }
                    }
                }
            }

            fun destroy() {
                token++
                destroyWebView(wv)
            }

            /** "Dayandır": səhifəni dərhal dayandırıb bağlayır (artıq hovuza qayıdıbsa toxunmur) */
            fun abort() {
                token++
                job = null; loading = false
                if (released) return
                released = true
                try { wv.stopLoading() } catch (e: Exception) { }
                destroyWebView(wv)
            }

            /** iş bitdi: səhifə bağlanır (hovuz yoxdur) */
            fun release(idle: Boolean) {
                token++
                released = true
                destroyWebView(wv)
            }

            private var holding = false      // bu işçi hazırda cari küçənin YVÖK-ü ilə məşğuldur

            fun next() {
                if (holding) { holding = false; assignedSource = -1; inFlight--; if ((inFlight <= 0 || jobs.isEmpty()) && parked.isNotEmpty()) wakeParked() }
                applyTailWaits()
                while (true) {
                    if (cancelled) { job = null; workerFinished(this); return }
                    if (running > limit && jobs.isNotEmpty()) { job = null; workerFinished(this); return }   // limit azalıb: artıq işçi çıxır
                    if (jobs.isEmpty() && retryQueue.isNotEmpty()) pullRetryNow()   // son YVÖK-lər: bütün işçilərin bitməsini gözləmədən dərhal təkrar
                    // küçə-küçə sıra ləğv edildi: bütün işçilər növbəti YVÖK-ü gözləmədən götürür (küçə sərhədində dayanma yoxdur)
                    val j = jobs.removeFirstOrNull()
                    if (j == null) { job = null; workerFinished(this); return }
                    holding = true; inFlight++
                    activeCodes.add(j.yvok)
                    progress()
                    job = j
                    j.t0 = nowMs()
                    attempt = 0                       // hər kod üçün cəhd sayğacı təzədən başlayır
                    // 70 san-lik sərt vaxt həddi ləğv edildi: kod yalnız mənbələrin öz gözləmə həddləri ilə (yelo/portmanat/hesab/e-bələdiyyə) bitir
                    val src = pickSource(j)
                    if (src < 0) {
                        if (orderedSingle) j.retried = true
                        job = null
                        markFail(j, "Bütün saytlar cavab vermədi")
                        next()
                    } else startOn(j, src)             // fərdi mənzil: Yelo -> e-bələdiyyə -> hesab.az -> Portmanat
                    return
                }
            }

            /** kod JOB_HARD_MS ərzində nəticə verməyib: gözləyən sorğu buraxılır, kod təkrar növbəyə / Yenilənmədi-yə keçir */
            private fun hardTimeout(j: Job) {
                token++
                unassign()
                job = null
                addLog("⏱ ${j.yvok} — ${JOB_HARD_MS / 1000} san ərzində cavab gəlmədi, dayandırıldı")
                markFail(j, "vaxt bitdi")
                next()
            }

            /** xarici mənbə (yelo.az / hesab.az / portmanat.az) tapılmadı dedi: bu texniki xəta deyil, mənbə dayanıb sayılmır; 2 mənbə tapmasa kod tapılmadı olur */
            private fun externalNotFound(j: Job, src: Int) {
                if (orderedSingle) { finishNotFound(j, srcName(src)); return }
                when (src) { SRC_Y -> { yeloOk(); j.yeloTried = true }; SRC_H -> { hesabOk(); j.hesabTried = true }; else -> { portOk(); j.portTried = true } }
                j.nf++
                if (j.nf >= 2 || pickSource(j) < 0) { finishNotFound(j, srcName(src)); return }
                addLog("↪ ${j.yvok} — ${srcName(src)} tapmadı, bir mənbə də yoxlanılır")
                rerouteAfterExternalFail(j)
            }

            /** kodu seçilmiş saytda başladır */
            private fun startOn(j: Job, src: Int) {
                assignedSource = src
                if (src in 0..3) { asg[src]++; if (hardDown(src)) probing[src] = true }
                when (src) {
                    SRC_Y -> startYelo(j)
                    SRC_H -> startHesab(j)
                    SRC_P -> startPort(j)
                    else -> startEbel()
                }
            }

            /** Sayt texniki olaraq cavab vermədikdə növbəti mənbəyə keç. Fərdi mənzildə mənbələr sabit ardıcıllıqla işləyir. */
            /** uğursuz olan mənbənin payı geri qaytarılır: pay yalnız cavab verən mənbələrə görə hesablanır */
            private fun unassign() { val a = assignedSource; if (a in 0..3 && asg[a] > 0) asg[a]--; assignedSource = -1 }

            private fun rerouteAfterExternalFail(j: Job) {
                token++
                unassign()
                val nextSource = pickSource(j)
                if (nextSource < 0 || overBudget(j)) {
                    // Bütün mənbələr yoxlanıb və ya bu kod üçün ayrılan vaxt bitib; eyni saytları sonsuz təkrar etmə.
                    if (orderedSingle) j.retried = true
                    job = null
                    markFail(j, if (nextSource < 0) "Bütün saytlar cavab vermədi" else "vaxt bitdi")
                    next()
                    return
                }
                startOn(j, nextSource)
            }

            /** Sayt açıq şəkildə "tapılmadı" dedikdə bu cavab sayılır; ehtiyat mənbələr başladılmır. */
            private fun finishNotFound(j: Job, source: String) {
                if (job !== j || cancelled || finished) return
                token++
                activeCodes.remove(j.yvok)
                notFound++; done++
                failedRows.remove(j.rowId)
                val rid = j.rowId
                dbWriter.execute { try { touchRowSheet(rid) } catch (e: Exception) { } }
                resultLine(j, "∅ ${j.yvok} — $source: Saytda tapılmadı")
                job = null
                progress()
                if (j.notify) Toast.makeText(this@BazaActivity, "Saytda tapılmadı", Toast.LENGTH_SHORT).show()
                next()
            }

            private fun startEbel() {
                if (pageReady && ++served <= PAGE_REUSE_MAX) startReuse() else { served = 0; startAttempt() }   // yüklənmiş səhifədə yeni kod: səhifə yenidən yüklənmir
            }

            /** Kodu yelo.az-da yoxlayır. Cavab gəlməsə kod avtomatik e-belediyyeyə qaytarılır (yelo bu kod üçün bir daha sınanmır) */
            private fun startYelo(j: Job) {
                val y = yeloChecker()
                if (y == null) { j.yeloTried = true; rerouteAfterExternalFail(j); return }
                token++
                val t = token
                reuse = false
                activeCodes.add(j.yvok)
                y.check(j.yvok, object : YeloChecker.Callback {
                    override fun onResult(name: String?, debt: String?) {
                        if (t != token || job !== j || cancelled || finished) return
                        val n = (name ?: "").trim().replace(Regex("\\s+"), " ")
                        val d = (debt ?: "").trim()
                        if (!nameOkRe.matches(n) || !debtOkRe.matches(d)) { onFail(); return }
                        yeloOk(); yeloCount++
                        token++
                        applyExternal(j, n, d, "yelo.az")
                    }

                    override fun onFail() {
                        if (t != token || job !== j || cancelled || finished) return
                        yeloBad()
                        j.yeloTried = true
                        addLog("↪ ${j.yvok} — yelo.az cavab vermədi, başqa sayta verildi")
                        rerouteAfterExternalFail(j)
                    }

                    override fun onNotFound() {
                        if (t != token || job !== j || cancelled || finished) return
                        externalNotFound(j, SRC_Y)
                    }
                })
            }

            /** Kodu hesab.az-da yoxlayır; cavab gəlməsə digər sayta verilir */
            private fun startHesab(j: Job) {
                val h = hesabChecker()
                if (h == null) { j.hesabTried = true; rerouteAfterExternalFail(j); return }
                token++
                val t = token
                reuse = false
                activeCodes.add(j.yvok)
                h.check(j.yvok, object : HesabChecker.Callback {
                    override fun onResult(name: String?, debt: String?) {
                        if (t != token || job !== j || cancelled || finished) return
                        val n = (name ?: "").trim().replace(Regex("\\s+"), " ")
                        val d = (debt ?: "").trim()
                        if (!nameOkRe.matches(n) || !debtOkRe.matches(d)) { onFail(); return }
                        hesabOk(); hesabCount++
                        token++
                        applyExternal(j, n, d, "hesab.az")
                    }

                    override fun onFail() {
                        if (t != token || job !== j || cancelled || finished) return
                        hesabBad()
                        j.hesabTried = true
                        addLog("↪ ${j.yvok} — hesab.az cavab vermədi, başqa sayta verildi")
                        rerouteAfterExternalFail(j)
                    }

                    override fun onNotFound() {
                        if (t != token || job !== j || cancelled || finished) return
                        externalNotFound(j, SRC_H)
                    }
                })
            }

            /** Kodu portmanat.az-da yoxlayır; cavab gəlməsə digər sayta verilir */
            private fun startPort(j: Job) {
                val p = portChecker()
                if (p == null) { j.portTried = true; rerouteAfterExternalFail(j); return }
                token++
                val t = token
                reuse = false
                activeCodes.add(j.yvok)
                p.check(j.yvok, object : PortmanatChecker.Callback {
                    override fun onResult(name: String?, debt: String?) {
                        if (t != token || job !== j || cancelled || finished) return
                        val n = (name ?: "").trim().replace(Regex("\\s+"), " ")
                        val d = (debt ?: "").trim()
                        if (!nameOkRe.matches(n) || !debtOkRe.matches(d)) {
                            addLog("⚠ ${j.yvok} — portmanat.az cavabı qəbul olunmadı: ad='$n', borc='$d'")   // diaqnostika: format uyğunsuzluğu
                            onFail(); return
                        }
                        portOk(); portCount++
                        token++
                        applyExternal(j, n, d, "portmanat.az")
                    }

                    override fun onFail() {
                        if (t != token || job !== j || cancelled || finished) return
                        portBad()
                        j.portTries++
                        j.portTried = true
                        addLog("↪ ${j.yvok} — portmanat.az cavab vermədi (${p.lastReason()}), digər aktiv mənbəyə keçirilir")
                        rerouteAfterExternalFail(j)
                    }

                    override fun onNotFound() {
                        if (t != token || job !== j || cancelled || finished) return
                        externalNotFound(j, SRC_P)
                    }
                })
            }

            /** Xarici mənbədən (yelo.az / hesab.az / portmanat.az) gələn nəticəni bazaya yazır */
            private fun applyExternal(j: Job, name: String, debt: String, src: String) {
                pendingWrites++
                val rid = j.rowId; val notify = j.notify
                dbWriter.execute {
                    try { applyFetched(rid, name, debt) } catch (e: Exception) { }
                    ui.post {
                        pendingWrites--
                        if (notify) afterRefresh()
                        checkDone()
                    }
                }
                updated++; done++
                markOk(j, debt, src)
                progress()
                next()
            }

            /** Səhifəni yenidən yükləmədən yeni YVÖK-ü eyni formaya yazır */
            private fun startReuse() {
                token++
                val t = token
                reuse = true; sawLoading = false; stable = 0; last = ""
                ui.postDelayed({ if (t == token && job != null && !finished) failAttempt() }, RESULT_LIMIT_MS)   // JS cavab verməsə ilişməsin
                wv.evaluateJavascript(JS_STATE) { v ->
                    if (t == token) {
                        base = parseJs(v)?.optString("text") ?: ""
                        fill(t)
                    }
                }
            }

            private fun startAttempt() {
                attempt++
                token++
                val t = token
                reuse = false; pageReady = false; sawLoading = false
                loading = true
                stable = 0; last = ""
                wv.loadUrl(TAX_URL)
                ui.postDelayed({ if (t == token && loading) { loading = false; failAttempt(true) } }, PAGE_LOAD_LIMIT_MS)
            }

            private fun parseJs(v: String?): JSONObject? {
                return try {
                    val s = JSONTokener(v ?: "null").nextValue() as? String ?: return null
                    JSONObject(s)
                } catch (e: Exception) { null }
            }

            private fun pollReady(t: Int, tries: Int) {
                if (t != token) return
                if (tries >= READY_POLL_MAX) { failAttempt(true); return }   // səhifə açılıb, forma görünmür: sonsuz gözləmə yoxdur
                wv.evaluateJavascript(JS_READY) { v ->
                    if (t == token) {
                        val o = parseJs(v)
                        if (o != null && o.optBoolean("ok")) {
                            base = o.optString("text"); cleanBase = base
                            pageReady = true
                            fill(t)
                        } else ui.postDelayed({ pollReady(t, tries + 1) }, DEFAULT_POLL_MS)
                    }
                }
            }

            private fun fill(t: Int) {
                val j = job ?: return
                wv.evaluateJavascript(jsFill(j.yvok)) { r ->
                    if (t == token) {
                        if (r != null && r.contains("ok")) {
                            stable = 0; last = ""; pollResult(t, 0)
                            // nəticə vaxtında gəlmirsə gözləmədən təzə səhifədə təkrar (əvvəl heç bir hədd yox idi: son YVÖK-lər ilişirdi)
                            val lim = if (jobs.isEmpty()) RESULT_LIMIT_TAIL_MS else RESULT_LIMIT_MS
                            ui.postDelayed({ if (t == token && job != null && !finished) failAttempt() }, lim)
                        }
                        else failAttempt()
                    }
                }
            }

            private fun pollResult(t: Int, tries: Int) {
                if (t != token) return
                wv.evaluateJavascript(JS_STATE) { v ->
                    if (t == token) {
                        val text = parseJs(v)?.optString("text") ?: ""
                        if (text.contains("Yoxlanılır")) sawLoading = true
                        val isLoading = text.contains("Yoxlanılır") && !base.contains("Yoxlanılır")
                        val changed = text != base || (reuse && sawLoading)
                        if (!isLoading && text.isNotEmpty() && changed) {
                            // tam nəticə (ad + borc) gəlibsə sabitləşməni gözləmədən dərhal tamamlanır
                            val p0 = parseResult(if (cleanBase.isNotEmpty()) cleanBase else base, text)
                            if (p0.name != null && p0.borc != null) { complete(text); return@evaluateJavascript }
                            if (reuse && !sawLoading) { stable = 0; last = "" }   // yükləmə başlamamış natamam mətn: yeni nəticəni gözlə
                            else {
                                if (text == last) stable++ else { last = text; stable = 0 }
                                if (stable >= 3) { complete(text); return@evaluateJavascript }
                            }
                        } else { stable = 0; last = "" }
                        // yüklənmiş səhifədə cavab gəlmirsə (məs. eyni nəticə təkrarlanıb) tez yenidən yüklənir
                        ui.postDelayed({ pollResult(t, tries + 1) }, DEFAULT_POLL_MS)
                    }
                }
            }

            private fun complete(text: String) {
                token++
                val j = job ?: return
                val p = parseResult(if (cleanBase.isNotEmpty()) cleanBase else base, text)
                if (p.name == null && p.borc == null) {
                    if (p.notFound) {
                        ebelOk()
                        notFound++; done++
                        activeCodes.remove(j.yvok)
                        val nfRid = j.rowId; dbWriter.execute { try { touchRowSheet(nfRid) } catch (e: Exception) { } }
                        resultLine(j, "∅ ${j.yvok} — Saytda tapılmadı")
                        val rc = j.race
                        if (rc != null) {
                            rc.ebel = 1
                            if (j.notify) { if (!rc.won) raceFailToast(rc, j.yvok); afterRefresh() }
                        } else if (j.notify) { Toast.makeText(this@BazaActivity, "Saytda tapılmadı", Toast.LENGTH_SHORT).show(); afterRefresh() }
                    } else if (orderedSingle) {
                        // Səhifə gəldi, amma cavabın formatı oxunmadı: e-bələdiyyə bu sorğu üçün işləmədi.
                        j.ebelTried = true
                        addLog("↪ ${j.yvok} — e-bələdiyyə cavabı oxunmadı, hesab.az-a keçirilir")
                        unassign()
                        rerouteAfterExternalFail(j)
                        return
                    } else {
                        job = null
                        markFail(j, "saytın cavabı oxunmadı")   // ilk dəfə: təkrar yoxlama növbəsinə; ikinci dəfə: Yenilənmədi
                    }
                } else {
                    val rc = j.race
                    if (rc != null) {
                        if (!rc.claim()) { job = null; next(); return }   // hesab.az / yelo.az artıq cavab verib
                        stopHesabOne(); stopYeloOne(); stopPortOne()        // digər mənbələrin sorğusunu dayandır
                    }
                    // bazaya yazma ayrıca arxa plan axınında gedir: ekran və digər işçilər gözləmir
                    pendingWrites++
                    val rid = j.rowId; val nm = p.name; val bc = p.borc; val notify = j.notify
                    dbWriter.execute {
                        try { applyFetched(rid, nm, bc) } catch (e: Exception) { }
                        ui.post {
                            pendingWrites--
                            if (notify) afterRefresh()
                            checkDone()
                        }
                    }
                    updated++; done++
                    ebelOk(); ebelCount++
                    markOk(j, p.borc, if (j.race == null && !silent) "e-belediyye" else "")
                    if (j.notify) Toast.makeText(this@BazaActivity, "Yeniləndi", Toast.LENGTH_SHORT).show()
                }
                progress()
                next()
            }

            /** YVÖK-dən cavab gəlmədi: heç vaxt əl çəkilmir; təzə səhifədə cavab gələnə qədər təkrar cəhd olunur (yalnız "Bitti" dayandırır) */
            private fun failAttempt(pageProblem: Boolean = false) {
                token++
                pageReady = false
                val j = job
                if (j == null || cancelled) { next(); return }
                if (overBudget(j)) { job = null; markFail(j, "vaxt bitdi"); next(); return }   // toplu yeniləmə: bir kod bütün növbəni gözlətmir
                if (orderedSingle && attempt >= 2) {
                    ebelBad()
                    j.ebelTried = true
                    addLog("↪ ${j.yvok} — e-bələdiyyə cavab vermədi, hesab.az-a keçirilir")
                    unassign()
                    rerouteAfterExternalFail(j)
                    return
                }
                if (silent && attempt >= 6) {   // tək mənzil (pəncərəsiz): dayandıracaq düyməsi olmadığı üçün tətbiq ilişməsin
                    job = null
                    markFail(j, if (pageProblem) "sayt açılmadı" else "sayt cavab vermədi"); next(); return
                }
                if (!silent && j.race == null) {
                    ebelBad()
                    // e-belediyye cavab vermirsə kod gözləmədən yelo.az-a keçir (hər kod üçün yalnız 1 dəfə)
                    if (attempt >= (if (jobs.isEmpty()) 1 else 2) || ebelDown()) {   // növbənin sonunda e-bələdiyyədə ikinci cəhd gözlənilmir
                        j.ebelTried = true
                        unassign()
                        val a = altSource(j)
                        if (a >= 0) {
                            addLog("↪ ${j.yvok} — e-belediyye cavab vermədi, " + srcName(a) + "-a verildi")
                            startOn(j, a); return
                        }
                        if (j.yeloTried && j.hesabTried && j.portTried) {   // bütün mənbələr sınanıb: sonsuz təkrar əvəzinə təkrar növbəsinə / "Yenilənmədi"
                            job = null
                            markFail(j, "Bütün saytlar cavab vermədi")
                            next(); return
                        }
                        // Başqa saytların tutumu doludursa, cari e-bələdiyyə təkrar cəhdini sayğacda saxla.
                        assignedSource = SRC_E
                    }
                }
                if (attempt % 3 == 0) addLog("… ${j.yvok} — cavab gözlənilir (cəhd $attempt)")
                val t = token
                val d = Math.min(attempt * RETRY_BACKOFF_MS, RETRY_BACKOFF_MAX_MS)
                ui.postDelayed({ if (t == token && job != null && !cancelled && !finished) startAttempt() }, d)
            }
        }
    }

    /** yeniləmədən sonra ekrandakı siyahıları təzələyir */
    private fun afterRefresh() {
        if (!catSearch.isEmpty()) catSearch.scheduleSearch(true)
        loadLevel(false, true)
    }

    private fun refreshRows(label: String, ids: List<Long>) = startRefresh(label, null, null, ids)

    // ---- tək mənzil: hesab.az ikinci mənbə ----
    private var hesabOne: HesabChecker? = null
    private val nameOkRe = Regex("^[\\p{L}\\s.'\\-]{3,100}$")
    private val debtOkRe = Regex("^(\\d{1,9}(\\.\\d{1,2})?)?$")

    private var yeloOne: YeloChecker? = null
    private fun stopYeloOne() {
        val y = yeloOne ?: return
        yeloOne = null
        try { y.clear() } catch (e: Exception) { }      // ortaq səhifələr bağlanmır, yalnız sorğu dayandırılır
    }

    /** Tək mənzil: yelo.az üçüncü mənbə kimi eyni anda yoxlanılır */
    private fun startYeloOne(j: Job, race: SingleRace) {
        stopYeloOne()
        val y = sharedYelo() ?: run { race.yelo = 2; return }
        y.clear()
        yeloOne = y
        y.check(j.yvok, object : YeloChecker.Callback {
            override fun onResult(name: String?, debt: String?) {
                val n = (name ?: "").trim().replace(Regex("\\s+"), " ")
                val d = (debt ?: "").trim()
                if (!nameOkRe.matches(n) || !debtOkRe.matches(d)) { onFail(); return }
                if (!race.claim()) return                       // başqa mənbə artıq cavab verib
                failedRows.remove(j.rowId)
                dbWriter.execute {
                    try { applyFetched(j.rowId, n, d) } catch (e: Exception) { }
                    ui.post { afterRefresh() }
                }
                refresher?.cancelQuiet()
                stopHesabOne()
                stopYeloOne()
                stopPortOne()
                Toast.makeText(this@BazaActivity, "Yeniləndi", Toast.LENGTH_SHORT).show()
            }

            override fun onFail() {
                race.yelo = 2
                if (yeloOne === y) stopYeloOne()
                raceFailToast(race, j.yvok)
            }
        })
    }

    private var portOne: PortmanatChecker? = null
    private fun stopPortOne() {
        val p = portOne ?: return
        portOne = null
        try { p.clear() } catch (e: Exception) { }      // ortaq səhifələr bağlanmır, yalnız sorğu dayandırılır
    }

    /** Tək mənzil: portmanat.az dördüncü mənbə kimi eyni anda yoxlanılır */
    private fun startPortOne(j: Job, race: SingleRace) {
        stopPortOne()
        val p = sharedPort() ?: run { race.port = 2; return }
        p.clear()
        portOne = p
        p.check(j.yvok, object : PortmanatChecker.Callback {
            override fun onResult(name: String?, debt: String?) {
                val n = (name ?: "").trim().replace(Regex("\\s+"), " ")
                val d = (debt ?: "").trim()
                if (!nameOkRe.matches(n) || !debtOkRe.matches(d)) { onFail(); return }
                if (!race.claim()) return                       // başqa mənbə artıq cavab verib
                failedRows.remove(j.rowId)
                dbWriter.execute {
                    try { applyFetched(j.rowId, n, d) } catch (e: Exception) { }
                    ui.post { afterRefresh() }
                }
                refresher?.cancelQuiet()
                stopHesabOne()
                stopYeloOne()
                stopPortOne()
                Toast.makeText(this@BazaActivity, "Yeniləndi", Toast.LENGTH_SHORT).show()
            }

            override fun onFail() {
                race.port = 2
                if (portOne === p) stopPortOne()
                raceFailToast(race, j.yvok)
            }
        })
    }

    private fun stopHesabOne() {
        val h = hesabOne ?: return
        hesabOne = null
        try { h.clear() } catch (e: Exception) { }
        ui.post { try { h.destroy() } catch (e: Exception) { } }
    }

    /** iki mənbə də nəticə verməyibsə (tapılmadı/xəta) bir dəfə xəbər verir */
    private fun raceFailToast(r: SingleRace, yvok: String) {
        if (r.won || r.ebel == 0 || r.hesab == 0 || r.yelo == 0 || r.port == 0) return
        if (r.ebel == 1) Toast.makeText(this, "Saytda tapılmadı", Toast.LENGTH_SHORT).show()
        else Toast.makeText(this, "Yenilənmədi: $yvok\nsayt cavab vermədi", Toast.LENGTH_LONG).show()
    }

    private fun startHesabOne(j: Job, race: SingleRace) {
        stopHesabOne()
        val h = try { HesabChecker(this, webHost, 0, dp(360), dp(640), 1) } catch (e: Exception) { return }
        hesabOne = h
        h.check(j.yvok, object : HesabChecker.Callback {
            override fun onResult(name: String?, debt: String?) {
                val n = (name ?: "").trim().replace(Regex("\\s+"), " ")
                val d = (debt ?: "").trim()
                if (!nameOkRe.matches(n) || !debtOkRe.matches(d)) { onFail(); return }
                if (!race.claim()) return                       // e-belediyye artıq cavab verib
                failedRows.remove(j.rowId)
                // bazaya yazma arxa planda; e-belediyye sorğusu səssizcə dayandırılır
                dbWriter.execute {
                    try { applyFetched(j.rowId, n, d) } catch (e: Exception) { }
                    ui.post { afterRefresh() }
                }
                refresher?.cancelQuiet()
                stopHesabOne()
                stopYeloOne()
                stopPortOne()
                Toast.makeText(this@BazaActivity, "Yeniləndi", Toast.LENGTH_SHORT).show()
            }

            override fun onFail() {
                race.hesab = 2
                if (hesabOne === h) stopHesabOne()
                raceFailToast(race, j.yvok)
            }
        })
    }

    /** Tək mənzil də ümumi mənbə paylayıcısından istifadə edir: e-bələdiyyə, Yelo, hesab.az və Portmanat aktivdir. */
    private fun refreshOne(rowId: Long) {
        refreshRows("Mənzil", listOf(rowId))
    }

    private fun refreshScope(label: String, scopeSql: String?, arg: String?) = startRefresh(label, scopeSql, arg, null)

    private fun currentScopeLabel(): String = when (level) {
        0 -> "Bütün baza"
        1 -> fileName
        2 -> "$fileName › $streetName"
        else -> tvPath.text.toString()
    }

    private fun refreshCurrentSection() {
        when (level) {
            0 -> refreshScope(currentScopeLabel(), null, null)
            1 -> refreshScope(currentScopeLabel(), "b.file_id = ?", fileId.toString())
            2 -> refreshScope(currentScopeLabel(), "b.street_id = ?", streetId.toString())
            else -> refreshScope(currentScopeLabel(), "b.id = ?", buildingId.toString())
        }
    }

    // =====================================================================
    //  Axtarış bölməsi (həm "Axtarış" tabında, həm kataloqun hər səviyyəsində)
    // =====================================================================
    inner class SearchUi(
        private val scope: () -> Pair<String, String>?,
        private val onActive: (Boolean) -> Unit,
        private val onRefresh: () -> Unit,
        private val onSort: () -> Unit = {},
        private val onCloud: () -> Unit = {}
    ) {
        private val tokS = Any()
        private val tokG = Any()
        private var searchGen = 0
        private var sugGen = 0
        private var suppress = false
        /** Təklifdən seçilmiş dəqiq küçə/bina: (ad, kateqoriya). Mətn əl ilə dəyişəndə silinir. */
        private var exactStreet: Pair<String, String>? = null
        private val adapter = CardAdapter()

        val etStreet: EditText = edit("Küçə adı", "street")
        val etMenzil: EditText = edit("Mənzil", "menzil")
        val etSoyad: EditText = edit("Soyad", "soyad")
        val etAd: EditText = edit("Ad", "ad")
        val etAta: EditText = edit("Atasının adı", "ata")
        val etNomre: EditText = edit("Nömrə", "nomre", InputType.TYPE_CLASS_PHONE)
        val etYvok: EditText = edit("YVÖK", "yvok")

        val form = LinearLayout(this@BazaActivity)
        // 1) Küçə adı + Mənzil, 2) Soyad + Ad + Atasının adı, 3) Nömrə (solda) + YVÖK (sağda)
        private val rowStreet = rowOf(etStreet to 2f, etMenzil to 1f)
        private val rowNames = rowOf(etSoyad to 1.5f, etAd to 0.75f, etAta to 0.75f)
        private val rowContact = rowOf(etNomre to 1f, etYvok to 1f)
        private val sugBox = LinearLayout(this@BazaActivity)
        val tvCount = TextView(this@BazaActivity)
        val btnToggle = Button(this@BazaActivity)
        val btnCloud = Button(this@BazaActivity)
        val btnFilter = Button(this@BazaActivity)
        private var sortMode = 0
        val results = ListView(this@BazaActivity)
        val resultsBox = LinearLayout(this@BazaActivity)

        init {
            form.orientation = LinearLayout.VERTICAL
            form.setPadding(dp(1), dp(4), dp(1), dp(4))
            etSoyad.textSize = 19f; etAd.textSize = 19f; etAta.textSize = 19f
            form.addView(rowStreet, LinearLayout.LayoutParams(-1, -2))
            form.addView(rowNames, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
            form.addView(rowContact, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

            sugBox.orientation = LinearLayout.VERTICAL
            sugBox.visibility = View.GONE
            sugBox.elevation = dp(6).toFloat()
            sugBox.background = GradientDrawable().apply {
                setColor(Color.parseColor("#0B0B0D")); setStroke(dp(1), Color.parseColor("#232328")); cornerRadius = dp(12).toFloat()
            }
            form.addView(sugBox, 1, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })

            val btnClear = Button(this@BazaActivity)
            btnClear.text = "Təmizlə"
            btnClear.setOnClickListener { clear(); scheduleSearch() }
            btnClear.setTextColor(Color.WHITE)
            btnClear.background = GradientDrawable().apply { setColor(Color.parseColor("#E53935")); cornerRadius = dp(12).toFloat() }
            form.addView(btnClear, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

            // Supabase düyməsi əsas başlıq sətrində göstərilir.
            btnCloud.text = "☁️ Supabase"
            btnCloud.textSize = 12f
            btnCloud.isAllCaps = false
            btnCloud.setPadding(dp(6), dp(2), dp(6), dp(2))
            btnCloud.setOnClickListener { hideSug(); onCloud() }

            // Təmizlə düyməsinin altında: Yenilə
            val btnRefresh = Button(this@BazaActivity)
            btnRefresh.text = "🔄  Yenilə"
            btnRefresh.setOnClickListener { hideSug(); onRefresh() }
            btnRefresh.setTextColor(Color.WHITE)
            btnRefresh.background = GradientDrawable().apply { setColor(Color.parseColor("#4F8CFF")); cornerRadius = dp(12).toFloat() }
            form.addView(btnRefresh, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

            tvCount.textSize = 13f
            tvCount.setPadding(dp(12), dp(2), dp(12), dp(4))
            tvCount.setTextColor(Color.parseColor("#FFE0B2"))
            results.divider = null
            results.adapter = adapter
            results.clipToPadding = false
            results.setPadding(dp(8), 0, dp(8), dp(8))
            results.setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_DOWN) hideSug(); false }
            resultsBox.orientation = LinearLayout.VERTICAL
            btnToggle.text = "🔼 Axtarışı gizlət"
            btnToggle.textSize = 12f
            btnToggle.isAllCaps = false
            btnToggle.setOnClickListener { setFormHidden(form.visibility == View.VISIBLE) }
            btnFilter.text = "🔽 Filter"; btnFilter.textSize = 13f; btnFilter.isAllCaps = false
            btnFilter.setOnClickListener {
                hideSug()
                AlertDialog.Builder(this@BazaActivity).setTitle("Filter")
                    .setSingleChoiceItems(arrayOf("Standart sıra", "Borc: ən çoxdan ən aza ↓"), sortMode) { d, which ->
                        d.dismiss()
                        if (which != sortMode) {
                            sortMode = which
                            btnFilter.text = if (which == 1) "🔽 Borc ↓" else "🔽 Filter"
                            if (isEmpty()) onSort() else scheduleSearch()
                        }
                    }
                    .setNegativeButton("Ləğv et", null).show()
            }
            resultsBox.addView(tvCount, LinearLayout.LayoutParams(-1, -2))
            resultsBox.addView(results, LinearLayout.LayoutParams(-1, 0, 1f))
        }

        fun sortDesc(): Boolean = sortMode == 1

        fun shownRowIds(): List<Long> = adapter.rowIds()

        fun refreshView() = adapter.notifyDataSetChanged()

        private fun edit(hint: String, key: String, type: Int = InputType.TYPE_CLASS_TEXT): EditText {
            val e = EditText(this@BazaActivity)
            e.hint = hint
            e.textSize = 19f
            e.isSingleLine = true
            e.inputType = type or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            e.imeOptions = EditorInfo.IME_ACTION_SEARCH
            e.setPadding(dp(12), dp(7), dp(12), dp(7))
            e.background = GradientDrawable().apply {
                setColor(Color.parseColor("#111114")); setStroke(dp(1), Color.parseColor("#232328")); cornerRadius = dp(12).toFloat()
            }
            e.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    if (suppress) return
                    if (key == "street") exactStreet = null
                    scheduleSearch(); scheduleSuggest(key)
                }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
            e.setOnFocusChangeListener { _, has -> if (has) scheduleSuggest(key) }
            e.setOnEditorActionListener { v, _, _ ->
                hideSug()
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                    .hideSoftInputFromWindow(v.windowToken, 0)
                true
            }
            return e
        }

        private fun fieldOf(key: String): EditText = when (key) {
            "street" -> etStreet; "menzil" -> etMenzil; "soyad" -> etSoyad
            "ad" -> etAd; "ata" -> etAta; "yvok" -> etYvok; else -> etNomre
        }

        fun isEmpty(): Boolean =
            listOf(etStreet, etMenzil, etSoyad, etAd, etAta).all { fold(it.text.toString()).isEmpty() } &&
                yvokText().isEmpty() &&
                etNomre.text.toString().none { it.isDigit() }

        private fun yvokText(): String = etYvok.text.toString().filter { it.isLetterOrDigit() }

        fun setFormHidden(h: Boolean) {
            form.visibility = if (h) View.GONE else View.VISIBLE
            btnToggle.text = if (h) "🔽 Axtarışı göstər" else "🔼 Axtarışı gizlət"
            if (h) hideSug()
        }

        fun clear() {
            setFormHidden(false)
            suppress = true
            exactStreet = null
            listOf(etStreet, etMenzil, etSoyad, etAd, etAta, etNomre, etYvok).forEach { it.setText("") }
            suppress = false
            hideSug()
        }

        fun hideSug() {
            sugGen++
            sugBox.visibility = View.GONE
        }

        fun sugVisible() = sugBox.visibility == View.VISIBLE

        /** Küçə/bina sözlərini qruplaşdırır: "11 a" -> "11a" (rəqəm + tək hərf birləşir) */
        private fun streetTokens(q: String): List<String> {
            val raw = q.split(' ').filter { it.isNotEmpty() }
            val out = ArrayList<String>()
            for (t in raw) {
                if (t.length == 1 && t[0].isLetter() && out.isNotEmpty() && out.last().all { it.isDigit() }) out[out.size - 1] = out.last() + t
                else out.add(t)
            }
            return out
        }

        /** Rəqəm olan söz (bina nömrəsi) yalnız binanın adında TAM söz kimi uyğun gəlir:
         *  "20" → "H.BABAŞOV 20" tapır, "H.BABAŞOV 11A" (tarix: 04,02,2025) və "120" tapmır.
         *  "205b" həm "205B", həm "205 B" kimi yazılmış adlara uyğun gəlir. */
        private fun addStreetWhere(q: String, where: ArrayList<String>, args: ArrayList<String>, loose: Boolean = false) {
            val nameNorm = "(' ' || replace(replace(replace(replace(replace(lower(b.name),'(',' '),')',' '),',',' '),'/',' '),'_',' ') || ' ')"
            for (t in streetTokens(q)) {
                if (t.any { it.isDigit() }) {
                    val c = t.replace(Regex("[(),/_]"), " ").replace(Regex("\\s+"), " ").trim()
                    if (c.isEmpty()) continue
                    val variants = arrayListOf(c)
                    Regex("^(.*\\d)([a-z])$").find(c)?.let { variants.add(it.groupValues[1] + " " + it.groupValues[2]) }
                    where.add("(" + variants.joinToString(" OR ") { "$nameNorm LIKE ?" } + ")")
                    variants.forEach { args.add(if (loose) "% $it%" else "% $it %") }
                } else {
                    where.add("b.name_n LIKE ?"); args.add("%$t%")
                }
            }
        }

        private fun buildWhere(exclude: String?, where: ArrayList<String>, args: ArrayList<String>) {
            scope()?.let { where.add(it.first); args.add(it.second) }
            if (exclude != "street") {
                val ex = exactStreet
                if (ex != null && fold(ex.first) == fold(etStreet.text.toString())) {
                    where.add("(b.name = ? OR b.street_id IN (SELECT id FROM streets WHERE name = ?))")
                    args.add(ex.first); args.add(ex.first)
                    if (ex.second.isNotEmpty()) {
                        where.add("b.file_id IN (SELECT id FROM files WHERE COALESCE(NULLIF(disp, ''), name) = ?)")
                        args.add(ex.second)
                    }
                } else addStreetWhere(fold(etStreet.text.toString()), where, args)
            }
            val mz = fold(etMenzil.text.toString())
            if (exclude != "menzil" && mz.isNotEmpty()) { where.add("r.menzil_n = ?"); args.add(mz) }
            val so = fold(etSoyad.text.toString())
            if (exclude != "soyad" && so.isNotEmpty()) { where.add("r.soyad_n LIKE ?"); args.add("%$so%") }
            val ad = fold(etAd.text.toString())
            if (exclude != "ad" && ad.isNotEmpty()) { where.add("r.ad_n LIKE ?"); args.add("%$ad%") }
            val at = fold(etAta.text.toString())
            if (exclude != "ata" && at.isNotEmpty()) { where.add("r.ata_n LIKE ?"); args.add("%$at%") }
            val yv = yvokText()
            if (exclude != "yvok" && yv.isNotEmpty()) { where.add("r.cells LIKE ?"); args.add("%$yv%") }
            val nr = etNomre.text.toString().filter { it.isDigit() }
            if (exclude != "nomre" && nr.isNotEmpty()) { where.add("r.nomre_d LIKE ?"); args.add("%$nr%") }
        }

        // ----- təkliflər -----
        private fun scheduleSuggest(key: String) {
            ui.removeCallbacksAndMessages(tokG)
            ui.postAtTime({ doSuggest(key) }, tokG, SystemClock.uptimeMillis() + 120)
        }

        private fun doSuggest(key: String) {
            val et = fieldOf(key)
            val q = fold(et.text.toString())
            if (key == "nomre" || key == "yvok" || q.isEmpty() || !et.hasFocus()) { hideSug(); return }
            val gen = ++sugGen
            Thread {
                val items = ArrayList<Pair<String, String>>()
                try {
                    if (key == "street") {
                        val catExpr = "COALESCE(NULLIF(f.disp, ''), f.name)"
                        fun add(loose: Boolean) {
                            val where = ArrayList<String>(); val args = ArrayList<String>()
                            scope()?.let { where.add(it.first); args.add(it.second) }
                            addStreetWhere(q, where, args, loose)
                            val w = where.joinToString(" AND ")
                            db.rawQuery(
                                "SELECT DISTINCT s.name, $catExpr FROM streets s JOIN buildings b ON b.street_id = s.id JOIN files f ON f.id = b.file_id WHERE $w ORDER BY s.name LIMIT 4",
                                args.toTypedArray()
                            ).use { c -> while (c.moveToNext()) { val n = c.getString(0); val k = c.getString(1) ?: ""; if (items.none { it.first == n && it.second == k }) items.add(n to k) } }
                            db.rawQuery(
                                "SELECT DISTINCT b.name, $catExpr FROM buildings b JOIN files f ON f.id = b.file_id WHERE $w ORDER BY b.file_id, b.ord LIMIT 10",
                                args.toTypedArray()
                            ).use { c -> while (c.moveToNext()) { val n = c.getString(0); val k = c.getString(1) ?: ""; if (items.none { it.first == n && it.second == k }) items.add(n to k) } }
                        }
                        add(false)   // əvvəlcə dəqiq uyğunluqlar
                        add(true)    // sonra oxşarlar: "20" üçün 20, 200, 205...
                        while (items.size > 14) items.removeAt(items.size - 1)
                    } else {
                        val col = when (key) { "menzil" -> "r.menzil"; "soyad" -> "r.soyad"; "ad" -> "r.ad"; else -> "r.ata" }
                        val where = ArrayList<String>(); val args = ArrayList<String>()
                        buildWhere(key, where, args)
                        where.add("${col}_n LIKE ?"); args.add("$q%")
                        where.add("$col <> ''")
                        db.rawQuery(
                            "SELECT DISTINCT $col, COALESCE(NULLIF(f.disp, ''), f.name) FROM rows r JOIN buildings b ON b.id = r.building_id JOIN files f ON f.id = b.file_id WHERE " +
                                where.joinToString(" AND ") + " ORDER BY ${col}_n LIMIT 8", args.toTypedArray()
                        ).use { c -> while (c.moveToNext()) items.add(c.getString(0) to (c.getString(1) ?: "")) }
                    }
                } catch (e: Exception) { /* ignore */ }
                runOnUiThread { if (gen == sugGen) showSug(key, items) }
            }.start()
        }

        private fun showSug(key: String, items: List<Pair<String, String>>) {
            if (items.isEmpty()) { sugBox.visibility = View.GONE; return }
            val anchor: View = when (key) { "street", "menzil" -> rowStreet; "soyad", "ad", "ata" -> rowNames; else -> rowContact }
            form.removeView(sugBox)
            form.addView(sugBox, form.indexOfChild(anchor) + 1, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
            sugBox.removeAllViews()
            items.forEachIndexed { idx, (text, cat) ->
                val rowV = LinearLayout(this@BazaActivity)
                rowV.orientation = LinearLayout.HORIZONTAL
                rowV.gravity = Gravity.CENTER_VERTICAL
                rowV.setPadding(dp(12), dp(11), dp(12), dp(11))
                val tv = TextView(this@BazaActivity)
                tv.text = "🔍  $text"; tv.textSize = 15f; tv.setTextColor(Color.parseColor("#F2F2F5"))
                tv.maxLines = 1; tv.ellipsize = TextUtils.TruncateAt.END
                rowV.addView(tv, LinearLayout.LayoutParams(0, -2, 1f))
                if (cat.isNotEmpty()) {
                    val tc = TextView(this@BazaActivity)
                    tc.text = cat; tc.textSize = 11f; tc.setTextColor(Color.parseColor("#4F8CFF"))
                    tc.maxLines = 1; tc.ellipsize = TextUtils.TruncateAt.END
                    tc.gravity = Gravity.END
                    tc.setPadding(dp(8), dp(2), dp(8), dp(2))
                    tc.background = GradientDrawable().apply {
                        setColor(Color.parseColor("#14233F")); cornerRadius = dp(10).toFloat()
                    }
                    rowV.addView(tc, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
                }
                rowV.setOnClickListener {
                    val f = fieldOf(key)
                    suppress = true
                    f.setText(text)
                    f.setSelection(f.text.length)
                    if (key == "street") exactStreet = text to cat
                    suppress = false
                    hideSug(); scheduleSearch()
                }
                sugBox.addView(rowV)
            }
            sugBox.visibility = View.VISIBLE
        }

        // ----- axtarış -----
        private var keepScroll = false

        fun scheduleSearch(keep: Boolean = false) {
            if (keep) keepScroll = true
            onActive(!isEmpty())
            ui.removeCallbacksAndMessages(tokS)
            ui.postAtTime({ doSearch() }, tokS, SystemClock.uptimeMillis() + 250)
        }

        private fun doSearch() {
            if (isEmpty()) {
                adapter.set(emptyList()); tvCount.text = ""; return
            }
            val gen = ++searchGen
            val desc = sortMode == 1
            val keep = keepScroll
            keepScroll = false
            val keepPos = results.firstVisiblePosition
            val keepTop = results.getChildAt(0)?.top ?: 0
            Thread {
                val where = ArrayList<String>(); val args = ArrayList<String>()
                buildWhere(null, where, args)
                val sql = "SELECT r.cells, b.headers, b.name, b.title, COALESCE(NULLIF(f.disp, ''), f.name), r.id, f.name, b.sheet, r.ord FROM rows r " +
                    "JOIN buildings b ON b.id = r.building_id JOIN files f ON f.id = b.file_id " +
                    "WHERE " + where.joinToString(" AND ") + " ORDER BY " + (if (desc) "r.borc DESC, " else "") + "f.ord, b.ord, r.ord LIMIT 201"
                val list = ArrayList<Card>()
                try {
                    db.rawQuery(sql, args.toTypedArray()).use { c ->
                        while (c.moveToNext()) {
                            list.add(Card(
                                path = c.getString(4) + "  ›  " + c.getString(2),
                                title = c.getString(3),
                                headers = jsonList(c.getString(1)),
                                cells = jsonList(c.getString(0)),
                                rowId = c.getLong(5),
                                bname = c.getString(2),
                                skey = c.getString(6) + "|" + c.getString(7) + "|" + c.getInt(8)
                            ))
                        }
                    }
                } catch (e: Exception) { /* ignore */ }
                runOnUiThread {
                    if (gen == searchGen) {
                        val more = list.size > 200
                        val shown = if (more) list.subList(0, 200) else list
                        adapter.set(shown)
                        tvCount.text = if (shown.isEmpty()) "Nəticə tapılmadı"
                        else if (more) "İlk 200 nəticə göstərilir — axtarışı dəqiqləşdirin" else "${shown.size} nəticə"
                        if (keep) results.setSelectionFromTop(keepPos, keepTop) else results.setSelection(0)
                    }
                }
            }.start()
        }
    }

    // =====================================================================
    //  Mesaj göndərmə (WhatsApp / SMS) və kataloq adlarının redaktəsi
    // =====================================================================
    private fun cellOf(c: Card, prefix: String): String {
        val i = colIdx(c.headers, prefix)
        return if (i >= 0) c.cells.getOrNull(i).orEmpty().trim() else ""
    }

    private fun nameOf(c: Card): String {
        val i = nameIdx(c.headers)
        return if (i >= 0) c.cells.getOrNull(i).orEmpty().trim().replace(Regex("\\s+"), " ") else ""
    }

    /** Mesajlarda küçə/bina adından əvvəlki sahə etiketi yazılmır (IV Sahə, V Sahə, VI Sahə və s.). */
    private fun messageLocationLabel(raw: String): String {
        var value = raw.trim().replace(Regex("\\s+"), " ")
        value = value.replace(Regex("(?i)^(?:I{1,3}|IV|V|VI|VII|VIII|IX|X)\\s+Sahə\\s*[,—–-]?\\s*"), "")
        return value.trim()
    }

    /** Mənzil sahəsində sözlü qeyd varsa (məs. "Mərtəbə 3, M1"), qarşısına "mənzil" əlavə edilmir. */
    private fun unitLine(c: Card): String {
        val building = messageLocationLabel(c.bname)
        val apartment = cellOf(c, "menzil")
        val location = if (building.isNotEmpty()) "$building " else ""
        val hasWords = Regex(".*\\p{L}{2,}.*").matches(apartment)
        val apartmentText = when {
            apartment.isBlank() -> ""
            hasWords -> apartment
            else -> "mənzil $apartment"
        }
        return (location + apartmentText).trim()
    }

    private fun waText(c: Card): String {
        val y = cellOf(c, "yvok")
        val borc = cellOf(c, "borc").ifEmpty { "0" }
        return listOf(
            "Binəqədi rayon Binəqədi bələdiyyəsi",
            "Əmlak vergisi",
            "",
            "Borc: $borc AZN",
            "YVÖK:$y",
            nameOf(c),
            unitLine(c),
            "",
            "Ödəniş növləri:",
            "𝟭.Birbank və ABB tətbiqləri",
            "- Ödənişlər",
            "- Dövlət(Hökümət)",
            "- Bələdiyyələr",
            "- YVÖK daxil edin",
            "- $y",
            "- Davam Etmək",
            "",
            "𝟮.MilliÖn,Mpay,ExpressPay Ödəniş Terminalları",
            "- Dövlət Ödənişləri",
            "- Bələdiyyələr",
            "- YVÖK",
            "- $y",
            "- İrəli"
        ).joinToString("\n")
    }

    /** SMS yalnız latın hərfləri ilə: ə→e, ı→i, ö→o, ü→u, ş→s, ç→c, ğ→g və s. */
    private fun latin(s: String): String {
        val m = java.text.Normalizer.normalize(
            s.replace('Ə', 'E').replace('ə', 'e').replace('İ', 'I').replace('ı', 'i'),
            java.text.Normalizer.Form.NFD
        )
        val sb = StringBuilder()
        for (ch in m) if (ch == '\n' || ch.code in 32..126) sb.append(ch)
        return sb.toString()
    }

    private fun smsText(c: Card): String {
        val y = cellOf(c, "yvok")
        val borc = cellOf(c, "borc").ifEmpty { "0" }
        return latin(
            "Bineqedi belediyyesi Emlak vergisi\n" +
                "Borc: $borc AZN\n" +
                "YVÖK:$y\n" +
                nameOf(c) + "\n" +
                unitLine(c) + "\n" +
                "Elaqe:0775668875 Barat m"
        )
    }

    /** Yalnız mobil nömrə: 9 simvol (501234567) və ya 10 simvol (0501234567), 994 ilə də ola bilər.
     *  012 ilə başlayan (ev) nömrələr və başqa uzunluqlar qəbul olunmur → null */
    private fun intlNumber(d: String): String? {
        val n9 = when {
            d.startsWith("994") && d.length == 12 -> d.substring(3)
            d.length == 10 && d.startsWith("0") -> d.substring(1)
            d.length == 9 -> d
            else -> return null
        }
        if (n9.startsWith("12") || n9.startsWith("0")) return null
        return "994$n9"
    }

    // =====================================================================
    //  Qeydlər + xatırlatma bildirişi, borc dəyişiklikləri siyahısı
    // =====================================================================
    private class NoteRec(val note: String, val remind: Long, val label: String)
    private val notesMap = HashMap<String, NoteRec>()
    private lateinit var btnNotes: Button
    private val dtFmt by lazy { java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()) }

    private fun noteLabel(c: Card): String {
        val nm = nameOf(c)
        return unitLine(c) + (if (nm.isNotEmpty()) " — $nm" else "")
    }

    private fun updateNotesBtn() {
        if (!::btnNotes.isInitialized) return
        val now = System.currentTimeMillis()
        val overdue = notesMap.values.count { it.remind in 1..now }
        btnNotes.text = "📝 Qeydlər" + (if (overdue > 0) "  ⏰ $overdue" else "")
    }

    private fun deleteAllNotes() {
        for (k in notesMap.keys.toList()) az.axtaris.baza.ReminderReceiver.cancel(this, k)
        try { editsDb.execSQL("DELETE FROM notes") } catch (e: Exception) { }
        notesMap.clear()
        refreshCards(); updateNotesBtn(); scheduleSync()
        Toast.makeText(this, "Qeydlər silindi", Toast.LENGTH_SHORT).show()
    }

    /** Serverdən endirmədən sonra qeydlər yaddaşa yüklənir, alarmlar yenidən qurulur (silinmiş qeydlərin alarmı ləğv olunur) */
    private fun reloadNotes() {
        val old = notesMap.keys.toList()
        notesMap.clear()
        try {
            editsDb.rawQuery("SELECT skey, note, remind, label FROM notes", null).use { c ->
                while (c.moveToNext()) notesMap[c.getString(0)] = NoteRec(c.getString(1) ?: "", c.getLong(2), c.getString(3) ?: "")
            }
        } catch (e: Exception) { }
        for (k in old) if (!notesMap.containsKey(k)) az.axtaris.baza.ReminderReceiver.cancel(this, k)
        try { az.axtaris.baza.ReminderReceiver.rescheduleAll(this) } catch (e: Exception) { }
        updateNotesBtn()
    }

    private fun requestNotifPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 301)
    }

    private fun saveNote(skey: String, label: String, note: String, remind: Long) {
        if (note.isBlank() && remind <= 0L) {
            editsDb.execSQL("DELETE FROM notes WHERE skey = ?", arrayOf<Any>(skey))
            notesMap.remove(skey)
            az.axtaris.baza.ReminderReceiver.cancel(this, skey)
        } else {
            editsDb.execSQL("INSERT OR REPLACE INTO notes VALUES(?,?,?,?)", arrayOf<Any>(skey, note, remind, label))
            notesMap[skey] = NoteRec(note, remind, label)
            if (remind > System.currentTimeMillis()) {
                az.axtaris.baza.ReminderReceiver.schedule(this, skey, remind, label, note.ifBlank { "Xatırlatma" })
                requestNotifPermission()
            } else az.axtaris.baza.ReminderReceiver.cancel(this, skey)
        }
        refreshCards(); updateNotesBtn()
        scheduleSync()
    }

    private fun showNoteDialog(skey: String, label: String) {
        val cur = notesMap[skey]
        var remind = cur?.remind ?: 0L
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(8), dp(20), 0)
        col.addView(TextView(this).apply { text = label; textSize = 13f; setTextColor(Color.parseColor("#B3B3BD")) })
        val et = EditText(this)
        et.hint = "Qeyd (məs. zəng etdim, cümə ödəyəcək)"; et.setText(cur?.note ?: "")
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        et.minLines = 2; et.maxLines = 6; et.gravity = Gravity.TOP
        col.addView(et)
        val tvRem = TextView(this).apply { textSize = 15f; setPadding(0, dp(10), 0, dp(4)) }
        fun showRem() {
            tvRem.text = if (remind > 0) "⏰ Xatırlatma: " + dtFmt.format(java.util.Date(remind)) else "⏰ Xatırlatma təyin edilməyib"
            tvRem.setTextColor(Color.parseColor(if (remind > 0 && remind < System.currentTimeMillis()) "#FF6B6B" else "#FFE0B2"))
        }
        showRem()
        col.addView(tvRem)
        fun smallBtn(t: String, f: () -> Unit) = Button(this).apply { text = t; isAllCaps = false; textSize = 12f; setOnClickListener { f() } }
        fun setIn(days: Int, hour: Int) {
            val cal = java.util.Calendar.getInstance()
            cal.add(java.util.Calendar.DAY_OF_YEAR, days)
            cal.set(java.util.Calendar.HOUR_OF_DAY, hour); cal.set(java.util.Calendar.MINUTE, 0); cal.set(java.util.Calendar.SECOND, 0); cal.set(java.util.Calendar.MILLISECOND, 0)
            remind = cal.timeInMillis; showRem()
        }
        val quick = rowOf(
            smallBtn("Sabah 10:00") { setIn(1, 10) } to 1f,
            smallBtn("3 gün sonra") { setIn(3, 10) } to 1f,
            smallBtn("1 həftə sonra") { setIn(7, 10) } to 1f
        )
        col.addView(quick)
        val pick = smallBtn("📅  Tarix və saat seç") {
            val cal = java.util.Calendar.getInstance().apply { if (remind > 0) timeInMillis = remind }
            android.app.DatePickerDialog(this, { _, y, m, d ->
                android.app.TimePickerDialog(this, { _, h, mi ->
                    val c2 = java.util.Calendar.getInstance()
                    c2.set(y, m, d, h, mi, 0); c2.set(java.util.Calendar.MILLISECOND, 0)
                    remind = c2.timeInMillis; showRem()
                }, cal.get(java.util.Calendar.HOUR_OF_DAY), cal.get(java.util.Calendar.MINUTE), true).show()
            }, cal.get(java.util.Calendar.YEAR), cal.get(java.util.Calendar.MONTH), cal.get(java.util.Calendar.DAY_OF_MONTH)).show()
        }
        col.addView(pick)
        col.addView(smallBtn("✖  Xatırlatmanı sil") { remind = 0L; showRem() })
        val sv = ScrollView(this); sv.addView(col)
        val b = AlertDialog.Builder(this).setTitle("Qeyd və xatırlatma").setView(sv)
            .setPositiveButton("Yadda saxla", null)
            .setNegativeButton("Ləğv et", null)
        if (cur != null) b.setNeutralButton("🗑 Sil") { _, _ -> saveNote(skey, label, "", 0L) }
        val dlg = b.create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val txt = et.text.toString().trim()
                if (remind > 0 && remind <= System.currentTimeMillis() && remind != (cur?.remind ?: 0L)) {
                    Toast.makeText(this, "Xatırlatma vaxtı keçmişdədir, gələcək vaxt seçin", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                saveNote(skey, label, txt, remind)
                dlg.dismiss()
            }
            dlg.getButton(AlertDialog.BUTTON_NEUTRAL)?.setTextColor(Color.parseColor("#FF6B6B"))
        }
        dlg.show()
    }

    /** Bütün qeydlər: əvvəl xatırlatması olanlar (vaxt sırası ilə, keçmişlər qırmızı), sonra qalanları */
    private fun showNotesList() {
        val now = System.currentTimeMillis()
        val items = notesMap.entries.sortedWith(compareBy({ if (it.value.remind > 0) 0 else 1 }, { it.value.remind }))
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(8), dp(16), dp(4))
        var dlg: AlertDialog? = null
        if (items.isEmpty()) col.addView(TextView(this).apply { text = "Qeyd yoxdur. Mənzil kartında «📝 Qeyd» düyməsinə basın."; textSize = 14f; setTextColor(Color.parseColor("#B3B3BD")) })
        for ((k, n) in items) {
            val over = n.remind in 1..now
            col.addView(TextView(this).apply {
                val sb = android.text.SpannableStringBuilder(n.label + "\n")
                sb.setSpan(StyleSpan(Typeface.BOLD), 0, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                if (n.note.isNotBlank()) sb.append(n.note + "\n")
                if (n.remind > 0) {
                    val st = sb.length
                    sb.append("⏰ " + dtFmt.format(java.util.Date(n.remind)) + (if (over) "  (vaxtı çatıb)" else ""))
                    sb.setSpan(ForegroundColorSpan(Color.parseColor(if (over) "#FF6B6B" else "#FFE0B2")), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                text = sb; textSize = 14f; setTextColor(Color.parseColor("#F2F2F5"))
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = GradientDrawable().apply { setColor(Color.parseColor("#14233F")); cornerRadius = dp(10).toFloat() }
                setOnClickListener { dlg?.dismiss(); showNoteDialog(k, n.label) }
            }.let { tv ->
                val trash = TextView(this).apply {
                    text = "🗑"; textSize = 20f; gravity = Gravity.CENTER; setPadding(dp(10), dp(4), dp(6), dp(4))
                    setOnClickListener {
                        AlertDialog.Builder(this@BazaActivity).setMessage("Bu qeyd silinsin?\n\n" + n.label)
                            .setPositiveButton("Sil") { _, _ -> saveNote(k, n.label, "", 0L); dlg?.dismiss(); showNotesList() }
                            .setNegativeButton("Ləğv et", null).show()
                    }
                }
                val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
                row.addView(tv, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(trash, LinearLayout.LayoutParams(-2, -2))
                row
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        }
        val sv = ScrollView(this); sv.addView(col)
        val nb = AlertDialog.Builder(this).setTitle("📝 Qeydlər (${items.size})").setView(sv).setPositiveButton("Bağla", null)
        if (items.isNotEmpty()) nb.setNeutralButton("🗑 Hamısını sil") { _, _ ->
            AlertDialog.Builder(this).setMessage("Bütün qeydlər (${items.size}) və xatırlatmalar silinsin?")
                .setPositiveButton("Hamısını sil") { _, _ -> deleteAllNotes() }
                .setNegativeButton("Xeyr", null).show()
        }
        dlg = nb.show()
    }

    /** Saytdan yeniləmə zamanı borcu dəyişən mənzillərin siyahısı (son 90 gün) */
    private fun showDebtChanges(startMode: Int = 0) {
        class Ch(val skey: String, val label: String, val old: Double, val nw: Double, val ts: Long)
        val all = ArrayList<Ch>()
        try {
            editsDb.execSQL("DELETE FROM debt_log WHERE ts < ?", arrayOf<Any>(System.currentTimeMillis() - 90L * 86400000L))
            editsDb.rawQuery("SELECT skey, label, old_v, new_v, ts FROM debt_log ORDER BY ts DESC LIMIT 2000", null).use { c ->
                while (c.moveToNext()) all.add(Ch(c.getString(0) ?: "", c.getString(1) ?: "", c.getDouble(2), c.getDouble(3), c.getLong(4)))
            }
        } catch (e: Exception) { }
        val up = all.filter { it.nw > it.old }; val down = all.filter { it.nw < it.old }
        // borcunu tam ödəyib sıfıra düşənlər (köhnə borc > 0, yeni borc 0)
        val paid = all.filter { it.old > 0.0 && it.nw <= 0.0 }
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(8), dp(16), dp(4))
        col.addView(TextView(this).apply {
            textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.parseColor("#F2F2F5"))
            text = if (all.isEmpty()) "Hələ borc dəyişikliyi yoxdur. Saytdan yeniləmədən sonra burada görünəcək."
            else "✅ Borcunu ödəyib sıfırlayan: ${paid.size} (${money(paid.sumOf { it.old })} AZN)\n⬆ Artıb: ${up.size} (+${money(up.sumOf { it.nw - it.old })} AZN)\n⬇ Azalıb / ödənib: ${down.size} (−${money(down.sumOf { it.old - it.nw })} AZN)"
        })
        val list = LinearLayout(this); list.orientation = LinearLayout.VERTICAL
        var dlgD: AlertDialog? = null
        var curMode = startMode
        fun render(mode: Int) {
            curMode = mode
            list.removeAllViews()
            val base = when (mode) { 1 -> up; 2 -> down; 3 -> paid; else -> all }
            // ödəyib sıfırlayanlar həmişə başda (hər qrupda ən yenisi birinci)
            val src = base.filter { it.old > 0.0 && it.nw <= 0.0 } + base.filter { !(it.old > 0.0 && it.nw <= 0.0) }
            for (ch in src.take(300)) {
                val inc = ch.nw > ch.old
                val zero = ch.old > 0.0 && ch.nw <= 0.0
                val tv = TextView(this).apply {
                    val diff = ch.nw - ch.old
                    val sb = android.text.SpannableStringBuilder((if (zero) "✅ " else "") + ch.label + "\n")
                    sb.setSpan(StyleSpan(Typeface.BOLD), 0, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    val st = sb.length
                    if (zero) sb.append("ÖDƏYİB — BORC 0\n")
                    sb.append((if (inc) "⬆ " else "⬇ ") + money(ch.old) + " → " + money(ch.nw) + "   (" + (if (inc) "+" else "−") + money(Math.abs(diff)) + " AZN)")
                    sb.setSpan(ForegroundColorSpan(Color.parseColor(if (inc) "#FF6B6B" else "#8FD18F")), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    if (zero) sb.setSpan(StyleSpan(Typeface.BOLD), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    val st2 = sb.length
                    sb.append("\n" + dtFmt.format(java.util.Date(ch.ts)))
                    sb.setSpan(ForegroundColorSpan(Color.parseColor("#8A8A93")), st2, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    text = sb; textSize = 14f; setTextColor(Color.parseColor("#F2F2F5"))
                    setPadding(dp(12), dp(8), dp(12), dp(8))
                    background = GradientDrawable().apply {
                        setColor(Color.parseColor(if (zero) "#0F2A17" else "#14233F")); cornerRadius = dp(10).toFloat()
                        if (zero) setStroke(dp(2), Color.parseColor("#2E9E4F"))
                    }
                }
                val trash = TextView(this).apply {
                    text = "🗑"; textSize = 20f; gravity = Gravity.CENTER; setPadding(dp(10), dp(4), dp(6), dp(4))
                    setOnClickListener {
                        AlertDialog.Builder(this@BazaActivity).setMessage("Bu sətir siyahıdan silinsin?\n\n" + ch.label)
                            .setPositiveButton("Sil") { _, _ ->
                                try { editsDb.execSQL("DELETE FROM debt_log WHERE skey = ? AND ts = ? AND new_v = ?", arrayOf<Any>(ch.skey, ch.ts, ch.nw)); scheduleSync(false) } catch (e: Exception) { }
                                dlgD?.dismiss(); showDebtChanges(curMode)
                            }.setNegativeButton("Ləğv et", null).show()
                    }
                }
                val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
                row.addView(tv, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(trash, LinearLayout.LayoutParams(-2, -2))
                list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
            }
            if (src.size > 300) list.addView(TextView(this).apply { text = "… və daha ${src.size - 300} dəyişiklik"; setTextColor(Color.parseColor("#8A8A93")); setPadding(dp(4), dp(8), 0, 0) })
        }
        if (all.isNotEmpty()) {
            val tabs = LinearLayout(this); tabs.orientation = LinearLayout.HORIZONTAL
            val names = arrayOf("Hamısı (${all.size})", "⬆ Artıb (${up.size})", "⬇ Azalıb (${down.size})", "✅ Ödəyib (${paid.size})")
            names.forEachIndexed { i, nm ->
                tabs.addView(Button(this).apply { text = nm; isAllCaps = false; textSize = 11f; setOnClickListener { render(i) } },
                    LinearLayout.LayoutParams(0, -2, 1f))
            }
            col.addView(tabs, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
            render(startMode)
            col.addView(list)
        }
        val sv = ScrollView(this); sv.addView(col)
        val b = AlertDialog.Builder(this).setTitle("📈 Borc dəyişiklikləri").setView(sv).setPositiveButton("Bağla", null)
        if (all.isNotEmpty()) b.setNeutralButton("🗑 Hamısını sil") { _, _ ->
            AlertDialog.Builder(this).setMessage("Bütün borc dəyişiklikləri (${all.size} sətir) silinsin?")
                .setPositiveButton("Hamısını sil") { _, _ ->
                    try { editsDb.execSQL("DELETE FROM debt_log"); scheduleSync(false); Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show() } catch (e: Exception) { }
                }
                .setNegativeButton("Xeyr", null).show()
        }
        dlgD = b.show()
    }

    // ---------- zəng ----------
    private var pendingCall: String? = null

    /** nömrə sütunundakı bütün nömrələr (mobil və ev) zəng üçün formatlanır */
    private fun dialNumbers(raw: String): List<String> {
        fun dial(d: String): String? = when {
            d.startsWith("994") && d.length == 12 -> "+$d"
            d.length == 10 && d.startsWith("0") -> d
            d.length == 9 -> "+994$d"
            d.length in 7..8 -> d
            else -> null
        }
        return raw.split(Regex("[\\n;,/|]+")).flatMap { part ->
            val d = part.filter { it.isDigit() }
            if (dial(d) != null || !part.trim().contains(Regex("\\s"))) listOf(d)
            else part.trim().split(Regex("\\s+")).map { t -> t.filter { it.isDigit() } }
        }.mapNotNull { dial(it) }.distinct()
    }

    private fun callCard(c: Card) {
        val raw = cellOf(c, "nomre")
        val nums = dialNumbers(raw)
        if (nums.isEmpty()) {
            Toast.makeText(this, if (raw.isBlank()) "Nömrə yoxdur" else "Zəng üçün uyğun nömrə tapılmadı: $raw", Toast.LENGTH_LONG).show()
            return
        }
        if (nums.size == 1) placeCall(nums[0])
        else AlertDialog.Builder(this).setTitle("Zəng ediləcək nömrə")
            .setItems(nums.toTypedArray()) { _, i -> placeCall(nums[i]) }
            .setNegativeButton("Ləğv et", null)
            .show()
    }

    private fun placeCall(num: String) {
        // İstifadəçi zəngi təsdiqləmək üçün əvvəlcə yığım ekranını görür.
        val uri = Uri.fromParts("tel", num, null)
        dialOnly(uri)
    }

    private fun dialOnly(uri: Uri) {
        try { startActivity(Intent(Intent.ACTION_DIAL, uri)) }
        catch (e: Exception) { Toast.makeText(this, "Zəng tətbiqi tapılmadı", Toast.LENGTH_LONG).show() }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    /** Nömrə xanasını (yalnız bu sütunu) saxlayır; redaktə qeydi və sinxronlaşma saveEdit ilə eynidir */
    private fun saveNumber(card: Card, value: String, onSaved: (List<String>) -> Unit): Boolean {
        val clBefore = ChangeLog.snapshot(editsDb)
        val ni = colIdx(card.headers, "nomre")
        if (ni < 0) { Toast.makeText(this, "Nömrə sütunu tapılmadı", Toast.LENGTH_LONG).show(); return false }
        val newCells = card.cells.toMutableList()
        while (newCells.size < card.headers.size) newCells.add("")
        val nv = value.trim()
        db.rawQuery(
            "SELECT f.name, b.sheet, r.ord FROM rows r JOIN buildings b ON b.id = r.building_id " +
                "JOIN files f ON f.id = b.file_id WHERE r.id = ?", arrayOf(card.rowId.toString())
        ).use { c ->
            if (c.moveToFirst() && nv != newCells[ni]) {
                newCells[ni] = nv
                editsDb.execSQL("INSERT OR REPLACE INTO edits VALUES(?,?,?,?,?)", arrayOf<Any>(c.getString(0), c.getString(1) ?: "", c.getInt(2), ni, nv))
            }
        }
        writeRow(db, card.rowId, newCells, card.headers)
        onSaved(newCells)
        ChangeLog.record(editsDb, "📞 Nömrə: " + clLabel(card) + "\n" + card.cells.getOrElse(ni) { "" }.ifBlank { "—" } + " → " + nv.ifBlank { "—" }, clBefore)
        scheduleSync()
        return true
    }

    /** Nömrə yazma pəncərəsi. needMobile=true olarsa yalnız düzgün mobil nömrə qəbul edilir (WhatsApp üçün) */
    private fun showNumberDialog(c: Card, initial: String, needMobile: Boolean, onSaved: (List<String>) -> Unit, onDone: ((String) -> Unit)?) {
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_PHONE
        et.setText(initial); et.isSingleLine = true; et.setSelection(et.text.length)
        et.hint = "050 123 45 67"
        val box = FrameLayout(this)
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(et)
        val nm = nameOf(c).ifEmpty { unitLine(c) }
        val dlg = AlertDialog.Builder(this)
            .setTitle(if (needMobile) "Nömrə yoxdur - yazın" else "Nömrəni redaktə et")
            .setMessage(nm)
            .setView(box)
            .setPositiveButton(if (needMobile) "Yadda saxla və göndər" else "Yadda saxla", null)
            .setNegativeButton("Ləğv et", null)
            .create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val txt = et.text.toString().trim()
                val intl = intlNumber(txt.filter { it.isDigit() })
                if (needMobile && intl == null) {
                    Toast.makeText(this, "Düzgün mobil nömrə yazın (məs. 0501234567)", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                if (saveNumber(c, txt, onSaved)) {
                    dlg.dismiss()
                    if (intl != null) onDone?.invoke(intl)
                }
            }
            et.requestFocus()
            dlg.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
        }
        dlg.show()
    }

    private fun sendMsg(c: Card, whatsapp: Boolean, onNumSaved: (List<String>) -> Unit = { }) {
        val raw = cellOf(c, "nomre")
        val nums = raw.split(Regex("[\\n;,/|]+")).flatMap { part ->
            val d = part.filter { it.isDigit() }
            // bir hissədə boşluqla ayrılmış bir neçə nömrə ola bilər (ev + mobil)
            if (intlNumber(d) != null || !part.trim().contains(Regex("\\s"))) listOf(d)
            else part.trim().split(Regex("\\s+")).map { t -> t.filter { it.isDigit() } }
        }.mapNotNull { intlNumber(it) }.distinct()
        // Hər dəfə nömrə siyahısı + altında "Nömrə əlavə et" düyməsi göstərilir
        showSendNumberPicker(c, raw, nums, whatsapp, onNumSaved)
    }

    /** Göndəriləcək nömrəni seçmək pəncərəsi: nömrələrin altında "➕ Nömrə əlavə et" düyməsi */
    private fun showSendNumberPicker(c: Card, raw: String, nums: List<String>, whatsapp: Boolean, onNumSaved: (List<String>) -> Unit) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(4))
        var dlg: AlertDialog? = null
        if (nums.isEmpty()) {
            box.addView(TextView(this).apply {
                text = if (raw.isBlank()) "Nömrə yoxdur" else "Mobil nömrə tapılmadı: $raw"
                textSize = 14f; setTextColor(Color.parseColor("#B3B3BD")); setPadding(dp(4), dp(8), dp(4), dp(8))
            })
        }
        for (n in nums) {
            box.addView(TextView(this).apply {
                text = "+$n"; textSize = 18f; setTextColor(Color.parseColor("#F2F2F5"))
                setPadding(dp(12), dp(12), dp(12), dp(12))
                background = GradientDrawable().apply { setColor(Color.parseColor("#14233F")); cornerRadius = dp(10).toFloat() }
                setOnClickListener { dlg?.dismiss(); launchMsg(n, c, whatsapp) }
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        }
        box.addView(TextView(this).apply {
            text = "➕  Nömrə əlavə et"; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#4F8CFF"))
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#10141C")); cornerRadius = dp(10).toFloat(); setStroke(dp(1), Color.parseColor("#4F8CFF"))
            }
            setOnClickListener { dlg?.dismiss(); showAddNumberDialog(c, raw, whatsapp, onNumSaved) }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        val sv = ScrollView(this); sv.addView(box)
        dlg = AlertDialog.Builder(this)
            .setTitle(if (nums.isEmpty()) "Nömrə yoxdur" else "Nömrəni seçin")
            .setView(sv)
            .setNegativeButton("Ləğv et", null)
            .show()
    }

    /** Yeni mobil nömrə yazılır, mövcud nömrələrin yanına əlavə edilib saxlanılır və həmin nömrəyə mesaj göndərilir */
    private fun showAddNumberDialog(c: Card, raw: String, whatsapp: Boolean, onNumSaved: (List<String>) -> Unit) {
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_PHONE
        et.isSingleLine = true; et.hint = "050 123 45 67"
        val box = FrameLayout(this)
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(et)
        val dlg = AlertDialog.Builder(this)
            .setTitle("Nömrə əlavə et")
            .setMessage(nameOf(c).ifEmpty { unitLine(c) })
            .setView(box)
            .setPositiveButton("Yadda saxla və göndər", null)
            .setNegativeButton("Ləğv et", null)
            .create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val txt = et.text.toString().trim()
                val intl = intlNumber(txt.filter { it.isDigit() })
                if (intl == null) {
                    Toast.makeText(this, "Düzgün mobil nömrə yazın (məs. 0501234567)", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                val merged = if (raw.isBlank()) txt else raw.trim().trimEnd(';', ',', '/', '|') + "; " + txt
                if (saveNumber(c, merged, onNumSaved)) {
                    dlg.dismiss()
                    launchMsg(intl, c, whatsapp)
                }
            }
            et.requestFocus()
            dlg.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
        }
        dlg.show()
    }

    private fun refreshCards() {
        catSearch.refreshView(); cardAdapterCat.notifyDataSetChanged(); updateNotesBtn()
    }

    private fun markSent(c: Card, whatsapp: Boolean) {
        if (c.skey.isEmpty()) return
        val kind = if (whatsapp) "wa" else "sms"
        if (sentSet.add(c.skey + "|" + kind)) editsDb.execSQL("INSERT OR REPLACE INTO sent VALUES(?, ?)", arrayOf<Any>(c.skey, kind))
        // "Göndərildi" yalnız bu telefonda göstərilir; Supabase-ə sinxronlaşdırılmır.
        refreshCards()
    }

    private fun unmarkSent(c: Card, whatsapp: Boolean) {
        val kind = if (whatsapp) "wa" else "sms"
        if (sentSet.remove(c.skey + "|" + kind)) {
            editsDb.execSQL("DELETE FROM sent WHERE skey = ? AND kind = ?", arrayOf<Any>(c.skey, kind))
            Toast.makeText(this, "Göndərildi işarəsi silindi", Toast.LENGTH_SHORT).show()
            // Yerli işarənin silinməsi baza məlumatı dəyişikliyi deyil.
            refreshCards()
        }
    }

    /** WhatsApp düyməsi ilə göndərilən hər mesaj sayğaca yazılır */
    private fun logWa(c: Card) {
        val p = c.skey.split("|")
        val ord = p.lastOrNull()?.toIntOrNull() ?: -1
        val sheet = if (p.size >= 3) p[p.size - 2] else ""
        val file = if (p.size >= 3) p.dropLast(2).joinToString("|") else ""
        editsDb.execSQL("INSERT INTO wa_log VALUES(?,?,?,?)", arrayOf<Any>(file, sheet, ord, System.currentTimeMillis()))
        ui.post { if (::catList.isInitialized) loadLevel(false, true) }
    }

    /** (fayla görə, fayl+vərəqə görə) göndərilmiş WhatsApp mesajlarının sayı */
    private fun dayStart(): Long = java.util.Calendar.getInstance().apply {
        set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0)
        set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
    }.timeInMillis
    private var waDay = 0L

    private fun waMaps(): Pair<HashMap<String, Int>, HashMap<String, Int>> {
        val byFile = HashMap<String, Int>(); val byFS = HashMap<String, Int>()
        val start = dayStart()
        waDay = start
        try {
            // Sayğac hər gün sıfırlanır: yalnız bu günün mesajları sayılır, köhnə qeydlər silinir.
            editsDb.execSQL("DELETE FROM wa_log WHERE ts < ?", arrayOf<Any>(start))
            editsDb.rawQuery("SELECT file, sheet, COUNT(*) FROM wa_log GROUP BY file, sheet", null).use { c ->
                while (c.moveToNext()) {
                    val f = c.getString(0) ?: ""; val sh = c.getString(1) ?: ""; val n = c.getInt(2)
                    byFile[f] = (byFile[f] ?: 0) + n
                    byFS["$f|$sh"] = n
                }
            }
        } catch (e: Exception) { }
        return Pair(byFile, byFS)
    }

    private var catWa = ArrayList<Int>()
    private fun waSuffix(n: Int) = "\n💬 WhatsApp (bu gün): $n"

    private fun computeCatWa() {
        catWa = ArrayList()
        val (byFile, byFS) = waMaps()
        val fk = if (level >= 1) fileKeyName(fileId) else ""
        for (id in catIds) {
            var n = 0
            when (level) {
                0 -> n = byFile[fileKeyName(id)] ?: 0
                1 -> db.rawQuery("SELECT DISTINCT sheet FROM buildings WHERE street_id = ?", arrayOf(id.toString()))
                    .use { while (it.moveToNext()) n += byFS["$fk|${it.getString(0) ?: ""}"] ?: 0 }
                2 -> db.rawQuery("SELECT sheet FROM buildings WHERE id = ?", arrayOf(id.toString()))
                    .use { if (it.moveToFirst()) n = byFS["$fk|${it.getString(0) ?: ""}"] ?: 0 }
            }
            catWa.add(n)
        }
    }

    private fun launchMsg(num: String, c: Card, whatsapp: Boolean) {
        try {
            if (whatsapp) {
                val text = java.net.URLEncoder.encode(waText(c), "UTF-8").replace("+", "%20")
                val uri = Uri.parse("https://wa.me/$num?text=$text")
                var done = false
                for (pkg in arrayOf("com.whatsapp", "com.whatsapp.w4b")) {
                    try {
                        val it = Intent(Intent.ACTION_VIEW, uri)
                        it.setPackage(pkg)
                        startActivity(it)
                        done = true
                        break
                    } catch (e: Exception) { }
                }
                if (!done) startActivity(Intent(Intent.ACTION_VIEW, uri))
            } else {
                val it = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:+$num"))
                it.putExtra("sms_body", smsText(c))
                startActivity(it)
            }
            markSent(c, whatsapp)
            if (whatsapp) logWa(c)
        } catch (e: Exception) {
            Toast.makeText(this, "Tətbiq açıla bilmədi", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- kataloq adlarının redaktəsi ----------
    private fun fileKeyName(fid: Long): String {
        var n = ""
        db.rawQuery("SELECT name FROM files WHERE id = ?", arrayOf(fid.toString())).use { if (it.moveToFirst()) n = it.getString(0) }
        return n
    }

    // ---------- fayl / küçə / bina menyusu (uzun basma) ----------
    private fun scalarLongE(sql: String, vararg a: String): Long {
        var r = 0L
        editsDb.rawQuery(sql, arrayOf(*a)).use { if (it.moveToFirst()) r = it.getLong(0) }
        return r
    }

    private fun catKindName() = when (level) { 0 -> "fayl"; 1 -> "küçə"; else -> "bina" }

    /** jurnalda yeri göstərmək üçün: «(fayl › küçə)» */
    private fun catWhere(): String = when (level) {
        1 -> "  (" + (tvPathName(fileId)) + ")"
        2 -> "  (" + tvPathName(fileId) + " › " + streetName + ")"
        else -> ""
    }

    private fun tvPathName(fid: Long): String {
        var n = ""
        db.rawQuery("SELECT COALESCE(NULLIF(disp, ''), name) FROM files WHERE id = ?", arrayOf(fid.toString())).use { if (it.moveToFirst()) n = it.getString(0) ?: "" }
        return n
    }

    private fun showCatMenu(pos: Int) {
        catSearch.hideSug()
        val items = ArrayList<String>(); val acts = ArrayList<() -> Unit>()
        items.add("✏️  Adını dəyiş"); acts.add { showRenameDialog(pos) }
        if (level >= 1) { items.add("↔️  Köçür"); acts.add { showMoveDialog(pos) } }
        items.add("🗑  Sil"); acts.add { confirmDeleteCat(pos) }
        AlertDialog.Builder(this).setTitle(catNames[pos]).setItems(items.toTypedArray()) { _, i -> acts[i]() }
            .setNegativeButton("Bağla", null).show()
    }

    private fun confirmDeleteCat(pos: Int) {
        val id = catIds[pos]
        val (nb, nr) = when (level) {
            0 -> Pair(scalarLong(db, "SELECT COUNT(*) FROM buildings WHERE file_id = ?", id.toString()),
                scalarLong(db, "SELECT COUNT(*) FROM rows WHERE building_id IN (SELECT id FROM buildings WHERE file_id = ?)", id.toString()))
            1 -> Pair(scalarLong(db, "SELECT COUNT(*) FROM buildings WHERE street_id = ?", id.toString()),
                scalarLong(db, "SELECT COUNT(*) FROM rows WHERE building_id IN (SELECT id FROM buildings WHERE street_id = ?)", id.toString()))
            else -> Pair(1L, scalarLong(db, "SELECT COUNT(*) FROM rows WHERE building_id = ?", id.toString()))
        }
        val inside = if (level == 2) "İçindəki $nr mənzil də silinəcək." else "İçindəki $nb bina, $nr mənzil də silinəcək."
        AlertDialog.Builder(this).setTitle("Sil")
            .setMessage("«" + catNames[pos] + "» (" + catKindName() + ") silinsin?\n\n" + inside + "\n\nBu əməliyyat geri alınmır.")
            .setPositiveButton("Sil") { _, _ -> doDeleteCat(pos) }
            .setNegativeButton("Ləğv et", null).show()
    }

    private fun doDeleteCat(pos: Int) {
        val id = catIds[pos]; val nm = catNames[pos]
        val where = catWhere(); val kind = catKindName()
        val clBefore = ChangeLog.snapshot(editsDb)
        try {
            when (level) {
                0 -> {
                    editsDb.execSQL("INSERT OR REPLACE INTO deleted_cats VALUES('f', ?, '')", arrayOf<Any>(fileKeyName(id)))
                    deleteFileSql(db, id)
                }
                1 -> {
                    val fk = fileKeyName(fileId)
                    editsDb.execSQL("INSERT OR REPLACE INTO deleted_cats VALUES('s', ?, ?)", arrayOf<Any>(fk, origStreetName(fk, nm)))
                    deleteStreetSql(db, id)
                }
                else -> {
                    var sheet = ""
                    db.rawQuery("SELECT sheet FROM buildings WHERE id = ?", arrayOf(id.toString())).use { if (it.moveToFirst()) sheet = it.getString(0) ?: "" }
                    editsDb.execSQL("INSERT OR REPLACE INTO deleted_cats VALUES('b', ?, ?)", arrayOf<Any>(fileKeyName(fileId), sheet))
                    deleteBuildingSql(db, id)
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Xəta: ${e.message}", Toast.LENGTH_LONG).show(); return
        }
        ChangeLog.record(editsDb, "🗑 Silindi ($kind): $nm$where", clBefore)
        Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
        scheduleSync()
        loadLevel(false, true)
    }

    private fun filesDisp(): List<Pair<Long, String>> {
        val l = ArrayList<Pair<Long, String>>()
        db.rawQuery("SELECT id, COALESCE(NULLIF(disp, ''), name) FROM files ORDER BY ord", null).use { c -> while (c.moveToNext()) l.add(Pair(c.getLong(0), c.getString(1) ?: "")) }
        return l
    }

    private fun showMoveDialog(pos: Int) {
        val files = filesDisp()
        if (level == 1) {
            val cand = files.filter { it.first != fileId }
            if (cand.isEmpty()) { Toast.makeText(this, "Başqa fayl yoxdur", Toast.LENGTH_SHORT).show(); return }
            AlertDialog.Builder(this).setTitle("«" + catNames[pos] + "» hansı fayla köçürülsün?")
                .setItems(cand.map { it.second }.toTypedArray()) { _, i -> doMoveStreet(pos, cand[i].first) }
                .setNegativeButton("Ləğv et", null).show()
        } else {
            AlertDialog.Builder(this).setTitle("«" + catNames[pos] + "» hansı fayla köçürülsün?")
                .setItems(files.map { it.second }.toTypedArray()) { _, i -> pickStreetForMove(pos, files[i].first) }
                .setNegativeButton("Ləğv et", null).show()
        }
    }

    private fun pickStreetForMove(pos: Int, destFid: Long) {
        val l = ArrayList<Pair<Long, String>>()
        db.rawQuery("SELECT id, name FROM streets WHERE file_id = ? ORDER BY ord", arrayOf(destFid.toString())).use { c -> while (c.moveToNext()) l.add(Pair(c.getLong(0), c.getString(1) ?: "")) }
        if (l.isEmpty()) { Toast.makeText(this, "Bu faylda küçə yoxdur", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("Hansı küçəyə?")
            .setItems(l.map { it.second }.toTypedArray()) { _, i -> doMoveBuilding(pos, destFid, l[i].first, l[i].second) }
            .setNegativeButton("Ləğv et", null).show()
    }

    /** Binanın (fayl, vərəq) açarı ilə bağlı redaktə qeydləri yeni fayla keçirilir */
    private fun rekeyBuilding(srcFk: String, destFk: String, sheet: String) {
        val a = arrayOf<Any>(destFk, srcFk, sheet)
        editsDb.execSQL("UPDATE OR REPLACE edits SET file = ? WHERE file = ? AND sheet = ?", a)
        editsDb.execSQL("UPDATE OR REPLACE added_rows SET file = ? WHERE file = ? AND sheet = ?", a)
        editsDb.execSQL("UPDATE OR REPLACE deleted_rows SET file = ? WHERE file = ? AND sheet = ?", a)
        editsDb.execSQL("UPDATE OR REPLACE sheet_upd SET file = ? WHERE file = ? AND sheet = ?", a)
        editsDb.execSQL("UPDATE OR REPLACE renames SET a = ? WHERE kind = 'b' AND a = ? AND b = ?", a)
    }

    private fun doMoveBuilding(pos: Int, destFid: Long, destSid: Long, destSName: String) {
        val bId = catIds[pos]; val nm = catNames[pos]
        if (destSid == streetId) { Toast.makeText(this, "Bina artıq bu küçədədir", Toast.LENGTH_SHORT).show(); return }
        var sheet = ""
        db.rawQuery("SELECT sheet FROM buildings WHERE id = ?", arrayOf(bId.toString())).use { if (it.moveToFirst()) sheet = it.getString(0) ?: "" }
        if (scalarLong(db, "SELECT id FROM buildings WHERE file_id = ? AND sheet = ? AND id <> ?", destFid.toString(), sheet, bId.toString()) >= 0) {
            Toast.makeText(this, "Bu faylda eyni adlı bina var", Toast.LENGTH_LONG).show(); return
        }
        val srcFk = fileKeyName(fileId); val destFk = fileKeyName(destFid)
        val destOrig = origStreetName(destFk, destSName)
        val from = tvPathName(fileId) + " › " + streetName
        val to = tvPathName(destFid) + " › " + destSName
        val clBefore = ChangeLog.snapshot(editsDb)
        try {
            if (scalarLongE("SELECT COUNT(*) FROM added WHERE kind = 'b' AND a = ? AND name = ?", srcFk, sheet) > 0) {
                editsDb.execSQL("DELETE FROM added WHERE kind = 'b' AND a = ? AND name = ?", arrayOf<Any>(srcFk, sheet))
                editsDb.execSQL("INSERT OR REPLACE INTO added VALUES('b', ?, ?, ?)", arrayOf<Any>(destFk, destOrig, sheet))
            } else {
                editsDb.execSQL("INSERT OR REPLACE INTO moved_cats VALUES('b', ?, ?, ?, ?)", arrayOf<Any>(srcFk, sheet, destFk, destOrig))
            }
            if (srcFk != destFk) rekeyBuilding(srcFk, destFk, sheet)
            moveBuildingSql(db, bId, destFid, destSid)
        } catch (e: Exception) {
            Toast.makeText(this, "Xəta: ${e.message}", Toast.LENGTH_LONG).show(); return
        }
        ChangeLog.record(editsDb, "↔️ Bina köçürüldü: $nm\n$from → $to", clBefore)
        Toast.makeText(this, "Köçürüldü", Toast.LENGTH_SHORT).show()
        scheduleSync()
        loadLevel(false, true)
    }

    private fun doMoveStreet(pos: Int, destFid: Long) {
        val sId = catIds[pos]; val nm = catNames[pos]
        val srcFk = fileKeyName(fileId); val destFk = fileKeyName(destFid)
        val orig = origStreetName(srcFk, nm)
        if (streetIdOf(db, destFid, nm) >= 0) { Toast.makeText(this, "Bu faylda eyni adlı küçə var", Toast.LENGTH_LONG).show(); return }
        val sheets = ArrayList<String>()
        db.rawQuery("SELECT sheet FROM buildings WHERE street_id = ?", arrayOf(sId.toString())).use { c -> while (c.moveToNext()) sheets.add(c.getString(0) ?: "") }
        for (sh in sheets) {
            if (scalarLong(db, "SELECT id FROM buildings WHERE file_id = ? AND sheet = ?", destFid.toString(), sh) >= 0) {
                Toast.makeText(this, "Hədəf faylda eyni adlı bina var: $sh", Toast.LENGTH_LONG).show(); return
            }
        }
        val from = tvPathName(fileId); val to = tvPathName(destFid)
        val clBefore = ChangeLog.snapshot(editsDb)
        try {
            if (scalarLongE("SELECT COUNT(*) FROM added WHERE kind = 's' AND a = ? AND name = ?", srcFk, orig) > 0) {
                editsDb.execSQL("DELETE FROM added WHERE kind = 's' AND a = ? AND name = ?", arrayOf<Any>(srcFk, orig))
                editsDb.execSQL("INSERT OR REPLACE INTO added VALUES('s', ?, '', ?)", arrayOf<Any>(destFk, orig))
                editsDb.execSQL("UPDATE OR REPLACE added SET a = ? WHERE kind = 'b' AND a = ? AND b = ?", arrayOf<Any>(destFk, srcFk, orig))
            } else {
                editsDb.execSQL("INSERT OR REPLACE INTO moved_cats VALUES('s', ?, ?, ?, '')", arrayOf<Any>(srcFk, orig, destFk))
            }
            if (srcFk != destFk) {
                for (sh in sheets) rekeyBuilding(srcFk, destFk, sh)
                editsDb.execSQL("UPDATE OR REPLACE renames SET a = ? WHERE kind = 's' AND a = ? AND b = ?", arrayOf<Any>(destFk, srcFk, orig))
            }
            moveStreetSql(db, sId, destFid)
        } catch (e: Exception) {
            Toast.makeText(this, "Xəta: ${e.message}", Toast.LENGTH_LONG).show(); return
        }
        ChangeLog.record(editsDb, "↔️ Küçə köçürüldü: $nm\n$from → $to", clBefore)
        Toast.makeText(this, "Köçürüldü", Toast.LENGTH_SHORT).show()
        scheduleSync()
        loadLevel(false, true)
    }

    // ---------- «Dəyişikliklər»: gözləyən təkliflər (təsdiq / ləğv) + tarixçə ----------
    private var changesDlg: AlertDialog? = null
    private lateinit var btnChanges: Button
    private val changesPoll = object : Runnable {
        override fun run() {
            if (changesDlg?.isShowing != true) return
            Thread { PendingChanges.syncNow() }.start()
            ui.postDelayed(this, 10000)
        }
    }

    /** Düymədəki gözləyən təkliflərin sayı */
    private fun updateChangesBadge() {
        if (!::btnChanges.isInitialized || !::editsDb.isInitialized) return
        val n = PendingChanges.pendingCount(editsDb)
        btnChanges.text = if (n > 0) "📝 Dəyişikliklər ($n)" else "📝 Dəyişikliklər"
    }

    private fun smallBtn(label: String, color: String, onClick: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 12f; setTextColor(Color.WHITE)
        minHeight = 0; minimumHeight = 0; minWidth = 0; minimumWidth = 0
        setPadding(dp(14), dp(4), dp(14), dp(4))
        background = GradientDrawable().apply { setColor(Color.parseColor(color)); cornerRadius = dp(10).toFloat() }
        setOnClickListener { onClick() }
    }

    private fun showChangesDialog() {
        catSearch.hideSug()
        try { changesDlg?.dismiss() } catch (e: Exception) { }
        val pend = PendingChanges.pending(editsDb)
        val hist = PendingChanges.history(editsDb)
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(8), dp(16), dp(4))
        val fmt = java.text.SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
        val white = Color.parseColor("#F2F2F5"); val grey = Color.parseColor("#8A8A93")
        fun head(t: String) = col.addView(TextView(this).apply {
            text = t; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.parseColor("#7FD6A8")); setPadding(0, dp(8), 0, dp(4))
        })
        fun stamp(ts: Long, who: String): android.text.SpannableStringBuilder {
            val sb = android.text.SpannableStringBuilder(fmt.format(java.util.Date(ts)) + (if (who.isEmpty()) "" else "  ·  📱 $who") + "\n")
            sb.setSpan(ForegroundColorSpan(grey), 0, sb.length, android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            return sb
        }
        fun divider() = col.addView(View(this).apply { setBackgroundColor(Color.parseColor("#232328")) }, LinearLayout.LayoutParams(-1, dp(1)))

        head("⏳ Gözləyən dəyişikliklər" + (if (pend.isEmpty()) "" else " (${pend.size})"))
        if (pend.isEmpty()) {
            col.addView(TextView(this).apply {
                textSize = 13f; setTextColor(grey); setPadding(0, 0, 0, dp(6))
                text = "Gözləyən dəyişiklik yoxdur. WhatsApp ilə göndərəndə yeni mənzil, yeni küçə və ya küçə/bina köçürməsi bazaya özü yazılmır, burada görünür; təsdiq edəndə bazaya yazılır."
            })
        }
        for (it in pend) {
            val box = LinearLayout(this); box.orientation = LinearLayout.VERTICAL; box.setPadding(0, dp(6), 0, dp(8))
            val sb = stamp(it.ts, it.devName); sb.append(it.descr)
            box.addView(TextView(this).apply { textSize = 13f; setTextColor(white); text = sb })
            val btns = LinearLayout(this); btns.orientation = LinearLayout.HORIZONTAL
            btns.addView(smallBtn("✅ Təsdiq", "#2E7D5B") { approvePending(it) }, LinearLayout.LayoutParams(-2, dp(36)))
            btns.addView(smallBtn("✖ Ləğv", "#8A3B3B") { cancelPending(it) }, LinearLayout.LayoutParams(-2, dp(36)).apply { leftMargin = dp(10) })
            box.addView(btns, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6) })
            col.addView(box)
            divider()
        }

        head("🕘 Tarixçə")
        if (hist.isEmpty()) {
            col.addView(TextView(this).apply { textSize = 13f; setTextColor(grey); text = "Hələ qeyd yoxdur." })
        }
        for (h in hist.take(200)) {
            val sb = stamp(h.ts, if (h.remote) h.devName.ifBlank { "digər cihaz" } else ""); sb.append(h.descr)
            col.addView(TextView(this).apply { textSize = 13f; setTextColor(white); text = sb; setPadding(0, dp(6), 0, dp(6)) })
            divider()
        }
        val sv = ScrollView(this); sv.addView(col)
        val b = AlertDialog.Builder(this).setTitle("📝 Dəyişikliklər").setView(sv).setPositiveButton("Bağla", null)
        if (hist.any { !it.remote }) b.setNeutralButton("🗑 Tarixçəni təmizlə") { _, _ ->
            AlertDialog.Builder(this).setMessage("Bu telefonun tarixçəsi təmizlənsin? Dəyişikliklər özü qalır.")
                .setPositiveButton("Təmizlə") { _, _ -> ChangeLog.clear(editsDb); PendingChanges.syncSoon() }
                .setNegativeButton("Ləğv et", null).show()
        }
        val dlg = b.show()
        changesDlg = dlg
        dlg.setOnDismissListener { ui.removeCallbacks(changesPoll) }
        updateChangesBadge()
        // açılanda dərhal və sonra hər 10 saniyədə serverdən başqa cihazın təklifləri götürülür
        ui.removeCallbacks(changesPoll)
        Thread { PendingChanges.syncNow() }.start()
        ui.postDelayed(changesPoll, 10000)
    }

    private fun cancelPending(it: PendingChanges.Item) {
        PendingChanges.resolve(editsDb, it.id, "cancelled")
        Toast.makeText(this, "Ləğv edildi", Toast.LENGTH_SHORT).show()
        showChangesDialog()
    }

    /** Təsdiq: təklif indi bazaya yazılır (bazaya yazma MainActivity-dəki ilə eyni koddur) */
    private fun approvePending(it: PendingChanges.Item) {
        if (refresher != null) { Toast.makeText(this, "Əvvəlcə yenilənmənin bitməsini gözləyin", Toast.LENGTH_SHORT).show(); return }
        Thread {
            var msg = ""
            var done = true
            try {
                val p = JSONObject(it.payload)
                val ops = BazaOps(this)
                val code = p.optString("code")
                when (it.kind) {
                    PendingChanges.KIND_MENZIL, PendingChanges.KIND_KUCE -> {
                        val r = ops.addNewToBazaImpl(code, p.optString("phone"), p.optString("name"), p.optString("borc"),
                            p.optString("street"), p.optString("menzil"))
                        msg = when (r) {
                            1 -> "Bazaya əlavə olundu"
                            2 -> "Bu YVÖK artıq bazada var, əlavə olunmadı"
                            else -> "Əlavə etmək mümkün olmadı"
                        }
                        if (r == 0) done = false
                    }
                    PendingChanges.KIND_KOCUR -> {
                        val ok = ops.relocateExistingImpl(code, p.optString("street"))
                        msg = if (ok) "Köçürüldü" else "Köçürmə artıq aktual deyil"
                    }
                    else -> { msg = "Naməlum təklif"; done = false }
                }
            } catch (e: Throwable) {
                msg = "Xəta: ${e.message}"; done = false
            }
            runOnUiThread {
                if (done) PendingChanges.resolve(editsDb, it.id, "approved")
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                try { afterRefresh() } catch (e: Exception) { }
                scheduleSync()
                showChangesDialog()
            }
        }.start()
    }

    private fun showRenameDialog(pos: Int) {
        val et = EditText(this)
        et.setText(catNames[pos]); et.isSingleLine = true; et.setSelection(et.text.length)
        val box = FrameLayout(this)
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(et)
        AlertDialog.Builder(this).setTitle("Adı dəyiş").setView(box)
            .setPositiveButton("Yadda saxla") { _, _ ->
                val nv = et.text.toString().trim()
                if (nv.isNotEmpty() && nv != catNames[pos]) renameCatItem(pos, nv)
            }
            .setNegativeButton("Ləğv et", null)
            .show()
    }

    private fun renameCatItem(pos: Int, nv: String) {
        val clBefore = ChangeLog.snapshot(editsDb)
        val id = catIds[pos]
        val cur = catNames[pos]
        when (level) {
            0 -> {
                val key = fileKeyName(id)
                if (nv == key) {
                    db.execSQL("UPDATE files SET disp = NULL WHERE id = ?", arrayOf<Any>(id))
                    editsDb.execSQL("DELETE FROM renames WHERE kind = 'f' AND a = ? AND b = ''", arrayOf<Any>(key))
                } else {
                    db.execSQL("UPDATE files SET disp = ? WHERE id = ?", arrayOf<Any>(nv, id))
                    editsDb.execSQL("INSERT OR REPLACE INTO renames VALUES('f', ?, '', ?)", arrayOf<Any>(key, nv))
                }
            }
            1 -> {
                val fk = fileKeyName(fileId)
                var orig = cur
                editsDb.rawQuery("SELECT b FROM renames WHERE kind = 's' AND a = ? AND value = ?", arrayOf(fk, cur)).use {
                    if (it.moveToFirst()) orig = it.getString(0)
                }
                db.execSQL("UPDATE streets SET name = ?, name_n = ? WHERE id = ?", arrayOf<Any>(nv, fold(nv), id))
                if (nv == orig) editsDb.execSQL("DELETE FROM renames WHERE kind = 's' AND a = ? AND b = ?", arrayOf<Any>(fk, orig))
                else editsDb.execSQL("INSERT OR REPLACE INTO renames VALUES('s', ?, ?, ?)", arrayOf<Any>(fk, orig, nv))
            }
            else -> {
                val fk = fileKeyName(fileId)
                var sheet = ""
                var title = ""
                db.rawQuery("SELECT sheet, title FROM buildings WHERE id = ?", arrayOf(id.toString())).use {
                    if (it.moveToFirst()) { sheet = it.getString(0) ?: ""; title = it.getString(1) ?: "" }
                }
                db.execSQL("UPDATE buildings SET name = ?, name_n = ? WHERE id = ?", arrayOf<Any>(nv, fold("$nv $title"), id))
                editsDb.execSQL("INSERT OR REPLACE INTO renames VALUES('b', ?, ?, ?)", arrayOf<Any>(fk, sheet, nv))
            }
        }
        ChangeLog.record(editsDb, "✏️ Ad dəyişdi (" + catKindName() + "): " + cur + " → " + nv + catWhere(), clBefore)
        scheduleSync()
        loadLevel(false, true)
    }

    private fun replayRenames(d: SQLiteDatabase) {
        val l = ArrayList<Array<String>>()
        editsDb.rawQuery("SELECT kind, a, b, value FROM renames", null).use { c ->
            while (c.moveToNext()) l.add(arrayOf(c.getString(0), c.getString(1), c.getString(2) ?: "", c.getString(3)))
        }
        for (r in l) {
            try {
                when (r[0]) {
                    "f" -> d.execSQL("UPDATE files SET disp = ? WHERE name = ?", arrayOf<Any>(r[3], r[1]))
                    "s" -> d.execSQL(
                        "UPDATE streets SET name = ?, name_n = ? WHERE name = ? AND file_id = (SELECT id FROM files WHERE name = ?)",
                        arrayOf<Any>(r[3], fold(r[3]), r[2], r[1])
                    )
                    "b" -> {
                        var bid = -1L
                        var title = ""
                        d.rawQuery(
                            "SELECT id, title FROM buildings WHERE sheet = ? AND file_id = (SELECT id FROM files WHERE name = ?)",
                            arrayOf(r[2], r[1])
                        ).use { if (it.moveToFirst()) { bid = it.getLong(0); title = it.getString(1) ?: "" } }
                        if (bid >= 0) d.execSQL(
                            "UPDATE buildings SET name = ?, name_n = ? WHERE id = ?",
                            arrayOf<Any>(r[3], fold(r[3] + " " + title), bid)
                        )
                    }
                }
            } catch (e: Exception) { }
        }
    }

    // =====================================================================
    //  Excel export / import
    // =====================================================================
    private val RC_EXPORT = 201
    private val RC_EXPORT_DIR = 202
    private val RC_IMPORT = 203
    private val XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    private class ExB(val id: Long, val name: String)
    private class ExStreet(val id: Long, val fileName: String, val name: String, val bs: List<ExB>)
    private var pendingExportIds: List<Long> = emptyList()
    private var pendingExportGroups: List<Pair<String, List<Long>>> = emptyList()
    private var pendingExportName = "Export"
    private val sentSet = HashSet<String>()

    private class ImpSheet(val name: String, val title: String, val headers: List<String>, val rows: List<List<String>>)

    private fun filesList(): List<Pair<Long, String>> {
        val l = ArrayList<Pair<Long, String>>()
        db.rawQuery("SELECT id, name FROM files ORDER BY ord", null).use { c -> while (c.moveToNext()) l.add(Pair(c.getLong(0), c.getString(1))) }
        return l
    }

    private fun safeName(s: String) = s.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()

    private fun busyDialog(title: String): AlertDialog {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.HORIZONTAL
        box.gravity = Gravity.CENTER_VERTICAL
        box.setPadding(dp(20), dp(16), dp(20), dp(16))
        box.addView(ProgressBar(this))
        box.addView(TextView(this).apply { text = "  Gözləyin…"; textSize = 15f })
        val d = AlertDialog.Builder(this).setTitle(title).setView(box).setCancelable(false).create()
        d.show()
        return d
    }

    private fun showExcelMenu() {
        AlertDialog.Builder(this).setTitle("Excel")
            .setItems(arrayOf("📤  Export (bazanı Excel-ə çıxar)", "📥  Import (Excel-dən bazaya yüklə)")) { _, which ->
                when (which) { 0 -> chooseExport(); else -> pickImport() }
            }
            .setNegativeButton("Ləğv et", null)
            .show()
    }

    /** Export: küçələr (açılıb-bağlanan), hər küçənin və hər binanın sağında quş işarəsi; yuxarıda "Hamısını seç" */
    private fun chooseExport() {
        val list = ArrayList<ExStreet>()
        db.rawQuery("SELECT s.id, f.name, s.name FROM streets s JOIN files f ON f.id = s.file_id ORDER BY f.ord, s.ord", null).use { c ->
            while (c.moveToNext()) {
                val sid = c.getLong(0)
                val bl = ArrayList<ExB>()
                db.rawQuery("SELECT id, name FROM buildings WHERE street_id = ? ORDER BY ord", arrayOf(sid.toString())).use { bc ->
                    while (bc.moveToNext()) bl.add(ExB(bc.getLong(0), bc.getString(1) ?: ""))
                }
                if (bl.isNotEmpty()) list.add(ExStreet(sid, c.getString(1) ?: "", c.getString(2) ?: "", bl))
            }
        }
        if (list.isEmpty()) { Toast.makeText(this, "Export üçün küçə yoxdur", Toast.LENGTH_SHORT).show(); return }

        val bChecks = ArrayList<List<CheckBox>>()
        val sChecks = ArrayList<CheckBox>()
        val sLabels = ArrayList<TextView>()
        var syncing = false
        var dlg: AlertDialog? = null
        val allCb = CheckBox(this)

        fun updateBtn() {
            val n = bChecks.sumOf { l -> l.count { it.isChecked } }
            dlg?.getButton(AlertDialog.BUTTON_POSITIVE)?.apply { text = if (n > 0) "Export ($n)" else "Export"; isEnabled = n > 0 }
            dlg?.getButton(AlertDialog.BUTTON_NEUTRAL)?.isEnabled = n > 0
        }
        fun refreshStreet(i: Int) {
            val n = bChecks[i].count { it.isChecked }
            sLabels[i].text = list[i].name + "  ·  " + (if (n > 0) "$n/" else "") + list[i].bs.size + " bina"
        }
        fun syncAll() {
            syncing = true; allCb.isChecked = bChecks.all { l -> l.all { it.isChecked } }; syncing = false
        }
        fun bRow(label: String, cb: CheckBox): LinearLayout {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(dp(44), dp(9), dp(16), dp(9))
            val tv = TextView(this); tv.text = label; tv.textSize = 14f
            cb.isClickable = false; cb.isFocusable = false
            r.addView(tv, LinearLayout.LayoutParams(0, -2, 1f))
            r.addView(cb, LinearLayout.LayoutParams(-2, -2))
            r.setOnClickListener { cb.isChecked = !cb.isChecked }
            return r
        }

        // "Hamısını seç"
        val allRow = LinearLayout(this)
        allRow.orientation = LinearLayout.HORIZONTAL
        allRow.gravity = Gravity.CENTER_VERTICAL
        allRow.setPadding(dp(20), dp(10), dp(16), dp(10))
        val allTv = TextView(this); allTv.text = "Hamısını seç"; allTv.textSize = 16f; allTv.typeface = Typeface.DEFAULT_BOLD
        allCb.isClickable = false; allCb.isFocusable = false
        allRow.addView(allTv, LinearLayout.LayoutParams(0, -2, 1f))
        allRow.addView(allCb, LinearLayout.LayoutParams(-2, -2))
        allRow.setOnClickListener { allCb.isChecked = !allCb.isChecked }
        val divider = View(this); divider.setBackgroundColor(0x33FFFFFF)

        val inner = LinearLayout(this)
        inner.orientation = LinearLayout.VERTICAL
        var lastFile: String? = null
        for ((i, st) in list.withIndex()) {
            if (st.fileName != lastFile) {
                lastFile = st.fileName
                val h = TextView(this)
                h.text = st.fileName; h.textSize = 12f; h.typeface = Typeface.DEFAULT_BOLD
                h.setTextColor(0xFF4F8CFF.toInt())
                h.setPadding(dp(20), dp(12), dp(16), dp(2))
                inner.addView(h)
            }
            // küçə sətri: solda ▸/▾ + ad (toxunanda açılır/bağlanır), sağda quş işarəsi
            val sr = LinearLayout(this)
            sr.orientation = LinearLayout.HORIZONTAL
            sr.gravity = Gravity.CENTER_VERTICAL
            sr.setPadding(dp(14), dp(10), dp(16), dp(10))
            val arrow = TextView(this); arrow.text = "▸"; arrow.textSize = 16f
            arrow.setTextColor(0xFFB3B3BD.toInt()); arrow.gravity = Gravity.CENTER
            val tv = TextView(this); tv.textSize = 15f; tv.typeface = Typeface.DEFAULT_BOLD
            val scb = CheckBox(this)
            sr.addView(arrow, LinearLayout.LayoutParams(dp(24), -2))
            sr.addView(tv, LinearLayout.LayoutParams(0, -2, 1f))
            sr.addView(scb, LinearLayout.LayoutParams(-2, -2))
            val body = LinearLayout(this)
            body.orientation = LinearLayout.VERTICAL
            body.visibility = View.GONE
            sr.setOnClickListener {
                val open = body.visibility == View.GONE
                body.visibility = if (open) View.VISIBLE else View.GONE
                arrow.text = if (open) "▾" else "▸"
            }
            sChecks.add(scb); sLabels.add(tv)
            val bcs = ArrayList<CheckBox>()
            for (bd in st.bs) {
                val cb = CheckBox(this)
                cb.setOnCheckedChangeListener { _, _ ->
                    if (!syncing) {
                        syncing = true; scb.isChecked = bcs.all { it.isChecked }; syncing = false
                        refreshStreet(i); syncAll(); updateBtn()
                    }
                }
                bcs.add(cb)
                body.addView(bRow(bd.name, cb))
            }
            bChecks.add(bcs)
            scb.setOnCheckedChangeListener { _, v ->
                if (!syncing) {
                    syncing = true; for (c in bcs) c.isChecked = v; syncing = false
                    refreshStreet(i); syncAll(); updateBtn()
                }
            }
            refreshStreet(i)
            inner.addView(sr)
            inner.addView(body)
        }
        allCb.setOnCheckedChangeListener { _, v ->
            if (!syncing) {
                syncing = true
                for (l in bChecks) for (c in l) c.isChecked = v
                for (c in sChecks) c.isChecked = v
                syncing = false
                for (i in list.indices) refreshStreet(i)
                updateBtn()
            }
        }
        val scroll = ScrollView(this)
        scroll.addView(inner)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.addView(allRow)
        root.addView(divider, LinearLayout.LayoutParams(-1, 1))
        root.addView(scroll, LinearLayout.LayoutParams(-1, (resources.displayMetrics.heightPixels * 0.55).toInt()))

        fun selected(): List<Pair<ExStreet, ExB>> {
            val r = ArrayList<Pair<ExStreet, ExB>>()
            for (i in list.indices) for (j in list[i].bs.indices) if (bChecks[i][j].isChecked) r.add(Pair(list[i], list[i].bs[j]))
            return r
        }
        val total = list.sumOf { it.bs.size }
        val d = AlertDialog.Builder(this).setTitle("Nə export edilsin?").setView(root)
            .setPositiveButton("Export") { _, _ ->
                val sel = selected()
                if (sel.isEmpty()) return@setPositiveButton
                pendingExportIds = sel.map { it.second.id }
                pendingExportName = when {
                    sel.size == 1 -> safeName(sel[0].second.name)
                    sel.size == total -> "Bələdiyyə bazası"
                    sel.map { it.first.id }.distinct().size == 1 -> safeName(sel[0].first.name)
                    sel.map { it.first.fileName }.distinct().size == 1 -> safeName(sel[0].first.fileName)
                    else -> "Export"
                }
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT)
                intent.addCategory(Intent.CATEGORY_OPENABLE)
                intent.type = XLSX_MIME
                intent.putExtra(Intent.EXTRA_TITLE, pendingExportName + ".xlsx")
                startActivityForResult(intent, RC_EXPORT)
            }
            .setNeutralButton("Qovluğa (baza üzrə ayrı fayl)") { _, _ ->
                val sel = selected()
                if (sel.isEmpty()) return@setNeutralButton
                pendingExportGroups = sel.groupBy { it.first.fileName }.map { e -> Pair(e.key, e.value.map { it.second.id }) }
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), RC_EXPORT_DIR)
            }
            .setNegativeButton("Ləğv et", null)
            .create()
        dlg = d
        d.show()
        updateBtn()
    }

    private fun pickImport() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = "*/*"
        intent.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(XLSX_MIME, "application/octet-stream"))
        startActivityForResult(intent, RC_IMPORT)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        when (requestCode) {
            RC_EXPORT -> runExport(listOf(Pair(pendingExportName, pendingExportIds)), uri, false)
            RC_EXPORT_DIR -> runExport(pendingExportGroups, uri, true)
            RC_IMPORT -> startImport(uri)
        }
    }

    // ---------- export ----------
    private fun runExport(files: List<Pair<String, List<Long>>>, uri: Uri, tree: Boolean) {
        val dlg = busyDialog("Export edilir…")
        Thread {
            var sheets = 0
            var rowsN = 0
            var err: String? = null
            try {
                for (f in files) {
                    val target: Uri = if (tree) {
                        val parent = DocumentsContract.buildDocumentUriUsingTree(uri, DocumentsContract.getTreeDocumentId(uri))
                        DocumentsContract.createDocument(contentResolver, parent, XLSX_MIME, safeName(f.first) + ".xlsx")
                            ?: throw IOException("Fayl yaradıla bilmədi")
                    } else uri
                    val os = contentResolver.openOutputStream(target) ?: throw IOException("Fayl açıla bilmədi")
                    val r = writeXlsx(f.second, os)
                    sheets += r.first
                    rowsN += r.second
                }
            } catch (e: Exception) {
                err = e.message ?: e.toString()
            }
            runOnUiThread {
                try { dlg.dismiss() } catch (e: Exception) { }
                val msg = if (err != null) "Xəta: $err" else "Export tamamlandı: ${files.size} fayl, $sheets vərəq (bina), $rowsN sətir"
                AlertDialog.Builder(this).setMessage(msg).setPositiveButton("Bağla", null).show()
            }
        }.start()
    }

    private fun xmlEsc(s: String): String {
        val sb = StringBuilder(s.length + 8)
        for (ch in s) {
            when {
                ch == '&' -> sb.append("&amp;")
                ch == '<' -> sb.append("&lt;")
                ch == '>' -> sb.append("&gt;")
                ch == '"' -> sb.append("&quot;")
                ch.code < 32 && ch != '\n' && ch != '\t' && ch != '\r' -> { }
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    private fun colName(i: Int): String {
        var n = i
        val sb = StringBuilder()
        do { sb.insert(0, ('A' + n % 26)); n = n / 26 - 1 } while (n >= 0)
        return sb.toString()
    }

    private fun uniqueSheetName(raw: String, used: HashSet<String>): String {
        var base = raw.replace(Regex("[\\\\/*?:\\[\\]]"), "_").trim()
        if (base.isEmpty()) base = "Sheet"
        base = base.take(31)
        var name = base
        var n = 2
        while (!used.add(name.lowercase(Locale.ROOT))) {
            val suf = " ($n)"
            name = base.take(31 - suf.length) + suf
            n++
        }
        return name
    }

    private val numRe2 = Regex("^-?\\d+(\\.\\d+)?$")

    private fun writeRowXml(w: Writer, r: Int, cells: List<String>, bold: Boolean, numCol: Int) {
        w.write("<row r=\"$r\">")
        for (i in cells.indices) {
            val v = cells[i]
            if (v.isEmpty()) continue
            val ref = colName(i) + r
            val nv = v.replace(',', '.').trim()
            if (i == numCol && numRe2.matches(nv)) {
                w.write("<c r=\"$ref\"><v>$nv</v></c>")
            } else {
                w.write("<c r=\"$ref\" t=\"inlineStr\"" + (if (bold) " s=\"1\"" else "") +
                    "><is><t xml:space=\"preserve\">" + xmlEsc(v) + "</t></is></c>")
            }
        }
        w.write("</row>")
    }

    /** Bir bazanı (fayl) .xlsx kimi yazır: hər bina ayrıca vərəq. (vərəq sayı, sətir sayı) qaytarır */
    private fun writeXlsx(buildingIds: List<Long>, out: OutputStream): Pair<Int, Int> {
        class B(val id: Long, val sheet: String, val title: String, val headers: List<String>)
        val bs = ArrayList<B>()
        val inIds = buildingIds.joinToString(",")
        db.rawQuery("SELECT b.id, b.name, b.sheet, b.title, b.headers FROM buildings b JOIN streets s ON s.id = b.street_id JOIN files f ON f.id = s.file_id " +
            "WHERE b.id IN ($inIds) ORDER BY f.ord, s.ord, b.ord", null).use { c ->
            while (c.moveToNext()) {
                val sh = c.getString(2)
                bs.add(B(c.getLong(0), if (sh.isNullOrBlank()) c.getString(1) else sh, c.getString(3) ?: "", jsonList(c.getString(4))))
            }
        }
        if (bs.isEmpty()) { out.close(); return Pair(0, 0) }
        val used = HashSet<String>()
        val names = bs.map { uniqueSheetName(it.sheet, used) }
        val ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
        val rel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
        var totalRows = 0
        ZipOutputStream(BufferedOutputStream(out)).use { z ->
            fun put(name: String, text: String) {
                z.putNextEntry(ZipEntry(name)); z.write(text.toByteArray(Charsets.UTF_8)); z.closeEntry()
            }
            val head = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
            val ct = StringBuilder(head)
            ct.append("<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">")
            ct.append("<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>")
            ct.append("<Default Extension=\"xml\" ContentType=\"application/xml\"/>")
            ct.append("<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>")
            ct.append("<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>")
            for (i in bs.indices) ct.append("<Override PartName=\"/xl/worksheets/sheet${i + 1}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>")
            ct.append("</Types>")
            put("[Content_Types].xml", ct.toString())
            put("_rels/.rels", head + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"$rel/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>")
            val wb = StringBuilder(head)
            wb.append("<workbook xmlns=\"$ns\" xmlns:r=\"$rel\"><sheets>")
            for (i in bs.indices) wb.append("<sheet name=\"${xmlEsc(names[i])}\" sheetId=\"${i + 1}\" r:id=\"rId${i + 1}\"/>")
            wb.append("</sheets></workbook>")
            put("xl/workbook.xml", wb.toString())
            val wr = StringBuilder(head)
            wr.append("<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">")
            for (i in bs.indices) wr.append("<Relationship Id=\"rId${i + 1}\" Type=\"$rel/worksheet\" Target=\"worksheets/sheet${i + 1}.xml\"/>")
            wr.append("<Relationship Id=\"rId${bs.size + 1}\" Type=\"$rel/styles\" Target=\"styles.xml\"/></Relationships>")
            put("xl/_rels/workbook.xml.rels", wr.toString())
            put("xl/styles.xml", head + "<styleSheet xmlns=\"$ns\">" +
                "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>" +
                "<fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills>" +
                "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>" +
                "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
                "<cellXfs count=\"2\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>" +
                "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/></cellXfs></styleSheet>")
            for ((i, b) in bs.withIndex()) {
                z.putNextEntry(ZipEntry("xl/worksheets/sheet${i + 1}.xml"))
                val w = BufferedWriter(OutputStreamWriter(z, Charsets.UTF_8))
                w.write(head)
                w.write("<worksheet xmlns=\"$ns\"><cols>")
                val nameCol = nameIdx(b.headers)
                for (k in 0 until Math.max(b.headers.size, 1)) {
                    w.write("<col min=\"${k + 1}\" max=\"${k + 1}\" width=\"${if (k == nameCol) 38 else 16}\" customWidth=\"1\"/>")
                }
                w.write("</cols><sheetData>")
                var r = 1
                if (b.title.isNotBlank()) writeRowXml(w, r++, listOf(b.title), true, -1)
                writeRowXml(w, r++, b.headers, true, -1)
                val borcCol = colIdx(b.headers, "borc")
                db.rawQuery("SELECT cells FROM rows WHERE building_id = ? ORDER BY ord", arrayOf(b.id.toString())).use { c ->
                    while (c.moveToNext()) {
                        writeRowXml(w, r++, jsonList(c.getString(0)), false, borcCol)
                        totalRows++
                    }
                }
                w.write("</sheetData></worksheet>")
                w.flush()
                z.closeEntry()
            }
        }
        return Pair(bs.size, totalRows)
    }

    // ---------- import ----------
    private fun colIndex(ref: String): Int {
        var idx = 0
        var any = false
        for (ch in ref) {
            if (ch.isLetter()) { idx = idx * 26 + (ch.uppercaseChar() - 'A' + 1); any = true } else break
        }
        return if (any) idx - 1 else -1
    }

    private fun numText(v: String?): String {
        if (v == null) return ""
        val d = v.trim().toDoubleOrNull() ?: return v
        if (d == Math.rint(d) && Math.abs(d) < 1e15) return d.toLong().toString()
        return try {
            java.math.BigDecimal(v.trim()).setScale(2, java.math.RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()
        } catch (e: Exception) { v }
    }

    private fun xmlParser(bytes: ByteArray): XmlPullParser {
        val p = Xml.newPullParser()
        p.setInput(ByteArrayInputStream(bytes), null)
        return p
    }

    private fun parseShared(bytes: ByteArray): List<String> {
        val res = ArrayList<String>()
        val p = xmlParser(bytes)
        val sb = StringBuilder()
        var inSi = false
        var rph = 0
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name.substringAfter(':')) {
                    "si" -> { inSi = true; sb.setLength(0) }
                    "rPh" -> rph++
                    "t" -> if (inSi && rph == 0) sb.append(p.nextText())
                }
            } else if (ev == XmlPullParser.END_TAG) {
                when (p.name.substringAfter(':')) {
                    "rPh" -> rph--
                    "si" -> { res.add(sb.toString()); inSi = false }
                }
            }
            ev = p.next()
        }
        return res
    }

    private fun parseSheetXml(bytes: ByteArray, shared: List<String>): List<List<String>> {
        val rows = ArrayList<List<String>>()
        val p = xmlParser(bytes)
        var cur: ArrayList<String>? = null
        var col = 0
        var type: String? = null
        var v: String? = null
        var open = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name.substringAfter(':')) {
                    "row" -> cur = ArrayList()
                    "c" -> { type = p.getAttributeValue(null, "t"); col = colIndex(p.getAttributeValue(null, "r") ?: ""); v = null; open = true }
                    "v" -> if (open) v = p.nextText()
                    "t" -> if (open && type == "inlineStr") v = (v ?: "") + p.nextText()
                }
            } else if (ev == XmlPullParser.END_TAG) {
                when (p.name.substringAfter(':')) {
                    "c" -> {
                        val r = cur
                        if (r != null) {
                            val s = when (type) {
                                "s" -> shared.getOrElse(v?.trim()?.toIntOrNull() ?: -1) { "" }
                                "inlineStr", "str" -> v ?: ""
                                "b" -> if (v?.trim() == "1") "TRUE" else "FALSE"
                                "e" -> ""
                                else -> numText(v)
                            }
                            if (col < 0) col = r.size
                            while (r.size <= col) r.add("")
                            r[col] = s
                        }
                        open = false
                    }
                    "row" -> { cur?.let { rows.add(it) }; cur = null }
                }
            }
            ev = p.next()
        }
        return rows
    }

    /** .xlsx faylını oxuyur: (vərəq adı, sətirlər) siyahısı */
    private fun readXlsx(input: InputStream): List<Pair<String, List<List<String>>>> {
        val files = HashMap<String, ByteArray>()
        ZipInputStream(BufferedInputStream(input)).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val n = e.name
                if (n == "xl/workbook.xml" || n == "xl/_rels/workbook.xml.rels" || n == "xl/sharedStrings.xml" ||
                    (n.startsWith("xl/worksheets/") && n.endsWith(".xml"))) files[n] = z.readBytes()
                e = z.nextEntry
            }
        }
        val wbBytes = files["xl/workbook.xml"] ?: throw IOException("Bu fayl .xlsx deyil")
        val rels = HashMap<String, String>()
        files["xl/_rels/workbook.xml.rels"]?.let { b ->
            val p = xmlParser(b)
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && p.name.substringAfter(':') == "Relationship") {
                    val id = p.getAttributeValue(null, "Id"); val t = p.getAttributeValue(null, "Target")
                    if (id != null && t != null) rels[id] = t
                }
                ev = p.next()
            }
        }
        val shared = files["xl/sharedStrings.xml"]?.let { parseShared(it) } ?: emptyList()
        val res = ArrayList<Pair<String, List<List<String>>>>()
        val p = xmlParser(wbBytes)
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG && p.name.substringAfter(':') == "sheet") {
                val name = p.getAttributeValue(null, "name") ?: "Sheet"
                var rid: String? = null
                for (i in 0 until p.attributeCount) if (p.getAttributeName(i).substringAfter(':') == "id") rid = p.getAttributeValue(i)
                var target = rels[rid ?: ""]
                if (target != null) {
                    target = target.trimStart('/')
                    if (!target.startsWith("xl/")) target = "xl/$target"
                    val bytes = files[target]
                    if (bytes != null) res.add(Pair(name, parseSheetXml(bytes, shared)))
                }
            }
            ev = p.next()
        }
        return res
    }

    /** vərəqlərdən başlıq sətri ("Mənzil ...") olanları ImpSheet-ə çevirir; (siyahı, keçilən sayı) */
    private fun parseImport(raw: List<Pair<String, List<List<String>>>>): Pair<List<ImpSheet>, Int> {
        val out = ArrayList<ImpSheet>()
        var skipped = 0
        for ((name, rows) in raw) {
            var h = -1
            for (i in 0 until Math.min(rows.size, 15)) if (rows[i].any { fold(it).startsWith("menzil") }) { h = i; break }
            if (h < 0) { skipped++; continue }
            val headers = ArrayList(rows[h].map { it.trim() })
            while (headers.isNotEmpty() && headers.last().isEmpty()) headers.removeAt(headers.size - 1)
            if (headers.size < 2) { skipped++; continue }
            var title = ""
            for (i in h - 1 downTo 0) {
                val t = rows[i].firstOrNull { it.isNotBlank() }
                if (t != null) { title = t.trim(); break }
            }
            val data = ArrayList<List<String>>()
            for (i in h + 1 until rows.size) {
                val r = rows[i]
                if (r.all { it.isBlank() }) continue
                data.add(List(headers.size) { k -> r.getOrNull(k)?.trim() ?: "" })
            }
            out.add(ImpSheet(name, title, headers, data))
        }
        return Pair(out, skipped)
    }

    private fun startImport(uri: Uri) {
        var disp = "import"
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) disp = c.getString(0) ?: disp
            }
        } catch (e: Exception) { }
        val base = disp.replace(Regex("\\.xlsx$", RegexOption.IGNORE_CASE), "").trim()
        val dlg = busyDialog("Fayl oxunur…")
        Thread {
            var parsed: Pair<List<ImpSheet>, Int>? = null
            var err: String? = null
            try {
                val ins = contentResolver.openInputStream(uri)
                if (ins == null) err = "Fayl açıla bilmədi"
                else ins.use { parsed = parseImport(readXlsx(it)) }
            } catch (e: Exception) {
                err = e.message ?: e.toString()
            }
            runOnUiThread {
                try { dlg.dismiss() } catch (e: Exception) { }
                val pr = parsed
                if (err != null || pr == null) {
                    AlertDialog.Builder(this).setMessage("Xəta: ${err ?: "oxunmadı"}").setPositiveButton("Bağla", null).show()
                } else if (pr.first.isEmpty()) {
                    AlertDialog.Builder(this)
                        .setMessage("Uyğun vərəq tapılmadı. Hər vərəqdə başlıq sətri olmalıdır (məs. \"Mənzil\", \"Soyad, Ad, Atasının adı\", \"YVÖK\", \"Borc\"…).")
                        .setPositiveButton("Bağla", null).show()
                } else chooseImportTarget(base, pr.first, pr.second)
            }
        }.start()
    }

    private fun chooseImportTarget(base: String, list: List<ImpSheet>, skipped: Int) {
        val files = filesList()
        val match = files.firstOrNull { fold(it.second) == fold(base) }
        if (match != null) { confirmImport(match.second, list, skipped); return }
        val items = files.map { it.second }.toMutableList()
        items.add("➕  Yeni baza: $base")
        AlertDialog.Builder(this).setTitle("Hansı bazaya import edilsin?")
            .setItems(items.toTypedArray()) { _, i ->
                confirmImport(if (i < files.size) files[i].second else base, list, skipped)
            }
            .setNegativeButton("Ləğv et", null)
            .show()
    }

    private fun confirmImport(fileName: String, list: List<ImpSheet>, skipped: Int) {
        val rowsN = list.sumOf { it.rows.size }
        val msg = "«$fileName» bazasına ${list.size} vərəq, $rowsN sətir import ediləcək.\n\n" +
            "Eyni adlı vərəqlərin (binaların) məlumatı əvəz olunacaq. Yeni adlı vərəqlər «İMPORT» küçəsi altında əlavə olunacaq." +
            (if (skipped > 0) "\n\nBaşlıq sətri tapılmadığı üçün keçilən vərəq: $skipped" else "")
        AlertDialog.Builder(this).setTitle("Import").setMessage(msg)
            .setPositiveButton("Davam et") { _, _ -> doImport(fileName, list) }
            .setNegativeButton("Ləğv et", null)
            .show()
    }

    private fun doImport(fileName: String, list: List<ImpSheet>) {
        val dlg = busyDialog("Import edilir…")
        val clBefore = ChangeLog.snapshot(editsDb)
        Thread {
            var err: String? = null
            var n = 0
            var rowsN = 0
            try {
                for (s in list) {
                    saveImportRecord(fileName, s)
                    applyImportedSheet(db, fileName, s)
                    n++; rowsN += s.rows.size
                }
            } catch (e: Exception) {
                err = e.message ?: e.toString()
            }
            runOnUiThread {
                try { dlg.dismiss() } catch (e: Exception) { }
                val msg = if (err != null) "Xəta ($n vərəq yazıldı): $err" else "Import tamamlandı: $n vərəq, $rowsN sətir"
                ChangeLog.record(editsDb, "📥 Import: $fileName — $n vərəq, $rowsN sətir", clBefore)
                AlertDialog.Builder(this).setMessage(msg).setPositiveButton("Bağla", null).show()
                afterRefresh()
                scheduleSync()
            }
        }.start()
    }

    /** import edilən vərəq ayrıca faylda da saxlanılır ki, baza yenilənəndə itməsin */
    private fun saveImportRecord(fileName: String, s: ImpSheet) {
        editsDb.beginTransaction()
        try {
            editsDb.execSQL("INSERT OR REPLACE INTO imp_sheets VALUES(?,?,?,?)",
                arrayOf<Any>(fileName, s.name, s.title, JSONArray(s.headers).toString()))
            editsDb.execSQL("DELETE FROM imp_rows WHERE file = ? AND sheet = ?", arrayOf<Any>(fileName, s.name))
            s.rows.forEachIndexed { i, r ->
                editsDb.execSQL("INSERT INTO imp_rows VALUES(?,?,?,?)", arrayOf<Any>(fileName, s.name, i + 1, JSONArray(r).toString()))
            }
            editsDb.execSQL("DELETE FROM edits WHERE file = ? AND sheet = ?", arrayOf<Any>(fileName, s.name))
            editsDb.execSQL("DELETE FROM deleted_rows WHERE file = ? AND sheet = ?", arrayOf<Any>(fileName, s.name))
            // əl ilə əlavə edilmiş mənzillər silinmir: import olunan sətirlərin ardınca yenidən nömrələnir
            val keep = ArrayList<String>()
            editsDb.rawQuery("SELECT cells FROM added_rows WHERE file = ? AND sheet = ? ORDER BY ord", arrayOf(fileName, s.name)).use { c ->
                while (c.moveToNext()) keep.add(c.getString(0))
            }
            editsDb.execSQL("DELETE FROM added_rows WHERE file = ? AND sheet = ?", arrayOf<Any>(fileName, s.name))
            keep.forEachIndexed { i, cj ->
                editsDb.execSQL("INSERT INTO added_rows VALUES(?,?,?,?)", arrayOf<Any>(fileName, s.name, s.rows.size + i + 1, cj))
            }
            editsDb.setTransactionSuccessful()
        } finally {
            editsDb.endTransaction()
        }
    }

    private fun replayImports(d: SQLiteDatabase) {
        val sheets = ArrayList<Array<String>>()
        editsDb.rawQuery("SELECT file, sheet, title, headers FROM imp_sheets", null).use { c ->
            while (c.moveToNext()) sheets.add(arrayOf(c.getString(0), c.getString(1), c.getString(2) ?: "", c.getString(3)))
        }
        for (s in sheets) {
            val rows = ArrayList<List<String>>()
            editsDb.rawQuery("SELECT cells FROM imp_rows WHERE file = ? AND sheet = ? ORDER BY ord", arrayOf(s[0], s[1])).use { c ->
                while (c.moveToNext()) rows.add(jsonList(c.getString(0)))
            }
            try { applyImportedSheet(d, s[0], ImpSheet(s[1], s[2], jsonList(s[3]), rows)) } catch (e: Exception) { }
        }
    }

    /** vərəqi bazaya yazır: eyni adlı bina varsa sətirləri əvəz edir, yoxdursa "İMPORT" küçəsi altında yeni bina yaradır */
    private fun applyImportedSheet(d: SQLiteDatabase, fileName: String, s: ImpSheet) {
        d.beginTransaction()
        try {
            var fileId = -1L
            d.rawQuery("SELECT id FROM files WHERE name = ?", arrayOf(fileName)).use { if (it.moveToFirst()) fileId = it.getLong(0) }
            if (fileId < 0) {
                var ord = 0
                d.rawQuery("SELECT COALESCE(MAX(ord), -1) + 1 FROM files", null).use { if (it.moveToFirst()) ord = it.getInt(0) }
                val cv = ContentValues()
                cv.put("name", fileName); cv.put("ord", ord)
                fileId = d.insert("files", null, cv)
            }
            var bId = -1L
            d.rawQuery("SELECT id FROM buildings WHERE file_id = ? AND sheet = ?", arrayOf(fileId.toString(), s.name)).use {
                if (it.moveToFirst()) bId = it.getLong(0)
            }
            val hdrJson = JSONArray(s.headers).toString()
            if (bId >= 0) {
                d.execSQL("DELETE FROM rows WHERE building_id = ?", arrayOf<Any>(bId))
                d.execSQL("UPDATE buildings SET headers = ? WHERE id = ?", arrayOf<Any>(hdrJson, bId))
                if (s.title.isNotEmpty()) d.execSQL("UPDATE buildings SET title = ? WHERE id = ?", arrayOf<Any>(s.title, bId))
            } else {
                var sId = -1L
                d.rawQuery("SELECT id FROM streets WHERE file_id = ? AND name = ?", arrayOf(fileId.toString(), "İMPORT")).use {
                    if (it.moveToFirst()) sId = it.getLong(0)
                }
                if (sId < 0) {
                    var ord = 0
                    d.rawQuery("SELECT COALESCE(MAX(ord), 0) + 1 FROM streets WHERE file_id = ?", arrayOf(fileId.toString())).use {
                        if (it.moveToFirst()) ord = it.getInt(0)
                    }
                    val cv = ContentValues()
                    cv.put("file_id", fileId); cv.put("name", "İMPORT"); cv.put("name_n", "import"); cv.put("ord", ord)
                    sId = d.insert("streets", null, cv)
                }
                var bord = 0
                d.rawQuery("SELECT COALESCE(MAX(ord), 0) + 1 FROM buildings WHERE file_id = ?", arrayOf(fileId.toString())).use {
                    if (it.moveToFirst()) bord = it.getInt(0)
                }
                val cv = ContentValues()
                cv.put("street_id", sId); cv.put("file_id", fileId); cv.put("name", s.name); cv.put("name_n", fold(s.name))
                cv.put("title", s.title); cv.put("sheet", s.name); cv.put("headers", hdrJson); cv.put("ord", bord)
                bId = d.insert("buildings", null, cv)
            }
            s.rows.forEachIndexed { i, cells ->
                val cv = ContentValues()
                cv.put("building_id", bId); cv.put("ord", i + 1)
                cv.put("menzil", ""); cv.put("soyad", ""); cv.put("ad", ""); cv.put("ata", "")
                cv.put("menzil_n", ""); cv.put("soyad_n", ""); cv.put("ad_n", ""); cv.put("ata_n", "")
                cv.put("nomre_d", ""); cv.put("cells", JSONArray(cells).toString()); cv.put("borc", 0.0)
                val id = d.insert("rows", null, cv)
                writeRow(d, id, cells, s.headers)
            }
            val extra = ArrayList<Pair<Int, String>>()
            editsDb.rawQuery("SELECT ord, cells FROM added_rows WHERE file = ? AND sheet = ? ORDER BY ord", arrayOf(fileName, s.name)).use { c ->
                while (c.moveToNext()) extra.add(Pair(c.getInt(0), c.getString(1)))
            }
            for ((o, cj) in extra) {
                if (scalarLong(d, "SELECT id FROM rows WHERE building_id = ? AND ord = ?", bId.toString(), o.toString()) < 0)
                    insertRow(d, bId, o, jsonList(cj), s.headers)
            }
            d.setTransactionSuccessful()
        } finally {
            d.endTransaction()
        }
    }

    // =====================================================================
    //  "+ əlavə et": kateqoriya / küçə / bina / mənzil əlavə etmək
    // =====================================================================
    private fun scalarLong(d: SQLiteDatabase, sql: String, vararg a: String): Long {
        var r = -1L
        d.rawQuery(sql, arrayOf(*a)).use { if (it.moveToFirst() && !it.isNull(0)) r = it.getLong(0) }
        return r
    }

    private fun fileIdOf(d: SQLiteDatabase, name: String) = scalarLong(d, "SELECT id FROM files WHERE name = ?", name)

    private fun streetIdOf(d: SQLiteDatabase, fid: Long, name: String) =
        scalarLong(d, "SELECT id FROM streets WHERE file_id = ? AND name = ?", fid.toString(), name)

    private val AZ_ALPHA = "abcçdeəfgğhxıijkqlmnoöprsştuüvyz"
    private fun azKey(ch: Char): Int { val i = AZ_ALPHA.indexOf(ch); return if (i >= 0) 1000 + i else ch.code }

    /** Azərbaycan əlifbası sırası (a b c ç d e ə f g ğ h x ı i j k q l m n o ö p r s ş t u ü v y z); rəqəmlər ədədi müqayisə olunur */
    private fun azCompare(a: String, b: String): Int {
        val x = a.replace('İ', 'i').replace('I', 'ı').lowercase(Locale.ROOT).trim()
        val y = b.replace('İ', 'i').replace('I', 'ı').lowercase(Locale.ROOT).trim()
        var i = 0; var j = 0
        while (i < x.length && j < y.length) {
            val c = x[i]; val e = y[j]
            if (c.isDigit() && e.isDigit()) {
                var ie = i; while (ie < x.length && x[ie].isDigit()) ie++
                var je = j; while (je < y.length && y[je].isDigit()) je++
                val n1 = x.substring(i, ie).trimStart('0'); val n2 = y.substring(j, je).trimStart('0')
                if (n1.length != n2.length) return n1.length.compareTo(n2.length)
                val k = n1.compareTo(n2); if (k != 0) return k
                i = ie; j = je
            } else {
                val k = azKey(c).compareTo(azKey(e)); if (k != 0) return k
                i++; j++
            }
        }
        return (x.length - i).compareTo(y.length - j)
    }

    /** Yeni elementin yerini əlifba sırası ilə tapır: ondan böyük ilk qonşunun yerini tutur, sonrakıları 1 aşağı itələyir */
    private fun slotOrd(d: SQLiteDatabase, table: String, shiftWhere: String, shiftArgs: List<Any>,
                        siblings: List<Pair<String, Int>>, name: String, next: Int): Int {
        val hit = siblings.firstOrNull { azCompare(name, it.first) < 0 } ?: return next
        d.execSQL("UPDATE $table SET ord = ord + 1 WHERE $shiftWhere AND ord >= ?", (shiftArgs + hit.second).toTypedArray())
        return hit.second
    }

    private fun siblingsOf(d: SQLiteDatabase, sql: String, vararg a: String): List<Pair<String, Int>> {
        val l = ArrayList<Pair<String, Int>>()
        d.rawQuery(sql, arrayOf(*a)).use { while (it.moveToNext()) l.add(Pair(it.getString(0) ?: "", it.getInt(1))) }
        return l
    }

    private fun addFileTo(d: SQLiteDatabase, name: String): Long {
        val ex = fileIdOf(d, name)
        if (ex >= 0) return ex
        val cv = ContentValues()
        val next = scalarLong(d, "SELECT COALESCE(MAX(ord), -1) + 1 FROM files").toInt()
        // "⭐ BARAT" qrupu həmişə ən üstdə qalır: yeni kateqoriya onun üstünə düşməsin
        val sib = siblingsOf(d, "SELECT COALESCE(NULLIF(disp, ''), name), ord FROM files ORDER BY ord").filter { !it.first.startsWith("⭐") }
        cv.put("name", name); cv.put("ord", slotOrd(d, "files", "1=1", emptyList(), sib, name, next))
        return d.insert("files", null, cv)
    }

    private fun addStreetTo(d: SQLiteDatabase, fid: Long, name: String): Long {
        val ex = streetIdOf(d, fid, name)
        if (ex >= 0) return ex
        val cv = ContentValues()
        cv.put("file_id", fid); cv.put("name", name); cv.put("name_n", fold(name))
        val next = scalarLong(d, "SELECT COALESCE(MAX(ord), 0) + 1 FROM streets WHERE file_id = ?", fid.toString()).toInt()
        val sib = siblingsOf(d, "SELECT name, ord FROM streets WHERE file_id = ? ORDER BY ord", fid.toString())
        cv.put("ord", slotOrd(d, "streets", "file_id = ?", listOf(fid), sib, name, next))
        return d.insert("streets", null, cv)
    }

    private fun addBuildingTo(d: SQLiteDatabase, fid: Long, sid: Long, name: String): Long {
        val ex = scalarLong(d, "SELECT id FROM buildings WHERE file_id = ? AND sheet = ?", fid.toString(), name)
        if (ex >= 0) return ex
        val cv = ContentValues()
        cv.put("street_id", sid); cv.put("file_id", fid); cv.put("name", name); cv.put("name_n", fold(name))
        cv.put("title", ""); cv.put("sheet", name); cv.put("headers", JSONArray(DEFAULT_HEADERS).toString())
        val next = scalarLong(d, "SELECT COALESCE(MAX(ord), 0) + 1 FROM buildings WHERE file_id = ?", fid.toString()).toInt()
        val sib = siblingsOf(d, "SELECT name, ord FROM buildings WHERE street_id = ? ORDER BY ord", sid.toString())
        cv.put("ord", slotOrd(d, "buildings", "file_id = ?", listOf(fid), sib, name, next))
        return d.insert("buildings", null, cv)
    }

    private fun insertRow(d: SQLiteDatabase, bId: Long, ord: Int, cells: List<String>, headers: List<String>): Long {
        val cv = ContentValues()
        cv.put("building_id", bId); cv.put("ord", ord)
        cv.put("menzil", ""); cv.put("soyad", ""); cv.put("ad", ""); cv.put("ata", "")
        cv.put("menzil_n", ""); cv.put("soyad_n", ""); cv.put("ad_n", ""); cv.put("ata_n", "")
        cv.put("nomre_d", ""); cv.put("cells", JSONArray(cells).toString()); cv.put("borc", 0.0)
        val id = d.insert("rows", null, cv)
        writeRow(d, id, cells, headers)
        return id
    }

    /** küçə adı yenidən adlandırılıbsa, ilkin (bazadakı) adını qaytarır — bərpa üçün açar */
    private fun origStreetName(fk: String, cur: String): String {
        var orig = cur
        editsDb.rawQuery("SELECT b FROM renames WHERE kind = 's' AND a = ? AND value = ?", arrayOf(fk, cur)).use {
            if (it.moveToFirst()) orig = it.getString(0)
        }
        return orig
    }

    /** Bütün qeydlərin təkrar tətbiqi sırası: import → yeni kateqoriya/küçə/bina → köçürmə → silmə → yeni sətirlər → redaktə → ad → silinmiş sətirlər */
    private fun replayAll(d: SQLiteDatabase) {
        replayImports(d); replayAddCats(d); replayCatMoves(d); replayCatDeletes(d); replayAddRows(d)
        replayEdits(d); replayRenames(d); replayDeletes(d)
    }

    // ---------- fayl / küçə / bina silmə və köçürmə (SQL) ----------
    private fun deleteBuildingSql(d: SQLiteDatabase, bId: Long) {
        d.execSQL("DELETE FROM rows WHERE building_id = ?", arrayOf<Any>(bId))
        d.execSQL("DELETE FROM buildings WHERE id = ?", arrayOf<Any>(bId))
    }
    private fun deleteStreetSql(d: SQLiteDatabase, sId: Long) {
        d.execSQL("DELETE FROM rows WHERE building_id IN (SELECT id FROM buildings WHERE street_id = ?)", arrayOf<Any>(sId))
        d.execSQL("DELETE FROM buildings WHERE street_id = ?", arrayOf<Any>(sId))
        d.execSQL("DELETE FROM streets WHERE id = ?", arrayOf<Any>(sId))
    }
    private fun deleteFileSql(d: SQLiteDatabase, fId: Long) {
        d.execSQL("DELETE FROM rows WHERE building_id IN (SELECT id FROM buildings WHERE file_id = ?)", arrayOf<Any>(fId))
        d.execSQL("DELETE FROM buildings WHERE file_id = ?", arrayOf<Any>(fId))
        d.execSQL("DELETE FROM streets WHERE file_id = ?", arrayOf<Any>(fId))
        d.execSQL("DELETE FROM files WHERE id = ?", arrayOf<Any>(fId))
    }
    private fun moveBuildingSql(d: SQLiteDatabase, bId: Long, destFid: Long, destSid: Long) {
        val last = scalarLong(d, "SELECT COALESCE(MAX(ord), -1) FROM buildings WHERE street_id = ? AND id <> ?", destSid.toString(), bId.toString())
        val ord = if (last >= 0) last + 1 else scalarLong(d, "SELECT COALESCE(MAX(ord), 0) + 1 FROM buildings WHERE file_id = ?", destFid.toString())
        d.execSQL("UPDATE buildings SET ord = ord + 1 WHERE file_id = ? AND ord >= ? AND id <> ?", arrayOf<Any>(destFid, ord, bId))
        d.execSQL("UPDATE buildings SET street_id = ?, file_id = ?, ord = ? WHERE id = ?", arrayOf<Any>(destSid, destFid, ord, bId))
    }
    private fun moveStreetSql(d: SQLiteDatabase, sId: Long, destFid: Long) {
        val ord = scalarLong(d, "SELECT COALESCE(MAX(ord), 0) + 1 FROM streets WHERE file_id = ?", destFid.toString())
        d.execSQL("UPDATE streets SET file_id = ?, ord = ? WHERE id = ?", arrayOf<Any>(destFid, ord, sId))
        d.execSQL("UPDATE buildings SET file_id = ? WHERE street_id = ?", arrayOf<Any>(destFid, sId))
    }

    private fun replayCatMoves(d: SQLiteDatabase) {
        val l = ArrayList<Array<String>>()
        editsDb.rawQuery("SELECT kind, a, b, c, d FROM moved_cats ORDER BY rowid", null).use { c ->
            while (c.moveToNext()) l.add(arrayOf(c.getString(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getString(3) ?: "", c.getString(4) ?: ""))
        }
        for (r in l) {
            try {
                val f = fileIdOf(d, r[1]); val df = fileIdOf(d, r[3])
                if (f < 0 || df < 0) continue
                when (r[0]) {
                    "b" -> {
                        val bId = scalarLong(d, "SELECT id FROM buildings WHERE file_id = ? AND sheet = ?", f.toString(), r[2])
                        val ds = streetIdOf(d, df, r[4])
                        if (bId >= 0 && ds >= 0) moveBuildingSql(d, bId, df, ds)
                    }
                    "s" -> {
                        val sId = streetIdOf(d, f, r[2])
                        if (sId >= 0) moveStreetSql(d, sId, df)
                    }
                }
            } catch (e: Exception) { }
        }
    }

    private fun replayCatDeletes(d: SQLiteDatabase) {
        val l = ArrayList<Array<String>>()
        editsDb.rawQuery("SELECT kind, a, b FROM deleted_cats ORDER BY rowid", null).use { c ->
            while (c.moveToNext()) l.add(arrayOf(c.getString(0), c.getString(1) ?: "", c.getString(2) ?: ""))
        }
        for (r in l) {
            try {
                val f = fileIdOf(d, r[1])
                if (f < 0) continue
                when (r[0]) {
                    "f" -> deleteFileSql(d, f)
                    "s" -> { val sId = streetIdOf(d, f, r[2]); if (sId >= 0) deleteStreetSql(d, sId) }
                    "b" -> { val bId = scalarLong(d, "SELECT id FROM buildings WHERE file_id = ? AND sheet = ?", f.toString(), r[2]); if (bId >= 0) deleteBuildingSql(d, bId) }
                }
            } catch (e: Exception) { }
        }
    }

    private fun replayAddCats(d: SQLiteDatabase) {
        val l = ArrayList<Array<String>>()
        editsDb.rawQuery("SELECT kind, a, b, name FROM added ORDER BY rowid", null).use { c ->
            while (c.moveToNext()) l.add(arrayOf(c.getString(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getString(3)))
        }
        for (r in l) {
            try {
                when (r[0]) {
                    "f" -> addFileTo(d, r[3])
                    "s" -> { val f = fileIdOf(d, r[1]); if (f >= 0) addStreetTo(d, f, r[3]) }
                    "b" -> {
                        val f = fileIdOf(d, r[1])
                        if (f >= 0) { val s = streetIdOf(d, f, r[2]); if (s >= 0) addBuildingTo(d, f, s, r[3]) }
                    }
                }
            } catch (e: Exception) { }
        }
    }

    private fun replayAddRows(d: SQLiteDatabase) {
        val rows = ArrayList<Array<String>>()
        editsDb.rawQuery("SELECT file, sheet, ord, cells FROM added_rows ORDER BY rowid", null).use { c ->
            while (c.moveToNext()) rows.add(arrayOf(c.getString(0), c.getString(1), c.getInt(2).toString(), c.getString(3)))
        }
        for (r in rows) {
            try {
                val bId = scalarLong(d, "SELECT b.id FROM buildings b JOIN files f ON f.id = b.file_id WHERE f.name = ? AND b.sheet = ?", r[0], r[1])
                if (bId < 0) continue
                if (scalarLong(d, "SELECT id FROM rows WHERE building_id = ? AND ord = ?", bId.toString(), r[2]) >= 0) continue
                var hdr: List<String> = DEFAULT_HEADERS
                d.rawQuery("SELECT headers FROM buildings WHERE id = ?", arrayOf(bId.toString())).use { if (it.moveToFirst()) hdr = jsonList(it.getString(0)) }
                insertRow(d, bId, r[2].toInt(), jsonList(r[3]), hdr)
            } catch (e: Exception) { }
        }
    }

    private fun scrollListToEnd() { catList.post { catList.setSelection(catList.count - 1) } }

    private fun showAddDialog() {
        if (level == 3) { showAddRowDialog(); return }
        val title = when (level) { 0 -> "Yeni kateqoriya"; 1 -> "Yeni küçə"; else -> "Yeni bina" }
        val et = EditText(this)
        et.hint = "Ad"; et.isSingleLine = true
        val box = FrameLayout(this)
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(et)
        AlertDialog.Builder(this).setTitle(title).setView(box)
            .setPositiveButton("Əlavə et") { _, _ -> addCatItem(et.text.toString().trim().replace(Regex("\\s+"), " ")) }
            .setNegativeButton("Ləğv et", null)
            .show()
    }

    private fun addCatItem(nv: String) {
        if (nv.isEmpty()) return
        var dup = catNames.any { fold(it) == fold(nv) }
        if (level == 2 && scalarLong(db, "SELECT id FROM buildings WHERE file_id = ? AND sheet = ?", fileId.toString(), nv) >= 0) dup = true
        if (dup) { Toast.makeText(this, "Bu ad artıq var", Toast.LENGTH_SHORT).show(); return }
        run {
            val fk0 = if (level == 0) "" else fileKeyName(fileId)
            val cnt = when (level) {
                0 -> scalarLongE("SELECT COUNT(*) FROM deleted_cats WHERE kind = 'f' AND a = ?", nv)
                1 -> scalarLongE("SELECT COUNT(*) FROM deleted_cats WHERE kind = 's' AND a = ? AND b = ?", fk0, nv)
                else -> scalarLongE("SELECT COUNT(*) FROM deleted_cats WHERE kind = 'b' AND a = ? AND b = ?", fk0, nv)
            }
            if (cnt > 0) { Toast.makeText(this, "Bu ad silinənlər arasındadır", Toast.LENGTH_LONG).show(); return }
        }
        val clBefore = ChangeLog.snapshot(editsDb)
        var newId = -1L
        try {
            when (level) {
                0 -> {
                    newId = addFileTo(db, nv)
                    editsDb.execSQL("INSERT OR REPLACE INTO added VALUES('f', '', '', ?)", arrayOf<Any>(nv))
                }
                1 -> {
                    newId = addStreetTo(db, fileId, nv)
                    editsDb.execSQL("INSERT OR REPLACE INTO added VALUES('s', ?, '', ?)", arrayOf<Any>(fileKeyName(fileId), nv))
                }
                else -> {
                    val fk = fileKeyName(fileId)
                    newId = addBuildingTo(db, fileId, streetId, nv)
                    editsDb.execSQL("INSERT OR REPLACE INTO added VALUES('b', ?, ?, ?)", arrayOf<Any>(fk, origStreetName(fk, streetName), nv))
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Xəta: ${e.message}", Toast.LENGTH_LONG).show(); return
        }
        Toast.makeText(this, "Əlavə olundu", Toast.LENGTH_SHORT).show()
        ChangeLog.record(editsDb, "➕ Yeni " + catKindName() + ": " + nv + catWhere(), clBefore)
        scheduleSync()
        loadLevel(false, true)
        val idx = catIds.indexOf(newId)
        if (idx >= 0) catList.post { catList.setSelection(idx) }
    }

    private fun showAddRowDialog() {
        var hdr: List<String> = emptyList(); var sheet = ""
        db.rawQuery("SELECT headers, sheet FROM buildings WHERE id = ?", arrayOf(buildingId.toString())).use {
            if (it.moveToFirst()) { hdr = jsonList(it.getString(0)); sheet = it.getString(1) ?: "" }
        }
        if (hdr.isEmpty()) return

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val inputs = ArrayList<EditText>()
        for (h in hdr) {
            val label = TextView(this)
            label.text = h; label.textSize = 12f; label.setTextColor(Color.parseColor("#B3B3BD")); label.setPadding(0, dp(10), 0, 0)
            col.addView(label)
            val e = EditText(this)
            e.textSize = 15f; e.isSingleLine = true
            inputs.add(e); col.addView(e)
        }

        val anchors = ArrayList<Pair<Int, String>>()
        anchors.add(Pair(0, "Mövcud mənzillərin sonuna əlavə et"))
        db.rawQuery("SELECT ord, cells FROM rows WHERE building_id = ? ORDER BY ord", arrayOf(buildingId.toString())).use { c ->
            while (c.moveToNext()) {
                val cells = jsonList(c.getString(1))
                val label = cells.filter { it.isNotBlank() }.take(2).joinToString(" — ").ifBlank { "Mənzil" }
                anchors.add(Pair(c.getInt(0), "${label} (altına əlavə et)"))
            }
        }
        val anchorSpinner = Spinner(this)
        anchorSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, anchors.map { it.second })
        val anchorLabel = TextView(this).apply {
            text = "Hansı mənzilin altında əlavə olunsun?"; textSize = 14f
            setTextColor(Color.parseColor("#B3B3BD")); setPadding(0, dp(12), 0, dp(4))
        }
        col.addView(anchorLabel); col.addView(anchorSpinner)

        val sv = ScrollView(this)
        sv.setPadding(dp(20), dp(8), dp(20), 0)
        sv.addView(col)
        val dialog = AlertDialog.Builder(this).setTitle("Yeni mənzil").setView(sv)
            .setPositiveButton("Əlavə et") { _, _ ->
                val anchorOrd = anchors.getOrNull(anchorSpinner.selectedItemPosition)?.first ?: 0
                saveNewRow(hdr, sheet, inputs.map { it.text.toString().trim() }, anchorOrd)
            }
            .setNegativeButton("Ləğv et", null)
            .create()
        dialog.show()
    }

    private fun saveNewRow(hdr: List<String>, sheet: String, cells: List<String>, anchorOrd: Int) {
        if (cells.all { it.isEmpty() }) return
        val clBefore = ChangeLog.snapshot(editsDb)
        try {
            var ord = if (anchorOrd <= 0) scalarLong(db, "SELECT COALESCE(MAX(ord), 0) + 1 FROM rows WHERE building_id = ?", buildingId.toString()).toInt() else anchorOrd + 1
            if (anchorOrd <= 0) {
                editsDb.rawQuery("SELECT COALESCE(MAX(ord), 0) FROM deleted_rows WHERE file = ? AND sheet = ?", arrayOf(fileKeyName(fileId), sheet)).use {
                    if (it.moveToFirst()) ord = Math.max(ord, it.getInt(0) + 1)
                }
            }
            if (anchorOrd > 0) {
                db.execSQL("UPDATE rows SET ord = ord + 1 WHERE building_id = ? AND ord >= ?", arrayOf<Any>(buildingId, ord))
                editsDb.execSQL("UPDATE added_rows SET ord = ord + 1 WHERE file = ? AND sheet = ? AND ord >= ?", arrayOf<Any>(fileKeyName(fileId), sheet, ord))
            }
            insertRow(db, buildingId, ord, cells, hdr)
            editsDb.execSQL("INSERT OR REPLACE INTO added_rows VALUES(?, ?, ?, ?)",
                arrayOf<Any>(fileKeyName(fileId), sheet, ord, JSONArray(cells).toString()))
        } catch (e: Exception) {
            Toast.makeText(this, "Xəta: ${e.message}", Toast.LENGTH_LONG).show(); return
        }
        Toast.makeText(this, "Əlavə olundu", Toast.LENGTH_SHORT).show()
        ChangeLog.record(editsDb, "➕ Yeni mənzil: " + sheet + " · " + cells.filter { it.isNotBlank() }.take(3).joinToString(" — "), clBefore)
        scheduleSync()
        loadLevel(false, true)
        scrollListToEnd()
    }

    // =====================================================================
    //  Supabase sinxronizasiyası
    //  Telefonda saxlanan baza dəyişiklikləri (Borc sütunu daxil olmaqla redaktə, silmə, əlavə,
    //  ad dəyişmə və import) snapshot kimi baza_sync cədvəlinə yazılır.
    //  "Göndərildi" işarələri yalnız yerli telefonda saxlanılır və buluda ötürülmür.
    // =====================================================================
    private val SYNC_TABLE = "baza_sync"
    private val SUPABASE_PROJECT_URL = "https://ybsncrjwkxwujakbwqay.supabase.co"
    private val SUPABASE_SECRET_KEY = "sb_secret_xGBxzxLlCFif9YCmC2iFCA_bXr0FhPN"
    private val OLD_SUPABASE_KEY_PREFIX = "sb_secret_BpeoOIx"   // köhnə açarın başlanğıcı: telefonda saxlanıbsa təzəsi ilə əvəz olunur
    private val sbPrefs by lazy { getSharedPreferences("sb", MODE_PRIVATE) }
    private var syncRunning = false
    private var syncPending = false
    private var syncErrShown = false
    private val syncRunnable = Runnable { runSync(false, false) }

    /** İstifadəçinin yazdığı URL-i düzgün Project URL-ə çevirir (ref, /rest/v1/, dashboard linki və s.) */
    private fun sbUrl(): String {
        var u = (sbPrefs.getString("url", SUPABASE_PROJECT_URL) ?: SUPABASE_PROJECT_URL).trim().trim('"', '\'', ' ')
        if (u.isEmpty()) return ""
        val dash = Regex("supabase\\.com/dashboard/project/([A-Za-z0-9]+)").find(u)
        if (dash != null) return "https://" + dash.groupValues[1].lowercase(Locale.US) + ".supabase.co"
        if (!u.contains("://")) u = if (u.contains(".")) "https://$u" else "https://" + u.lowercase(Locale.US) + ".supabase.co"
        if (u.startsWith("http://") && u.contains(".supabase.co")) u = "https://" + u.removePrefix("http://")
        if (u.contains(".supabase.co")) {
            val m = Regex("^(https://[^/]+)").find(u)
            if (m != null) u = m.groupValues[1]
        }
        return u.trimEnd('/')
    }
    private fun sbKey(): String {
        if (sbPrefs.getString("key", null)?.trim()?.trim('"', '\'')?.startsWith(OLD_SUPABASE_KEY_PREFIX) == true) sbPrefs.edit().putString("key", SUPABASE_SECRET_KEY).apply()
        var k = (sbPrefs.getString("key", SUPABASE_SECRET_KEY) ?: SUPABASE_SECRET_KEY).trim().trim('"', '\'')
        if (k.startsWith("Bearer ", true)) k = k.substring(7)
        return k.replace(Regex("\\s"), "")
    }

    /** Yararsız açar növü üçün izah (null = problem yoxdur) */
    private fun sbKeyProblem(): String? {
        val k = sbKey()
        if (k.startsWith("sb_publishable_")) return "Bu «publishable» açardır. Secret açar (sb_secret_...) və ya service_role lazımdır."
        if (k.startsWith("eyJ")) {
            try {
                val parts = k.split(".")
                if (parts.size >= 2) {
                    val json = String(android.util.Base64.decode(parts[1],
                        android.util.Base64.URL_SAFE or android.util.Base64.NO_PADDING or android.util.Base64.NO_WRAP), Charsets.UTF_8)
                    if (JSONObject(json).optString("role") == "anon") return "Bu «anon» açardır. service_role açarı lazımdır."
                }
            } catch (e: Exception) { }
        }
        return null
    }

    /** Texniki xətanı başa düşülən izaha çevirir */
    private fun sbFriendly(raw: String): String = when {
        raw.contains("PGRST205") || raw.contains("HTTP 404") || raw.contains("does not exist", true) ->
            "baza_sync cədvəli tapılmadı. Supabase SQL Editor-da təlimatdakı SQL-i işlədin."
        raw.contains("HTTP 401") || raw.contains("Invalid API key", true) ->
            "API açarı qəbul edilmədi (401). Açarı yenidən kopyalayın (secret və ya service_role)."
        raw.contains("HTTP 403") || raw.contains("42501") || raw.contains("permission denied", true) ->
            "İcazə yoxdur (403). Secret/service_role açarı istifadə edin və SQL-dəki grant sətrini işlədin."
        raw.contains("UnknownHost", true) || raw.contains("Unable to resolve", true) ->
            "Project URL tapılmadı və ya internet yoxdur."
        raw.contains("timeout", true) || raw.contains("timed out", true) ->
            "Vaxt bitdi. İnterneti yoxlayın; pulsuz layihə dayandırılıbsa Supabase panelində Restore edin."
        else -> raw
    }

    private val SQL_SETUP = """create table if not exists public.baza_sync (
    id text primary key,
    data jsonb not null,
    updated_at timestamptz not null default now()
);

alter table public.baza_sync enable row level security;

grant select, insert, update, delete
on table public.baza_sync to service_role;

do $$
begin
    alter publication supabase_realtime add table public.baza_sync;
exception when duplicate_object then null;
end $$;"""

    private fun copySql() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("sql", SQL_SETUP))
        Toast.makeText(this, "SQL kopyalandı. Supabase SQL Editor-a yapışdırıb Run edin", Toast.LENGTH_LONG).show()
    }
    private fun sbConfigured() = sbUrl().startsWith("http") && sbKey().isNotEmpty()
    private fun sbAuto() = false   // telefon → server avtomatik yükləmə söndürülüb: yalnız Supabase düyməsindən əl ilə
    private fun sbAutoDown() = false   // server → telefon avtomatik endirmə (seçilə bilər)

    private fun setCloudStatus(s: String) {
        catSearch.btnCloud.text = "☁️  Supabase" + (if (s.isEmpty()) "" else "   $s")
    }

    // ---------- telefon ilə server arasındakı fərqlər (Supabase düyməsindəki qırmızı say) ----------
    private class DiffItem(val table: String, val key: List<String>, val local: String?, val server: String?)
    private val SYNC_TABLES = arrayOf("edits" to 4, "imp_sheets" to 2, "imp_rows" to 3, "renames" to 3, "added" to 4, "added_rows" to 3, "deleted_rows" to 3, "deleted_cats" to 3, "moved_cats" to 3, "notes" to 1, "debt_log" to 5)
    @Volatile private var serverSnap: JSONObject? = null
    @Volatile private var serverSnapStamp = ""
    @Volatile private var snapGen = 0
    private var diffItems: List<DiffItem> = emptyList()
    private var diffSeq = 0
    private var diffApplied = 0
    private lateinit var cloudBadge: TextView
    private val badgeRunnable = Runnable { if (sbConfigured()) refreshDiff(false) }

    private fun setBadge(n: Int) {
        if (!::cloudBadge.isInitialized) return
        cloudBadge.visibility = if (n > 0) View.VISIBLE else View.GONE
        cloudBadge.text = if (n > 999) "999+" else n.toString()
    }

    private fun tableMap(snap: JSONObject?, table: String, k: Int): HashMap<String, Pair<List<String>, String>> {
        val m = HashMap<String, Pair<List<String>, String>>()
        val arr = snap?.optJSONArray(table) ?: return m
        for (i in 0 until arr.length()) {
            val r = arr.optJSONArray(i) ?: continue
            val parts = ArrayList<String>()
            for (j in 0 until r.length()) parts.add(if (r.isNull(j)) "" else r.get(j).toString())
            val key = parts.take(k)
            m[key.joinToString("\u0001")] = Pair(key, parts.drop(k).joinToString("\u0001"))
        }
        return m
    }

    /** yerli snapshot ilə server snapshot-unu sətir-sətir müqayisə edir (_meta nəzərə alınmır) */
    private fun computeDiff(local: JSONObject, server: JSONObject?): List<DiffItem> {
        val out = ArrayList<DiffItem>()
        for ((t, k) in SYNC_TABLES) {
            val lm = tableMap(local, t, k); val sm = tableMap(server, t, k)
            for ((kk, lv) in lm) {
                val sv = sm[kk]
                if (sv == null) out.add(DiffItem(t, lv.first, lv.second, null))
                else if (sv.second != lv.second) out.add(DiffItem(t, lv.first, lv.second, sv.second))
            }
            for ((kk, sv) in sm) if (!lm.containsKey(kk)) out.add(DiffItem(t, sv.first, null, sv.second))
        }
        return out
    }

    /** fetch=true olarsa server snapshot-u yenidən endirilir, əks halda yaddaşdakı nüsxə ilə müqayisə olunur */
    private fun refreshDiff(fetch: Boolean, done: ((Boolean) -> Unit)? = null) {
        if (!sbConfigured()) { setBadge(0); done?.invoke(true); return }
        val my = ++diffSeq
        Thread {
            var ok = true
            try {
                if (fetch || serverSnap == null) {
                    val gen = snapGen
                    val arr = JSONArray(sbRequest("GET", "/rest/v1/$SYNC_TABLE?id=eq.main&select=data", null))
                    val s = if (arr.length() > 0) arr.getJSONObject(0).getJSONObject("data") else JSONObject()
                    if (gen == snapGen) { serverSnap = s; serverSnapStamp = s.optJSONObject("_meta")?.optString("stamp") ?: "" }
                }
            } catch (e: Exception) { ok = false }
            var items: List<DiffItem>? = null
            val ss = serverSnap
            if (ss != null) { try { items = computeDiff(buildSnapshot(), ss) } catch (e: Exception) { ok = false } }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                if (items != null && my >= diffApplied) { diffApplied = my; diffItems = items; setBadge(items.size) }
                done?.invoke(ok)
            }
        }.start()
    }

    private fun diffLabel(t: String) = when (t) {
        "edits" -> "Redaktə"; "imp_sheets" -> "İmport vərəqi"; "imp_rows" -> "İmport sətri"
        "renames" -> "Ad dəyişmə"; "added" -> "Əlavə"; "added_rows" -> "Əlavə sətir"; "notes" -> "Qeyd"; "debt_log" -> "Borc dəyişikliyi"; "deleted_cats" -> "Silinmiş fayl/küçə/bina"; "moved_cats" -> "Köçürülmüş küçə/bina"; else -> "Silinmiş sətir"
    }

    private fun headerName(file: String, sheet: String, col: Int): String {
        var h = ""
        try {
            db.rawQuery("SELECT b.headers FROM buildings b JOIN files f ON f.id = b.file_id WHERE f.name = ? AND b.sheet = ?", arrayOf(file, sheet))
                .use { if (it.moveToFirst()) h = jsonList(it.getString(0)).getOrNull(col) ?: "" }
        } catch (e: Exception) { }
        return if (h.isEmpty()) "sütun ${col + 1}" else h
    }

    private fun diffText(d: DiffItem): String {
        val k = d.key
        val place = if (d.table == "edits" && k.size >= 4) "${k[0]} › ${k[1]} › sətir ${k[2]} › ${headerName(k[0], k[1], k[3].toIntOrNull() ?: 0)}"
                    else k.joinToString(" › ")
        fun q(v: String?): String {
            if (v.isNullOrEmpty()) return ""
            val t = v.replace("\u0001", " | ").replace("\n", " ")
            return " «" + (if (t.length > 60) t.take(60) + "…" else t) + "»"
        }
        val body = when {
            d.server == null -> "⬆ telefonda yenidir," + q(d.local)
            d.local == null -> "⬇ serverdə yenidir," + q(d.server)
            else -> "↕ fərqlidir: telefon" + q(d.local) + " ≠ server" + q(d.server)
        }
        return "• ${diffLabel(d.table)}: $place\n    $body"
    }

    private fun showDiffDialog(ok: Boolean) {
        val items = diffItems
        val up = items.count { it.server == null }
        val down = items.count { it.local == null }
        val diff = items.size - up - down
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(4)) }
        val head = TextView(this).apply {
            textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            val warn = if (ok) "" else "⚠️ Serverlə əlaqə alınmadı, son məlum müqayisə göstərilir.\n\n"
            text = warn + if (items.isEmpty()) "✅ Telefon ilə server arasında fərq yoxdur."
            else "Telefon ilə server arasında ${items.size} fərq var:\n⬆ Telefonda yeni (serverə yüklənməyib): $up\n⬇ Serverdə yeni (telefona endirilməyib): $down\n↕ Hər ikisində fərqli: $diff"
        }
        col.addView(head)
        if (items.isNotEmpty()) {
            val body = TextView(this).apply {
                textSize = 13f
                val shown = items.take(300).joinToString("\n") { diffText(it) }
                text = shown + if (items.size > 300) "\n… və daha ${items.size - 300} dəyişiklik" else ""
                setPadding(0, dp(8), 0, dp(8))
            }
            val sv = ScrollView(this).apply { addView(body) }
            col.addView(sv, LinearLayout.LayoutParams(-1, if (items.size > 3) dp(300) else -2))
        }
        var dlg: AlertDialog? = null
        col.addView(Button(this).apply {
            text = "⚙️  Ayarlar"; isAllCaps = false
            setOnClickListener { dlg?.dismiss(); showSbSettings() }
        })
        dlg = AlertDialog.Builder(this).setTitle("☁️ Supabase").setView(col)
            .setPositiveButton("⬆️ Serverə yüklə") { _, _ -> requestCloudUpload() }
            .setNeutralButton("⬇️ Serverdən endir") { _, _ -> requestCloudDownload() }
            .setNegativeButton("Bağla", null)
            .show()
    }

    private fun nowIso(): String =
        java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }.format(java.util.Date())

    private fun sbRequest(method: String, path: String, body: ByteArray?, extra: Map<String, String> = emptyMap()): String {
        val conn = java.net.URL(sbUrl() + path).openConnection() as java.net.HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 20000; conn.readTimeout = 120000
            val key = sbKey()
            conn.setRequestProperty("apikey", key)
            if (!key.startsWith("sb_")) conn.setRequestProperty("Authorization", "Bearer $key")
            extra.forEach { (k, v) -> conn.setRequestProperty(k, v) }
            if (body != null) {
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setFixedLengthStreamingMode(body.size)
                conn.outputStream.use { it.write(body) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IOException("HTTP $code: ${text.take(200)}")
            return text
        } finally { conn.disconnect() }
    }

    /** verilən vərəqdə "Borc" sütununun indeksi (tapılmasa -1) */
    private fun borcColOf(file: String, sheet: String, cache: HashMap<String, Int>): Int =
        cache.getOrPut("$file|$sheet") {
            var r = -1
            try {
                db.rawQuery(
                    "SELECT b.headers FROM buildings b JOIN files f ON f.id = b.file_id WHERE f.name = ? AND b.sheet = ?",
                    arrayOf(file, sheet)
                ).use { if (it.moveToFirst()) r = colIdx(jsonList(it.getString(0)), "borc") }
            } catch (e: Exception) { }
            r
        }

    private fun dumpTable(table: String, cols: Int, filter: ((android.database.Cursor) -> Boolean)? = null): JSONArray {
        val out = JSONArray()
        editsDb.rawQuery("SELECT * FROM $table", null).use { c ->
            while (c.moveToNext()) {
                if (filter != null && !filter(c)) continue
                val a = JSONArray()
                for (i in 0 until cols) {
                    if (c.getType(i) == android.database.Cursor.FIELD_TYPE_INTEGER) a.put(c.getLong(i)) else a.put(c.getString(i) ?: "")
                }
                out.put(a)
            }
        }
        return out
    }

    private fun buildSnapshot(): JSONObject {
        val o = JSONObject()
        val cache = HashMap<String, Int>()
        // Telefonda edilmiş bütün sütun redaktələri, Borc daxil olmaqla, sinxronlaşdırılır.
        o.put("edits", dumpTable("edits", 5))
        o.put("imp_sheets", dumpTable("imp_sheets", 4))
        o.put("imp_rows", dumpTable("imp_rows", 4))
        o.put("renames", dumpTable("renames", 4))
        o.put("added", dumpTable("added", 4))
        o.put("added_rows", dumpTable("added_rows", 4))
        o.put("deleted_rows", dumpTable("deleted_rows", 3))
        o.put("deleted_cats", dumpTable("deleted_cats", 3))   // silinmiş fayl/küçə/binalar
        o.put("moved_cats", dumpTable("moved_cats", 5))       // köçürülmüş küçə/binalar
        o.put("notes", dumpTable("notes", 4))          // qeydlər + xatırlatma vaxtı
        o.put("debt_log", dumpTable("debt_log", 5))    // borc dəyişiklikləri siyahısı
        o.put("sheet_upd", dumpTable("sheet_upd", 3))   // son yenilənmə tarixləri də serverə düşür
        // sent cədvəli qəsdən snapshot-a daxil edilmir.
        return o
    }

    private fun snapHash(o: JSONObject): String { val t = o.toString(); return t.hashCode().toString() + ":" + t.length }

    /** null = uğurlu */
    private fun pushSync(force: Boolean): String? {
        val snap = buildSnapshot()
        val h = snapHash(snap)
        if (!force && sbPrefs.getString("hash", "") == h) return null
        // Hər yükləmənin öz möhürü var: başqa telefon "serverdə yenilik var"ı bununla tanıyır.
        // Hash möhürsüz hesablandığı üçün dəyişiklik olmayanda təkrar yükləmə baş vermir.
        val stamp = devId() + ":" + System.currentTimeMillis()
        snap.put("_meta", JSONObject().put("stamp", stamp))
        val row = JSONObject()
        row.put("id", "main"); row.put("data", snap); row.put("updated_at", nowIso())
        // Realtime öz yükləməmizi "yenilik" kimi göstərməsin deyə möhür sorğudan əvvəl yazılır.
        val oldStamp = sbPrefs.getString("stamp", "") ?: ""
        sbPrefs.edit().putString("stamp", stamp).apply()
        try {
            sbRequest("POST", "/rest/v1/$SYNC_TABLE?on_conflict=id", JSONArray().put(row).toString().toByteArray(Charsets.UTF_8),
                mapOf("Prefer" to "resolution=merge-duplicates,return=minimal"))
        } catch (e: Exception) {
            sbPrefs.edit().putString("stamp", oldStamp).apply()
            throw e
        }
        sbPrefs.edit().putString("hash", h).apply()
        snapGen++; serverSnap = snap; serverSnapStamp = stamp
        remoteNewStamp = ""
        return null
    }

    /** Borc istisna olmaqla hər hansı dəyişiklik/əlavə olubsa true: yalnız bu halda avtomatik yükləmə işləyir */
    private var syncDirty = false

    /** auto=false: yalnız borc yenilənməsi/silinməsi; qırmızı say yenilənir, amma serverə avtomatik yüklənmir */
    private fun scheduleSync(auto: Boolean = true) {
        if (auto) syncDirty = true
        // Qırmızı say yerli dəyişikliklərdən sonra yenilənir.
        if (sbConfigured()) { ui.removeCallbacks(badgeRunnable); ui.postDelayed(badgeRunnable, 1200) }
        if (!auto || !sbConfigured() || !sbAuto()) return
        ui.removeCallbacks(syncRunnable)
        ui.postDelayed(syncRunnable, 3000)
    }

    private fun runSync(force: Boolean, manual: Boolean) {
        if (!sbConfigured()) return
        if (syncRunning) { syncPending = true; return }
        syncRunning = true
        setCloudStatus("⏳")
        Thread {
            var err: String? = null
            var remoteNewer = false
            try {
                if (!force) {
                    // Serverdə başqa cihazdan yeni dəyişiklik varsa, üzərinə yazmazdan əvvəl birləşdirilir
                    val arr = JSONArray(sbRequest("GET", "/rest/v1/$SYNC_TABLE?id=eq.main&select=meta:data->_meta", null))
                    val st = if (arr.length() > 0) arr.getJSONObject(0).optJSONObject("meta")?.optString("stamp") ?: "" else ""
                    if (st.isNotEmpty() && st != (sbPrefs.getString("stamp", "") ?: "") && localPending()) remoteNewer = true
                }
                if (!remoteNewer) err = pushSync(force)
            } catch (e: Exception) { err = e.message ?: e.toString() }
            runOnUiThread {
                syncRunning = false
                if (remoteNewer) { if (sbAutoDown()) doPull(true, true) else setCloudStatus("⬇"); return@runOnUiThread }
                if (err == null) {
                    setCloudStatus("✓ " + java.text.SimpleDateFormat("HH:mm", Locale.US).format(java.util.Date()))
                    syncErrShown = false
                    syncDirty = false
                    refreshDiff(false)
                    if (manual) Toast.makeText(this, "Serverə yükləndi", Toast.LENGTH_SHORT).show()
                } else {
                    setCloudStatus("⚠")
                    if (manual || !syncErrShown) { syncErrShown = true; Toast.makeText(this, "Supabase xətası: " + sbFriendly(err ?: ""), Toast.LENGTH_LONG).show() }
                }
                if (syncPending) { syncPending = false; scheduleSync() }
            }
        }.start()
    }

    private fun restoreTable(table: String, arr: JSONArray?, cols: Int) {
        editsDb.execSQL("DELETE FROM $table")
        if (arr == null) return
        val ph = List(cols) { "?" }.joinToString(",")
        for (i in 0 until arr.length()) {
            val r = arr.getJSONArray(i)
            val args = Array<Any>(cols) { k -> val v = r.get(k); if (v == JSONObject.NULL) "" else v }
            editsDb.execSQL("INSERT OR REPLACE INTO $table VALUES($ph)", args)
        }
    }

    /** serverdəki son yenilənmə tarixləri telefondakılarla birləşdirilir: hər bina üçün ən yeni tarix qalır (heç vaxt köhnəsi yenisini əvəz etmir) */
    private fun mergeUpd(arr: JSONArray?) {
        if (arr == null) return
        for (i in 0 until arr.length()) {
            val r = arr.getJSONArray(i)
            val file = r.getString(0); val sheet = r.optString(1, ""); val ts = r.getLong(2)
            var cur = 0L
            editsDb.rawQuery("SELECT ts FROM sheet_upd WHERE file = ? AND sheet = ?", arrayOf(file, sheet)).use { if (it.moveToFirst()) cur = it.getLong(0) }
            if (ts > cur) editsDb.execSQL("INSERT OR REPLACE INTO sheet_upd VALUES(?,?,?)", arrayOf<Any>(file, sheet, ts))
        }
    }

    private fun applySnapshot(o: JSONObject) {
        editsDb.beginTransaction()
        try {
            val cache = HashMap<String, Int>()
            // Bütün yerli redaktələr server snapshot-u ilə əvəz olunur (Borc sütunu da daxil).
            editsDb.execSQL("DELETE FROM edits")
            val ed = o.optJSONArray("edits")
            if (ed != null) for (i in 0 until ed.length()) {
                val r = ed.getJSONArray(i)
                editsDb.execSQL("INSERT OR REPLACE INTO edits VALUES(?,?,?,?,?)",
                    arrayOf<Any>(r.getString(0), r.getString(1), r.getInt(2), r.getInt(3), r.getString(4)))
            }
            restoreTable("imp_sheets", o.optJSONArray("imp_sheets"), 4)
            restoreTable("imp_rows", o.optJSONArray("imp_rows"), 4)
            restoreTable("renames", o.optJSONArray("renames"), 4)
            restoreTable("added", o.optJSONArray("added"), 4)
            restoreTable("added_rows", o.optJSONArray("added_rows"), 4)
            restoreTable("deleted_rows", o.optJSONArray("deleted_rows"), 3)
            if (o.has("deleted_cats")) restoreTable("deleted_cats", o.optJSONArray("deleted_cats"), 3)
            if (o.has("moved_cats")) restoreTable("moved_cats", o.optJSONArray("moved_cats"), 5)
            // köhnə server snapshot-unda qeyd/jurnal yoxdursa telefondakılar silinmir
            if (o.has("notes")) restoreTable("notes", o.optJSONArray("notes"), 4)
            if (o.has("debt_log")) restoreTable("debt_log", o.optJSONArray("debt_log"), 5)
            mergeUpd(o.optJSONArray("sheet_upd"))
            // Köhnə server snapshot-unda "sent" olsa belə, bu statusu telefona tətbiq etmirik.
            editsDb.setTransactionSuccessful()
        } finally { editsDb.endTransaction() }
        sentSet.clear()
        editsDb.rawQuery("SELECT skey, kind FROM sent", null).use { c -> while (c.moveToNext()) sentSet.add(c.getString(0) + "|" + c.getString(1)) }
    }

    /** Server snapshot-unu telefondakı hələ göndərilməmiş dəyişikliklərlə birləşdirir: serverdə olub telefonda olmayanlar əlavə olunur, eyni xanada telefondakı dəyər qalır */
    private fun mergeSnapshot(o: JSONObject) {
        editsDb.beginTransaction()
        try {
            fun ins(table: String, arr: JSONArray?, cols: Int) {
                if (arr == null) return
                val ph = List(cols) { "?" }.joinToString(",")
                for (i in 0 until arr.length()) {
                    val r = arr.getJSONArray(i)
                    val args = Array<Any>(cols) { k -> val v = r.get(k); if (v == JSONObject.NULL) "" else v }
                    editsDb.execSQL("INSERT OR IGNORE INTO $table VALUES($ph)", args)
                }
            }
            // Redaktələr (Borc daxil) 3 tərəfli birləşdirilir: son sinxronizasiyadan sonra bu telefonda DƏYİŞMƏYƏN xanalar
            // serverdəki yeni dəyəri alır (yeni borc avtomatik yenilənir), telefonda dəyişənlər qalır.
            val base = tableMap(serverSnap, "edits", 4)
            val ed = o.optJSONArray("edits")
            if (ed != null) for (i in 0 until ed.length()) {
                val r = ed.getJSONArray(i)
                val file = r.getString(0); val sheet = r.getString(1); val ord = r.getInt(2); val col = r.getInt(3); val sv = r.getString(4)
                var lv: String? = null
                editsDb.rawQuery("SELECT value FROM edits WHERE file = ? AND sheet = ? AND ord = ? AND col = ?",
                    arrayOf(file, sheet, ord.toString(), col.toString())).use { if (it.moveToFirst()) lv = it.getString(0) }
                val bv = base[listOf(file, sheet, ord.toString(), col.toString()).joinToString("\u0001")]?.second
                if (lv == null || (bv != null && lv == bv)) {
                    editsDb.execSQL("INSERT OR REPLACE INTO edits VALUES(?,?,?,?,?)", arrayOf<Any>(file, sheet, ord, col, sv))
                }
            }
            ins("imp_sheets", o.optJSONArray("imp_sheets"), 4)
            ins("imp_rows", o.optJSONArray("imp_rows"), 4)
            ins("renames", o.optJSONArray("renames"), 4)
            ins("added", o.optJSONArray("added"), 4)
            ins("added_rows", o.optJSONArray("added_rows"), 4)
            ins("deleted_rows", o.optJSONArray("deleted_rows"), 3)
            ins("deleted_cats", o.optJSONArray("deleted_cats"), 3)
            ins("moved_cats", o.optJSONArray("moved_cats"), 5)
            // qeydlər: bu telefonda dəyişməyənlər serverdəki yeni versiyanı alır, telefonda dəyişənlər qalır
            val nBase = tableMap(serverSnap, "notes", 1)
            val nArr = o.optJSONArray("notes")
            if (nArr != null) for (i in 0 until nArr.length()) {
                val r = nArr.getJSONArray(i)
                val k = r.getString(0)
                var lv: String? = null
                editsDb.rawQuery("SELECT note, remind, label FROM notes WHERE skey = ?", arrayOf(k)).use {
                    if (it.moveToFirst()) lv = (it.getString(0) ?: "") + "\u0001" + it.getLong(1) + "\u0001" + (it.getString(2) ?: "")
                }
                val bv = nBase[k]?.second
                // lv == null && bv != null: bu telefonda silinib, serverdən geri qayıtmasın
                if ((lv == null && bv == null) || (lv != null && bv != null && lv == bv)) {
                    editsDb.execSQL("INSERT OR REPLACE INTO notes VALUES(?,?,?,?)",
                        arrayOf<Any>(k, r.optString(1, ""), r.optLong(2, 0L), r.optString(3, "")))
                }
            }
            val dBase = tableMap(serverSnap, "debt_log", 5)
            val dArr = o.optJSONArray("debt_log")
            if (dArr != null) for (i in 0 until dArr.length()) {
                val r = dArr.getJSONArray(i)
                val key = (0 until 5).map { j -> if (r.isNull(j)) "" else r.get(j).toString() }.joinToString("\u0001")
                if (dBase.containsKey(key)) continue   // əvvəl sinxronlaşıb, indi telefonda yoxdursa silinib: geri qaytarılmır
                editsDb.execSQL("INSERT OR IGNORE INTO debt_log VALUES(?,?,?,?,?)",
                    arrayOf<Any>(r.getString(0), r.optString(1, ""), r.optDouble(2, 0.0), r.optDouble(3, 0.0), r.optLong(4, 0L)))
            }
            mergeUpd(o.optJSONArray("sheet_upd"))
            editsDb.setTransactionSuccessful()
        } finally { editsDb.endTransaction() }
    }

    /** data.db-ni asset-dən yenidən qurub bütün qeydləri (import, əlavə, redaktə, ad, silmə) təkrar tətbiq edir */
    private fun rebuildDb() {
        try { db.close() } catch (e: Exception) { }
        migrateBarat()
        migrateBaratBack()
        val f = File(filesDir, "data.db")
        assets.open("data.db").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        val d = SQLiteDatabase.openDatabase(f.path, null, SQLiteDatabase.OPEN_READWRITE)
        var hasDisp = false
        d.rawQuery("PRAGMA table_info(files)", null).use { c -> while (c.moveToNext()) if (c.getString(1) == "disp") hasDisp = true }
        if (!hasDisp) d.execSQL("ALTER TABLE files ADD COLUMN disp TEXT")
        replayAll(d)
        db = d
    }

    private fun doPull(silent: Boolean = false, merge: Boolean = false) {
        if (refresher != null) {
            if (!silent) Toast.makeText(this, "Əvvəlcə yenilənmənin bitməsini gözləyin", Toast.LENGTH_SHORT).show()
            else ui.postDelayed({ doPull(true, merge) }, 4000)   // yeniləmə bitəndən sonra avtomatik endirilir
            return
        }
        val dlg = if (silent) null else busyDialog("Serverdən endirilir…")
        Thread {
            var err: String? = null
            var snapshot: JSONObject? = null
            try {
                val arr = JSONArray(sbRequest("GET", "/rest/v1/$SYNC_TABLE?id=eq.main&select=data", null))
                if (arr.length() > 0) snapshot = arr.getJSONObject(0).getJSONObject("data")
            } catch (e: Exception) { err = e.message ?: e.toString() }
            runOnUiThread {
                // Baza dəyişdirilməsi əsas axında edilir ki, ekran köhnə bazaya sorğu göndərməsin.
                val snap = snapshot
                if (err == null && snap != null) {
                    try {
                        val st = snap.optJSONObject("_meta")?.optString("stamp") ?: ""
                        if (merge) {
                            mergeSnapshot(snap)
                            rebuildDb()
                            reloadNotes()
                            remoteNewStamp = ""
                            snapGen++; serverSnap = snap; serverSnapStamp = st
                            sbPrefs.edit().putString("stamp", st).apply()   // hash dəyişmir: birləşmiş nəticə serverə yüklənəcək
                        } else {
                            applySnapshot(snap)
                            rebuildDb()
                            reloadNotes()
                            remoteNewStamp = ""
                            snapGen++; serverSnap = snap; serverSnapStamp = st
                            sbPrefs.edit().putString("hash", snapHash(buildSnapshot())).putString("stamp", st).apply()
                        }
                    } catch (e: Exception) { err = e.message ?: e.toString() }
                }
                try { dlg?.dismiss() } catch (e: Exception) { }
                val e1 = err
                if (e1 == null && snap != null) refreshDiff(false)
                if (silent) {
                    if (e1 == null && snap != null) {
                        remoteNewStamp = ""
                        afterRefresh()
                        Toast.makeText(this, "Serverdən yeni məlumatlar endirildi", Toast.LENGTH_SHORT).show()
                        if (merge) runSync(false, false)   // birləşmiş nəticə avtomatik serverə yüklənir
                    }
                } else {
                    val msg = when {
                        e1 != null -> "Xəta: " + sbFriendly(e1)
                        snap == null -> "Serverdə hələ məlumat yoxdur. Əvvəlcə «Serverə yüklə» edin."
                        else -> "Endirildi və tətbiq olundu."
                    }
                    AlertDialog.Builder(this).setMessage(msg).setPositiveButton("Bağla", null).show()
                    if (e1 == null && snap != null) afterRefresh()
                }
            }
        }.start()
    }

    private fun showSbSettings(then: () -> Unit = {}) {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(8), dp(20), dp(8))
        val etUrl = EditText(this)
        etUrl.hint = "Project URL  (https://xxxx.supabase.co)"; etUrl.isSingleLine = true
        etUrl.setText(sbPrefs.getString("url", SUPABASE_PROJECT_URL) ?: SUPABASE_PROJECT_URL)
        val etKey = EditText(this)
        etKey.hint = "Secret / service_role açarı (şəxsi test üçün)"; etKey.isSingleLine = true
        etKey.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        etKey.setText(sbPrefs.getString("key", SUPABASE_SECRET_KEY) ?: SUPABASE_SECRET_KEY)
        val btnSite = Button(this).apply {
            text = "🌐 Supabase saytını aç"; isAllCaps = false
            setOnClickListener {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://supabase.com/dashboard"))) }
                catch (e: Exception) { Toast.makeText(this@BazaActivity, "Brauzer tapılmadı", Toast.LENGTH_SHORT).show() }
            }
        }
        val btnSql = Button(this).apply { text = "📋 SQL-i kopyala"; isAllCaps = false; setOnClickListener { copySql() } }
        col.addView(etUrl); col.addView(etKey)
        col.addView(btnSite); col.addView(btnSql)
        val scrollCol = ScrollView(this).apply { addView(col) }
        val builder = AlertDialog.Builder(this).setTitle("Supabase ayarları").setView(scrollCol)
            .setPositiveButton("Yadda saxla") { _, _ ->
                sbPrefs.edit().putString("url", etUrl.text.toString().trim()).putString("key", etKey.text.toString().trim())
                    .putString("hash", "").apply()
                sbKeyProblem()?.let { Toast.makeText(this, it, Toast.LENGTH_LONG).show() }
                then()
                scheduleSync()
                stopLive(); startLive()
            }
            .setNeutralButton("Bağlantını yoxla", null)
            .setNegativeButton("Ləğv et", null)
        val settingsDlg = builder.show()
        // Yoxlama düyməsi pəncərəni bağlamır: nəticəni görüb açarı yerindəcə düzəltmək olar.
        settingsDlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            sbPrefs.edit().putString("url", etUrl.text.toString().trim()).putString("key", etKey.text.toString().trim())
                .putString("hash", "").apply()
            testSupabaseConnection()
        }
    }

    private fun requestCloudUpload() {
        if (!sbConfigured()) {
            showSbSettings { if (sbConfigured()) runSync(true, true) }
            return
        }
        runSync(true, true)
    }

    private fun requestCloudDownload() {
        if (!sbConfigured()) {
            showSbSettings { if (sbConfigured()) confirmCloudDownload() }
            return
        }
        confirmCloudDownload()
    }

    private fun confirmCloudDownload() {
        if (refresher != null) {
            Toast.makeText(this, "Əvvəlcə yenilənmənin bitməsini gözləyin", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this).setTitle("Serverdən endir")
            .setMessage("Serverdəki məlumat bu telefondakı redaktələrin, əlavələrin və silinmələrin yerinə yazılacaq (borc dəyərləri saxlanılır). Davam edilsin?")
            .setPositiveButton("Bəli") { _, _ -> doPull() }
            .setNegativeButton("Xeyr", null).show()
    }

    private fun showCloudMenu() {
        if (!sbConfigured()) { showSbSettings { if (sbConfigured()) showCloudMenu() }; return }
        val busy = busyDialog("Server ilə müqayisə edilir…")
        refreshDiff(true) { ok ->
            try { busy.dismiss() } catch (e: Exception) { }
            showDiffDialog(ok)
        }
    }

    private fun testSupabaseConnection() {
        if (!sbConfigured()) {
            Toast.makeText(this, "Project URL və API açarını daxil edin", Toast.LENGTH_LONG).show()
            return
        }
        val keyProblem = sbKeyProblem()
        if (keyProblem != null) {
            AlertDialog.Builder(this).setTitle("Supabase bağlantısı").setMessage(keyProblem)
                .setPositiveButton("Bağla", null).show()
            return
        }
        val dlg = busyDialog("Supabase bağlantısı yoxlanılır…")
        Thread {
            var err: String? = null
            try {
                // 1) oxuma
                sbRequest("GET", "/rest/v1/$SYNC_TABLE?select=id&limit=1", null)
                // 2) yazma (RLS / icazə səhvləri yalnız burada üzə çıxır)
                val row = JSONObject()
                row.put("id", "_ping"); row.put("data", JSONObject().put("t", nowIso())); row.put("updated_at", nowIso())
                sbRequest("POST", "/rest/v1/$SYNC_TABLE?on_conflict=id", JSONArray().put(row).toString().toByteArray(Charsets.UTF_8),
                    mapOf("Prefer" to "resolution=merge-duplicates,return=minimal"))
                // 3) test sətrini sil
                sbRequest("DELETE", "/rest/v1/$SYNC_TABLE?id=eq._ping", null, mapOf("Prefer" to "return=minimal"))
            } catch (e: Exception) { err = e.message ?: e.toString() }
            runOnUiThread {
                try { dlg.dismiss() } catch (_: Exception) { }
                val msg = if (err == null) "Bağlantı uğurludur. baza_sync cədvəlində oxuma və yazma işləyir.\n\nİndi «Yadda saxla» düyməsinə toxunun."
                    else "Bağlantı alınmadı.\n\n" + sbFriendly(err ?: "") + "\n\nTexniki məlumat: " + (err ?: "").take(160)
                AlertDialog.Builder(this).setTitle("Supabase bağlantısı").setMessage(msg)
                    .setPositiveButton("Bağla", null).show()
            }
        }.start()
    }

    // ---------- açılışda yoxlama, Realtime və layihəni "canlı" saxlama ----------
    private var wsClient: okhttp3.OkHttpClient? = null
    private var ws: okhttp3.WebSocket? = null
    private var wsJoined = false
    private var wsWanted = false
    private var wsRef = 2
    private var lastCheckAt = 0L
    private var checkRunning = false

    private val wsHeartbeat = object : Runnable {
        override fun run() {
            if (!wsWanted) return
            ws?.send("{\"topic\":\"phoenix\",\"event\":\"heartbeat\",\"payload\":{},\"ref\":\"${wsRef++}\"}")
            ui.postDelayed(this, 25000)
        }
    }
    private val wsReconnect = Runnable { if (wsWanted) connectRealtime() }
    private val rtCheck = Runnable { checkRemote(false) }
    // Realtime qoşulmayıbsa (açar növü, publication və s.) 20 saniyədən bir yüngül yoxlama aparılır
    private val pollRunnable = object : Runnable {
        override fun run() {
            if (!wsWanted) return
            checkRemote(false)   // Realtime qoşulu olsa belə, yeni borc dəyərləri üçün 20 saniyədən bir yoxlanılır
            ui.postDelayed(this, 20000)
        }
    }

    private fun devId(): String {
        var d = sbPrefs.getString("dev", "") ?: ""
        if (d.isEmpty()) { d = java.util.UUID.randomUUID().toString().take(8); sbPrefs.edit().putString("dev", d).apply() }
        return d
    }

    /** bu telefonda hələ serverə getməmiş dəyişiklik varmı */
    private fun localPending(): Boolean = sbPrefs.getString("hash", "") != snapHash(buildSnapshot())

    /** Serverdəki möhürü oxuyur (kiçik sorğu; eyni zamanda layihəni aktiv saxlayır) */
    private fun checkRemote(startup: Boolean) {
        if (!sbConfigured() || checkRunning) return
        checkRunning = true
        Thread {
            var stamp = ""
            var failed = false
            try {
                val arr = JSONArray(sbRequest("GET", "/rest/v1/$SYNC_TABLE?id=eq.main&select=meta:data->_meta", null))
                if (arr.length() > 0) stamp = arr.getJSONObject(0).optJSONObject("meta")?.optString("stamp") ?: ""
            } catch (e: Exception) { failed = true }
            runOnUiThread {
                checkRunning = false
                lastCheckAt = SystemClock.elapsedRealtime()
                if (failed || isFinishing) return@runOnUiThread
                if (stamp.isEmpty()) { if (serverSnap == null) refreshDiff(true); return@runOnUiThread }
                if (syncRunning) { ui.postDelayed({ checkRemote(startup) }, 1500); return@runOnUiThread }
                // Serverdə yeni möhür varsa (və ya hələ heç endirilməyibsə) fərqlər yenidən hesablanır
                if (serverSnap == null || serverSnapStamp != stamp) refreshDiff(true)
                if (stamp == (sbPrefs.getString("stamp", "") ?: "")) return@runOnUiThread
                onRemoteChanged(stamp, startup)
            }
        }.start()
    }

    /** Serverdə hələ endirilməmiş dəyişikliyin möhürü; yalnız Supabase menyusunda göstərilir */
    private var remoteNewStamp = ""

    private fun onRemoteChanged(stamp: String, startup: Boolean) {
        // Yeniləmə gedərkən gözlənilir; bitəndən sonra serverdəki yeniliklər avtomatik endirilir
        if (refresher != null) { ui.postDelayed({ checkRemote(false) }, 4000); return }
        remoteNewStamp = stamp
        // Avtomatik endirmə söndürülübsə yalnız qırmızı say/status göstərilir; endirmək üçün "⬇️ Serverdən endir" düyməsi istifadə olunur
        if (!sbAutoDown()) { setCloudStatus("⬇"); return }
        // Telefonda göndərilməmiş dəyişiklik varsa birləşdirilir (itmir), yoxdursa server nüsxəsi olduğu kimi endirilir
        doPull(true, localPending())
    }

    private fun wsUrl(): String {
        val host = sbUrl().removePrefix("https://").removePrefix("http://")
        return "wss://$host/realtime/v1/websocket?apikey=" + java.net.URLEncoder.encode(sbKey(), "UTF-8") + "&vsn=1.0.0"
    }

    private fun connectRealtime() {
        if (!sbConfigured() || !wsWanted) return
        try { ws?.cancel() } catch (e: Exception) { }
        wsJoined = false
        val client = wsClient ?: okhttp3.OkHttpClient.Builder().build().also { wsClient = it }
        val req = try { okhttp3.Request.Builder().url(wsUrl()).build() } catch (e: Exception) { return }
        ws = client.newWebSocket(req, object : okhttp3.WebSocketListener() {
            override fun onOpen(webSocket: okhttp3.WebSocket, response: okhttp3.Response) {
                val key = sbKey()
                val cfg = JSONObject()
                cfg.put("broadcast", JSONObject().put("self", false))
                cfg.put("presence", JSONObject().put("key", ""))
                cfg.put("postgres_changes", JSONArray().put(
                    JSONObject().put("event", "*").put("schema", "public").put("table", SYNC_TABLE)))
                val payload = JSONObject().put("config", cfg)
                if (key.startsWith("eyJ")) payload.put("access_token", key)
                webSocket.send(JSONObject().put("topic", "realtime:baza").put("event", "phx_join")
                    .put("payload", payload).put("ref", "1").toString())
            }
            override fun onMessage(webSocket: okhttp3.WebSocket, text: String) {
                try {
                    val o = JSONObject(text)
                    val ev = o.optString("event")
                    if (ev == "phx_reply" && o.optString("topic") == "realtime:baza") {
                        val ok = o.optJSONObject("payload")?.optString("status") == "ok"
                        ui.post {
                            if (ws !== webSocket) return@post
                            wsJoined = ok
                            if (ok) checkRemote(false)  // qoşulmazdan əvvəl qaçırılanları tutur
                        }
                    } else if (ev == "postgres_changes") {
                        ui.post {
                            if (ws !== webSocket) return@post
                            ui.removeCallbacks(rtCheck); ui.postDelayed(rtCheck, 400)
                        }
                    }
                } catch (e: Exception) { }
            }
            override fun onClosed(webSocket: okhttp3.WebSocket, code: Int, reason: String) { ui.post { realtimeLost(webSocket) } }
            override fun onFailure(webSocket: okhttp3.WebSocket, t: Throwable, response: okhttp3.Response?) { ui.post { realtimeLost(webSocket) } }
        })
    }

    private fun realtimeLost(w: okhttp3.WebSocket) {
        if (ws !== w) return
        ws = null; wsJoined = false
        if (wsWanted) { ui.removeCallbacks(wsReconnect); ui.postDelayed(wsReconnect, 5000) }
    }

    /** Canlı (Realtime) izləmə və 20 saniyəlik yoxlama söndürülüb: server yalnız bazaya girəndə (onResume -> checkRemote) yoxlanılır */
    private fun startLive() { }

    private fun stopLive() {
        wsWanted = false
        ui.removeCallbacks(wsHeartbeat); ui.removeCallbacks(pollRunnable)
        ui.removeCallbacks(wsReconnect); ui.removeCallbacks(rtCheck)
        try { ws?.close(1000, null) } catch (e: Exception) { }
        ws = null; wsJoined = false
    }

    // ---------- UI ----------
    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#000000"))   // AMOLED qara fon (əvvəlki rəng)
        }

        val btnExcel = Button(this).apply {
            text = "📊 Excel"; isAllCaps = false; textSize = 12f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE); minHeight = 0; minimumHeight = 0; minWidth = dp(100); minimumWidth = dp(100); setPadding(dp(12), dp(4), dp(12), dp(4))
            background = GradientDrawable().apply { setColor(Color.parseColor("#2E9E4F")); cornerRadius = dp(10).toFloat() }   // yaşıl fon
            setOnClickListener { showExcelMenu() }
        }

        // ----- Əsas ekran: başlıq + axtarış + kataloq siyahısı (həmişə görünür) -----
        catList = ListView(this)
        val btnAdd = Button(this).apply {
            text = "+ əlavə et"; textSize = 16f; isAllCaps = false; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply { setColor(Color.parseColor("#4F8CFF")); cornerRadius = dp(10).toFloat() }
            setOnClickListener { catSearch.hideSug(); showAddDialog() }
        }
        val addWrap = LinearLayout(this).apply {
            setPadding(dp(12), dp(12), dp(12), dp(20))
            addView(btnAdd, LinearLayout.LayoutParams(-1, dp(52)))
        }
        catList.addFooterView(addWrap, null, false)
        catSearch = SearchUi(
            scope = {
                when (level) {
                    1 -> Pair("b.file_id = ?", fileId.toString())
                    2 -> Pair("b.street_id = ?", streetId.toString())
                    3 -> Pair("b.id = ?", buildingId.toString())
                    else -> null
                }
            },
            onActive = { active ->
                catSearch.resultsBox.visibility = if (active) View.VISIBLE else View.GONE
                catList.visibility = if (active) View.GONE else View.VISIBLE
            },
            onRefresh = {
                // axtarış aktivdirsə — nəticələr, deyilsə — seçilmiş bölmə
                if (!catSearch.isEmpty()) {
                    val ids = catSearch.shownRowIds()
                    if (ids.isEmpty()) Toast.makeText(this, "Nəticə yoxdur", Toast.LENGTH_SHORT).show()
                    else refreshRows("Axtarış nəticələri (${currentScopeLabel()})", ids)
                } else refreshCurrentSection()
            },
            onSort = { loadLevel(false) },
            onCloud = { showCloudMenu() }
        )
        catPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tvPath = TextView(this).apply {
            textSize = 19f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.parseColor("#F2F2F5"))
        }
        tvTotal = TextView(this).apply {
            textSize = 17f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.parseColor("#FFE0B2"))
        }
        val btnHeaderRefresh = TextView(this).apply {
            text = "🔄"; textSize = 20f; gravity = Gravity.CENTER
            setPadding(dp(10), dp(4), dp(10), dp(4))
            setOnClickListener { catSearch.hideSug(); refreshCurrentSection() }
        }
        val line2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(tvTotal, LinearLayout.LayoutParams(0, -2, 1f))
            addView(btnHeaderRefresh, LinearLayout.LayoutParams(-2, -2))
        }
        catSearch.btnCloud.text = "☁ Supabase"
        catSearch.btnCloud.textSize = 12f
        catSearch.btnCloud.typeface = Typeface.DEFAULT_BOLD
        catSearch.btnCloud.minHeight = 0; catSearch.btnCloud.minimumHeight = 0; catSearch.btnCloud.minWidth = dp(100); catSearch.btnCloud.minimumWidth = dp(100)
        catSearch.btnCloud.setPadding(dp(12), dp(4), dp(12), dp(4))
        catSearch.btnCloud.setTextColor(Color.WHITE)
        catSearch.btnCloud.background = GradientDrawable().apply { setColor(Color.parseColor("#4F8CFF")); cornerRadius = dp(10).toFloat() }   // mavi fon
        // Başlıq və üç sinxronizasiya düyməsi eyni sətirdədir; düymələr başlığın sağındadır.
        cloudBadge = TextView(this).apply {
            textSize = 10f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER; minWidth = dp(18); setPadding(dp(4), 0, dp(4), 0)
            background = GradientDrawable().apply { setColor(Color.parseColor("#E53935")); cornerRadius = dp(9).toFloat() }
            visibility = View.GONE
        }
        val cloudWrap = FrameLayout(this).apply {
            addView(catSearch.btnCloud, FrameLayout.LayoutParams(-2, dp(34)))
            addView(cloudBadge, FrameLayout.LayoutParams(-2, dp(18), Gravity.TOP or Gravity.END).apply { topMargin = dp(1); rightMargin = dp(1) })
        }
        btnChanges = Button(this).apply {
            text = "📝 Dəyişikliklər"; textSize = 12f; isAllCaps = false; typeface = Typeface.DEFAULT_BOLD
            minHeight = 0; minimumHeight = 0; minWidth = 0; minimumWidth = 0
            setPadding(dp(10), dp(4), dp(10), dp(4)); setTextColor(Color.WHITE)
            background = GradientDrawable().apply { setColor(Color.parseColor("#2E7D5B")); cornerRadius = dp(10).toFloat() }
            setOnClickListener { showChangesDialog() }
        }
        val cloudActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(btnChanges, LinearLayout.LayoutParams(-2, dp(34)).apply { leftMargin = dp(2); rightMargin = dp(2) })
            addView(cloudWrap, LinearLayout.LayoutParams(-2, dp(34)).apply { leftMargin = dp(2); rightMargin = dp(2) })
            addView(btnExcel, LinearLayout.LayoutParams(-2, dp(34)))
        }
        val pathRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(tvPath, LinearLayout.LayoutParams(0, -2, 1f))
            addView(cloudActions, LinearLayout.LayoutParams(-2, -2))
        }
        tvPath.textSize = 15f
        tvPath.setOnLongClickListener { catSearch.hideSug(); showCloudMenu(); true }   // gizli Supabase menyusu: başlığa uzun basın
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(8), dp(4))
            addView(pathRow, LinearLayout.LayoutParams(-1, -2))
            addView(line2)
        }
        catPanel.addView(header)
        catPanel.addView(catSearch.form)
        catPanel.addView(rowOf(catSearch.btnFilter to 1.1f, catSearch.btnToggle to 1f), LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(4); leftMargin = dp(4); rightMargin = dp(4)
        })
        val btnChanges = Button(this).apply {
            text = "📈 Borc dəyişiklikləri"; isAllCaps = false; textSize = 12f
            setOnClickListener { catSearch.hideSug(); showDebtChanges() }
        }
        btnNotes = Button(this).apply {
            text = "📝 Qeydlər"; isAllCaps = false; textSize = 12f
            setOnClickListener { catSearch.hideSug(); showNotesList() }
        }
        catPanel.addView(rowOf(btnChanges to 1.2f, btnNotes to 1f), LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(2); leftMargin = dp(4); rightMargin = dp(4)
        })
        val frame = FrameLayout(this)
        frame.addView(catList, FrameLayout.LayoutParams(-1, -1))
        catSearch.resultsBox.visibility = View.GONE
        frame.addView(catSearch.resultsBox, FrameLayout.LayoutParams(-1, -1))
        catPanel.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(catPanel, LinearLayout.LayoutParams(-1, 0, 1f))

        catList.setOnItemClickListener { _, _, pos, _ ->
            if (level < 3) openChild(catIds[pos], catNames[pos])
        }
        // fayl / küçə / binanın üstünə uzun basanda: adını dəyiş, köçür, sil
        catList.setOnItemLongClickListener { _, _, pos, _ ->
            if (level < 3 && pos < catIds.size) { showCatMenu(pos); true } else false
        }

        setContentView(root)
        // Açılışda heç bir xana fokus almasın: klaviatura avtomatik açılmasın
        root.isFocusableInTouchMode = true
        root.requestFocus()
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)

        // saytdan yeniləmə üçün gizli WebView-lar bu konteynerdə işləyir (görünmür)
        webHost = FrameLayout(this)
        webHost.clipChildren = false
        addContentView(webHost, FrameLayout.LayoutParams(1, 1))

        loadLevel()
    }

    override fun onDestroy() {
        PendingChanges.onRemoteChange = null
        ui.removeCallbacks(changesPoll)
        try { stopHesabOne(); yeloOne = null; portOne = null; yeloShared?.destroy(); yeloShared = null; hesabShared?.destroy(); hesabShared = null; portShared?.destroy(); portShared = null } catch (e: Exception) { }
        try { dbWriter.shutdown() } catch (e: Exception) { }
        super.onDestroy()
    }

    override fun onPause() {
        // Son dəyişikliklər tətbiq arxa plana keçəndə də Supabase-ə göndərilmək üçün növbəyə qoyulur.
        if (::db.isInitialized && sbConfigured() && sbAuto() && syncDirty) scheduleSync()
        stopLive()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        // «Dəyişikliklər»: başqa cihazın təklifləri götürülür, düymədəki say yenilənir
        if (::editsDb.isInitialized) { updateChangesBadge(); Thread { PendingChanges.syncNow() }.start() }
        // Gün dəyişibsə WhatsApp sayğacı sıfırlanmış göstərilsin
        if (::catList.isInitialized && waDay != 0L && waDay != dayStart()) loadLevel(false, true)
        if (sbConfigured()) {
            startLive()
            // Açılışda (və uzun fasilədən sonra) serverdə dəyişiklik varmı; bu kiçik sorğu layihəni də aktiv saxlayır
            if (SystemClock.elapsedRealtime() - lastCheckAt > 60000) checkRemote(true)
        }
        // WhatsApp və SMS tətbiqindən geri qayıdanda, yaxud tətbiq yenidən açıldıqda
        // əvvəlki "Göndərildi" nişanları avtomatik silinsin; bu nişanlar daimi tarixçə deyil.
        if (::editsDb.isInitialized) {
            val hadSentMarks = sentSet.isNotEmpty()
            if (hadSentMarks) {
                sentSet.clear()
                editsDb.execSQL("DELETE FROM sent")
                if (::catSearch.isInitialized) refreshCards()
                // İşarənin silinməsi Supabase sinxronizasiyasını başlatmır.
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (catSearch.sugVisible()) { catSearch.hideSug(); return }
        if (!catSearch.isEmpty()) { catSearch.clear(); catSearch.scheduleSearch(); return }
        if (level > 0) { level--; loadLevel() } else super.onBackPressed()
    }

    // ---------- kataloq ----------
    private fun openChild(id: Long, label: String) {
        when (level) {
            0 -> { fileId = id; fileName = label }
            1 -> { streetId = id; streetName = label }
            2 -> { buildingId = id }
        }
        level++; loadLevel()
    }

    private fun refreshItem(pos: Int) {
        val id = catIds[pos]
        val label = catNames[pos]
        when (level) {
            0 -> refreshScope(label, "b.file_id = ?", id.toString())
            1 -> refreshScope("$fileName › $label", "b.street_id = ?", id.toString())
            else -> refreshScope("$streetName › $label", "b.id = ?", id.toString())
        }
    }

    /** Küçə adlarının ekranda tam yazılışını qaytarır; daxili baza açarları dəyişmir. */
    private fun fullStreetName(rawName: String): String = when (rawName.trim().uppercase(Locale.ROOT)) {
        "Ə.ƏLİXANOV" -> "Ənvər Əlixanov"
        "İ.HƏŞİMOV" -> "İsrafil Həşimov"
        "İ.CÜMŞÜDOV" -> "İlqar Cümşüdov"
        "KEÇİD" -> "Keçid küçəsi"
        "M.KAZIMOVSKİ" -> "Mir Mahmud Kazımovski"
        "R.BEHBUDOV" -> "Rəşid Behbudov"
        "S.MƏMMƏDOVA" -> "Svetlana Məmmədova"
        "Ü.HACIBƏYOV" -> "Üzeyir Hacıbəyov"
        "A.KUNANBAYEV" -> "Abay Kunanbayev"
        "S.S.AXUNDOV", "S.AXUNDOV" -> "Süleyman Sani Axundov"
        "H.HÜSEYNOV" -> "Heydər Hüseynov"
        "İ.DADAŞOV" -> "İbrahimpaşa Dadaşov"
        "N.NƏRİMANOV" -> "Nəriman Nərimanov"
        "Ş.MƏMMƏDOVA" -> "Şövkət Məmmədova"
        "A.MƏMMƏDOV" -> "Adil Məmmədov"
        "CAVADXAN" -> "Cavad xan"
        "H.BABAŞOV" -> "Həmzə Babaşov"
        "MİR CƏLAL" -> "Mir Cəlal"
        "SEYİDZADƏ" -> "Hüseyn Seyidzadə"
        "AZADLIQ PR" -> "Azadlıq prospekti"
        "A.GƏRYABƏYLİ" -> "Ağasadıq Gəraybəyli"
        "CƏFƏR XƏNDAN" -> "Cəfər Xəndan"
        "C.HACIBƏYLİ" -> "Ceyhun Hacıbəyli"
        "K.RƏHİMOV" -> "Koroğlu Rəhimov"
        "S.BƏHLULZADƏ" -> "Səttar Bəhlulzadə"
        "Z.BÜNYADOV" -> "Ziya Bünyadov"
        "ATATÜRK" -> "Mustafa Kamal Atatürk"
        "Ə.NAXÇIVANİ" -> "Əcəmi Naxçıvani"
        "Ş.RƏHİMOV" -> "Şəmsi Rəhimov"
        else -> rawName.trim()
    }

    private fun streetPathLabel(rawName: String): String = fullStreetName(rawName)

    /** Bina adının əvvəlində küçə qısaltması varsa, yalnız göstərilən mətndə tam ada çevirir. */
    private fun fullBuildingName(rawName: String): String {
        val raw = rawName.trim()
        val keys = listOf(
            "Ə.ƏLİXANOV", "İ.HƏŞİMOV", "İ.CÜMŞÜDOV", "M.KAZIMOVSKİ", "R.BEHBUDOV",
            "S.MƏMMƏDOVA", "Ü.HACIBƏYOV", "A.KUNANBAYEV", "S.S.AXUNDOV", "S.AXUNDOV",
            "H.HÜSEYNOV", "İ.DADAŞOV", "N.NƏRİMANOV", "Ş.MƏMMƏDOVA", "A.MƏMMƏDOV",
            "CAVADXAN", "H.BABAŞOV", "MİR CƏLAL", "SEYİDZADƏ", "AZADLIQ PR",
            "A.GƏRYABƏYLİ", "CƏFƏR XƏNDAN", "C.HACIBƏYLİ", "K.RƏHİMOV", "S.BƏHLULZADƏ",
            "Z.BÜNYADOV", "ATATÜRK", "Ə.NAXÇIVANİ", "Ş.RƏHİMOV", "KEÇİD"
        ).sortedByDescending { it.length }
        for (key in keys) {
            if (raw.uppercase(Locale.ROOT) == key || raw.uppercase(Locale.ROOT).startsWith("$key ") || raw.uppercase(Locale.ROOT).startsWith("$key,")) {
                return fullStreetName(key) + raw.substring(key.length)
            }
        }
        return raw
    }

    private fun loadLevel(clearSearch: Boolean = true, keepScroll: Boolean = false) {
        val keepPos = if (keepScroll) catList.firstVisiblePosition else 0
        val keepTop = if (keepScroll) (catList.getChildAt(0)?.top ?: 0) else 0
        if (clearSearch) {
            catSearch.clear()
            catSearch.resultsBox.visibility = View.GONE
            catList.visibility = View.VISIBLE
        }
        catIds = ArrayList(); catNames = ArrayList(); catCounts = ArrayList(); catBorc = ArrayList(); catUpd = ArrayList()
        val desc = catSearch.sortDesc()
        val sumOrd = if (desc) "COALESCE(SUM(r.borc),0) DESC, " else ""
        fun collect(c: android.database.Cursor) {
            while (c.moveToNext()) {
                catIds.add(c.getLong(0)); catNames.add(c.getString(1)); catCounts.add(c.getInt(2)); catBorc.add(c.getDouble(3))
            }
        }
        when (level) {
            0 -> {
                tvPath.text = "Əsas kateqoriya (fayl)"
                db.rawQuery(
                    "SELECT f.id, COALESCE(NULLIF(f.disp, ''), f.name), COUNT(r.id), COALESCE(SUM(r.borc),0) FROM files f LEFT JOIN buildings b ON b.file_id = f.id " +
                        "LEFT JOIN rows r ON r.building_id = b.id GROUP BY f.id ORDER BY ${sumOrd}f.ord", null
                ).use { collect(it) }
            }
            1 -> {
                tvPath.text = fileName
                db.rawQuery(
                    "SELECT s.id, s.name, COUNT(r.id), COALESCE(SUM(r.borc),0) FROM streets s LEFT JOIN buildings b ON b.street_id = s.id " +
                        "LEFT JOIN rows r ON r.building_id = b.id WHERE s.file_id = ? GROUP BY s.id ORDER BY ${sumOrd}s.ord",
                    arrayOf(fileId.toString())
                ).use { collect(it) }
                // küçənin son yenilənmə vaxtı = onun binalarından ən yenisi
                try {
                    val bySheet = sheetUpdMap()
                    val byStreet = HashMap<Long, Long>()
                    if (bySheet.isNotEmpty()) db.rawQuery("SELECT street_id, sheet FROM buildings WHERE file_id = ?", arrayOf(fileId.toString())).use { b ->
                        while (b.moveToNext()) { val t = bySheet[b.getString(1) ?: ""] ?: continue; val sid = b.getLong(0); if (t > (byStreet[sid] ?: 0L)) byStreet[sid] = t }
                    }
                    for (id in catIds) catUpd.add(byStreet[id] ?: 0L)
                } catch (e: Exception) { catUpd = ArrayList() }
            }
            2 -> {
                tvPath.text = "$fileName  ›  ${streetPathLabel(streetName)}"
                db.rawQuery(
                    "SELECT b.id, b.name, COUNT(r.id), COALESCE(SUM(r.borc),0) FROM buildings b LEFT JOIN rows r ON r.building_id = b.id " +
                        "WHERE b.street_id = ? GROUP BY b.id ORDER BY ${sumOrd}b.ord",
                    arrayOf(streetId.toString())
                ).use { collect(it) }
                // alt küçə (bina) üçün son yenilənmə vaxtı
                try {
                    val bySheet = sheetUpdMap()
                    val byB = HashMap<Long, Long>()
                    if (bySheet.isNotEmpty()) db.rawQuery("SELECT id, sheet FROM buildings WHERE street_id = ?", arrayOf(streetId.toString())).use { b ->
                        while (b.moveToNext()) { val t = bySheet[b.getString(1) ?: ""] ?: continue; byB[b.getLong(0)] = t }
                    }
                    for (id in catIds) catUpd.add(byB[id] ?: 0L)
                } catch (e: Exception) { catUpd = ArrayList() }
            }
            3 -> {
                val cards = ArrayList<Card>()
                var waB = 0
                db.rawQuery("SELECT headers, name, title, sheet FROM buildings WHERE id=?", arrayOf(buildingId.toString())).use { b ->
                    if (b.moveToFirst()) {
                        val hdr = jsonList(b.getString(0)); val nm = b.getString(1); val title = b.getString(2); val sheet = b.getString(3) ?: ""; val fk = fileKeyName(fileId)
                        waB = waMaps().second["$fk|$sheet"] ?: 0
                        tvPath.text = "$fileName  ›  $nm"
                        db.rawQuery("SELECT cells, id, ord FROM rows WHERE building_id=? ORDER BY ${if (desc) "borc DESC, " else ""}ord", arrayOf(buildingId.toString())).use { c ->
                            while (c.moveToNext()) cards.add(Card("", title, hdr, jsonList(c.getString(0)), c.getLong(1), nm, "$fk|$sheet|${c.getInt(2)}"))
                        }
                    }
                }
                var sum = 0.0
                db.rawQuery("SELECT COALESCE(SUM(borc),0) FROM rows WHERE building_id=?", arrayOf(buildingId.toString())).use { c ->
                    if (c.moveToFirst()) sum = c.getDouble(0)
                }
                tvTotal.text = totalText(sum, cards.size) + waSuffix(waB)
                cardAdapterCat.set(cards)
                catList.divider = null
                catList.adapter = cardAdapterCat
                catList.clipToPadding = false
                catList.setPadding(dp(8), 0, dp(8), dp(8))
                if (keepScroll) catList.setSelectionFromTop(keepPos, keepTop)
                return
            }
        }
        computeCatWa()
        tvTotal.text = totalText(catBorc.sum(), catCounts.sum()) + waSuffix(catWa.sum())
        catList.divider = ColorDrawable(Color.parseColor("#232328"))
        catList.dividerHeight = 1
        catList.setPadding(0, 0, 0, 0)
        catList.adapter = CatAdapter()
        if (keepScroll) catList.setSelectionFromTop(keepPos, keepTop)
    }

    /** Ad yuxarıda; altında "Ümumi Borc (…) / Ümumi Mənzil (…)" və sağda dairəvi ox (yenilə) */
    inner class CatAdapter : BaseAdapter() {
        override fun getCount() = catNames.size
        override fun getItem(position: Int) = catNames[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = LinearLayout(this@BazaActivity)
            row.orientation = LinearLayout.VERTICAL
            row.setBackgroundColor(Color.parseColor("#0B0B0D"))
            row.setPadding(dp(14), dp(10), dp(6), dp(8))
            val name = TextView(this@BazaActivity)
            name.textSize = 15f; name.typeface = Typeface.DEFAULT_BOLD
            name.setTextColor(Color.parseColor("#F2F2F5"))
            name.maxLines = 2
            name.ellipsize = TextUtils.TruncateAt.END
            // Küçə və bina adları ekranda tam göstərilir; daxili baza adları dəyişmir.
            val shownName = when (level) {
                1 -> fullStreetName(catNames[position])
                2 -> fullBuildingName(catNames[position])
                else -> catNames[position]
            }
            name.text = shownName
            val nameLine = LinearLayout(this@BazaActivity)
            nameLine.orientation = LinearLayout.HORIZONTAL
            nameLine.gravity = Gravity.CENTER_VERTICAL
            nameLine.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
            if ((level == 1 || level == 2) && position < catUpd.size) {
                val ts = catUpd[position]
                val status = TextView(this@BazaActivity)
                status.text = if (ts > 0) java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date(ts)) else "Yenilənməyib"
                status.textSize = 11f
                status.typeface = Typeface.DEFAULT
                status.gravity = Gravity.END or Gravity.CENTER_VERTICAL
                status.setTextColor(Color.parseColor(if (ts > 0) "#8FD18F" else "#8A8A93"))
                status.setPadding(dp(8), 0, dp(4), 0)
                status.maxLines = 2
                status.maxWidth = dp(132)
                nameLine.addView(status, LinearLayout.LayoutParams(-2, -2))
            }
            val info = TextView(this@BazaActivity)
            info.text = totalText(catBorc[position], catCounts[position]) + waSuffix(catWa.getOrElse(position) { 0 }); info.textSize = 13f
            info.setTextColor(Color.parseColor("#4F8CFF"))
            val ref = TextView(this@BazaActivity)
            ref.text = "🔄"; ref.textSize = 20f; ref.gravity = Gravity.CENTER
            ref.setPadding(dp(12), dp(4), dp(12), dp(4))
            ref.isFocusable = false
            ref.setOnClickListener { refreshItem(position) }
            val line = LinearLayout(this@BazaActivity)
            line.orientation = LinearLayout.HORIZONTAL
            line.gravity = Gravity.CENTER_VERTICAL
            line.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            line.addView(ref, LinearLayout.LayoutParams(-2, -2))
            row.addView(nameLine)
            row.addView(line)
            return row
        }
    }

    // ---------- nəticə kartları ----------
    inner class CardAdapter : BaseAdapter() {
        private var items: MutableList<Card> = ArrayList()
        fun set(l: List<Card>) { items = ArrayList(l); notifyDataSetChanged() }
        fun rowIds(): List<Long> = items.map { it.rowId }.filter { it >= 0 }
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()
        private fun releaseWebViews(view: View?) {
            if (view == null) return
            if (view is WebView) {
                try {
                    view.stopLoading()
                    view.webViewClient = WebViewClient()
                    (view.parent as? ViewGroup)?.removeView(view)
                    view.destroy()
                } catch (_: Exception) { }
                return
            }
            if (view is ViewGroup) {
                for (i in view.childCount - 1 downTo 0) releaseWebViews(view.getChildAt(i))
            }
        }
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            releaseWebViews(convertView)
            val c = items[position]
            val upd: (List<String>) -> Unit = { nc ->
                if (position < items.size) items[position] = c.copy(cells = nc)
                notifyDataSetChanged()
            }
            val box = LinearLayout(this@BazaActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#0B0B0D")); cornerRadius = dp(16).toFloat(); setStroke(dp(1), Color.parseColor("#232328"))
                }
            }
            if (c.path.isNotEmpty()) box.addView(TextView(this@BazaActivity).apply {
                text = c.path; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.parseColor("#4F8CFF"))
            })
            if (c.title.isNotEmpty()) box.addView(TextView(this@BazaActivity).apply {
                text = c.title; textSize = 13f; setTextColor(Color.parseColor("#B3B3BD")); setPadding(0, 0, 0, dp(4))
            })
            val body = LinearLayout(this@BazaActivity)
            body.orientation = LinearLayout.HORIZONTAL
            val col = LinearLayout(this@BazaActivity)
            col.orientation = LinearLayout.VERTICAL
            for (i in c.headers.indices) {
                val v = c.cells.getOrNull(i).orEmpty().ifEmpty { "—" }
                col.addView(TextView(this@BazaActivity).apply {
                    text = "${c.headers[i]}: $v"; textSize = 16f; setTextColor(Color.parseColor("#F2F2F5"))
                    setTextIsSelectable(true)
                    if (c.rowId >= 0 && i == colIdx(c.headers, "nomre")) {
                        // nömrəyə bir dəfə toxunduqda redaktə pəncərəsi açılır (uzun basma mətni seçməyə davam edir)
                        val gd = android.view.GestureDetector(this@BazaActivity, object : android.view.GestureDetector.SimpleOnGestureListener() {
                            override fun onDown(e: MotionEvent) = true
                            override fun onSingleTapUp(e: MotionEvent): Boolean {
                                catSearch.hideSug()
                                showNumberDialog(c, c.cells.getOrNull(i).orEmpty(), false, upd, null)
                                return true
                            }
                        })
                        setOnTouchListener { _, ev -> gd.onTouchEvent(ev); false }
                    }
                })

            }
            body.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            if (c.rowId >= 0) {
                val ic = LinearLayout(this@BazaActivity)
                ic.orientation = LinearLayout.VERTICAL
                ic.gravity = Gravity.CENTER_VERTICAL
                val smsIcon = IconView(this@BazaActivity, false)
                smsIcon.contentDescription = "Mesaj"
                smsIcon.sent = sentSet.contains(c.skey + "|sms")
                smsIcon.setOnClickListener { sendMsg(c, false) }
                smsIcon.setOnLongClickListener { unmarkSent(c, false); true }
                val waIcon = IconView(this@BazaActivity, true)
                waIcon.contentDescription = "WhatsApp"
                waIcon.sent = sentSet.contains(c.skey + "|wa")
                waIcon.setOnClickListener { sendMsg(c, true, upd) }
                waIcon.setOnLongClickListener { unmarkSent(c, true); true }
                val hasDebt = parseNum(cellOf(c, "borc")) > 0.0   // Borc 0 olanlarda WhatsApp ikonu göstərilmir
                if (hasDebt) {   // Borc 0 olanlarda Mesaj və WhatsApp ikonları göstərilmir
                    ic.addView(smsIcon, LinearLayout.LayoutParams(dp(52), dp(52)).apply { bottomMargin = dp(14) })
                    ic.addView(waIcon, LinearLayout.LayoutParams(dp(52), dp(52)))
                }
                val callIcon = CallIconView(this@BazaActivity)
                callIcon.contentDescription = "Zəng"
                callIcon.setOnClickListener { callCard(c) }
                body.addView(callIcon, LinearLayout.LayoutParams(dp(52), dp(52)).apply { leftMargin = dp(10); rightMargin = dp(10); gravity = Gravity.CENTER_VERTICAL })
                if (hasDebt) body.addView(ic, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(14); gravity = Gravity.CENTER_VERTICAL })
            }
            box.addView(body, LinearLayout.LayoutParams(-1, -2))
            if (c.rowId >= 0) {
                val nrec = notesMap[c.skey]
                if (nrec != null) box.addView(TextView(this@BazaActivity).apply {
                    val over = nrec.remind in 1..System.currentTimeMillis()
                    val sb = android.text.SpannableStringBuilder()
                    if (nrec.note.isNotBlank()) sb.append("📝 " + nrec.note)
                    if (nrec.remind > 0) {
                        if (sb.isNotEmpty()) sb.append("\n")
                        val st = sb.length
                        sb.append("⏰ " + dtFmt.format(java.util.Date(nrec.remind)) + (if (over) "  (vaxtı çatıb)" else ""))
                        sb.setSpan(ForegroundColorSpan(Color.parseColor(if (over) "#FF6B6B" else "#FFB74D")), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    }
                    text = sb; textSize = 14f; setTextColor(Color.parseColor("#FFE0B2"))
                    setPadding(dp(10), dp(8), dp(10), dp(8))
                    background = GradientDrawable().apply { setColor(Color.parseColor("#1F1A10")); cornerRadius = dp(10).toFloat() }
                    setOnClickListener { showNoteDialog(c.skey, noteLabel(c)) }
                }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
                val failReason = failedRows[c.rowId]
                if (failReason != null) box.addView(TextView(this@BazaActivity).apply {
                    text = "⚠ Yenilənmədi: $failReason"; textSize = 14f; typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.parseColor("#FF6B6B")); setPadding(0, dp(8), 0, 0)
                })
                fun cardBtn(label: String, filled: Boolean): TextView = TextView(this@BazaActivity).apply {
                    text = label; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
                    setTextColor(if (filled) Color.WHITE else Color.parseColor("#4F8CFF"))
                    setPadding(dp(8), dp(11), dp(8), dp(11))
                    background = GradientDrawable().apply {
                        setColor(Color.parseColor(if (filled) "#4F8CFF" else "#10141C")); cornerRadius = dp(10).toFloat()
                        setStroke(dp(1), Color.parseColor("#4F8CFF"))
                    }
                }
                val btnRef = cardBtn("🔄  Yenilə", true)
                btnRef.setOnClickListener { refreshOne(c.rowId) }
                val btnEdit = cardBtn("✏️  Redaktə et", false)
                btnEdit.setOnClickListener {
                    showEditDialog(c, { afterRefresh() }) { nc ->
                        if (position < items.size) items[position] = c.copy(cells = nc)
                        notifyDataSetChanged()
                    }
                }
                val btnNote = cardBtn("📝  Qeyd" + (if (notesMap.containsKey(c.skey)) " •" else ""), false)
                btnNote.setOnClickListener { showNoteDialog(c.skey, noteLabel(c)) }
                btnRef.textSize = 14f; btnEdit.textSize = 14f; btnNote.textSize = 14f
                val btns = LinearLayout(this@BazaActivity)
                btns.orientation = LinearLayout.HORIZONTAL
                btns.gravity = Gravity.CENTER_VERTICAL
                btns.setPadding(0, dp(10), 0, 0)
                btns.addView(btnRef, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(4) })
                btns.addView(btnEdit, LinearLayout.LayoutParams(0, -2, 1.2f).apply { leftMargin = dp(4); rightMargin = dp(4) })
                btns.addView(btnNote, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(4) })
                box.addView(btns, LinearLayout.LayoutParams(-1, -2))
            }
            val wrap = FrameLayout(this@BazaActivity).apply {
                setPadding(0, dp(3), 0, dp(3)); layoutParams = AbsListView.LayoutParams(-1, -2)
            }
            wrap.addView(box, FrameLayout.LayoutParams(-1, -2))
            return wrap
        }
    }
}
