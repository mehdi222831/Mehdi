package com.mehdi.keymapper

import android.content.Context
import android.provider.Settings
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

object Adb {
    private lateinit var app: Context
    @Volatile private var client: AdbClient? = null
    private val connExec = Executors.newSingleThreadExecutor()
    private val cmdExec = Executors.newSingleThreadExecutor()
    private val pending = AtomicInteger(0)
    @Volatile var status = "ADB: qoşulmayıb"
    val connected: Boolean get() = client?.alive == true
    @Volatile private var lastServerStart = 0L

    val token: String
        get() {
            val sp = app.getSharedPreferences("adb", Context.MODE_PRIVATE)
            var t = sp.getString("tok", null)
            if (t == null) {
                t = java.util.UUID.randomUUID().toString().replace("-", "")
                sp.edit().putString("tok", t).apply()
            }
            return t!!
        }

    /** (Re)starts the shell-uid input server through ADB. Rate limited. */
    fun startServer() {
        val now = System.currentTimeMillis()
        if (now - lastServerStart < 8000) return
        lastServerStart = now
        val cp = app.applicationInfo.sourceDir
        sh("pkill -f com.mehdi.keymapper.InputServer")
        try { Thread.sleep(200) } catch (e: InterruptedException) {}
        sh("CLASSPATH=$cp nohup app_process /system/bin com.mehdi.keymapper.InputServer $token ${InputClient.PORT} >/dev/null 2>&1 &")
        try { Thread.sleep(800) } catch (e: InterruptedException) {}
    }

    fun ensureServerAsync() {
        connExec.execute {
            try {
                if (!connected) connectBlocking() else synchronized(this) { startServer() }
            } catch (e: Exception) {}
        }
    }

    fun init(c: Context) { if (!::app.isInitialized) app = c.applicationContext }

    fun connectAsync() { connExec.execute { try { connectBlocking() } catch (e: Exception) {} } }

    @Synchronized
    fun connectBlocking(): Boolean {
        if (connected) return true
        val hosts = ArrayList<String>()
        hosts.add("127.0.0.1")
        hosts.addAll(localIps())
        val ports = LinkedHashSet<Int>()
        ports.add(5555)
        propPort()?.let { ports.add(it) }
        var err = ""
        for (h in hosts) for (p in ports) {
            val c = AdbClient(File(app.filesDir, "adb"))
            try {
                status = "ADB: $h:$p qoşulur… (icazə pəncərəsi çıxsa: həmişə icazə ver → OK)"
                c.connect(h, p)
                client = c
                status = "ADB: qoşuldu ($h:$p)"
                postSetup()
                return true
            } catch (e: Exception) {
                err = e.javaClass.simpleName
                c.close()
            }
        }
        status = "ADB: qoşulmadı ($err). 5555 portu açıq olmalıdır"
        return false
    }

    private fun sh(cmd: String): String? = try { client?.shell(cmd) } catch (e: Exception) { null }

    private fun postSetup() {
        val pkg = app.packageName
        sh("pm grant $pkg android.permission.WRITE_SECURE_SETTINGS")
        enableAccessibility()
        startServer()
        sh("dumpsys deviceidle whitelist +$pkg")
        sh("appops set $pkg RUN_IN_BACKGROUND allow")
        sh("appops set $pkg RUN_ANY_IN_BACKGROUND allow")
    }

    fun enableAccessibility(): Boolean {
        val svc = "${app.packageName}/${KeyMapperService::class.java.name}"
        val cr = app.contentResolver
        val cur = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        if (cur.split(":").contains(svc)) return true
        val v = if (cur.isEmpty()) svc else "$cur:$svc"
        try {
            Settings.Secure.putString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, v)
            Settings.Secure.putString(cr, Settings.Secure.ACCESSIBILITY_ENABLED, "1")
            return true
        } catch (e: SecurityException) {}
        if (connected) {
            sh("settings put secure enabled_accessibility_services $v")
            sh("settings put secure accessibility_enabled 1")
            return true
        }
        return false
    }

    /** Queues "input keyevent". Returns false if dropped (droppable key-repeat while busy). */
    fun inputKey(code: Int, droppable: Boolean): Boolean {
        if (droppable && pending.get() > 1) return false
        pending.incrementAndGet()
        cmdExec.execute {
            try {
                if (!connected) connectBlocking()
                client?.shell("input keyevent $code")
            } catch (e: Exception) {
                client?.close()
            } finally {
                pending.decrementAndGet()
            }
        }
        return true
    }

    fun runAsync(cmds: List<String>) {
        cmdExec.execute {
            try {
                if (!connected) connectBlocking()
                cmds.forEach { client?.shell(it) }
            } catch (e: Exception) {
                client?.close()
            }
        }
    }

    private fun localIps(): List<String> {
        val r = ArrayList<String>()
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in ni.inetAddresses) if (a is Inet4Address && !a.isLoopbackAddress) r.add(a.hostAddress ?: continue)
            }
        } catch (e: Exception) {}
        return r
    }

    private fun propPort(): Int? = try {
        val p = Runtime.getRuntime().exec(arrayOf("getprop", "service.adb.tcp.port"))
        p.inputStream.bufferedReader().readText().trim().toIntOrNull()?.takeIf { it in 1..65535 }
    } catch (e: Exception) { null }
}
