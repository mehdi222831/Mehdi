package az.tvlauncher

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.media.tv.TvContract
import android.media.tv.TvInputInfo
import android.media.tv.TvInputManager
import android.net.ConnectivityManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Tile(val label: String, val image: Drawable?, val banner: Boolean, val action: () -> Unit)

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var temp: TextView
    private lateinit var desc: TextView
    private lateinit var details: TextView
    private lateinit var wifi: ImageView
    private lateinit var apps: RecyclerView
    private lateinit var shortcuts: RecyclerView

    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val dateFmt = SimpleDateFormat("EEEE, d MMMM", Locale("az", "AZ"))

    private val ticker = object : Runnable {
        override fun run() {
            val now = Date()
            clock.text = timeFmt.format(now)
            date.text = dateFmt.format(now).replaceFirstChar { it.uppercase() }
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            @Suppress("DEPRECATION")
            wifi.visibility = if (cm.activeNetworkInfo?.isConnected == true) View.VISIBLE else View.INVISIBLE
            h.postDelayed(this, 1000)
        }
    }
    private val weatherLoop = object : Runnable {
        override fun run() {
            loadWeather()
            h.postDelayed(this, 15 * 60_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        clock = findViewById(R.id.clock)
        date = findViewById(R.id.date)
        temp = findViewById(R.id.temp)
        desc = findViewById(R.id.desc)
        details = findViewById(R.id.details)
        wifi = findViewById(R.id.wifi)
        apps = findViewById(R.id.apps)
        shortcuts = findViewById(R.id.shortcuts)
        apps.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        shortcuts.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
    }

    override fun onResume() {
        super.onResume()
        apps.adapter = TileAdapter(appTiles(), R.layout.item_app)
        shortcuts.adapter = TileAdapter(shortcutTiles(), R.layout.item_shortcut)
        h.post(ticker)
        h.post(weatherLoop)
        if (currentFocus == null) apps.post { (apps.getChildAt(0) ?: shortcuts.getChildAt(0))?.requestFocus() }
    }

    override fun onPause() {
        super.onPause()
        h.removeCallbacks(ticker)
        h.removeCallbacks(weatherLoop)
    }

    @Deprecated("Launcher-dən çıxmasın")
    override fun onBackPressed() {}

    private fun launch(i: Intent) {
        try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {}
    }

    private fun appTiles(): List<Tile> {
        val skip = setOf(packageName, "com.android.vending", "com.android.settings", "com.android.tv.settings")
        fun query(cat: String) = packageManager.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(cat), 0
        ).filter { it.activityInfo.packageName !in skip }
        val list = query(Intent.CATEGORY_LEANBACK_LAUNCHER).ifEmpty { query(Intent.CATEGORY_LAUNCHER) }
        return list.sortedBy { it.loadLabel(packageManager).toString().lowercase() }.map { ri ->
            val ai = ri.activityInfo
            val banner = ai.loadBanner(packageManager) ?: ai.applicationInfo.loadBanner(packageManager)
            Tile(ri.loadLabel(packageManager).toString(), banner ?: ri.loadIcon(packageManager), banner != null) {
                launch(Intent(Intent.ACTION_MAIN).setClassName(ai.packageName, ai.name))
            }
        }
    }

    private fun shortcutTiles(): List<Tile> {
        val t = mutableListOf<Tile>()
        t += Tile("Play Store", getDrawable(R.drawable.ic_play), false) {
            (packageManager.getLeanbackLaunchIntentForPackage("com.android.vending")
                ?: packageManager.getLaunchIntentForPackage("com.android.vending"))?.let { launch(it) }
        }
        try {
            val tim = getSystemService(Context.TV_INPUT_SERVICE) as TvInputManager
            tim.tvInputList.filter { it.type == TvInputInfo.TYPE_HDMI }.forEachIndexed { i, info ->
                val name = info.loadCustomLabel(this)?.toString()?.ifBlank { null } ?: "HDMI ${i + 1}"
                t += Tile(name, getDrawable(R.drawable.ic_hdmi), false) {
                    launch(Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput(info.id)))
                }
            }
        } catch (e: Exception) {}
        t += Tile("Settings", getDrawable(R.drawable.ic_settings), false) { launch(Intent(Settings.ACTION_SETTINGS)) }
        return t
    }

    private fun loadWeather() {
        Thread {
            try {
                val url = URL(
                    "https://api.open-meteo.com/v1/forecast?latitude=40.4093&longitude=49.8671" +
                        "&current=temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m,weather_code" +
                        "&wind_speed_unit=ms&timezone=Asia%2FBaku"
                )
                val c = url.openConnection() as HttpURLConnection
                c.connectTimeout = 10000
                c.readTimeout = 10000
                val cur = JSONObject(c.inputStream.bufferedReader().use { it.readText() }).getJSONObject("current")
                val t = Math.round(cur.getDouble("temperature_2m"))
                val feels = Math.round(cur.getDouble("apparent_temperature"))
                val hum = cur.getInt("relative_humidity_2m")
                val wind = cur.getDouble("wind_speed_10m")
                val text = codeText(cur.getInt("weather_code"))
                runOnUiThread {
                    temp.text = "$t°"
                    desc.text = text
                    details.text = "Hiss olunan $feels°\nRütubət $hum%  •  Külək ${"%.1f".format(wind)} m/s"
                }
            } catch (e: Exception) {
                runOnUiThread { if (desc.text.isNullOrEmpty()) desc.text = "Hava məlumatı alınmadı" }
            }
        }.start()
    }

    private fun codeText(c: Int) = when (c) {
        0 -> "Aydın"
        1, 2 -> "Az buludlu"
        3 -> "Buludlu"
        45, 48 -> "Dumanlı"
        in 51..57 -> "Çiskin"
        in 61..67 -> "Yağışlı"
        in 71..77 -> "Qarlı"
        in 80..82 -> "Leysan"
        in 95..99 -> "Tufan"
        else -> "—"
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    inner class TileAdapter(private val items: List<Tile>, private val layout: Int) :
        RecyclerView.Adapter<TileAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val icon: ImageView = v.findViewById(R.id.icon)
            val label: TextView = v.findViewById(R.id.label)
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int) =
            VH(LayoutInflater.from(p.context).inflate(layout, p, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(vh: VH, i: Int) {
            val t = items[i]
            val wide = layout == R.layout.item_app
            vh.icon.setImageDrawable(t.image)
            vh.icon.scaleType = if (t.banner) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.FIT_CENTER
            val pad = if (wide && !t.banner) dp(14) else 0
            vh.icon.setPadding(pad, pad, pad, pad)
            vh.label.text = t.label
            if (wide) vh.label.visibility = View.INVISIBLE
            vh.itemView.setOnClickListener { t.action() }
            vh.itemView.setOnFocusChangeListener { v, f ->
                val s = if (f) 1.1f else 1f
                v.animate().scaleX(s).scaleY(s).setDuration(120).start()
                if (wide) vh.label.visibility = if (f) View.VISIBLE else View.INVISIBLE
            }
        }
    }
}
