package com.mehdi.keymappertv;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

final class ConfigStore {
    static final String PREFS = "keymapper_tv_settings";
    static final String KEY_RULES = "rules_json";
    static final String KEY_LAUNCH_PACKAGE = "launch_package";
    static final String KEY_REPEAT_MS = "repeat_ms";
    static final String KEY_CAPTURE_MODE = "capture_mode";
    static final long DEFAULT_REPEAT_MS = 40L;
    static final long DOUBLE_TAP_MS = 220L;
    static final long LONG_PRESS_MS = 550L;

    private ConfigStore() { }

    static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static List<MappingRule> defaults() {
        List<MappingRule> rules = new ArrayList<>();
        // Android KeyEvent values: BUTTON_7=194, BUTTON_6=193, BUTTON_5=192.
        // DPAD_RIGHT=22, DPAD_LEFT=21, DPAD_CENTER=23.
        rules.add(new MappingRule(194, 22, MappingRule.REPEAT));
        rules.add(new MappingRule(193, 21, MappingRule.REPEAT));
        rules.add(new MappingRule(192, 23, MappingRule.MULTI));
        return rules;
    }

    static List<MappingRule> loadRules(Context context) {
        SharedPreferences p = prefs(context);
        String raw = p.getString(KEY_RULES, null);
        if (raw == null) {
            List<MappingRule> defaults = defaults();
            saveRules(context, defaults);
            return defaults;
        }
        List<MappingRule> result = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o != null) result.add(MappingRule.fromJson(o));
            }
        } catch (JSONException ignored) {
            result = defaults();
            saveRules(context, result);
        }
        return result;
    }

    static void saveRules(Context context, List<MappingRule> rules) {
        JSONArray a = new JSONArray();
        for (MappingRule rule : rules) {
            try { a.put(rule.toJson()); } catch (JSONException ignored) { }
        }
        prefs(context).edit().putString(KEY_RULES, a.toString()).apply();
    }

    static String launchPackage(Context context) {
        return prefs(context).getString(KEY_LAUNCH_PACKAGE, "");
    }

    static long repeatInterval(Context context) {
        return Math.max(20L, Math.min(250L, prefs(context).getLong(KEY_REPEAT_MS, DEFAULT_REPEAT_MS)));
    }
}
