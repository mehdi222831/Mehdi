package az.keymapper;

import android.util.SparseArray;

import java.io.BufferedInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.TimeUnit;

/** Sadə ADB protokol müştərisi (TCP üzərindən, öz-özünə qoşulmaq üçün). */
final class AdbConnection {
    static final int A_CNXN = 0x4e584e43;
    static final int A_AUTH = 0x48545541;
    static final int A_OPEN = 0x4e45504f;
    static final int A_OKAY = 0x59414b4f;
    static final int A_CLSE = 0x45534c43;
    static final int A_WRTE = 0x45545257;

    private static final class Pkt {
        int cmd, a0, a1;
        byte[] data;
    }

    private final Socket sock;
    private final InputStream in;
    private final OutputStream out;
    private final Object wl = new Object();
    private final SparseArray<AdbStream> streams = new SparseArray<>();
    private int nextId = 1;
    volatile boolean alive = true;
    int maxData = 4096;
    String peer = "";

    private AdbConnection(Socket s) throws IOException {
        sock = s;
        in = new BufferedInputStream(s.getInputStream(), 8192);
        out = s.getOutputStream();
    }

    static AdbConnection connect(String host, int port, AdbKey key) throws Exception {
        Socket s = new Socket();
        AdbConnection c = null;
        try {
            s.connect(new InetSocketAddress(host, port), 1500);
            s.setTcpNoDelay(true);
            s.setKeepAlive(true);
            s.setSoTimeout(6000);
            c = new AdbConnection(s);
            c.peer = host + ":" + port;
            c.send(A_CNXN, 0x01000001, 256 * 1024, "host::\u0000".getBytes("UTF-8"));
            boolean signed = false;
            while (true) {
                Pkt p = c.read();
                if (p.cmd == A_CNXN) {
                    c.maxData = p.a1 > 0 ? Math.min(p.a1, 256 * 1024) : 4096;
                    break;
                } else if (p.cmd == A_AUTH && p.a0 == 1) {
                    if (!signed) {
                        c.send(A_AUTH, 2, 0, key.sign(p.data));
                        signed = true;
                    } else {
                        s.setSoTimeout(90000); // TV-də "İcazə ver" pəncərəsini gözləyir
                        c.send(A_AUTH, 3, 0, key.androidPublicKey());
                    }
                } else {
                    throw new IOException("gözlənilməz cavab " + Integer.toHexString(p.cmd));
                }
            }
            s.setSoTimeout(0);
            c.startReader();
            return c;
        } catch (Exception e) {
            try { s.close(); } catch (IOException ignored) { }
            throw e;
        }
    }

    private void startReader() {
        Thread t = new Thread(new Runnable() {
            @Override public void run() { loop(); }
        }, "km-adb-reader");
        t.setDaemon(true);
        t.start();
    }

    private void loop() {
        try {
            while (alive) {
                Pkt p = read();
                switch (p.cmd) {
                    case A_OKAY: {
                        AdbStream s = get(p.a1);
                        if (s != null) {
                            if (s.remoteId == 0) {
                                s.remoteId = p.a0;
                                s.open.countDown();
                            }
                            s.credit.release();
                        }
                        break;
                    }
                    case A_WRTE: {
                        AdbStream s = get(p.a1);
                        send(A_OKAY, p.a1, p.a0, new byte[0]);
                        if (s != null) s.onData(p.data);
                        break;
                    }
                    case A_CLSE: {
                        AdbStream s = remove(p.a1);
                        if (s != null) {
                            boolean wasOpen = s.remoteId != 0 && !s.closed;
                            s.markClosed();
                            if (wasOpen) {
                                try { send(A_CLSE, p.a1, p.a0, new byte[0]); } catch (IOException ignored) { }
                            }
                        }
                        break;
                    }
                    default:
                        break;
                }
            }
        } catch (Exception ignored) {
        }
        shutdown();
    }

    void shutdown() {
        alive = false;
        try { sock.close(); } catch (IOException ignored) { }
        synchronized (streams) {
            for (int i = 0; i < streams.size(); i++) streams.valueAt(i).markClosed();
            streams.clear();
        }
    }

    AdbStream get(int id) {
        synchronized (streams) { return streams.get(id); }
    }

    AdbStream remove(int id) {
        synchronized (streams) {
            AdbStream s = streams.get(id);
            streams.remove(id);
            return s;
        }
    }

    AdbStream open(String service, int ms) {
        AdbStream st;
        int id;
        synchronized (streams) {
            id = nextId++;
            st = new AdbStream(this, id);
            streams.put(id, st);
        }
        try {
            send(A_OPEN, id, 0, (service + "\u0000").getBytes("UTF-8"));
            if (!st.open.await(ms, TimeUnit.MILLISECONDS) || st.remoteId == 0 || st.closed) {
                remove(id);
                return null;
            }
            return st;
        } catch (Exception e) {
            remove(id);
            return null;
        }
    }

    /** Qısa əmri icra edib nəticəni qaytarır. */
    String run(String cmd, int ms) {
        AdbStream s = open("exec:" + cmd, 3000);
        if (s == null) s = open("shell:" + cmd, 3000);
        if (s == null) return null;
        String r = s.waitClosed(ms);
        s.close();
        return r;
    }

    void send(int cmd, int a0, int a1, byte[] data) throws IOException {
        byte[] p = new byte[24 + data.length];
        int sum = 0;
        for (byte b : data) sum += (b & 0xff);
        ByteBuffer b = ByteBuffer.wrap(p).order(ByteOrder.LITTLE_ENDIAN);
        b.putInt(cmd).putInt(a0).putInt(a1).putInt(data.length).putInt(sum).putInt(cmd ^ 0xffffffff);
        System.arraycopy(data, 0, p, 24, data.length);
        synchronized (wl) {
            out.write(p);
            out.flush();
        }
    }

    private Pkt read() throws IOException {
        byte[] h = new byte[24];
        readFully(h);
        ByteBuffer b = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN);
        Pkt p = new Pkt();
        p.cmd = b.getInt();
        p.a0 = b.getInt();
        p.a1 = b.getInt();
        int len = b.getInt();
        b.getInt();
        int magic = b.getInt();
        if (magic != (p.cmd ^ 0xffffffff)) throw new IOException("bad magic");
        if (len < 0 || len > (1 << 20)) throw new IOException("bad length");
        p.data = new byte[len];
        if (len > 0) readFully(p.data);
        return p;
    }

    private void readFully(byte[] b) throws IOException {
        int o = 0;
        while (o < b.length) {
            int r = in.read(b, o, b.length - o);
            if (r < 0) throw new EOFException();
            o += r;
        }
    }
}
