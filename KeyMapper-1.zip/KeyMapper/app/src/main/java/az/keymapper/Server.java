package az.keymapper;

import android.os.SystemClock;
import android.view.InputEvent;
import android.view.KeyEvent;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Method;

/**
 * ADB shell (uid 2000) altında app_process ilə işə düşür və stdin-dən gələn əmrlərlə
 * düymə hadisələrini birbaşa sistemə yeridir. Daimi proses olduğu üçün gecikmə ~0-dır.
 *
 * Protokol (hər sətir):
 *   k <action 0/1> <keycode> <repeat> <flags>
 *   x <shell əmri>
 */
public final class Server {
    private static Object im;
    private static Method inject;
    private static long downTime;

    public static void main(String[] args) {
        try {
            init();
        } catch (Throwable t) {
            inject = null;
        }
        System.out.println(inject != null ? "READY" : "READY fallback");
        System.out.flush();
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(System.in));
            String l;
            while ((l = r.readLine()) != null) {
                try {
                    handle(l.trim());
                } catch (Throwable t) {
                    System.out.println("ERR " + t);
                    System.out.flush();
                }
            }
        } catch (IOException ignored) { }
        System.exit(0);
    }

    private static void init() throws Exception {
        Class<?> cls;
        try {
            cls = Class.forName("android.hardware.input.InputManagerGlobal");
            im = cls.getMethod("getInstance").invoke(null);
        } catch (Throwable t) {
            cls = Class.forName("android.hardware.input.InputManager");
            im = cls.getMethod("getInstance").invoke(null);
        }
        inject = cls.getMethod("injectInputEvent", InputEvent.class, int.class);
    }

    private static void handle(String l) throws Exception {
        if (l.startsWith("k ")) {
            String[] p = l.split(" ");
            key(Integer.parseInt(p[1]), Integer.parseInt(p[2]), Integer.parseInt(p[3]), Integer.parseInt(p[4]));
        } else if (l.startsWith("x ")) {
            exec(l.substring(2));
        }
    }

    private static void key(int action, int code, int repeat, int flags) throws Exception {
        long now = SystemClock.uptimeMillis();
        if (action == 0 && repeat == 0) downTime = now;
        if (inject != null) {
            KeyEvent e = new KeyEvent(downTime, now, action, code, repeat, 0, -1, 0, flags, 0x101);
            inject.invoke(im, e, 0);
        } else if (action == 1) {
            exec("input keyevent " + code);
        }
    }

    private static void exec(String cmd) throws IOException {
        final Process p = new ProcessBuilder("sh", "-c", cmd + " >/dev/null 2>&1").start();
        new Thread(new Runnable() {
            @Override public void run() {
                try { p.waitFor(); } catch (Exception ignored) { }
            }
        }).start();
    }
}
