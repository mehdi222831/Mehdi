package com.mehdi.keymapper;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

/** Tətbiqdən ADB (shell) ilə işə salınmış Server prosesinə gedən sürətli kanal. */
public class Bridge {
    public static final int VERSION = 1;
    public static final int PORT = 47931;

    public static final int CMD_DOWN = 1;
    public static final int CMD_UP = 2;
    public static final int CMD_CLICK = 3;
    public static final int CMD_LONG = 4;
    public static final int CMD_RELEASE_ALL = 5;
    public static final int CMD_QUIT = 100;

    private static volatile Socket sock;
    private static volatile OutputStream out;

    private static final ExecutorService ex = Executors.newSingleThreadExecutor(new ThreadFactory() {
        @Override
        public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "km-bridge");
            t.setDaemon(true);
            t.setPriority(Thread.MAX_PRIORITY);
            return t;
        }
    });

    public static boolean isConnected() {
        Socket s = sock;
        return s != null && s.isConnected() && !s.isClosed();
    }

    private static byte[] frame(int cmd, int key) {
        return new byte[]{(byte) cmd, (byte) (key >>> 24), (byte) (key >>> 16), (byte) (key >>> 8), (byte) key};
    }

    public static synchronized boolean connect(String token) {
        close();
        Socket s = null;
        try {
            s = new Socket();
            s.connect(new InetSocketAddress("127.0.0.1", PORT), 700);
            s.setTcpNoDelay(true);
            s.setSoTimeout(2000);
            DataOutputStream o = new DataOutputStream(s.getOutputStream());
            o.writeUTF(token);
            o.flush();
            int v = new DataInputStream(s.getInputStream()).readInt();
            if (v != VERSION) {
                o.write(frame(CMD_QUIT, 0));
                o.flush();
                s.close();
                return false;
            }
            s.setSoTimeout(0);
            sock = s;
            out = o;
            startReader(s);
            return true;
        } catch (Exception e) {
            try {
                if (s != null) s.close();
            } catch (Exception ignored) {
            }
            return false;
        }
    }

    private static void startReader(final Socket s) {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    InputStream in = s.getInputStream();
                    while (in.read() != -1) {
                    }
                } catch (IOException ignored) {
                } finally {
                    if (sock == s) close();
                }
            }
        }, "km-bridge-reader");
        t.setDaemon(true);
        t.start();
    }

    public static void close() {
        Socket s = sock;
        sock = null;
        out = null;
        try {
            if (s != null) s.close();
        } catch (Exception ignored) {
        }
    }

    public static void send(final int cmd, final int key) {
        ex.execute(new Runnable() {
            @Override
            public void run() {
                OutputStream o = out;
                if (o == null) return;
                try {
                    o.write(frame(cmd, key));
                    o.flush();
                } catch (IOException e) {
                    close();
                }
            }
        });
    }
}
