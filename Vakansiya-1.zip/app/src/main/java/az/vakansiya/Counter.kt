package az.vakansiya

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import org.json.JSONTokener
import java.util.Calendar

/** Saytları gizli brauzerlərdə eyni anda açıb bu gün / dünən yerləşdirilən elanları təxmini sayır. */
class Counter(
    private val ctx: Context,
    private val sites: List<Site>,
    private val onUpdate: (Int) -> Unit,
    private val onDone: () -> Unit,
    private val onPartial: ((Int) -> Unit)? = null
) {
    private val h = Handler(Looper.getMainLooper())
    /** İş siyahısı: hər sayt + (varsa) əlavə səhifələri (məs. Busy.az ?page=2). Əlavə səhifəli saytlarda nəticə birləşdirilir. */
    private val work = ArrayList<Site>()
    private val owner = ArrayList<Int>()
    private val wvs: Array<WebView?>
    private val finished: BooleanArray
    private val started: BooleanArray
    private val pageDone: LongArray
    /** Nömrəli səhifəli saytlarda (Jobing, Jobu) əvvəlki səhifələrin yığılmış nəticəsi. */
    private class PageAcc(val t: Int, val y: Int, val w: Int, val items: List<Hit>, val links: LinkedHashSet<String>, val keys: HashSet<String>)
    private val base: Array<PageAcc?>
    private val pageNo: IntArray
    private val emptyRun: IntArray
    /** Hazırkı səhifədə 2 gündən köhnə elana çatılıb (təsdiqlənib)? Çatılmayıbsa skan BİTMİR. */
    private val oldReached: BooleanArray
    private val cardsBase: IntArray
    private val undatedBase: IntArray
    private val t00 = System.currentTimeMillis()
    private val visited = ArrayList<HashSet<String>>()
    private var left: Int
    var stopped = false

    init {
        sites.forEachIndexed { i, s ->
            val ex = Store.extraPages(s.url)
            if (ex.isEmpty()) { work.add(s); owner.add(i) }
            else {
                work.add(Site(s.name, s.url)); owner.add(i)
                ex.forEach { work.add(Site(s.name, it)); owner.add(i) }
            }
        }
        wvs = arrayOfNulls(work.size)
        finished = BooleanArray(work.size)
        started = BooleanArray(work.size)
        pageDone = LongArray(work.size)
        base = arrayOfNulls(work.size)
        pageNo = IntArray(work.size)
        emptyRun = IntArray(work.size)
        oldReached = BooleanArray(work.size)
        cardsBase = IntArray(work.size)
        undatedBase = IntArray(work.size)
        work.forEach { _ -> visited.add(HashSet()) }
        left = work.size
    }

    /** Əlavə səhifəli saytın hissə nəticələrini əsas sayta toplayır. */
    private fun merge(o: Int) {
        val real = sites[o]
        val parts = work.indices.filter { owner[it] == o && work[it] !== real }.map { work[it] }
        if (parts.isEmpty()) return
        val ok = parts.filter { it.today >= 0 }
        if (ok.isEmpty()) return
        real.today = ok.sumOf { it.today }
        real.yest = ok.sumOf { maxOf(it.yest, 0) }
        real.d2 = if (ok.any { it.d2 >= 0 }) ok.sumOf { maxOf(it.d2, 0) } else -1
        val seen = HashSet<String>()
        real.items = ok.flatMap { it.items }.filter { seen.add(it.key) }
            .sortedWith(compareBy({ it.day }, { if (it.kind == 0) 9 else it.kind }))
        val ls = LinkedHashSet<String>()
        ok.forEach { p -> p.links?.let { ls.addAll(it) } }
        real.links = ls.toList()
        real.cards = ok.sumOf { it.cards }
        real.undated = ok.sumOf { it.undated }
        real.undWhy = ok.flatMap { it.undWhy }.take(4)
        real.page = parts.maxOf { it.page }
        real.status = parts.firstOrNull { it.status.isNotEmpty() && !it.status.startsWith("✔") }?.status
            ?: ("✔ " + parts.size + " səhifə yoxlandı · " + real.cards + " elan oxundu")
    }

    private val sig = arrayOfNulls<String>(work.size)

    /** Yalnız say / elan siyahısı dəyişəndə ekranı yeniləyir (hər 250 ms-də lazımsız yenilənmə olmasın). */
    private fun livePartial(i: Int) {
        val s = work[i]
        val g = "${s.today}|${s.yest}|${s.d2}|${s.items.size}|${s.page}|${s.status}"
        if (sig[i] == g) return
        sig[i] = g
        partial(i)
    }

    private fun partial(i: Int) {
        val o = owner[i]
        if (sites[o] !== work[i]) merge(o)
        onPartial?.invoke(o)
    }

    inner class Bridge(val i: Int) {
        /** Elan tapıldıqca (məs. HRIN-də hər yeni yüklənən səhifədən sonra) ekranda canlı artsın. */
        @JavascriptInterface
        fun part(json: String) {
            h.post {
                if (!stopped && !finished[i]) {
                    try {
                        val o = JSONObject(json)
                        applyRes(i, work[i], o)
                        if (Store.telegram(work[i].url)) {
                            oldReached[i] = o.optInt("o") == 1
                            work[i].status = if (oldReached[i]) "🔎 Köhnə elana çatıldı, təsdiqlənir…" else "⬇ Dərin skan: Telegram yuxarı sürüşdürülür… (${o.optInt("n")} paylaşım oxundu)"
                        }
                        livePartial(i)
                    } catch (e: Exception) { }
                }
            }
        }

        @JavascriptInterface
        fun done(json: String) {
            h.post {
                if (!stopped && !finished[i]) {
                    try {
                        val o = JSONObject(json)
                        applyRes(i, work[i], o)
                        if (Store.telegram(work[i].url)) { oldReached[i] = o.optInt("o") == 1; work[i].cards = maxOf(work[i].cards, o.optInt("n")) }
                    } catch (e: Exception) { }
                    finish(i)
                }
            }
        }
    }

    private fun applyRes(i: Int, site: Site, o: JSONObject) {
        try {
            val t = o.getInt("t")
            val y = o.getInt("y")
            val w = o.optInt("w", -1)
            val items = Hit.parse(o.optJSONArray("s"))
            val arr = o.getJSONArray("l")
            val ls = List(arr.length()) { arr.getString(it) }
            site.cards = cardsBase[i] + o.optInt("n", 0)
            site.undated = undatedBase[i] + o.optInt("u", 0)
            o.optJSONArray("uw")?.let { u -> site.undWhy = List(u.length()) { k -> u.getString(k) } }
            val b = base[i]
            if (b == null) {
                site.today = t; site.yest = y; site.items = items; site.d2 = w; site.links = ls
                return
            }
            // əvvəlki səhifələrin nəticəsi ilə birləşdir; eyni elan iki səhifədə görünsə iki dəfə sayılmasın
            val cnt = intArrayOf(t, y, maxOf(w, 0))
            val add = ArrayList<Hit>()
            for (h in items) { if (h.key in b.keys) { if (h.day in 0..2) cnt[h.day]-- } else add.add(h) }
            site.today = b.t + maxOf(cnt[0], 0)
            site.yest = b.y + maxOf(cnt[1], 0)
            site.d2 = b.w + maxOf(cnt[2], 0)
            site.items = (b.items + add).sortedWith(compareBy({ it.day }, { if (it.kind == 0) 9 else it.kind }))
            site.links = LinkedHashSet<String>().also { s -> s.addAll(b.links); s.addAll(ls) }.toList()
        } catch (e: Exception) { }
    }

    /** Səhifə bitdi: nömrəli səhifəli saytda yeni elan çıxmayana qədər (2 boş səhifə) növbəti səhifə açılır; digər saytlarda bitirilir. */
    private fun end(i: Int, site: Site) {
        // nömrəli saytlarda həmişə, digər saytlarda isə 2 gündən köhnə elana ÇATILMAYIBSA növbəti səhifəyə keçilir
        val more = Store.paged(site.url) || (!oldReached[i] && !site.url.contains("busy.az") && pageNo[i] < 6)
        if (!more || stopped || site.today < 0) { finish(i); return }
        val prev = base[i]
        val total = site.today + maxOf(site.yest, 0) + maxOf(site.d2, 0)
        val newHits = total - (if (prev != null) prev.t + prev.y + prev.w else 0)
        emptyRun[i] = if (newHits <= 0) emptyRun[i] + 1 else 0
        cardsBase[i] = site.cards; undatedBase[i] = site.undated
        site.status = "➡ ${pageNo[i] + 2}-ci səhifə yoxlanılır… (${site.cards} elan oxundu)"
        oldReached[i] = false
        base[i] = PageAcc(site.today, maxOf(site.yest, 0), maxOf(site.d2, 0), site.items, LinkedHashSet(site.links ?: emptyList()), HashSet(site.items.map { it.key }))
        partial(i)
        if (emptyRun[i] >= 2 || pageNo[i] >= 40) { finish(i); return }
        val w = wvs[i] ?: run { finish(i); return }
        w.evaluateJavascript(Scan.nextJs()) { r ->
            if (stopped || finished[i]) return@evaluateJavascript
            var href = ""
            var click = false
            try { val j = JSONObject(JSONTokener(r).nextValue() as String); href = j.optString("h"); click = j.optInt("c") == 1 } catch (e: Exception) { }
            visited[i].add(w.url ?: "")
            if (href.isNotEmpty() && visited[i].add(href)) {
                pageNo[i]++
                site.page = pageNo[i] + 1
                started[i] = false
                w.loadUrl(href)
            } else if (click) {
                pageNo[i]++
                site.page = pageNo[i] + 1
                started[i] = false
                h.postDelayed({
                    if (!stopped && !finished[i] && !started[i]) { started[i] = true; poll(w, i, site, false) }
                }, 3000)
            } else finish(i)
        }
    }

    /** Səhifə hazır olana qədər tez-tez yoxlayır (sabit gözləmə yoxdur): nəticə sabitləşən kimi qəbul edir. */
    private fun poll(v: WebView, i: Int, site: Site, detail: Boolean) {
        val careful = Store.careful(site.url)
        val script = if (detail) "" else Scan.js(ctx, careful, site.url, true)
        val glorri = site.url.contains("glorri.az")
        val jobing = site.url.contains("jobing.az")
        val slow = Store.scrolly(site.url)   // Glorri qaydası: gözlə, aşağı sürüşdür, "daha çox yüklə"
        val firstWait = Store.firstWait(site.url)
        val t0 = System.currentTimeMillis()
        val extra = (if (detail) 10000L else if (glorri) 150000L else if (site.url.contains("iseqebul.az")) 100000L else if (Store.boss(site.url)) 180000L else if (slow) 32000L else if (jobing) 38000L else if (careful) 20000L else 10000L)
        // vaxt limiti səhifənin yüklənmə bitişindən (onPageFinished) hesablanır: erkən başlasaq da, yavaş render olunan saytlar tələsik bitirilməsin
        var ext = 0L
        fun deadline() = maxOf(t0, pageDone[i]) + firstWait + extra + ext
        var same = 0
        var last = ""
        var lastN = 0
        var stag = 0
        fun tick() {
            if (stopped || finished[i]) return
            val late = System.currentTimeMillis() >= deadline()
            if (detail) {
                v.evaluateJavascript(if (Store.telegram(site.url)) "document.querySelectorAll('.tgme_widget_message').length" else "document.querySelectorAll('a[href*=\"/vakansiya-is-elani/\"]').length") { r ->
                    if (stopped || finished[i]) return@evaluateJavascript
                    val n = r?.toIntOrNull() ?: 0
                    if (n > 0 || late) v.evaluateJavascript(Scan.detailScript(ctx, site.url, true), null)
                    else h.postDelayed({ tick() }, 300)
                }
            } else {
                v.evaluateJavascript(script) { r ->
                    if (stopped || finished[i]) return@evaluateJavascript
                    var o: JSONObject? = null
                    try { o = JSONObject(JSONTokener(r).nextValue() as String) } catch (e: Exception) { }
                    val size = o?.getJSONArray("l")?.length() ?: 0
                    // elan səhifəsindən tarixi oxunmaqda olan (tarixsiz) kartlar: bitməzdən əvvəl gözlənilir
                    val pend = o?.optInt("q", 0) ?: 0
                    if (pend > 0 && ext < 150000L) ext += 250L
                    if (slow) {
                        // Glorri: səhifə yavaş-yavaş aşağı sürüşdürülür, saylar canlı yenilənir
                        val g = o?.optInt("g", 0) ?: 0
                        if (o != null && g > 0) {
                            applyRes(i, site, o)
                            val pg = if (pageNo[i] > 0) "${pageNo[i] + 1}-ci səhifə · " else ""
                            site.status = if (g == 2) "🔎 $pg" + "2 gündən köhnə elana çatdı, təsdiqlənir… (${site.cards} elan oxundu)"
                                else "⬇ ${pg}Aşağı sürüşdürülür, yeni elanlar yüklənir… (${site.cards} elan oxundu)"
                            oldReached[i] = g == 2
                            livePartial(i)
                            if (size > lastN) { lastN = size; stag = 0; ext = minOf(ext + 6000L, 150000L) } else stag++
                        } else {
                            site.status = "⏳ Səhifə yüklənir, elanlar gözlənilir…"
                            livePartial(i)
                            if (System.currentTimeMillis() - t0 >= firstWait) stag++
                        }
                        val stagMax = if (Store.boss(site.url) || glorri || jobing || site.url.contains("iseqebul.az") || site.url.contains("jobu.az")) 40 else if (Store.scrollyOld(site.url)) 30 else 60
                        if ((g == 2 && r == last && pend == 0) || (stag >= stagMax && pend == 0) || late) {
                            // son oxunmuş nəticə həmişə tətbiq olunur (az elanlı səhifədə g=0 qalanda köhnə say qalmasın)
                            if (o != null && (site.today < 0 || g == 0)) applyRes(i, site, o)
                            end(i, site)
                        } else { last = r ?: ""; h.postDelayed({ tick() }, 250) }
                        return@evaluateJavascript
                    }
                    val hits = (o?.optInt("t", 0) ?: 0) + (o?.optInt("y", 0) ?: 0) + (o?.optInt("w", 0) ?: 0)
                    if (r == last) same++ else same = 0
                    // elan tapılmayıbsa (səhifə hələ boşdur) daha uzun sabitləşmə gözlənilir
                    val need = if (hits == 0) 8 else 4
                    if (o != null && ((size >= 3 && same >= need && pend == 0) || late)) {
                        applyRes(i, site, o)
                        // nömrəli səhifəli sayt (Busy.az): aşağı sürüşdürmədən növbəti səhifəyə keçilir
                        if (Store.paged(site.url)) end(i, site) else finish(i)
                    } else if (late) finish(i)
                    else {
                        // canlı yenilənmə: yarımçıq nəticə də ekranda dərhal görünsün
                        if (o != null && size >= 1 && r != last) { applyRes(i, site, o); livePartial(i) }
                        last = r ?: ""; h.postDelayed({ tick() }, 150)
                    }
                }
            }
        }
        h.postDelayed({ tick() }, Store.startDelay(site.url))
    }

    /** Uzun çəkən (ağır) saytlar əvvəl başlayır: ümumi skan vaxtı qısalır. */
    private fun startWeight(u: String): Int = Store.weight(u)

    @android.annotation.SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    fun start() {
        if (work.isEmpty()) { onDone(); return }
        work.indices.sortedByDescending { startWeight(work[it].url) }.forEach { i ->
            val site = work[i]
            val detail = Store.detail(site.url)
            val careful = Store.careful(site.url)
            val glorri = site.url.contains("glorri.az")
            val slow = Store.scrolly(site.url)
            val jooble = site.url.contains("jooble")
            val jobing = site.url.contains("jobing.az")
            val w = WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.blockNetworkImage = true
                settings.loadsImagesAutomatically = false
                if (detail) addJavascriptInterface(Bridge(i), "Bridge")
                webChromeClient = object : android.webkit.WebChromeClient() {
                    override fun onProgressChanged(v: WebView, p: Int) {
                        if (p < 90 || stopped || finished[i] || started[i]) return
                        started[i] = true
                        poll(v, i, site, detail)
                    }
                }
                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(v: WebView, req: android.webkit.WebResourceRequest) = Block.intercept(req)
                    override fun onPageFinished(v: WebView, u: String) {
                        pageDone[i] = System.currentTimeMillis()
                        if (stopped || finished[i] || started[i]) return
                        started[i] = true
                        poll(v, i, site, detail)
                    }
                }
            }
            if (slow || Store.telegram(site.url) || site.url.contains("busy.az")) {
                // ekrana bağlı olmayan WebView-a ölçü ver ki, sürüşdürmə/yükləmə işləsin
                w.measure(android.view.View.MeasureSpec.makeMeasureSpec(1080, android.view.View.MeasureSpec.EXACTLY),
                    android.view.View.MeasureSpec.makeMeasureSpec(1920, android.view.View.MeasureSpec.EXACTLY))
                w.layout(0, 0, 1080, 1920)
            }
            wvs[i] = w
            w.loadUrl(Store.scanUrl(site.url))
            // hər sayt üçün ayrıca vaxt limiti
            // nəticə gəlməyibsə bir dəfə yenidən yüklənir, sonra bitirilir
            fun guard() {
                if (stopped || finished[i]) return
                // elanlar hələ yüklənir və 2 gündən köhnə elana çatılmayıb: skan BİTMİR (ən çox 5 dəqiqə)
                if (site.today >= 0 && !oldReached[i] && !Store.telegram(site.url) && !detail && System.currentTimeMillis() - t00 < 300000L) {
                    h.postDelayed({ guard() }, 5000L); return
                }
                if (site.today < 0) {
                    started[i] = false
                    w.loadUrl(Store.scanUrl(site.url))
                    h.postDelayed({ if (!stopped && !finished[i]) finish(i) }, if (Store.paged(site.url)) 60000L else if (detail) (if (Store.telegram(site.url)) 160000L else 65000L) else if (glorri) 150000L else if (site.url.contains("iseqebul.az")) 100000L else if (Store.boss(site.url)) 60000L else if (slow) 40000L else if (jobing) 55000L else if (careful) 40000L else 28000L)
                } else finish(i)
            }
            h.postDelayed({ guard() }, if (Store.paged(site.url)) 1200000L else if (detail) (if (Store.telegram(site.url)) 160000L else 65000L) else if (glorri) 160000L else if (site.url.contains("iseqebul.az")) 110000L else if (Store.boss(site.url)) 190000L else if (slow) 50000L else if (jooble) 32000L else if (jobing) 50000L else if (careful) 32000L else 20000L)
        }
    }

    private fun finish(i: Int) {
        if (finished[i]) return
        finished[i] = true
        work[i].page = 0
        val ws = work[i]
        if (ws.cards > 0) {
            var txt = "✔ Skan bitdi: " + ws.cards + " elan oxundu"
            if (pageNo[i] > 0) txt += " · " + (pageNo[i] + 1) + " səhifə"
            if (oldReached[i]) txt += " · köhnə elana çatıldı"
            ws.status = txt
        } else if (ws.today >= 0) {
            ws.status = "✔ Skan bitdi"
        }
        try { wvs[i]?.destroy() } catch (e: Exception) { }
        val o = owner[i]
        if (sites[o] !== work[i]) merge(o)
        if (work.indices.all { owner[it] != o || finished[it] }) onUpdate(o) else onPartial?.invoke(o)
        left--
        if (left == 0 && !stopped) onDone()
    }

    fun stop() {
        stopped = true
        h.removeCallbacksAndMessages(null)
        wvs.forEachIndexed { i, w ->
            if (w != null && !finished[i]) { finished[i] = true; try { w.destroy() } catch (e: Exception) { } }
        }
    }
}
