package az.keymapper;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.provider.Settings;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** ADB-yə qoşulma, server prosesinin işə salınması və nəzarət (watchdog). */
final class Core {
    static volatile Context app;
    static volatile AdbConnection conn;
    static volatile AdbStream server;
    static volatile String status = "Başlayır…";
    private static Thread th;

    static synchronized void start(Context c) {
        app = c.getApplicationContext();
        Prefs.load(app);
        if (th != null && th.isAlive()) return;
        th = new Thread(new Runnable() {
            @Override public void run() { loop(); }
        }, "km-core");
        th.setDaemon(true);
        th.start();
    }

    static boolean ready() {
        AdbStream s = server;
        AdbConnection c = conn;
        return s != null && !s.closed && c != null && c.alive;
    }

    static void kick() {
        reset();
        Thread t = th;
        if (t != null) t.interrupt();
    }

    private static synchronized void reset() {
        AdbStream s = server;
        AdbConnection c = conn;
        server = null;
        conn = null;
        try { if (s != null) s.close(); } catch (Throwable ignored) { }
        try { if (c != null) c.shutdown(); } catch (Throwable ignored) { }
    }

    private static void loop() {
        int tick = 0;
        while (true) {
            try {
                if (!ready()) {
                    connectAll();
                } else if (++tick % 3 == 0) {
                    ensureAccessibility();
                }
                Thread.sleep(ready() ? 4000 : 3000);
            } catch (InterruptedException ignored) {
            } catch (Throwable t) {
                status = "Xəta: " + t;
                reset();
                try { Thread.sleep(3000); } catch (InterruptedException ignored) { }
            }
        }
    }

    private static void connectAll() throws Exception {
        reset();
        status = "ADB-yə qoşulur…";
        AdbKey key = AdbKey.get(app);
        List<Integer> ports = ports();
        List<String> hosts = hosts();
        AdbConnection c = null;
        for (int port : ports) {
            for (String h : hosts) {
                try {
                    status = "Qoşulur: " + h + ":" + port + "  (TV-də icazə pəncərəsi çıxsa «Həmişə icazə ver» seçin)";
                    c = AdbConnection.connect(h, port, key);
                    break;
                } catch (Exception ignored) { }
            }
            if (c != null) break;
        }
        if (c == null) {
            status = "ADB tapılmadı (127.0.0.1 və öz IP, port 5555). Developer options-da USB debugging / ADB over network açın.";
            return;
        }
        conn = c;
        String pkg = app.getPackageName();
        c.run("dumpsys deviceidle whitelist +" + pkg, 3000);
        c.run("cmd appops set " + pkg + " RUN_IN_BACKGROUND allow", 3000);
        c.run("cmd appops set " + pkg + " SYSTEM_ALERT_WINDOW allow", 3000);
        ensureAccessibility();

        String cmd = "CLASSPATH=" + app.getPackageCodePath() + " exec app_process /system/bin az.keymapper.Server";
        AdbStream s = c.open("exec:" + cmd, 4000);
        if (s == null) s = c.open("shell:" + cmd, 4000);
        if (s == null) {
            status = "Server prosesi açıla bilmədi";
            return;
        }
        if (!s.waitFor("READY", 7000)) {
            status = "Server cavab vermir: " + s.text();
            s.close();
            return;
        }
        server = s;
        status = "Hazırdır ✓  (" + c.peer + ")" + (s.text().contains("fallback") ? "  [ehtiyat rejim]" : "");
    }

    static void ensureAccessibility() {
        try {
            String cn = new ComponentName(app, KeyService.class).flattenToString();
            String cur = Settings.Secure.getString(app.getContentResolver(), "enabled_accessibility_services");
            int on = Settings.Secure.getInt(app.getContentResolver(), "accessibility_enabled", 0);
            if (cur != null && cur.contains(cn) && on == 1) return;
            AdbConnection c = conn;
            if (c == null) return;
            String s = (cur == null || cur.equals("null")) ? "" : cur;
            String nv = s.contains(cn) ? s : (s.isEmpty() ? cn : s + ":" + cn);
            c.run("settings put secure enabled_accessibility_services " + nv, 4000);
            c.run("settings put secure accessibility_enabled 1", 4000);
        } catch (Throwable ignored) { }
    }

    static void launch(String pkg) {
        try {
            PackageManager pm = app.getPackageManager();
            Intent in = pm.getLeanbackLaunchIntentForPackage(pkg);
            if (in == null) in = pm.getLaunchIntentForPackage(pkg);
            if (in == null) return;
            ComponentName cn = in.getComponent();
            if (ready() && cn != null) {
                Injector.exec("am start -n '" + cn.flattenToShortString() + "' -a android.intent.action.MAIN");
            } else {
                in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                app.startActivity(in);
            }
        } catch (Throwable ignored) { }
    }

    private static List<Integer> ports() {
        List<Integer> l = new ArrayList<>();
        int p = prop("service.adb.tcp.port");
        if (p <= 0) p = prop("persist.adb.tcp.port");
        if (p > 0) l.add(p);
        if (!l.contains(5555)) l.add(5555);
        return l;
    }

    private static int prop(String name) {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"getprop", name});
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String s = r.readLine();
            p.waitFor();
            if (s != null && s.trim().matches("\\d+")) return Integer.parseInt(s.trim());
        } catch (Throwable ignored) { }
        return 0;
    }

    private static List<String> hosts() {
        List<String> l = new ArrayList<>();
        l.add("127.0.0.1");
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) l.add(a.getHostAddress());
                }
            }
        } catch (Throwable ignored) { }
        return l;
    }
}
