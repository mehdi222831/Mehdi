package az.yvok.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Locale;

/**
 * Üçüncü yoxlama mənbəyi: gpp.yelo.az (Yelo.az "search-to-pay").
 * HesabChecker ilə eyni qaydada işləyir: gizli səhifələr, növbə, callback-lər UI axınında çağırılır.
 * Ödəyən -> Ad Soyad Ata adı; Məbləğ (AZN) -> Borc (mənfi dəyər 0 sayılır).
 */
public class YeloChecker {
    public interface Callback {
        void onResult(String name, String debt);
        void onFail();                                  // sayt cavab vermədi (açılmadı / vaxt bitdi)
        default void onNotFound() { onFail(); }         // sayt cavab verdi, lakin "tapılmadı" dedi (cavab verməməkdən fərqli)
    }

    private static final String URL = "https://gpp.yelo.az/search-to-pay/db6ed060-63f2-4085-88eb-c2f8fdb05b40";
    private static final int FIRST_POLL_MS = 250;
    private static final int WARM_FIRST_POLL_MS = 30;   // səhifə əvvəlcədən açılıbsa ilk yoxlama dərhal
    private static final long WARM_STALE_MS = 15000;    // hazır səhifə bu qədər gözləyibsə "köhnə ola bilər" sayılır
    private static final long WARM_STALL_MS = 3000;     // köhnə ola bilən hazır səhifə bu müddətdə işə düşməsə bir dəfə təzələnir
    private static final int POLL_MS = 80;
    private static final int MAX_JOBS_PER_VIEW = 12;   // bu qədər sorğudan sonra gizli səhifə təzələnir

    private static class Req {
        final String code; final Callback cb;
        Req(String code, Callback cb) { this.code = code; this.cb = cb; }
    }

    private class Slot {
        WebView wv; Req cur; int session = 0; int jobs = 0; long startedAt = 0; int nfHits = 0; long readyAt = 0; boolean suspect = false, reloaded = false;
    }

    private final Activity act;
    private final FrameLayout host;
    private final int index, width, height;
    private int maxParallel;
    private long maxWaitMs = 30000;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final ArrayDeque<Req> queue = new ArrayDeque<>();
    private final ArrayList<Slot> slots = new ArrayList<>();
    private final String js;
    private boolean destroyed = false;
    private boolean armed = false;     // YVÖK xanasına toxunuşdan sonra true: səhifələr arxada hazır saxlanılır

    public YeloChecker(Activity act, FrameLayout host, int index, int width, int height, int maxParallel) {
        this.act = act; this.host = host; this.index = index; this.width = width; this.height = height;
        this.maxParallel = Math.max(1, maxParallel);
        this.js = readAsset("yelo.js");
    }

    private String readAsset(String name) {
        try (InputStream in = act.getAssets().open(name)) {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] b = new byte[4096]; int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            return bo.toString("UTF-8");
        } catch (Exception e) { return "''"; }
    }

    /** nəticə gözləmə həddi: bu müddətdə cavab gəlmirsə onFail() çağırılır */
    public void setMaxWait(long ms) { maxWaitMs = Math.max(5000, ms); }

    /** növbədə gözləyən + hazırda işləyən sorğu sayı (yük bölüşdürmək üçün) */
    public int load() {
        int n = queue.size();
        for (Slot s : slots) if (s.cur != null) n++;
        return n;
    }

    public void check(String code, Callback cb) {
        if (destroyed) { cb.onFail(); return; }
        queue.addLast(new Req(code, cb));
        pump();
    }

    /** növbəni və işləyənləri ləğv edir (callback çağırılmır) */
    public void clear() {
        queue.clear();
        for (Slot s : new ArrayList<>(slots)) {
            if (s.cur == null) continue;                    // boş (hazır) səhifəyə toxunulmur
            s.session++; s.cur = null; s.readyAt = 0;       // işlənmiş səhifə çirklidir: təkrar istifadə olunmur
            try { s.wv.stopLoading(); } catch (Exception ignored) { }
            if (armed) rewarm(s);                           // növbəti kod üçün arxada təzəsi hazırlanır
        }
    }

    /**
     * YVÖK xanasına toxunanda çağırılır. İlk toxunuşdan sonra rejim aktiv olur: səhifə öncədən yüklənir,
     * bağlanmır və vaxtla köhnəlmir; hər istifadədən sonra növbəti kod üçün arxada təzəsi yüklənir.
     */
    public void warmUp() {
        if (destroyed) return;
        armed = true;
        for (Slot x : slots) if (x.cur == null && x.readyAt > 0) return;   // hazır səhifə artıq var
        Slot s = null;
        for (Slot x : slots) if (x.cur == null) { s = x; break; }
        if (s == null) {
            if (slots.size() >= maxParallel) return;        // hamısı məşğuldur: iş bitəndə finish() təzəsini hazırlayacaq
            s = newSlot();
        }
        rewarm(s);
    }

    /** boş səhifəni saytın başlanğıcına yükləyib "hazır" işarələyir (gözləyir, bağlanmır) */
    private void rewarm(Slot s) {
        if (destroyed) return;
        if (s.jobs >= MAX_JOBS_PER_VIEW) {                  // köhnə səhifə yaddaşı doldurmasın: təzəsi ilə əvəz olunur
            slots.remove(s); destroyView(s);
            s = newSlot();
        }
        s.session++; s.cur = null; s.reloaded = false; s.suspect = false;
        s.wv.stopLoading();
        s.wv.loadUrl(URL);
        s.readyAt = android.os.SystemClock.elapsedRealtime();
    }

    public void destroy() {
        destroyed = true;
        queue.clear();
        h.removeCallbacksAndMessages(null);
        for (Slot s : slots) destroyView(s);
        slots.clear();
    }

    private void destroyView(Slot s) {
        try { s.wv.stopLoading(); host.removeView(s.wv); s.wv.destroy(); } catch (Exception ignored) { }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private Slot newSlot() {
        final Slot s = new Slot();
        WebView wv = new WebView(act);
        wv.setFocusable(false);
        wv.setFocusableInTouchMode(false);
        wv.getSettings().setJavaScriptEnabled(true);
        wv.getSettings().setDomStorageEnabled(true);
        wv.getSettings().setLoadsImagesAutomatically(false);
        wv.getSettings().setBlockNetworkImage(true);
        wv.getSettings().setMediaPlaybackRequiresUserGesture(true);
        wv.getSettings().setSupportMultipleWindows(false);
        wv.getSettings().setGeolocationEnabled(false);
        wv.getSettings().setUseWideViewPort(true);
        wv.getSettings().setLoadWithOverviewMode(true);
        wv.setAlpha(0.01f);
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) { return SiteBlocker.intercept(r); }
        });
        host.addView(wv, index, new FrameLayout.LayoutParams(width, height));
        s.wv = wv;
        slots.add(s);
        return s;
    }

    private void pump() {
        while (!queue.isEmpty() && !destroyed) {
            Slot s = null;
            for (Slot x : slots) if (x.cur == null) { s = x; break; }
            if (s == null && slots.size() < maxParallel) s = newSlot();
            if (s == null) return;
            start(s, queue.pollFirst());
        }
    }

    private void start(final Slot s, final Req r) {
        if (s.jobs >= MAX_JOBS_PER_VIEW) {
            slots.remove(s); destroyView(s);
            start(newSlot(), r);
            return;
        }
        s.jobs++;
        s.cur = r; s.nfHits = 0; s.startedAt = android.os.SystemClock.elapsedRealtime();
        final boolean warm = s.readyAt > 0;                                            // öncədən açılmış təmiz səhifə
        s.suspect = warm && s.startedAt - s.readyAt >= WARM_STALE_MS;                  // uzun gözləyib: işləməyə bilər
        s.reloaded = false;
        s.readyAt = 0;
        final int ses = ++s.session;
        if (!warm) {
            s.wv.stopLoading();
            s.wv.loadUrl(URL);                          // əks halda səhifə təzədən açılır (təmiz vəziyyət)
        }
        h.postDelayed(() -> poll(s, ses, r.code), warm ? WARM_FIRST_POLL_MS : FIRST_POLL_MS);
    }

    private void poll(final Slot s, final int ses, final String code) {
        if (s.session != ses || destroyed) return;
        s.wv.evaluateJavascript(js.replace("__CODE__", code.replace("'", "")), raw -> {
            if (s.session != ses || destroyed) return;
            String payer = "", yvok = "", amount = "", st = ""; boolean nf = false;
            try {
                Object v = new JSONTokener(raw == null ? "null" : raw).nextValue();
                if (v instanceof String) {
                    JSONObject o = new JSONObject((String) v);
                    payer = o.optString("payer").trim();
                    yvok = o.optString("yvok").trim();
                    amount = o.optString("amount").trim();
                    nf = o.optBoolean("nf");
                    st = o.optString("st");
                }
            } catch (Exception ignored) { }
            final Req r = s.cur;
            if (r == null) return;
            boolean yvokOk = yvok.isEmpty() || yvok.replaceAll("\\s", "").toUpperCase(Locale.ROOT).contains(r.code.toUpperCase(Locale.ROOT));
            if (!payer.isEmpty() && !amount.isEmpty() && yvokOk) {
                String debt = debtFromAmount(amount);
                if (debt != null) { finish(s, r, payer.replaceAll("\\s+", " "), debt); return; }
            }
            // uzun gözləmiş hazır səhifə işə düşmürsə (sayt sessiyası bitib / yüklənməyib) bir dəfə təzədən açılır
            if (s.suspect && !s.reloaded && "wait".equals(st)
                    && android.os.SystemClock.elapsedRealtime() - s.startedAt >= WARM_STALL_MS) {
                s.reloaded = true; s.wv.stopLoading(); s.wv.loadUrl(URL);
            }
            if (nf) { if (++s.nfHits >= 3) { finish(s, r, null, null, true); return; } } else s.nfHits = 0;
            if (android.os.SystemClock.elapsedRealtime() - s.startedAt >= maxWaitMs) {
                finish(s, r, null, null);
            } else {
                h.postDelayed(() -> poll(s, ses, code), POLL_MS);
            }
        });
    }

    private void finish(Slot s, Req r, String name, String debt) { finish(s, r, name, debt, false); }

    private void finish(Slot s, Req r, String name, String debt, boolean notFound) {
        s.session++; s.cur = null;
        if (name != null) r.cb.onResult(name, debt); else if (notFound) r.cb.onNotFound(); else r.cb.onFail();
        pump();
        if (armed && s.cur == null && s.readyAt == 0 && slots.contains(s)) rewarm(s);   // növbəti kod üçün arxada təzə səhifə
    }

    /** Məbləğ -> Borc: mənfi 0 sayılır; tam ədəd olanda kəsrsiz */
    static String debtFromAmount(String amount) {
        try {
            double d = Double.parseDouble(amount.trim().replace(',', '.'));
            if (d < 0) d = 0;
            if (d == Math.floor(d)) return String.valueOf((long) d);
            return String.format(Locale.US, "%.2f", d);
        } catch (Exception e) { return null; }
    }
}
