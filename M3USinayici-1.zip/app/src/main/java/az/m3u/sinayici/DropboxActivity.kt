package az.m3u.sinayici

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File

/**
 * Dropbox hesabını (dropbox.com/home) tətbiqin içində açır.
 * Saytda "Upload / Yüklə" basılanda fayl seçimində YALNIZ ixrac olunan fayl təklif olunur.
 * Giriş (cookie) saxlanılır, ona görə hər dəfə yenidən daxil olmaq lazım deyil.
 */
class DropboxActivity : Activity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val file = File(intent.getStringExtra("path") ?: "")
        val name = intent.getStringExtra("name") ?: file.name
        val dp = resources.displayMetrics.density

        val sbId = resources.getIdentifier("status_bar_height", "dimen", "android")
        val sb = if (sbId > 0) resources.getDimensionPixelSize(sbId) else (24 * dp).toInt()

        val close = TextView(this).apply {
            text = "✕"; setTextColor(Color.WHITE); textSize = 20f; gravity = Gravity.CENTER
            setOnClickListener { finish() }
        }
        val info = TextView(this).apply {
            text = "📦 Dropbox · yüklənəcək fayl: $name"
            setTextColor(Color.WHITE); textSize = 13f
            setPadding((8 * dp).toInt(), 0, (8 * dp).toInt(), 0)
            gravity = Gravity.CENTER_VERTICAL
            maxLines = 2
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#1B1B1B"))
            gravity = Gravity.CENTER_VERTICAL
            addView(close, LinearLayout.LayoutParams((48 * dp).toInt(), (48 * dp).toInt()))
            addView(info, LinearLayout.LayoutParams(0, (48 * dp).toInt(), 1f))
        }

        web = WebView(this)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            javaScriptCanOpenWindowsAutomatically = false
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val s = r.url.scheme ?: ""
                return !(s == "http" || s == "https")
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView?, cb: ValueCallback<Array<Uri>>?, p: FileChooserParams?): Boolean {
                chooser?.onReceiveValue(null)
                chooser = cb
                if (!file.exists()) {
                    AlertDialog.Builder(this@DropboxActivity).setMessage("İxrac faylı tapılmadı. Əvvəlcə «İxrac et» düyməsinə basın.")
                        .setPositiveButton("OK", null).show()
                    finishChooser(null)
                    return true
                }
                val kb = (file.length() + 1023) / 1024
                AlertDialog.Builder(this@DropboxActivity)
                    .setTitle("Fayl seçin")
                    .setItems(arrayOf("📄 $name  ($kb KB)")) { _, _ -> finishChooser(arrayOf(Uri.fromFile(file))) }
                    .setOnCancelListener { finishChooser(null) }
                    .show()
                return true
            }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding(0, sb, 0, 0)
            addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        setContentView(root)
        web.loadUrl("https://www.dropbox.com/home")
    }

    private fun finishChooser(v: Array<Uri>?) {
        chooser?.onReceiveValue(v)
        chooser = null
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        finishChooser(null)
        try { web.destroy() } catch (e: Exception) { }
        super.onDestroy()
    }
}
