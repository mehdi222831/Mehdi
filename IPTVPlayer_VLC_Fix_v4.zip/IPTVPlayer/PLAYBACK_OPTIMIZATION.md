# Oynatma konfiqurasiyası (2 GB RAM TV box)

## Pleyer ardıcıllığı (aktual)
**Yeni kanal (15 s):** ExoPlayer (Media3) 5 s → VLC 5 s → ExoPlayer 5 s. Hansı açsa, o yadda saxlanılır (`player_memory_v3`: `vlc` / `exo`). Yadda `vlc` qalıbsa ardıcıllıq VLC → Media3 → VLC olur. Hamısı açmasa "Kanal İşləmir" (və ya ehtiyat link prosesi).

**İşləyən kanal buferdə qalsa:** bufer/donma 5 s-dən uzun çəkərsə → VLC 5 s → ExoPlayer 5 s; hansı açsa yadda saxlanılır.

**Media3 ilə işləyən kanal:** bufer/donma olsa VLC-yə keçid olmur, yalnız Media3 yenidən qoşulur.

rtmp, udp, srt kimi Media3-ün oxuya bilmədiyi protokollar yalnız VLC ilə açılır.

> Aşağıdakı köhnə təsvirlər (VLC → codec yoxlaması → Media3) artıq tətbiq olunmur.

## Pleyer ardıcıllığı
1. Yayım **əvvəl VLC ilə** açılır (6 s).
2. VLC oynamağa başlayan kimi Media3 arxa planda **səssiz və dekodersiz** açılıb video/audio codec-lərinin cihazda dəstəklənib-dəstəklənmədiyini yoxlayır (3 s). Heç bir codec problemi yoxdursa VLC dayandırılır və yayım **Media3**-də davam edir.
3. Codec problemi varsa (və ya Media3 yayımı açmırsa) VLC ilə qalınır və bu seçim yadda saxlanır.
4. VLC yayımı aça bilmirsə (xəta/6 s) → yayım **Media3**-ə verilir (4 s). Media3 də açmasa xəta göstərilir.
5. Media3-ə keçiddən sonra o açılmasa/xəta versə, yenidən VLC-yə qayıdılır və yoxlama təkrarlanmır.
- Media3-ün oxuya bilmədiyi protokollar (rtmp, udp, srt...) yalnız VLC ilə açılır.
- Yoxlama zamanı yayım qısa müddət iki dəfə endirilir (VLC + Media3).

## Bufer (saniyə)
- Media3: min 10 s, max 20 s, başlamaq 2.5 s, təkrar buferdən sonra 4 s, ölçü limiti 24 MB, geriyə bufer yox, maksimum 1080p / 30 kadr (yalnız 4K varsa o açılır), OkHttp: HTTP/1.1, hovuz 2 bağlantı, eyni anda ən çox 8 sorğu (host başına 4), connect timeout 6 s, read timeout 10 s, ekran ölçüsündən böyük variant seçilmir. Canlı yayım: hədəf gecikmə yayımın öz siyahısından götürülür (HLS-də adətən 3 seqment), oxutma sürəti həmişə 1.0x (sürət dəyişmir). Asinxron MediaCodec növbəsi məcbur edilmir (köhnə Android-də ilişmə yarada bilir). MPEG-TS üçün IDR olmayan açar kadrlar və kadr sərhədinin avtomatik tapılması açıqdır.
- VLC: network-caching / live-caching 4 s, file-caching 1 s, dekoder thread sayı avtomatik (bütün nüvələr), `--no-avcodec-fast`, `--avcodec-skiploopfilter=0`, `--no-skip-frames`, `--deinterlace=-1` (cores>=6 yadif, əks halda linear), standart ekran formatı (RV16 yox), audio time-stretch açıq, `--rtsp-tcp`, adaptiv yayımda maksimum 1920x1080, `--no-spu`, `--no-osd`, `--no-snapshot-preview`. `--no-stats`.

## Yaddaş
- libVLC yalnız Media3 açmayanda yaradılır; Media3 20 s işləyirsə VLC yaddaşdan boşaldılır.
- Eyni anda yalnız bir video səthi görünür.

Video həmişə tam ekran uzadılır.

## Bütün stream linkləri
- http/https (m3u8, ts, mp4, mpd, ism və genişlənməsiz linklər), rtsp → əvvəl VLC, codec problemi yoxdursa Media3-ə keçid; VLC açmasa Media3.
- rtmp, rtmps, mms, mmsh, rtp, udp, srt, rist və s. → birbaşa VLC.
- `.m3u8`/`.mpd` linkdə harada olsa (sorğu hissəsində də) HLS/DASH kimi tanınır.
- Media3 HTTP: yönləndirmələr (http↔https), vaxtı keçmiş/özü imzalı sertifikat qəbul edilir, standart User-Agent `VLC/3.0.20`; kanalın öz User-Agent və Referer-i varsa o işlədilir.

## Pleyer yaddaşı
Kanal linki (SHA-1) → `exo` və ya `vlc`, `SharedPreferences("player_memory_v3")`-də saxlanılır. `exo` yadda qalıbsa kanal birbaşa Media3 ilə açılır (VLC gözlənilmir), açmasa VLC; `vlc` yadda qalıbsa kanal VLC ilə açılır və Media3 yoxlaması aparılmır.

## Bufer və stretch
- Bufer limitə çatanda yükləmə dayanır, geriyə bufer saxlanmır (yaddaş avtomatik boşalır). Gecikmə yığılarsa, sürət dəyişdirilmir; pleyer canlı pəncərədən geri qalarsa kanal canlı nöqtəyə qayıdır.
- Video həmişə stretch: Media3-də `VIDEO_SCALING_MODE_SCALE_TO_FIT`, VLC-də görüntü nisbəti səthin nisbətinə bərabər edilir (`setAspectRatio("W:H")` + `setScale(0)`); hər açılışda və video ölçüsü dəyişəndə yenidən tətbiq olunur.

## Avtomatik bərpa (davamlı izləmə)
- Yayım işləyərkən qırılsa (xəta, yayım bitdi) kanal 0.5 s sonra eyni pleyerlə avtomatik yenidən qoşulur.
- Bufer 6 s dolmursa və ya görüntü (oynatma mövqeyi) 6 s donursa, yenə avtomatik yenidən qoşulur.
- Donma/qırılma eyni pleyerlə yenidən qoşulma ilə həll olunur, pleyer dəyişmir.
- Kanal əvvəl işləyibsə, hər iki pleyer açmayanda belə hər 3 s-dən bir avtomatik təkrar yoxlanılır (xəta mesajı göstərilmir).
- İstifadəçi pauza edibsə, bərpa işləmir.

## Pleyer işarəsi
EPG-nin sağında üstdə Media3 üçün 💙, VLC üçün 🧡, yanında ölçü, altında bufer (🟢🟡🔴) • endirmə sürəti • bitrate yazılır.



## Bufer
Bufer idarəsi Media3 və VLC-nin özünə həvalə olunub (əlavə təzələmə və ya xüsusi bufer seçimi yoxdur). Yalnız şəbəkə buferi VLC-də 3 s, Media3-də yuxarıda göstərilən limitlərdir.

## Playlist linki dəyişəndə
Pleyer yaddaşı linkə görə saxlanır, ona görə dəyişmiş link yeni sayılır və həmişə VLC → (codec yoxlaması) → Media3 ardıcıllığı ilə açılır (rtmp/udp kimi Media3-ün oxuya bilmədiyi protokollar birbaşa VLC ilə). Playlist yüklənəndə siyahıda olmayan köhnə linklərin yaddaşı silinir. İzlənən kanalın linki yeni playlistdə dəyişibsə, kanal yeni linklə avtomatik yenidən açılır.

## Son kanal
Son izlənən kanal link, ad, qrup və tvg-id ilə saxlanılır. Playlistdə linki dəyişsə də, tətbiq yenidən açılanda həmin kanal ad/qrup və ya tvg-id ilə tapılıb açılır.

## VLC donma bərpası (yeni)
- Təkrar qoşulma gecikməsi 0: donma/bufer aşkarlandığı anda (eyni döngədə) VLC yenidən başladılır, heç nə gözlənmir.
- VLC-də bufer/donma aşkarı 3 s, "səs var, görüntü donub" aşkarı 2,5 s. Hər iki sayğac (göstərilən və dekodlanan kadr) ayrıca izlənir.
- Təkrar cəhddə bufer TAM boşaldılır: stop() + media ayrılır (media=null) + video səthi ayrılıb yenidən qoşulur, sonra yeni Media açılır. İki dəfə donubsa proqram dekoderinə keçilir.
- Əvvəl işləmiş kanalın təkrar cəhdində yükləmə paneli dərhal çıxmır (son kadr ekranda qalır); yalnız 3,5 s-dən uzun çəkərsə görünür.

- Yeniləmə: VLC-də donma/bufer aşkarı gözləmə olmadan (0 s); təkrar cəhddə pleyer və libVLC tam boşaldılıb yenidən yaradılır, bufer sıfırdan toplanır.

- Hər yeni kanala keçiddə VLC (pleyer + libVLC) yaddaşdan tam boşaldılır; kanal VLC ilə açılacaqsa təzədən yaradılır.
