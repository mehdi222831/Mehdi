package az.keymapper;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

final class Injector {
    private static final ExecutorService IO = Executors.newSingleThreadExecutor(new ThreadFactory() {
        @Override public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "km-io");
            t.setPriority(Thread.MAX_PRIORITY);
            t.setDaemon(true);
            return t;
        }
    });

    static void key(int action, int code, int repeat, int flags) {
        send("k " + action + " " + code + " " + repeat + " " + flags + "\n");
    }

    static void tap(int code) {
        key(0, code, 0, 0);
        key(1, code, 0, 0);
    }

    static void exec(String cmd) {
        send("x " + cmd.replace('\n', ' ') + "\n");
    }

    private static void send(final String s) {
        IO.execute(new Runnable() {
            @Override public void run() {
                AdbStream st = Core.server;
                if (st == null || st.closed) return;
                try {
                    st.write(s.getBytes("UTF-8"));
                } catch (IOException e) {
                    Core.kick();
                }
            }
        });
    }
}
