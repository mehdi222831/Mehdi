package az.axtaris.baza

import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.Locale

/**
 * Baza açıq olmayanda da (məs. «Whatsapp ilə göndər»dən sonra yeni YVÖK / nömrə əlavə olunanda)
 * dəyişiklikləri Supabase-ə avtomatik yükləyir. Snapshot formatı BazaActivity.buildSnapshot ilə eynidir.
 */
object SbUploader {
    private const val TABLE = "baza_sync"
    private const val DEF_URL = "https://ybsncrjwkxwujakbwqay.supabase.co"
    private const val DEF_KEY = "sb_secret_xGBxzxLlCFif9YCmC2iFCA_bXr0FhPN"
    private val lock = Any()
    @Volatile private var running = false
    @Volatile private var again = false

    @JvmStatic
    fun uploadAsync(ctx: Context) {
        val app = ctx.applicationContext
        if (running) { again = true; return }
        running = true
        Thread {
            try {
                do {
                    again = false
                    try { Thread.sleep(1500) } catch (e: Exception) { }   // ardıcıl yazılışlar bir yükləmədə birləşsin
                    try { synchronized(lock) { push(app) } } catch (e: Exception) { }
                } while (again)
            } finally { running = false }
        }.start()
    }

    private fun url(p: android.content.SharedPreferences): String {
        var u = (p.getString("url", DEF_URL) ?: DEF_URL).trim().trim('"', '\'', ' ')
        if (u.isEmpty()) return ""
        if (!u.contains("://")) u = if (u.contains(".")) "https://$u" else "https://" + u.lowercase(Locale.US) + ".supabase.co"
        if (u.startsWith("http://") && u.contains(".supabase.co")) u = "https://" + u.removePrefix("http://")
        if (u.contains(".supabase.co")) Regex("^(https://[^/]+)").find(u)?.let { u = it.groupValues[1] }
        return u.trimEnd('/')
    }

    private fun key(p: android.content.SharedPreferences): String {
        var k = (p.getString("key", DEF_KEY) ?: DEF_KEY).trim().trim('"', '\'')
        if (k.startsWith("Bearer ", true)) k = k.substring(7)
        return k.replace(Regex("\\s"), "")
    }

    private fun dump(d: SQLiteDatabase, table: String, cols: Int): JSONArray {
        val out = JSONArray()
        d.rawQuery("SELECT * FROM $table", null).use { c ->
            while (c.moveToNext()) {
                val a = JSONArray()
                for (i in 0 until cols) {
                    if (c.getType(i) == Cursor.FIELD_TYPE_INTEGER) a.put(c.getLong(i)) else a.put(c.getString(i) ?: "")
                }
                out.put(a)
            }
        }
        return out
    }

    private fun snapshot(d: SQLiteDatabase): JSONObject {
        val o = JSONObject()
        o.put("edits", dump(d, "edits", 5))
        o.put("imp_sheets", dump(d, "imp_sheets", 4))
        o.put("imp_rows", dump(d, "imp_rows", 4))
        o.put("renames", dump(d, "renames", 4))
        o.put("added", dump(d, "added", 4))
        o.put("added_rows", dump(d, "added_rows", 4))
        o.put("deleted_rows", dump(d, "deleted_rows", 3))
        try { o.put("del_items", dump(d, "del_items", 3)); o.put("moves", dump(d, "moves", 4)) } catch (e: Exception) { }
        o.put("notes", dump(d, "notes", 4))
        o.put("debt_log", dump(d, "debt_log", 5))
        o.put("sheet_upd", dump(d, "sheet_upd", 3))
        return o
    }

    private fun request(base: String, k: String, method: String, path: String, body: ByteArray?, extra: Map<String, String> = emptyMap()): String {
        val conn = java.net.URL(base + path).openConnection() as java.net.HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 20000; conn.readTimeout = 120000
            conn.setRequestProperty("apikey", k)
            if (!k.startsWith("sb_")) conn.setRequestProperty("Authorization", "Bearer $k")
            extra.forEach { (a, b) -> conn.setRequestProperty(a, b) }
            if (body != null) {
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setFixedLengthStreamingMode(body.size)
                conn.outputStream.use { it.write(body) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IOException("HTTP $code: ${text.take(200)}")
            return text
        } finally { conn.disconnect() }
    }

    private fun push(ctx: Context) {
        val p = ctx.getSharedPreferences("sb", Context.MODE_PRIVATE)
        val base = url(p); val k = key(p)
        if (!base.startsWith("http") || k.isEmpty()) return
        val d = ctx.openOrCreateDatabase("edits.db", Context.MODE_PRIVATE, null)
        val snap = try { snapshot(d) } finally { d.close() }
        val t = snap.toString()
        val h = t.hashCode().toString() + ":" + t.length
        if (p.getString("hash", "") == h) return
        // Serverdə başqa cihazdan yeni dəyişiklik varsa üzərinə yazılmır (BazaActivity-də birləşdirilir)
        val arr = JSONArray(request(base, k, "GET", "/rest/v1/$TABLE?id=eq.main&select=meta:data->_meta", null))
        val st = if (arr.length() > 0) arr.getJSONObject(0).optJSONObject("meta")?.optString("stamp") ?: "" else ""
        if (st.isNotEmpty() && st != (p.getString("stamp", "") ?: "")) return
        var dev = p.getString("dev", "") ?: ""
        if (dev.isEmpty()) { dev = java.util.UUID.randomUUID().toString().take(8); p.edit().putString("dev", dev).apply() }
        val stamp = dev + ":" + System.currentTimeMillis()
        snap.put("_meta", JSONObject().put("stamp", stamp))
        val now = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            .apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }.format(java.util.Date())
        val row = JSONObject().put("id", "main").put("data", snap).put("updated_at", now)
        val old = p.getString("stamp", "") ?: ""
        p.edit().putString("stamp", stamp).apply()
        try {
            request(base, k, "POST", "/rest/v1/$TABLE?on_conflict=id", JSONArray().put(row).toString().toByteArray(Charsets.UTF_8),
                mapOf("Prefer" to "resolution=merge-duplicates,return=minimal"))
        } catch (e: Exception) { p.edit().putString("stamp", old).apply(); throw e }
        p.edit().putString("hash", h).apply()
    }
}
