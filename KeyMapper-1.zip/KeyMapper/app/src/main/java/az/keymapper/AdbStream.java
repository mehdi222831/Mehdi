package az.keymapper;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

final class AdbStream {
    final AdbConnection conn;
    final int localId;
    volatile int remoteId;
    volatile boolean closed;
    final CountDownLatch open = new CountDownLatch(1);
    final Semaphore credit = new Semaphore(0);
    private final StringBuilder buf = new StringBuilder();

    AdbStream(AdbConnection c, int id) {
        conn = c;
        localId = id;
    }

    synchronized void onData(byte[] d) {
        buf.append(new String(d, StandardCharsets.UTF_8));
        if (buf.length() > 20000) buf.delete(0, 10000);
        notifyAll();
    }

    void write(byte[] d) throws IOException {
        if (closed) throw new IOException("closed");
        try {
            if (!credit.tryAcquire(3, TimeUnit.SECONDS)) throw new IOException("ack timeout");
        } catch (InterruptedException e) {
            throw new IOException("interrupted");
        }
        conn.send(AdbConnection.A_WRTE, localId, remoteId, d);
    }

    synchronized boolean waitFor(String token, long ms) {
        long end = System.currentTimeMillis() + ms;
        try {
            while (buf.indexOf(token) < 0 && !closed) {
                long left = end - System.currentTimeMillis();
                if (left <= 0) return false;
                wait(left);
            }
        } catch (InterruptedException e) {
            return false;
        }
        return buf.indexOf(token) >= 0;
    }

    synchronized String waitClosed(long ms) {
        long end = System.currentTimeMillis() + ms;
        try {
            while (!closed) {
                long left = end - System.currentTimeMillis();
                if (left <= 0) break;
                wait(left);
            }
        } catch (InterruptedException ignored) { }
        return buf.toString();
    }

    synchronized String text() {
        return buf.toString();
    }

    synchronized void markClosed() {
        closed = true;
        open.countDown();
        notifyAll();
    }

    void close() {
        if (!closed) {
            markClosed();
            try {
                conn.send(AdbConnection.A_CLSE, localId, remoteId, new byte[0]);
            } catch (IOException ignored) { }
        }
        conn.remove(localId);
    }
}
