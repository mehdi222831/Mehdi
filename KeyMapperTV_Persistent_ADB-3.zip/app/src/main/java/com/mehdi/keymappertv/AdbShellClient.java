package com.mehdi.keymappertv;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

/** Minimal ADB host client that opens an interactive shell over adbd TCP/5555. */
final class AdbShellClient implements Closeable {
    private static final int ADB_VERSION = 0x01000000;
    private static final int MAX_DATA = 4096;
    private static final int CMD_CNXN = cmd("CNXN");
    private static final int CMD_AUTH = cmd("AUTH");
    private static final int CMD_OPEN = cmd("OPEN");
    private static final int CMD_OKAY = cmd("OKAY");
    private static final int CMD_WRTE = cmd("WRTE");
    private static final int CMD_CLSE = cmd("CLSE");
    private static final int AUTH_TOKEN = 1;
    private static final int AUTH_SIGNATURE = 2;
    private static final int AUTH_PUBLIC_KEY = 3;
    private static final int LOCAL_ID = 1;

    private final Socket socket;
    private final DataInputStream in;
    private final DataOutputStream out;
    private final CountDownLatch shellOpenLatch = new CountDownLatch(1);
    private final Semaphore canWrite = new Semaphore(0);
    private volatile boolean connected = true;
    private volatile int remoteId = -1;
    private Thread readerThread;

    private AdbShellClient(Socket socket) throws IOException {
        this.socket = socket;
        this.in = new DataInputStream(socket.getInputStream());
        this.out = new DataOutputStream(socket.getOutputStream());
        this.socket.setTcpNoDelay(true);
    }

    static AdbShellClient connect(Context context) throws Exception {
        KeyMaterial keyMaterial = KeyMaterial.loadOrCreate(context.getApplicationContext());
        List<String> hosts = candidateHosts();
        IOException lastError = null;
        for (String host : hosts) {
            Socket socket = new Socket();
            try {
                socket.connect(new InetSocketAddress(host, 5555), 800);
                socket.setSoTimeout(6500);
                AdbShellClient client = new AdbShellClient(socket);
                client.handshake(keyMaterial);
                socket.setSoTimeout(0);
                client.startReader();
                client.openShell();
                return client;
            } catch (Exception e) {
                try { socket.close(); } catch (Exception ignored) { }
                lastError = e instanceof IOException ? (IOException) e : new IOException(e);
            }
        }
        throw new IOException("ADB TCP/5555 əlçatan deyil. Əvvəlcə adbd üçün TCP port 5555 aktiv olmalıdır.", lastError);
    }

    boolean isConnected() {
        return connected && !socket.isClosed() && remoteId >= 0;
    }

    boolean sendLineForStatus(String command) {
        if (command == null || !command.matches("[A-Za-z0-9_ .-]+")) return false;
        return sendLine(command);
    }

    /** Apply device-level background exemptions through the already authenticated local adbd shell. */
    boolean applyKeepAliveCommands() {
        final String pkg = "com.mehdi.keymappertv";
        final String svc = pkg + "/" + pkg + ".KeyMapAccessibilityService";
        String[] commands = new String[] {
                "pm grant " + pkg + " android.permission.WRITE_SECURE_SETTINGS",
                "cur=$(settings get secure enabled_accessibility_services); [ \"$cur\" = null ] && cur=; "
                        + "case \"$cur\" in *" + svc + "*) ;; *) settings put secure enabled_accessibility_services \"${cur:+$cur:}" + svc + "\" ;; esac",
                "settings put secure accessibility_enabled 1",
                "cmd deviceidle whitelist +" + pkg,
                "cmd appops set " + pkg + " RUN_IN_BACKGROUND allow",
                "cmd appops set " + pkg + " RUN_ANY_IN_BACKGROUND allow",
                "cmd appops set " + pkg + " START_FOREGROUND allow",
                "cmd appops set " + pkg + " AUTO_START allow",
                "am set-standby-bucket " + pkg + " active",
                "svc power stayon true"
        };
        for (String command : commands) {
            if (!sendLine(command)) return false;
            try { Thread.sleep(150L); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); return false; }
        }
        return true;
    }

    boolean sendKey(int keyCode) {
        return sendLine("input keyevent " + Math.max(0, Math.min(1000, keyCode)));
    }

    boolean sendLongKey(int keyCode) {
        return sendLine("input keyevent --longpress " + Math.max(0, Math.min(1000, keyCode)));
    }

    boolean launchPackage(String packageName) {
        if (packageName == null || !packageName.matches("[A-Za-z0-9_.]+")) return false;
        return sendLine("monkey -p " + packageName + " 1");
    }

    private boolean sendLine(String command) {
        if (!isConnected()) return false;
        try {
            if (!canWrite.tryAcquire(1200, TimeUnit.MILLISECONDS)) return false;
            if (!isConnected()) return false;
            byte[] data = (command + "\n").getBytes(java.nio.charset.StandardCharsets.UTF_8);
            sendPacket(CMD_WRTE, LOCAL_ID, remoteId, data);
            return true;
        } catch (Exception e) {
            connected = false;
            return false;
        }
    }

    private void handshake(KeyMaterial keys) throws Exception {
        String banner = "host::\0";
        sendPacket(CMD_CNXN, ADB_VERSION, MAX_DATA, banner.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        boolean signatureSent = false;
        int steps = 0;
        while (steps++ < 12) {
            Packet packet = readPacket();
            if (packet.command == CMD_CNXN) return;
            if (packet.command == CMD_AUTH && packet.arg0 == AUTH_TOKEN) {
                if (!signatureSent) {
                    Signature signature = Signature.getInstance("SHA1withRSA");
                    signature.initSign(keys.privateKey);
                    signature.update(packet.data);
                    sendPacket(CMD_AUTH, AUTH_SIGNATURE, 0, signature.sign());
                    signatureSent = true;
                } else {
                    sendPacket(CMD_AUTH, AUTH_PUBLIC_KEY, 0, keys.adbPublicKey);
                }
            } else if (packet.command == CMD_CLSE || packet.command == 0) {
                throw new IOException("ADB əl sıxışması uğursuz oldu.");
            }
        }
        throw new IOException("ADB təsdiqi tamamlanmadı. TV Box-da RSA icazə pəncərəsini yoxlayın.");
    }

    private void startReader() {
        readerThread = new Thread(() -> {
            try {
                while (connected) {
                    Packet p = readPacket();
                    if (p.command == CMD_OKAY) {
                        if (remoteId < 0) {
                            remoteId = p.arg0;
                            canWrite.release();
                            shellOpenLatch.countDown();
                        } else if (p.arg0 == remoteId && p.arg1 == LOCAL_ID) {
                            canWrite.release();
                        }
                    } else if (p.command == CMD_WRTE) {
                        if (p.arg0 == remoteId && p.arg1 == LOCAL_ID) {
                            sendPacket(CMD_OKAY, LOCAL_ID, remoteId, new byte[0]);
                        }
                    } else if (p.command == CMD_CLSE) {
                        connected = false;
                        shellOpenLatch.countDown();
                        break;
                    } else if (p.command == CMD_CNXN) {
                        // A repeated CNXN is harmless after transport establishment.
                    }
                }
            } catch (Exception e) {
                connected = false;
                shellOpenLatch.countDown();
            }
        }, "KeyMapper-ADB-reader");
        readerThread.setDaemon(true);
        readerThread.start();
    }

    private void openShell() throws IOException {
        byte[] service = "shell:sh\0".getBytes(java.nio.charset.StandardCharsets.UTF_8);
        sendPacket(CMD_OPEN, LOCAL_ID, 0, service);
        try {
            if (!shellOpenLatch.await(5, TimeUnit.SECONDS) || !isConnected()) {
                throw new IOException("ADB shell açılmadı.");
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("ADB shell gözləməsi dayandırıldı.", e);
        }
    }

    private synchronized void sendPacket(int command, int arg0, int arg1, byte[] data) throws IOException {
        if (data == null) data = new byte[0];
        int checksum = 0;
        for (byte b : data) checksum += b & 0xff;
        out.writeInt(Integer.reverseBytes(command));
        out.writeInt(Integer.reverseBytes(arg0));
        out.writeInt(Integer.reverseBytes(arg1));
        out.writeInt(Integer.reverseBytes(data.length));
        out.writeInt(Integer.reverseBytes(checksum));
        out.writeInt(Integer.reverseBytes(~command));
        if (data.length > 0) out.write(data);
        out.flush();
    }

    private Packet readPacket() throws IOException {
        byte[] header = new byte[24];
        in.readFully(header);
        int command = readIntLe(header, 0);
        int arg0 = readIntLe(header, 4);
        int arg1 = readIntLe(header, 8);
        int length = readIntLe(header, 12);
        int magic = readIntLe(header, 20);
        if (magic != ~command || length < 0 || length > 1024 * 1024) {
            throw new IOException("ADB paket başlığı yanlışdır.");
        }
        byte[] data = new byte[length];
        if (length > 0) in.readFully(data);
        return new Packet(command, arg0, arg1, data);
    }

    private static int readIntLe(byte[] b, int off) {
        return (b[off] & 0xff) | ((b[off + 1] & 0xff) << 8) |
                ((b[off + 2] & 0xff) << 16) | ((b[off + 3] & 0xff) << 24);
    }

    private static int cmd(String s) {
        return s.charAt(0) | (s.charAt(1) << 8) | (s.charAt(2) << 16) | (s.charAt(3) << 24);
    }

    private static List<String> candidateHosts() {
        List<String> result = new ArrayList<>();
        result.add("127.0.0.1");
        try {
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface ni : interfaces) {
                try {
                    if (!ni.isUp() || ni.isLoopback()) continue;
                    for (InetAddress address : Collections.list(ni.getInetAddresses())) {
                        if (address instanceof Inet4Address && !address.isLoopbackAddress() && !address.isLinkLocalAddress()) {
                            String host = address.getHostAddress();
                            if (!result.contains(host)) result.add(host);
                        }
                    }
                } catch (Exception ignored) { }
            }
        } catch (Exception ignored) { }
        return result;
    }

    @Override
    public void close() {
        connected = false;
        try {
            if (remoteId >= 0) sendPacket(CMD_CLSE, LOCAL_ID, remoteId, new byte[0]);
        } catch (Exception ignored) { }
        try { socket.close(); } catch (Exception ignored) { }
    }

    private static final class Packet {
        final int command, arg0, arg1;
        final byte[] data;
        Packet(int command, int arg0, int arg1, byte[] data) {
            this.command = command; this.arg0 = arg0; this.arg1 = arg1; this.data = data;
        }
    }

    private static final class KeyMaterial {
        final PrivateKey privateKey;
        final byte[] adbPublicKey;
        KeyMaterial(PrivateKey privateKey, byte[] adbPublicKey) {
            this.privateKey = privateKey; this.adbPublicKey = adbPublicKey;
        }

        static KeyMaterial loadOrCreate(Context context) throws Exception {
            SharedPreferences p = context.getSharedPreferences("adb_host_key", Context.MODE_PRIVATE);
            String privateB64 = p.getString("private_pkcs8", null);
            String publicB64 = p.getString("public_x509", null);
            KeyFactory factory = KeyFactory.getInstance("RSA");
            if (privateB64 != null && publicB64 != null) {
                PrivateKey privateKey = factory.generatePrivate(new PKCS8EncodedKeySpec(Base64.decode(privateB64, Base64.DEFAULT)));
                RSAPublicKey publicKey = (RSAPublicKey) factory.generatePublic(new X509EncodedKeySpec(Base64.decode(publicB64, Base64.DEFAULT)));
                return new KeyMaterial(privateKey, toAdbPublicKey(publicKey));
            }
            KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
            generator.initialize(2048);
            KeyPair pair = generator.generateKeyPair();
            p.edit()
                    .putString("private_pkcs8", Base64.encodeToString(pair.getPrivate().getEncoded(), Base64.NO_WRAP))
                    .putString("public_x509", Base64.encodeToString(pair.getPublic().getEncoded(), Base64.NO_WRAP))
                    .apply();
            return new KeyMaterial(pair.getPrivate(), toAdbPublicKey((RSAPublicKey) pair.getPublic()));
        }

        private static byte[] toAdbPublicKey(RSAPublicKey publicKey) throws IOException {
            BigInteger modulus = publicKey.getModulus();
            byte[] nLe = toLittleEndian256(modulus);
            BigInteger radix = BigInteger.ONE.shiftLeft(2048);
            BigInteger rr = radix.multiply(radix).mod(modulus);
            byte[] rrLe = toLittleEndian256(rr);
            BigInteger two32 = BigInteger.ONE.shiftLeft(32);
            long n0inv = modulus.mod(two32).modInverse(two32).negate().mod(two32).longValue();

            ByteArrayOutputStream buffer = new ByteArrayOutputStream(524);
            writeIntLe(buffer, 64);              // Number of 32-bit modulus words.
            writeIntLe(buffer, (int) n0inv);      // -N^-1 mod 2^32.
            buffer.write(nLe);                    // 2048-bit modulus, little-endian.
            buffer.write(rrLe);                   // (2^2048)^2 mod N, little-endian.
            writeIntLe(buffer, publicKey.getPublicExponent().intValue());
            String encoded = Base64.encodeToString(buffer.toByteArray(), Base64.NO_WRAP);
            return (encoded + " keymappertv@android\0").getBytes(java.nio.charset.StandardCharsets.UTF_8);
        }

        private static byte[] toLittleEndian256(BigInteger value) {
            byte[] src = value.toByteArray();
            byte[] bigEndian = new byte[256];
            int copyLen = Math.min(256, src.length);
            System.arraycopy(src, src.length - copyLen, bigEndian, 256 - copyLen, copyLen);
            byte[] littleEndian = new byte[256];
            for (int i = 0; i < 256; i++) littleEndian[i] = bigEndian[255 - i];
            return littleEndian;
        }

        private static void writeIntLe(ByteArrayOutputStream out, int value) {
            out.write(value & 0xff);
            out.write((value >>> 8) & 0xff);
            out.write((value >>> 16) & 0xff);
            out.write((value >>> 24) & 0xff);
        }
    }
}
