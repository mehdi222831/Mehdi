package com.mehdi.keymapper;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;

/** Daim işləyən xidmət: ADB-ni, Server prosesini və əlçatanlıq xidmətini izləyib bərpa edir. */
public class KeepAliveService extends Service {
    static volatile boolean kick = false;
    private static volatile boolean running = false;
    private Thread worker;
    private PowerManager.WakeLock wl;

    public static void start(Context c) {
        Intent i = new Intent(c, KeepAliveService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
            else c.startService(i);
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        try {
            startForeground(1, buildNotification());
        } catch (Throwable ignored) {
        }
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "keymapper:svc");
            wl.setReferenceCounted(false);
            wl.acquire();
        } catch (Throwable ignored) {
        }
    }

    private Notification buildNotification() {
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel("km", "Key Mapper", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
            b = new Notification.Builder(this, "km");
        } else {
            b = new Notification.Builder(this);
        }
        b.setSmallIcon(android.R.drawable.ic_menu_manage).setContentTitle("Key Mapper işləyir").setOngoing(true);
        return b.build();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            startForeground(1, buildNotification());
        } catch (Throwable ignored) {
        }
        running = true;
        if (worker == null || !worker.isAlive()) {
            worker = new Thread(new Runnable() {
                @Override
                public void run() {
                    loop();
                }
            }, "km-worker");
            worker.setDaemon(true);
            worker.start();
        }
        return START_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        start(this);
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        running = false;
        try {
            if (wl != null && wl.isHeld()) wl.release();
        } catch (Throwable ignored) {
        }
        try {
            Intent i = new Intent("com.mehdi.keymapper.RESTART");
            i.setComponent(new ComponentName(this, BootReceiver.class));
            sendBroadcast(i);
        } catch (Throwable ignored) {
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    // ---------------------------------------------------------------- işçi dövrü

    private void loop() {
        Context c = getApplicationContext();
        while (running) {
            boolean ok = false;
            try {
                tick(c);
                ok = Bridge.isConnected() && KeyService.instance != null;
            } catch (Throwable t) {
                Status.error = t.getClass().getSimpleName() + ": " + t.getMessage();
            }
            long until = SystemClock.elapsedRealtime() + (ok ? 4000 : 9000);
            while (running && !kick && SystemClock.elapsedRealtime() < until) {
                try {
                    Thread.sleep(200);
                } catch (InterruptedException e) {
                    return;
                }
            }
            kick = false;
        }
    }

    private void tick(Context c) throws Exception {
        String token = Store.token(c);
        boolean serverUp = Bridge.isConnected() || Bridge.connect(token);
        boolean needSecure = KeyService.instance == null && !hasSecure(c);
        if (!serverUp || needSecure) {
            Status.adb = "qoşulur...";
            Adb.bootstrap(c, !serverUp);
            if (!serverUp) {
                for (int i = 0; i < 25 && !Bridge.isConnected(); i++) {
                    Thread.sleep(300);
                    Bridge.connect(token);
                }
            }
        }
        if (KeyService.instance == null) enableAccessibility(c);
        if (Bridge.isConnected()) Status.error = "";
        else Status.error = "Server başlamadı";
    }

    static boolean hasSecure(Context c) {
        return c.checkCallingOrSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED;
    }

    static void enableAccessibility(Context c) {
        if (!hasSecure(c)) return;
        try {
            String pkg = c.getPackageName();
            String full = pkg + "/" + KeyService.class.getName();
            String shortName = pkg + "/." + KeyService.class.getSimpleName();
            android.content.ContentResolver cr = c.getContentResolver();
            String cur = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (cur == null) cur = "";
            if (!cur.contains(full) && !cur.contains(shortName)) {
                String n = cur.length() == 0 ? full : cur + ":" + full;
                Settings.Secure.putString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, n);
            }
            Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 1);
        } catch (Throwable t) {
            Status.error = "Əlçatanlıq: " + t.getMessage();
        }
    }
}
