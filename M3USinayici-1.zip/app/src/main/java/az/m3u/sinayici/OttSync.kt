package az.m3u.sinayici

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.webkit.*
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * İxracdan sonra arxa planda (ekranda görünməyən WebView) https://ottplayer.tv/playlist/original səhifəsinə girir,
 * "Mehdi" yazılan sətrin sağındakı dairəvi ox (yenilə / update) düyməsinə basır və nəticəni bildirir.
 * Giriş lazım olsa OttLogin skripti ilə avtomatik daxil olur (BrowserActivity-dəki cookie-lər paylaşılır).
 *
 * Nəticə: cb(ok, info). ok=true yalnız yeniləmə düyməsinə BASILIBSA (fayl yalnız onda silinir).
 */
object OttSync {
    private const val HOME = "https://ottplayer.tv/playlist/original"
    private const val TIMEOUT_MS = 150_000L
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false

    @SuppressLint("SetJavaScriptEnabled")
    fun run(act: Activity, name: String = "Mehdi", background: Boolean = false, onStep: ((String) -> Unit)? = null, cb: (Boolean, String) -> Unit) {
        if (running) { cb(false, "Ottplayer yeniləməsi artıq gedir"); return }
        running = true
        val host = act.window.decorView as ViewGroup
        val web = WebView(act)
        // background=true: görünməz (alpha 0), lakin tam ölçüdə qurulur (skript elementləri görsün) və toxunuşları ötürür
        val panel = if (background) object : LinearLayout(act) {
            override fun dispatchTouchEvent(ev: android.view.MotionEvent?): Boolean = false
        }.apply { orientation = LinearLayout.VERTICAL; alpha = 0f }
        else LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        var finished = false
        var pressed = false   // yenilə düyməsinə yalnız 1 dəfə basılır: basıldıqdan sonra səhifə yenilənsə də skript təkrar yeridilmir

        fun finish(ok: Boolean, info: String) {
            if (finished) return
            finished = true
            main.removeCallbacksAndMessages(null)
            try { host.removeView(panel) } catch (e: Exception) { }
            try { web.stopLoading(); web.removeJavascriptInterface("OttSyncBridge"); web.destroy() } catch (e: Exception) { }
            running = false
            cb(ok, info)
        }

        // Canlı görünən panel: yuxarıda status sətri + "Gizlət" düyməsi, altında Ottplayer səhifəsi
        val dm = act.resources.displayMetrics
        val dp = dm.density
        val sbId = act.resources.getIdentifier("status_bar_height", "dimen", "android")
        val sb = if (sbId > 0) act.resources.getDimensionPixelSize(sbId) else (24 * dp).toInt()
        val status = TextView(act).apply {
            text = "🔄 Ottplayer açılır..."
            setTextColor(Color.WHITE); textSize = 14f
            setPadding((12 * dp).toInt(), 0, (8 * dp).toInt(), 0)
            gravity = Gravity.CENTER_VERTICAL
        }
        val hide = Button(act).apply {
            text = "Gizlət"; textSize = 12f; isAllCaps = false
            setOnClickListener { panel.visibility = View.GONE }
        }
        val bar = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#CC1B1B1B"))
            gravity = Gravity.CENTER_VERTICAL
            addView(status, LinearLayout.LayoutParams(0, (48 * dp).toInt(), 1f))
            addView(hide, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, (40 * dp).toInt()))
        }
        web.setBackgroundColor(Color.BLACK)
        panel.setBackgroundColor(Color.BLACK)
        panel.setPadding(0, sb, 0, 0)
        panel.addView(bar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        panel.addView(web, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        panel.elevation = 100f * dp
        host.addView(panel, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        fun setStatus(t: String) { status.text = t; onStep?.invoke(t) }

        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            javaScriptCanOpenWindowsAutomatically = false
            mediaPlaybackRequiresUserGesture = true
        }
        CookieManager.getInstance().setAcceptCookie(true)
        web.webChromeClient = object : WebChromeClient() {
            // Sayt "əminsiniz?" soruşsa avtomatik təsdiq
            override fun onJsConfirm(v: WebView?, u: String?, m: String?, r: JsResult?): Boolean { r?.confirm(); return true }
            override fun onJsAlert(v: WebView?, u: String?, m: String?, r: JsResult?): Boolean { r?.confirm(); return true }
        }
        web.addJavascriptInterface(object {
            @JavascriptInterface fun pressed() { main.post { pressed = true } }
            /** Giriş forması göndərildi: 5 saniyə sonra hələ /playlist/original-da deyilsə, ora keç. */
            @JavascriptInterface fun submitted() {
                main.postDelayed({
                    if (!finished && !pressed) {
                        val u = try { web.url ?: "" } catch (e: Exception) { "" }
                        if (!u.contains("/playlist/original")) web.loadUrl(HOME)
                    }
                }, 5000)
            }
            @JavascriptInterface fun step(t: String) { main.post { setStatus(t) } }
            @JavascriptInterface fun result(status: String, info: String) {
                main.post {
                    when (status) {
                        "ok" -> finish(true, info)
                        else -> finish(false, info)
                    }
                }
            }
        }, "OttSyncBridge")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, url: String?) {
                super.onPageFinished(v, url)
                val h = try { android.net.Uri.parse(url ?: "").host } catch (e: Exception) { null }
                if (!OttLogin.host(h) || pressed) return
                v.evaluateJavascript(OttLogin.js(), null)
                v.evaluateJavascript(script(name), null)
            }
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean = !OttLogin.host(r.url.host)
        }
        main.postDelayed({ finish(false, "Ottplayer-də 150 saniyə ərzində yeniləmə tamamlanmadı") }, TIMEOUT_MS)
        setStatus("🔄 Ottplayer səhifəsi yüklənir...")
        web.loadUrl(HOME)
    }

    /** Səhifədə "Mehdi" sətrini tapıb sağındakı yeniləmə (dairəvi ox) ikonuna basır. */
    fun script(name: String): String = """
(function(){
  if(window.__ottSyncRun) return; window.__ottSyncRun = true;
  var NAME = ${org.json.JSONObject.quote(name)}.toLowerCase();
  var POS = /updt_pl|refresh|update|sync|reload|renew|rotate|cycle|clockwise|redo|yenil|обнов/i;
  var NEG = /delete|trash|remove|bin\b|edit|pencil|copy|share|link|setting|menu|more|close|download|qr|add|plus|play|info|sil\b|удал|измен/i;
  var pending = 0, afterClick = false, doneReq = 0;
  // Klikdən sonra gedən şəbəkə sorğularını izləyirik (yeniləmənin bitdiyini bilmək üçün)
  try {
    var xs = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.send = function(){
      if(afterClick){ pending++; var x = this; x.addEventListener('loadend', function(){ pending--; doneReq++; }); }
      return xs.apply(this, arguments);
    };
    var of = window.fetch;
    if(of) window.fetch = function(){
      if(!afterClick) return of.apply(this, arguments);
      pending++;
      return of.apply(this, arguments).then(function(r){ pending--; doneReq++; return r; }, function(e){ pending--; doneReq++; throw e; });
    };
  } catch(e){}
  function vis(e){ var r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
  function sig(e){
    var s = (e.className && e.className.baseVal !== undefined ? e.className.baseVal : e.className) + ' ' + (e.id||'') + ' ' + (e.title||'') + ' ' +
      (e.getAttribute('aria-label')||'') + ' ' + (e.getAttribute('data-icon')||'') + ' ' + (e.getAttribute('name')||'') + ' ' +
      (e.getAttribute('href')||'') + ' ' + (e.getAttribute('data-original-title')||'') + ' ' + (e.getAttribute('ng-click')||'') + ' ' +
      (e.getAttribute('onclick')||'') + ' ' + (e.getAttribute('@click')||'') + ' ' + (e.getAttribute('v-on:click')||'');
    if(e.children.length < 3) s += ' ' + (e.innerText||'').slice(0,30);   // material-icons: mətn "refresh"
    var u = e.querySelector && e.querySelector('use'); if(u) s += ' ' + (u.getAttribute('href')||u.getAttribute('xlink:href')||'');
    var ch = e.querySelector && e.querySelector('i, svg, span[class*=icon], mat-icon'); if(ch && ch !== e) s += ' ' + (ch.className && ch.className.baseVal !== undefined ? ch.className.baseVal : ch.className) + ' ' + (ch.innerText||'').slice(0,20);
    return s;
  }
  function nameEl(){
    var all = [].slice.call(document.querySelectorAll('body *')).filter(function(e){
      if(!vis(e) || e.children.length > 2) return false;
      var t = (e.innerText || e.textContent || '').trim().toLowerCase();
      return t === NAME;
    });
    return all[0] || null;
  }
  var __fired = false;
  function fire(el){
    // YALNIZ BİR klik: əvvəl pointer/mouse hadisələri + click + t.click() yeniləməni 2-3 dəfə işə salırdı,
    // ikinci sorğu isə saytda "error update" yazısı çıxarırdı
    if(__fired) return; __fired = true;
    var t = el.closest('button, a, [role=button], [onclick]') || el;
    try { t.click(); } catch(e){ try { t.dispatchEvent(new MouseEvent('click', {bubbles:true, cancelable:true, view:window})); } catch(e2){} }
  }
  // "Playlist updated" yazısı görünməyənə qədər növbəti mərhələyə KEÇMİR
  var DONE_RE = /playlist\s*(was\s*|has\s*been\s*)?updat|плейлист\s*обновл|updated\s*successfully/gi;
  var baseCount = 0;
  function pageText(){ try { return document.body ? (document.body.innerText || '') : ''; } catch(e){ return ''; } }
  function countDone(){ var m = pageText().match(DONE_RE); return m ? m.length : 0; }
  function waitDone(){
    var t0 = Date.now(), fin = false;
    try { OttSyncBridge.step('👆 Yenilə düyməsinə basıldı — "Playlist updated" yazısı gözlənilir...'); } catch(e){}
    var iv = setInterval(function(){
      if(fin) return;
      if(countDone() > baseCount){
        fin = true; clearInterval(iv);
        try { OttSyncBridge.step('✅ "Playlist updated" yazısı görüldü'); } catch(e){}
        setTimeout(function(){ try { OttSyncBridge.result('ok', 'Playlist updated yazısı görüldü'); } catch(e){} }, 3000);
        return;
      }
      var sec = Math.round((Date.now() - t0) / 1000);
      if(sec >= 100){
        fin = true; clearInterval(iv);
        try { OttSyncBridge.result('fail', 'Düyməyə basıldı, amma 100 saniyə ərzində "Playlist updated" yazısı görünmədi'); } catch(e){}
        return;
      }
      try { OttSyncBridge.step('⏳ "Playlist updated" yazısı gözlənilir... ' + sec + ' san'); } catch(e){}
    }, 500);
  }
  var tries = 0, clicked = false;
  try { OttSyncBridge.step('🔎 \"' + NAME + '\" sətri axtarılır...'); } catch(e){}
  var timer = setInterval(function(){
    if(clicked || ++tries > 110){ if(!clicked){ clearInterval(timer); try{ OttSyncBridge.result('fail', 'Səhifədə \"' + NAME + '\" sətri tapılmadı (giriş olmaya bilər)'); }catch(e){} } return; }
    var ne = nameEl(); if(!ne) return;
    var nr = ne.getBoundingClientRect(), row = ne, cands = [], direct = null;
    // Dəqiq hədəf: Mehdi sətrindəki <a class="updt_pl uk-icon"> (yalnız bir updt_pl olan ən yaxın üst element = həmin sətir)
    for(var u2 = 0, r2 = ne; u2 < 10 && r2.parentElement; u2++){
      r2 = r2.parentElement;
      var L = r2.querySelectorAll('.updt_pl');
      if(L.length === 1){ direct = L[0]; break; }
      if(L.length > 1) break;
    }
    if(direct){
      clicked = true; clearInterval(timer);
      setTimeout(function(){
        afterClick = true; pending = 0; doneReq = 0; baseCount = countDone();
        try { OttSyncBridge.pressed(); } catch(e){}
        fire(direct);
        waitDone();
      }, 800);
      return;
    }
    for(var up = 0; up < 7 && row.parentElement; up++){
      row = row.parentElement;
      cands = [].slice.call(row.querySelectorAll('button, a, [role=button], i, svg, mat-icon, span[class*=icon], span[class*=btn], div[class*=btn], div[class*=icon], [onclick], [ng-click]'))
        .filter(function(e){
          if(!vis(e) || e.contains(ne) || ne.contains(e)) return false;
          var r = e.getBoundingClientRect();
          return r.left >= nr.right - 4 && Math.abs((r.top + r.height/2) - (nr.top + nr.height/2)) < Math.max(40, nr.height * 1.5);
        });
      if(cands.length) break;
    }
    if(!cands.length) return;
    var best = null, bs = 0;
    cands.forEach(function(e){
      var s = sig(e), sc = 0;
      if(POS.test(s)) sc += 10;
      if(NEG.test(s)) sc -= 10;
      if(sc > bs){ bs = sc; best = e; }
    });
    if(!best){
      var ok = cands.filter(function(e){ return !NEG.test(sig(e)); });
      // eyni düymənin içindəki svg + button təkrarlarını say: ən kənar düymələrə endir
      var tops = ok.filter(function(e){ return !ok.some(function(o){ return o !== e && o.contains(e); }); });
      if(tops.length === 1) best = tops[0];
    }
    if(!best){
      clearInterval(timer); clicked = true;
      var d = cands.slice(0, 8).map(function(e){ return e.tagName + '.' + String(e.className && e.className.baseVal !== undefined ? e.className.baseVal : e.className).slice(0,40); }).join(' | ');
      try { OttSyncBridge.result('fail', 'Yeniləmə (dairəvi ox) düyməsi dəqiq tapılmadı. Sətirdəki elementlər: ' + d); } catch(e){}
      return;
    }
    clicked = true; clearInterval(timer);
    setTimeout(function(){
      afterClick = true; pending = 0; doneReq = 0; baseCount = countDone();
      try { OttSyncBridge.pressed(); } catch(e){}
      fire(best);
      waitDone();
    }, 800);
  }, 500);
})();
"""
}
