package com.mehdi.keymapper

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class Mapping(val src: Int, val gesture: String, val action: String, val arg: String)

object Gesture { const val SINGLE = "SINGLE"; const val DOUBLE = "DOUBLE"; const val LONG = "LONG" }
object Act {
    const val SEND_KEY = "SEND_KEY"; const val LAUNCH = "LAUNCH"; const val KILL_FG = "KILL_FG"
    const val HOME = "HOME"; const val BACK = "BACK"; const val RECENTS = "RECENTS"
}

object CaptureHub { @Volatile var listener: ((Int) -> Unit)? = null }

object Store {
    private lateinit var sp: SharedPreferences
    @Volatile private var list: List<Mapping> = emptyList()

    @Synchronized fun init(c: Context) {
        if (::sp.isInitialized) return
        sp = c.applicationContext.getSharedPreferences("maps", Context.MODE_PRIVATE)
        try {
            val arr = JSONArray(sp.getString("j", "[]"))
            list = (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Mapping(o.getInt("s"), o.getString("g"), o.getString("a"), o.optString("r"))
            }
        } catch (e: Exception) { list = emptyList() }
    }

    fun all(): List<Mapping> = list
    fun forKey(k: Int): List<Mapping> = list.filter { it.src == k }

    fun save(n: List<Mapping>) {
        list = n
        val arr = JSONArray()
        n.forEach { arr.put(JSONObject().put("s", it.src).put("g", it.gesture).put("a", it.action).put("r", it.arg)) }
        sp.edit().putString("j", arr.toString()).apply()
    }
    fun add(m: Mapping) = save(list.filter { !(it.src == m.src && it.gesture == m.gesture) } + m)
    fun remove(m: Mapping) = save(list.filter { it != m })
}
