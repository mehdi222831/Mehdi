package com.mehdi.keymapper;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.SparseArray;
import android.view.KeyEvent;

import org.json.JSONArray;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

public class Store {
    private static final String P = "km";

    /** Xidmətin işlətdiyi aktiv qaydalar: mənbə düymə kodu -> qayda */
    public static volatile SparseArray<Mapping> active = new SparseArray<>();
    /** Düyməni tanıma rejimi: xidmət düymələri udmur */
    public static volatile boolean capturing = false;
    public static volatile int doubleWindow = 250;

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(P, Context.MODE_PRIVATE);
    }

    public static List<Mapping> load(Context c) {
        List<Mapping> l = new ArrayList<>();
        String js = sp(c).getString("mappings", null);
        if (js == null) {
            l.add(new Mapping(KeyEvent.KEYCODE_BUTTON_7, KeyEvent.KEYCODE_DPAD_RIGHT, false));
            l.add(new Mapping(KeyEvent.KEYCODE_BUTTON_6, KeyEvent.KEYCODE_DPAD_LEFT, false));
            l.add(new Mapping(KeyEvent.KEYCODE_BUTTON_5, KeyEvent.KEYCODE_DPAD_CENTER, true));
            save(c, l);
            return l;
        }
        try {
            JSONArray a = new JSONArray(js);
            for (int i = 0; i < a.length(); i++) l.add(Mapping.fromJson(a.getJSONObject(i)));
        } catch (Exception ignored) {
        }
        return l;
    }

    public static void save(Context c, List<Mapping> l) {
        JSONArray a = new JSONArray();
        for (Mapping m : l) {
            try {
                a.put(m.toJson());
            } catch (Exception ignored) {
            }
        }
        sp(c).edit().putString("mappings", a.toString()).commit();
        publish(l);
    }

    private static void publish(List<Mapping> l) {
        SparseArray<Mapping> n = new SparseArray<>();
        for (Mapping m : l) n.put(m.source, m);
        active = n;
    }

    public static void reload(Context c) {
        publish(load(c));
        doubleWindow = sp(c).getInt("win", 250);
    }

    public static synchronized String token(Context c) {
        SharedPreferences p = sp(c);
        String t = p.getString("token", null);
        if (t == null) {
            byte[] b = new byte[16];
            new SecureRandom().nextBytes(b);
            StringBuilder sb = new StringBuilder();
            for (byte x : b) sb.append(String.format("%02x", x & 0xff));
            t = sb.toString();
            p.edit().putString("token", t).commit();
        }
        return t;
    }

    public static String adbHost(Context c) {
        return sp(c).getString("adb_host", "");
    }

    public static int adbPort(Context c) {
        return sp(c).getInt("adb_port", 5555);
    }

    public static void setAdb(Context c, String host, int port) {
        sp(c).edit().putString("adb_host", host).putInt("adb_port", port).commit();
    }

    public static int window(Context c) {
        return sp(c).getInt("win", 250);
    }

    public static void setWindow(Context c, int ms) {
        sp(c).edit().putInt("win", ms).commit();
        doubleWindow = ms;
    }
}
