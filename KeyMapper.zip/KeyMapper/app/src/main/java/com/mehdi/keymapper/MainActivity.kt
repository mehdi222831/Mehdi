package com.mehdi.keymapper

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.KeyEvent
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var listBox: LinearLayout
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { refreshStatus(); h.postDelayed(this, 2000) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        Adb.init(this)
        KeepAliveService.start(this)
        Adb.connectAsync()

        val sv = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(16), dp(24), dp(16))
        }
        sv.addView(col)

        col.addView(TextView(this).apply { text = "Key Mapper"; textSize = 26f })
        status = TextView(this).apply { textSize = 15f; setPadding(0, dp(8), 0, dp(8)) }
        col.addView(status)

        fun btn(t: String, f: () -> Unit) {
            col.addView(Button(this).apply { text = t; isAllCaps = false; setOnClickListener { f() } })
        }
        btn("ADB-yə qoş (127.0.0.1 / öz IP : 5555)") { Adb.connectAsync(); toast("Qoşulur…") }
        btn("Düymə xidmətini aktivləşdir (Accessibility)") { enableService() }
        btn("Batareya məhdudiyyətini söndür") { batteryOpt() }
        val zb = Button(this).apply { isAllCaps = false }
        fun zText() { zb.text = "Sıfır gecikmə rejimi: " + (if (Store.zeroMode) "AÇIQ" else "BAĞLI") }
        zb.setOnClickListener { Store.zeroMode = !Store.zeroMode; zText() }
        zText()
        col.addView(zb)
        btn("+ Yeni düymə təyinatı") { addFlow() }
        btn("Hazır təyinatları yüklə (BUTTON_5/6/7)") { Store.loadPresets(); refreshList() }

        col.addView(TextView(this).apply { text = "Təyinatlar:"; textSize = 18f; setPadding(0, dp(16), 0, dp(4)) })
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(listBox)

        setContentView(sv)
        refreshList()
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun refreshStatus() {
        val acc = if (KeyMapperService.instance != null) "aktiv ✅" else "söndürülüb ❌"
        status.text = "${Adb.status}\nDüymə xidməti: $acc"
    }

    private fun enableService() {
        if (Adb.enableAccessibility()) { toast("Aktivləşdirildi"); return }
        toast("ADB qoşulandan sonra avtomatik olacaq; indi əl ilə aç")
        try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (e: Exception) {}
    }

    private fun batteryOpt() {
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } else toast("Artıq söndürülüb")
        } catch (e: Exception) { toast("Bu cihazda açılmadı") }
    }

    private fun keyName(c: Int) = KeyEvent.keyCodeToString(c)

    private fun keyLabel(c: Int) = when (c) {
        KeyEvent.KEYCODE_DPAD_LEFT -> "Sol — " + keyName(c)
        KeyEvent.KEYCODE_DPAD_RIGHT -> "Sağ — " + keyName(c)
        KeyEvent.KEYCODE_DPAD_CENTER -> "Enter / OK — " + keyName(c)
        else -> keyName(c)
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    private fun describe(m: Mapping): String {
        val g = when (m.gesture) { Gesture.SINGLE -> "1× bas"; Gesture.DOUBLE -> "2× bas"; else -> "basıb saxla" }
        val a = when (m.action) {
            Act.SEND_KEY -> "düymə: " + keyName(m.arg.toIntOrNull() ?: 0)
            Act.SEND_KEY_LONG -> "düymə (uzun basma): " + keyName(m.arg.toIntOrNull() ?: 0)
            Act.LAUNCH -> "tətbiq: " + appLabel(m.arg)
            Act.KILL_FG -> "ekrandakı tətbiqi bağla + RAM təmizlə"
            Act.HOME -> "ana ekran"
            Act.BACK -> "geri"
            else -> "son tətbiqlər"
        }
        return "${keyName(m.src)}  [$g]\n→ $a"
    }

    private fun refreshList() {
        listBox.removeAllViews()
        val all = Store.all()
        if (all.isEmpty()) listBox.addView(TextView(this).apply { text = "Hələ təyinat yoxdur" })
        for (m in all) {
            listBox.addView(TextView(this).apply { text = describe(m); textSize = 16f; setPadding(0, dp(10), 0, 0) })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(Button(this).apply {
                text = "Düyməni dəyiş"; isAllCaps = false
                setOnClickListener {
                    captureKey("${keyName(m.src)} əvəzinə yeni düyməni basın") { nk ->
                        Store.save(Store.all().map { if (it == m) it.copy(src = nk) else it })
                        refreshList()
                    }
                }
            })
            row.addView(Button(this).apply {
                text = "Sil"; isAllCaps = false
                setOnClickListener { Store.remove(m); refreshList() }
            })
            listBox.addView(row)
        }
    }

    private fun captureKey(msg: String, cb: (Int) -> Unit) {
        var done = false
        val d = AlertDialog.Builder(this).setTitle("Düyməni basın").setMessage(msg + "\n(20 saniyə)")
            .setNegativeButton("Ləğv", null).create()
        val finish: (Int) -> Unit = { code ->
            if (!done) { done = true; CaptureHub.listener = null; d.dismiss(); cb(code) }
        }
        d.setOnKeyListener { _, code, ev ->
            if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) finish(code)
            true
        }
        CaptureHub.listener = { code -> finish(code) }
        d.setOnDismissListener { CaptureHub.listener = null }
        d.show()
        h.postDelayed({ if (!done) { done = true; d.dismiss() } }, 20000)
    }

    private fun pick(title: String, items: List<String>, cb: (Int) -> Unit) {
        AlertDialog.Builder(this).setTitle(title)
            .setItems(items.toTypedArray()) { _, w -> cb(w) }
            .setNegativeButton("Ləğv", null).show()
    }

    private val commonKeys = listOf(
        KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_CENTER,
        KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_ENTER,
        KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_HOME, KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_APP_SWITCH,
        KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_VOLUME_DOWN, KeyEvent.KEYCODE_VOLUME_MUTE,
        KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_CHANNEL_DOWN,
        KeyEvent.KEYCODE_PAGE_UP, KeyEvent.KEYCODE_PAGE_DOWN
    )

    private fun chooseKey(cb: (Int) -> Unit) {
        val names = commonKeys.map { keyLabel(it) } + "Digər (düyməni bas)"
        pick("Hansı düymə göndərilsin?", names) { i ->
            if (i < commonKeys.size) cb(commonKeys[i])
            else captureKey("Göndəriləcək düyməni basın", cb)
        }
    }

    private fun chooseApp(cb: (String) -> Unit) {
        val pm = packageManager
        val seen = HashSet<String>()
        val items = ArrayList<Pair<String, String>>()
        for (cat in listOf(Intent.CATEGORY_LAUNCHER, Intent.CATEGORY_LEANBACK_LAUNCHER)) {
            pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0).forEach {
                val p = it.activityInfo.packageName
                if (seen.add(p)) items.add(it.loadLabel(pm).toString() to p)
            }
        }
        items.sortBy { it.first.lowercase() }
        pick("Hansı tətbiq açılsın?", items.map { it.first }) { i -> cb(items[i].second) }
    }

    private fun addFlow() {
        captureKey("Təyin ediləcək düyməni basın") { src ->
            pick("Necə basılanda?", listOf("Bir dəfə bas", "İki dəfə bas", "Basıb saxla")) { gi ->
                val g = listOf(Gesture.SINGLE, Gesture.DOUBLE, Gesture.LONG)[gi]
                val acts = listOf(
                    "Başqa düyməni göndər", "Tətbiq aç",
                    "Ekrandakı tətbiqi bağla + RAM təmizlə", "Ana ekran", "Geri", "Son tətbiqlər",
                    "Başqa düyməni UZUN basma kimi göndər"
                )
                pick("Nə etsin?", acts) { ai ->
                    fun save(a: String, arg: String) { Store.add(Mapping(src, g, a, arg)); refreshList() }
                    when (ai) {
                        0 -> chooseKey { k -> save(Act.SEND_KEY, k.toString()) }
                        1 -> chooseApp { p -> save(Act.LAUNCH, p) }
                        2 -> save(Act.KILL_FG, "")
                        3 -> save(Act.HOME, "")
                        4 -> save(Act.BACK, "")
                        5 -> save(Act.RECENTS, "")
                        else -> chooseKey { k -> save(Act.SEND_KEY_LONG, k.toString()) }
                    }
                }
            }
        }
    }
}
