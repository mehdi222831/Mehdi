package az.vakansiya

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature

class BrowserActivity : AppCompatActivity() {
    private lateinit var wv: WebView
    private lateinit var base: String
    private var cssDark = false
    private var pending: ValueCallback<Array<Uri>>? = null

    // aşağıdakı axtarış paneli: 0 = bağlı, 1 = söz axtarışı, 2 = açar sözlərlə elan axtarışı
    private var fmode = 0
    private lateinit var fbar: LinearLayout
    private lateinit var fEdit: android.widget.EditText
    private lateinit var fLabel: TextView
    private lateinit var fCnt: TextView

    private fun imm() = getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager

    private fun clearFind() {
        wv.clearMatches()
        wv.evaluateJavascript(KW_CLEAR, null)
    }

    private fun closeFind() {
        clearFind()
        fmode = 0
        fbar.visibility = View.GONE
        imm().hideSoftInputFromWindow(fEdit.windowToken, 0)
        fEdit.setText("")
        fCnt.text = ""
    }

    private fun openFind(mode: Int) {
        if (fmode != 0) clearFind()
        fmode = mode
        fCnt.text = ""
        fbar.visibility = View.VISIBLE
        fEdit.visibility = if (mode == 1) View.VISIBLE else View.GONE
        fLabel.visibility = if (mode == 2) View.VISIBLE else View.GONE
        if (mode == 1) {
            fEdit.requestFocus()
            fEdit.post { imm().showSoftInput(fEdit, 0) }
            if (fEdit.text.isNotEmpty()) wv.findAllAsync(fEdit.text.toString())
        } else {
            imm().hideSoftInputFromWindow(fEdit.windowToken, 0)
            runKw()
        }
    }

    /** Açar sözlərə (İT / çağrı mərkəzi / mühafizə) uyğun elanları səhifədə tapıb çərçivəyə alır, birincisinə keçir. */
    private fun runKw() {
        val js = "(function(){" + Keywords.js(this) + KW_SCAN + "})()"
        wv.evaluateJavascript(js) { r ->
            val v = (r ?: "").trim('"')
            if (v == "0" || v == "null" || v.isEmpty()) {
                fCnt.text = "0/0"
                android.widget.Toast.makeText(this, "Bu səhifədə açar sözlərə uyğun elan tapılmadı", android.widget.Toast.LENGTH_SHORT).show()
            } else fCnt.text = v
        }
    }

    private fun step(forward: Boolean) {
        if (fmode == 1) {
            if (fEdit.text.isNotEmpty()) wv.findNext(forward)
        } else if (fmode == 2) {
            wv.evaluateJavascript("(window.__kwGo?window.__kwGo(" + (if (forward) 1 else -1) + "):'0')") { r ->
                val v = (r ?: "").trim('"')
                if (v == "0" || v == "null" || v.isEmpty()) runKw() else fCnt.text = v
            }
        }
    }

    companion object {
        private const val KW_CLEAR = "(function(){var o=document.querySelectorAll('[data-kwm]');for(var i=0;i<o.length;i++){var e=o[i];e.style.outline='';e.style.outlineOffset='';e.style.background='';e.removeAttribute('data-kwm')}window.__kwL=[];window.__kwI=-1})()"
        private const val KW_SCAN = """
var old=document.querySelectorAll('[data-kwm]');
for(var i=0;i<old.length;i++){var o=old[i];o.style.outline='';o.style.outlineOffset='';o.style.background='';o.removeAttribute('data-kwm')}
var as=document.querySelectorAll('a[href]'),L=[],colors={1:'#60A5FA',2:'#FB923C',3:'#34D399'};
for(var i=0;i<as.length;i++){
 var a=as[i];if(a.getClientRects().length==0)continue;
 var card=null;try{card=a.closest('article,li,tr,[class*=card],[class*=item],[class*=vacanc],[class*=job]')}catch(e){}
 if(!card)card=a.parentElement||a;
 var t='';try{t=titleOf(a,card)}catch(e){t=(a.innerText||'').split('
')[0]}
 var k=kindOf(t);if(!k)continue;
 var el=card,r=el.getBoundingClientRect();
 if(el===document.body||el===document.documentElement||r.height>window.innerHeight*0.9)el=a;
 if(el.getAttribute('data-kwm'))continue;
 el.setAttribute('data-kwm',k);el.style.outline='3px solid '+colors[k];el.style.outlineOffset='-2px';
 L.push(el)}
window.__kwL=L;window.__kwI=-1;
window.__kwGo=function(d){var n=window.__kwL.length;if(!n)return '0';
 var p=window.__kwL[window.__kwI];if(p)p.style.background='';
 if(window.__kwI<0)window.__kwI=d>0?0:n-1;else window.__kwI=((window.__kwI+d)%n+n)%n;
 var e=window.__kwL[window.__kwI];e.style.background='rgba(251,191,36,.28)';
 e.scrollIntoView({block:'center',behavior:'smooth'});
 return (window.__kwI+1)+'/'+n};
return window.__kwGo(1);
"""
    }

    // sistem fayl seçicisi (telefondan birdəfəlik seçim)
    private val sysPick = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val cb = pending; pending = null
        cb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
    }

    private fun systemPicker(p: WebChromeClient.FileChooserParams) {
        try { sysPick.launch(p.createIntent()) }
        catch (e: Exception) { pending?.onReceiveValue(null); pending = null }
    }

    /** Sayt fayl istəyəndə: əvvəlcə tətbiqə əlavə edilmiş fayllar göstərilir. */
    private fun chooseFile(cb: ValueCallback<Array<Uri>>, p: WebChromeClient.FileChooserParams) {
        pending?.onReceiveValue(null)
        pending = cb
        val all = Files.list(this)
        if (all.isEmpty()) {
            android.widget.Toast.makeText(this, "Tətbiqdə saxlanmış fayl yoxdur (əsas səhifədə 📎)", android.widget.Toast.LENGTH_LONG).show()
            systemPicker(p); return
        }
        val ok = all.filter { Files.matches(it, p.acceptTypes) }
        val list = if (ok.isEmpty()) all else ok
        val names = list.map { it.name + "  (" + Files.size(it) + ")" }.toTypedArray()
        fun deliver(files: List<java.io.File>) {
            val c = pending; pending = null
            c?.onReceiveValue(if (files.isEmpty()) null else files.map { Files.uri(this, it) }.toTypedArray())
        }
        val b = AlertDialog.Builder(this).setTitle("Yüklənəcək fayl")
        if (p.mode == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE) {
            val chk = BooleanArray(list.size)
            b.setMultiChoiceItems(names, chk) { _, i, v -> chk[i] = v }
            b.setPositiveButton("Seç") { _, _ -> deliver(list.filterIndexed { i, _ -> chk[i] }) }
        } else {
            b.setItems(names) { _, i -> deliver(listOf(list[i])) }
        }
        b.setNeutralButton("Telefondan seç") { _, _ -> systemPicker(p) }
        b.setNegativeButton("Ləğv et") { _, _ -> deliver(emptyList()) }
        b.setOnCancelListener { deliver(emptyList()) }
        b.show()
    }

    private fun dp(i: Int) = (i * resources.displayMetrics.density).toInt()

    /** Gmail-də həmin ünvana yeni məktub yazma ekranını açır; Gmail yoxdursa, başqa mail proqramı. */
    private fun composeGmail(addr: String) {
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + Uri.encode(addr)))
        try {
            startActivity(Intent(i).setPackage("com.google.android.gm"))
        } catch (e: Exception) {
            try { startActivity(i) }
            catch (e2: Exception) {
                android.widget.Toast.makeText(this, "Mail proqramı tapılmadı", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun btn(t: String, click: () -> Unit) = TextView(this).apply {
        text = t; textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(10), dp(10), dp(10), dp(10))
        setOnClickListener { click() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        base = intent.getStringExtra("base") ?: ""
        val start = intent.getStringExtra("start") ?: base
        val title = intent.getStringExtra("title") ?: ""

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#000000"))
            gravity = Gravity.CENTER_VERTICAL
        }
        bar.addView(btn("◀") { if (wv.canGoBack()) wv.goBack() })
        bar.addView(btn("🏠") { wv.loadUrl(base) })
        bar.addView(btn("⟳") { wv.reload() })
        bar.addView(btn("🔍") { if (fmode == 1) closeFind() else openFind(1) })
        bar.addView(btn("🔑") { if (fmode == 2) closeFind() else openFind(2) })
        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        titleBox.addView(TextView(this).apply {
            text = title; setTextColor(Color.WHITE); textSize = 15f; maxLines = 1
            gravity = Gravity.CENTER
        })
        val mailPrefs = getSharedPreferences("app", MODE_PRIVATE)
        val mailRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        }
        val mailBox = android.widget.EditText(this).apply {
            hint = "mail ünvanı"; textSize = 12f
            setTypeface(typeface, android.graphics.Typeface.ITALIC)
            setTextColor(Color.WHITE); setHintTextColor(Color.parseColor("#6B7280"))
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEND
            backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#374151"))
            setText(mailPrefs.getString("mailTo", ""))
            setPadding(dp(4), dp(2), dp(4), dp(2))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val send = TextView(this).apply {
            text = "✉"; textSize = 18f; setTextColor(Color.parseColor("#60A5FA"))
            setPadding(dp(10), dp(2), dp(4), dp(2))
        }
        fun go() {
            val a = mailBox.text.toString().trim()
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(a).matches()) {
                android.widget.Toast.makeText(this, "Düzgün mail ünvanı yazın", android.widget.Toast.LENGTH_SHORT).show()
                return
            }
            mailPrefs.edit().putString("mailTo", a).apply()
            composeGmail(a)
        }
        send.setOnClickListener { go() }
        mailBox.setOnEditorActionListener { _, _, _ -> go(); true }
        mailRow.addView(mailBox); mailRow.addView(send)
        titleBox.addView(mailRow)
        bar.addView(titleBox)
        bar.addView(btn("✕") { finish() })
        root.addView(bar)

        val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#60A5FA"))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3))
        }
        root.addView(pb)

        wv = WebView(this)
        wv.setBackgroundColor(Color.BLACK)
        root.addView(wv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // aşağıdakı axtarış paneli: [söz qutusu / 🔑 açar sözlər] [say] ▲ ▼ ✕
        fbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#0A0A0A"))
            setPadding(dp(12), dp(2), dp(2), dp(2)); visibility = View.GONE
        }
        fEdit = android.widget.EditText(this).apply {
            hint = "Səhifədə söz axtar…"; textSize = 15f
            setTextColor(Color.WHITE); setHintTextColor(Color.parseColor("#6B7280"))
            setSingleLine(true)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
            backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#374151"))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        fLabel = TextView(this).apply {
            text = "🔑 Açar sözlər  ⟳"; textSize = 14f; setTextColor(Color.parseColor("#FBBF24"))
            setPadding(0, dp(10), dp(8), dp(10)); visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { runKw() }
        }
        fCnt = TextView(this).apply {
            textSize = 13f; setTextColor(Color.parseColor("#9CA3AF")); setPadding(dp(8), 0, dp(4), 0)
        }
        fun arrow(t: String, fwd: Boolean) = TextView(this).apply {
            text = t; textSize = 24f; setTextColor(Color.parseColor("#60A5FA"))
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnClickListener { step(fwd) }
        }
        fbar.addView(fEdit); fbar.addView(fLabel); fbar.addView(fCnt)
        fbar.addView(arrow("▲", false)); fbar.addView(arrow("▼", true))
        fbar.addView(TextView(this).apply {
            text = "✕"; textSize = 18f; setTextColor(Color.WHITE); setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { closeFind() }
        })
        root.addView(fbar)
        window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        setContentView(root)

        fEdit.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, e: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, c: Int, e: Int) {}
            override fun afterTextChanged(e: android.text.Editable?) {
                if (fmode != 1) return
                val q = e?.toString()?.trim().orEmpty()
                if (q.isEmpty()) { wv.clearMatches(); fCnt.text = "" } else wv.findAllAsync(q)
            }
        })
        fEdit.setOnEditorActionListener { _, _, _ -> step(true); true }
        wv.setFindListener { active, total, _ ->
            if (fmode == 1 && fEdit.text.isNotBlank()) fCnt.text = if (total == 0) "0/0" else "${active + 1}/$total"
        }

        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(wv.settings, true)
        } else if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            @Suppress("DEPRECATION")
            WebSettingsCompat.setForceDark(wv.settings, WebSettingsCompat.FORCE_DARK_ON)
            if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK_STRATEGY)) {
                @Suppress("DEPRECATION")
                WebSettingsCompat.setForceDarkStrategy(wv.settings, WebSettingsCompat.DARK_STRATEGY_PREFER_WEB_THEME_OVER_USER_AGENT_DARKENING)
            }
        } else cssDark = true
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(wv, true)
        }
        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: android.webkit.WebResourceRequest): Boolean {
                val u = r.url.toString()
                if (u.startsWith("http://") || u.startsWith("https://")) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (e: Exception) { }
                return true
            }
            override fun onPageStarted(v: WebView, u: String, f: android.graphics.Bitmap?) { pb.visibility = View.VISIBLE }
            override fun onPageFinished(v: WebView, u: String) {
                pb.visibility = View.GONE
                if (cssDark) v.evaluateJavascript("(function(){if(document.getElementById('__dk'))return;var s=document.createElement('style');s.id='__dk';s.textContent='html{background:#fff;filter:invert(1) hue-rotate(180deg)}img,video,picture,canvas,svg image{filter:invert(1) hue-rotate(180deg)}';document.head.appendChild(s)})()", null)
                if (fmode == 2) runKw()
                Store.setLast(this@BrowserActivity, base, u)
                CookieManager.getInstance().flush()
            }
        }
        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) { pb.progress = p }
            override fun onShowFileChooser(v: WebView, cb: ValueCallback<Array<Uri>>, p: WebChromeClient.FileChooserParams): Boolean {
                chooseFile(cb, p); return true
            }
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (wv.canGoBack()) wv.goBack() else finish() }
        })
        wv.loadUrl(start)
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
    }

    override fun onDestroy() {
        pending?.onReceiveValue(null); pending = null
        wv.destroy()
        super.onDestroy()
    }
}
