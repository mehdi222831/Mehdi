package az.tvlauncher

import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import dadb.AdbKeyPair
import dadb.Dadb
import java.io.File

/**
 * Tətbiq açılanda özünü default (HOME) launcher təyin edir.
 * Cihazın öz-özünə ADB-yə (127.0.0.1:5555) qoşulur və shell əmrləri ilə təyin edir.
 * Tələb: Developer options -> "USB debugging" + "Network/Wireless debugging" (TCP 5555) açıq olmalıdır.
 */
object DefaultLauncher {

    fun isDefault(ctx: Context): Boolean {
        val ri = ctx.packageManager.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
            PackageManager.MATCH_DEFAULT_ONLY
        )
        return ri?.activityInfo?.packageName == ctx.packageName
    }

    /** true -> təyin olundu. Bloklayır (ilk dəfə "USB debugging icazəsi" dialoqu çıxa bilər) – arxa thread-də çağırın. */
    fun setViaAdb(ctx: Context, port: Int): Boolean {
        return try {
            val priv = File(ctx.filesDir, "adbkey")
            val pub = File(ctx.filesDir, "adbkey.pub")
            if (!priv.exists() || !pub.exists()) AdbKeyPair.generate(priv, pub)
            val keys = AdbKeyPair.read(priv, pub)
            val comp = "${ctx.packageName}/.MainActivity"
            val cmds = mutableListOf<String>()
            if (Build.VERSION.SDK_INT >= 29) cmds += "cmd role add-role-holder --user 0 android.app.role.HOME ${ctx.packageName}"
            cmds += "cmd package set-home-activity --user 0 $comp"
            cmds += "pm set-home-activity $comp"
            Dadb.create("127.0.0.1", port, keys).use { adb ->
                for (c in cmds) {
                    try { adb.shell(c) } catch (e: Exception) { /* növbəti əmri yoxla */ }
                    Thread.sleep(600)
                    if (isDefault(ctx)) return true
                }
            }
            isDefault(ctx)
        } catch (e: Exception) {
            false
        }
    }

    /** ADB alınmasa: sistemin öz seçim pəncərəsi / Ayarlar. */
    fun askSystem(act: Activity) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val rm = act.getSystemService(RoleManager::class.java)
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                    act.startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), 4711)
                    return
                }
            }
            act.startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        } catch (e: Exception) {
        }
    }
}
