package az.tvlauncher

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.media.tv.TvContract
import android.media.tv.TvInputInfo
import android.media.tv.TvInputManager
import android.net.ConnectivityManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.content.pm.ResolveInfo
import android.text.SpannableString
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import android.view.KeyEvent
import java.util.Calendar
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Tile(val label: String, val image: Drawable?, val banner: Boolean, val key: String = "", val action: () -> Unit)

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var temp: TextView
    private lateinit var desc: TextView
    private lateinit var details: TextView
    private lateinit var wifi: ImageView
    private lateinit var apps: RecyclerView
    private lateinit var shortcuts: RecyclerView
    private lateinit var wIcon: ImageView
    private lateinit var bg: WeatherBackground
    private lateinit var forecast: LinearLayout
    private var wCode = 0
    private var wDay: Boolean? = null
    private var moving = false
    private var ignoreUp = false
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }

    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private val dateFmt = SimpleDateFormat("EEEE, d MMMM", Locale("az", "AZ"))

    private val ticker = object : Runnable {
        override fun run() {
            val now = Date()
            val ts = timeFmt.format(now)
            clock.text = SpannableString(ts).apply { setSpan(RelativeSizeSpan(0.42f), 5, ts.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
            date.text = dateFmt.format(now).replaceFirstChar { it.uppercase() }
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            @Suppress("DEPRECATION")
            wifi.visibility = if (cm.activeNetworkInfo?.isConnected == true) View.VISIBLE else View.INVISIBLE
            val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            bg.set(wCode, wDay ?: (hr in 6..18), hr)
            h.postDelayed(this, 1000)
        }
    }
    private val weatherLoop = object : Runnable {
        override fun run() {
            loadWeather()
            h.postDelayed(this, 15 * 60_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        clock = findViewById(R.id.clock)
        date = findViewById(R.id.date)
        temp = findViewById(R.id.temp)
        desc = findViewById(R.id.desc)
        details = findViewById(R.id.details)
        wifi = findViewById(R.id.wifi)
        wIcon = findViewById(R.id.wicon)
        bg = findViewById(R.id.bg)
        forecast = findViewById(R.id.forecast)
        wIcon.setImageResource(if (Calendar.getInstance().get(Calendar.HOUR_OF_DAY) in 6..18) R.drawable.ic_w_clear_day else R.drawable.ic_w_clear_night)
        apps = findViewById(R.id.apps)
        shortcuts = findViewById(R.id.shortcuts)
        apps.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        shortcuts.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
    }

    override fun onResume() {
        super.onResume()
        moving = false
        apps.adapter = TileAdapter(appTiles().toMutableList(), R.layout.item_app)
        shortcuts.adapter = TileAdapter(shortcutTiles().toMutableList(), R.layout.item_shortcut)
        h.post(ticker)
        h.post(weatherLoop)
        if (currentFocus == null) apps.post { (apps.getChildAt(0) ?: shortcuts.getChildAt(0))?.requestFocus() }
    }

    override fun onPause() {
        super.onPause()
        h.removeCallbacks(ticker)
        h.removeCallbacks(weatherLoop)
    }

    @Deprecated("Launcher-dən çıxmasın")
    override fun onBackPressed() {}

    // OK düyməsini basılı saxla -> köçürmə rejimi; sol/sağ -> yer dəyiş; OK/Geri -> saxla
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (!moving) return super.dispatchKeyEvent(e)
        val down = e.action == KeyEvent.ACTION_DOWN
        when (e.keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> { if (down) moveFocused(-1); return true }
            KeyEvent.KEYCODE_DPAD_RIGHT -> { if (down) moveFocused(1); return true }
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> return true
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_BACK -> {
                if (!down) {
                    if (ignoreUp && e.keyCode != KeyEvent.KEYCODE_BACK) { ignoreUp = false; return super.dispatchKeyEvent(e) }
                    endMove()
                }
                return true
            }
        }
        return super.dispatchKeyEvent(e)
    }

    private fun startMove(vh: TileAdapter.VH) {
        moving = true
        ignoreUp = true
        vh.label.text = "‹  Köçür  ›"
        vh.itemView.animate().scaleX(1.2f).scaleY(1.2f).setDuration(120).start()
    }

    private fun moveFocused(d: Int) {
        val child = apps.focusedChild ?: return
        val a = apps.adapter as? TileAdapter ?: return
        val pos = apps.getChildAdapterPosition(child)
        val to = pos + d
        if (pos < 0 || to !in 0 until a.itemCount) return
        a.swap(pos, to)
        apps.scrollToPosition(to)
    }

    private fun endMove() {
        moving = false
        val a = apps.adapter as? TileAdapter ?: return
        prefs.edit().putString("order", a.items.joinToString("\n") { it.key }).apply()
        val child = apps.focusedChild
        val pos = if (child != null) apps.getChildAdapterPosition(child) else -1
        child?.findViewById<TextView>(R.id.label)?.text = a.items.getOrNull(pos)?.label
        child?.animate()?.scaleX(1.1f)?.scaleY(1.1f)?.setDuration(120)?.start()
    }

    private fun launch(i: Intent) {
        try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {}
    }

    private fun appTiles(): List<Tile> {
        val skip = setOf(packageName, "com.android.vending", "com.android.settings", "com.android.tv.settings")
        fun query(cat: String) = packageManager.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(cat), 0
        ).filter { it.activityInfo.packageName !in skip }
        val list = query(Intent.CATEGORY_LEANBACK_LAUNCHER).ifEmpty { query(Intent.CATEGORY_LAUNCHER) }
        val idx = (prefs.getString("order", "") ?: "").split("\n").withIndex().associate { it.value to it.index }
        return list.sortedWith(compareBy<ResolveInfo>({ idx["${it.activityInfo.packageName}/${it.activityInfo.name}"] ?: Int.MAX_VALUE }, { it.loadLabel(packageManager).toString().lowercase() })).map { ri ->
            val ai = ri.activityInfo
            val banner = ai.loadBanner(packageManager) ?: ai.applicationInfo.loadBanner(packageManager)
            Tile(ri.loadLabel(packageManager).toString(), banner ?: ri.loadIcon(packageManager), banner != null, "${ai.packageName}/${ai.name}") {
                launch(Intent(Intent.ACTION_MAIN).setClassName(ai.packageName, ai.name))
            }
        }
    }

    private fun shortcutTiles(): List<Tile> {
        val t = mutableListOf<Tile>()
        t += Tile("Play Store", getDrawable(R.drawable.ic_play), false) {
            (packageManager.getLeanbackLaunchIntentForPackage("com.android.vending")
                ?: packageManager.getLaunchIntentForPackage("com.android.vending"))?.let { launch(it) }
        }
        try {
            val tim = getSystemService(Context.TV_INPUT_SERVICE) as TvInputManager
            tim.tvInputList.filter { it.type == TvInputInfo.TYPE_HDMI }.forEachIndexed { i, info ->
                val name = info.loadCustomLabel(this)?.toString()?.ifBlank { null } ?: "HDMI ${i + 1}"
                t += Tile(name, getDrawable(R.drawable.ic_hdmi), false) {
                    launch(Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput(info.id)))
                }
            }
        } catch (e: Exception) {}
        t += Tile("Settings", getDrawable(R.drawable.ic_settings), false) { launch(Intent(Settings.ACTION_SETTINGS)) }
        return t
    }

    private fun loadWeather() {
        Thread {
            try {
                val url = URL(
                    "https://api.open-meteo.com/v1/forecast?latitude=40.4093&longitude=49.8671" +
                        "&current=temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m,weather_code,is_day" +
                        "&daily=weather_code,temperature_2m_max,temperature_2m_min&forecast_days=5" +
                        "&wind_speed_unit=ms&timezone=Asia%2FBaku"
                )
                val c = url.openConnection() as HttpURLConnection
                c.connectTimeout = 10000
                c.readTimeout = 10000
                val root = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                val cur = root.getJSONObject("current")
                val dly = root.getJSONObject("daily")
                val t = Math.round(cur.getDouble("temperature_2m"))
                val feels = Math.round(cur.getDouble("apparent_temperature"))
                val hum = cur.getInt("relative_humidity_2m")
                val wind = cur.getDouble("wind_speed_10m")
                val code = cur.getInt("weather_code")
                val day = cur.getInt("is_day") == 1
                val text = codeText(code)
                runOnUiThread {
                    temp.text = "$t°"
                    wIcon.setImageResource(iconFor(code, day))
                    wCode = code
                    wDay = day
                    showForecast(dly)
                    desc.text = text
                    details.text = "Hiss olunan $feels°\nRütubət $hum%  •  Külək ${"%.1f".format(wind)} m/s"
                }
            } catch (e: Exception) {
                runOnUiThread { if (desc.text.isNullOrEmpty()) desc.text = "Hava məlumatı alınmadı" }
            }
        }.start()
    }

    private fun codeText(c: Int) = when (c) {
        0 -> "Aydın"
        1 -> "Əsasən aydın"
        2 -> "Az buludlu"
        3 -> "Buludlu"
        45, 48 -> "Dumanlı"
        in 51..57 -> "Çiskin"
        in 61..67 -> "Yağışlı"
        in 71..77 -> "Qarlı"
        in 80..82 -> "Leysan"
        in 95..99 -> "Tufan"
        else -> "—"
    }

    private fun showForecast(d: JSONObject) {
        val times = d.getJSONArray("time")
        val codes = d.getJSONArray("weather_code")
        val mx = d.getJSONArray("temperature_2m_max")
        val mn = d.getJSONArray("temperature_2m_min")
        val names = arrayOf("B", "B.e", "Ç.a", "Ç", "C.a", "C", "Ş")
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        forecast.removeAllViews()
        for (i in 0 until times.length()) {
            val v = LayoutInflater.from(this).inflate(R.layout.item_day, forecast, false)
            val cal = Calendar.getInstance().apply { time = fmt.parse(times.getString(i))!! }
            v.findViewById<TextView>(R.id.day).text = if (i == 0) "Bu gün" else names[cal.get(Calendar.DAY_OF_WEEK) - 1]
            v.findViewById<ImageView>(R.id.dicon).setImageResource(iconFor(codes.getInt(i), true))
            v.findViewById<TextView>(R.id.dtemp).text = "${Math.round(mx.getDouble(i))}°/${Math.round(mn.getDouble(i))}°"
            forecast.addView(v)
        }
    }

    private fun iconFor(c: Int, day: Boolean) = when (c) {
        0 -> if (day) R.drawable.ic_w_clear_day else R.drawable.ic_w_clear_night
        1, 2 -> if (day) R.drawable.ic_w_partly_day else R.drawable.ic_w_partly_night
        3 -> R.drawable.ic_w_cloudy
        45, 48 -> R.drawable.ic_w_fog
        in 51..67, in 80..82 -> R.drawable.ic_w_rain
        in 71..77, in 85..86 -> R.drawable.ic_w_snow
        in 95..99 -> R.drawable.ic_w_storm
        else -> R.drawable.ic_w_cloudy
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    inner class TileAdapter(val items: MutableList<Tile>, private val layout: Int) :
        RecyclerView.Adapter<TileAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val icon: ImageView = v.findViewById(R.id.icon)
            val label: TextView = v.findViewById(R.id.label)
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int) =
            VH(LayoutInflater.from(p.context).inflate(layout, p, false))

        override fun getItemCount() = items.size

        fun swap(a: Int, b: Int) {
            items.add(b, items.removeAt(a))
            notifyItemMoved(a, b)
        }

        override fun onBindViewHolder(vh: VH, i: Int) {
            val t = items[i]
            val wide = layout == R.layout.item_app
            vh.icon.setImageDrawable(t.image)
            vh.icon.scaleType = if (t.banner) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.FIT_CENTER
            val pad = if (wide && !t.banner) dp(14) else 0
            vh.icon.setPadding(pad, pad, pad, pad)
            vh.label.text = t.label
            if (wide) vh.label.visibility = View.INVISIBLE
            vh.itemView.setOnClickListener { t.action() }
            if (wide) vh.itemView.setOnLongClickListener { startMove(vh); true }
            vh.itemView.setOnFocusChangeListener { v, f ->
                val s = if (f) 1.1f else 1f
                v.animate().scaleX(s).scaleY(s).setDuration(120).start()
                if (wide) vh.label.visibility = if (f) View.VISIBLE else View.INVISIBLE
            }
        }
    }
}
