# Azər TV Player

Gizli WebView `yodaplayer.yodacdn.net/aztv/index.php` səhifəsini açır, oradan
`str.yodacdn.net/azertv/index.m3u8?token=...` linkini tutur və ExoPlayer ilə oynadır.
Token IP və User-Agent-ə bağlı olduğu üçün link həmin cihazda alınır və həmin UA ilə oynadılır.
Xəta olarsa və ya token bitərsə link avtomatik yenilənir.

Build: GitHub-a yüklə, Actions > Build APK > artifact `AztvPlayer-apk`.
