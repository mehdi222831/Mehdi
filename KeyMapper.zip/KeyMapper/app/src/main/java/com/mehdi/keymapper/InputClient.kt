package com.mehdi.keymapper

import java.io.BufferedOutputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors

/** Sends key events to InputServer over a persistent loopback socket. action: 0=down 1=up 2=tap */
object InputClient {
    const val PORT = 5556
    private val ex = Executors.newSingleThreadExecutor()
    private var sock: Socket? = null
    private var out: DataOutputStream? = null

    fun send(code: Int, action: Int, repeat: Int) { ex.execute { sendBlocking(code, action, repeat) } }

    fun warmUp() {
        ex.execute {
            if (out == null && !open()) Adb.ensureServerAsync()
        }
    }

    private fun sendBlocking(code: Int, action: Int, repeat: Int) {
        for (attempt in 0..1) {
            try {
                if (out == null && !open()) break
                val o = out!!
                o.writeInt(code); o.writeByte(action); o.writeInt(repeat); o.flush()
                return
            } catch (e: Exception) { close() }
        }
        if (action != 1 && repeat == 0) Adb.inputKey(code, false)
        Adb.ensureServerAsync()
    }

    private fun open(): Boolean = try {
        val s = Socket()
        s.tcpNoDelay = true
        s.connect(InetSocketAddress("127.0.0.1", PORT), 250)
        val o = DataOutputStream(BufferedOutputStream(s.getOutputStream()))
        o.writeUTF(Adb.token)
        o.flush()
        sock = s; out = o
        true
    } catch (e: Exception) { false }

    private fun close() {
        try { sock?.close() } catch (e: Exception) {}
        sock = null; out = null
    }
}
