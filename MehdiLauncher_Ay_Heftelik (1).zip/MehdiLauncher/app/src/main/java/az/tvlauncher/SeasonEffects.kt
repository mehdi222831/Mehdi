package az.tvlauncher

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.Build
import java.util.Calendar
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * Mövsümi və Azərbaycan bayram effektləri (fonun üstündə çəkilir):
 *  - LEAVES    : payızda (15 sentyabr – 30 noyabr) düşən yarpaqlar
 *  - PETALS    : yazda (1 aprel – 20 may) düşən çiçək ləçəkləri
 *  - NOVRUZ    : Novruz (10–26 mart) rəngli bəzək bayraqcıqları + tonqal qığılcımları
 *  - FLAG      : 28 May, 15 İyun, 18 Oktyabr, 8 və 9 Noyabr – bayraq rəngli bəzək + konfeti
 *  - NEWYEAR   : Yeni il (20 dekabr – 8 yanvar) qar + işıq zəncirləri
 *  - HALLOWEEN : 25 oktyabr – 1 noyabr: yarasalar, sallanan balqabaqlar, kabuslar
 *  - RELIGIOUS : Ramazan ayı, Ramazan və Qurban bayramı – aypara, ulduzlar, fənərlər
 */
class SeasonEffects(private val d: Float) {
    enum class Fx { LEAVES, PETALS, NOVRUZ, FLAG, NEWYEAR, RELIGIOUS, HALLOWEEN }

    var active: Set<Fx> = emptySet()
        private set
    private var forced: Set<Fx>? = null
    private var lastKey = -1

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = Random(11)
    private val n = 64
    private val rx = FloatArray(n) { rnd.nextFloat() }
    private val ry = FloatArray(n) { rnd.nextFloat() }
    private val rs = FloatArray(n) { 0.5f + rnd.nextFloat() }          // 0.5 .. 1.5
    private val rp = FloatArray(n) { rnd.nextFloat() * 6.2831f }

    private fun unit(c: Int) = RadialGradient(0f, 0f, 1f, c, c and 0x00FFFFFF, Shader.TileMode.CLAMP)

    private val leafColors = intArrayOf(0xFFD9822B.toInt(), 0xFFB5432A.toInt(), 0xFFE0B531.toInt(), 0xFF8C5A2B.toInt(), 0xFFC2662D.toInt())
    private val petalColors = intArrayOf(0xFFFFC1D6.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFA8C5.toInt())
    private val novruzColors = intArrayOf(0xFFE53935.toInt(), 0xFFFFC107.toInt(), 0xFF43A047.toInt(), 0xFFFB8C00.toInt(), 0xFF1E88E5.toInt())
    private val flagColors = intArrayOf(0xFF00B5E2.toInt(), 0xFFEF3340.toInt(), 0xFF509E2F.toInt())   // Azərbaycan bayrağı
    private val bulbColors = intArrayOf(0xFFFF4D4D.toInt(), 0xFFFFD84D.toInt(), 0xFF4DDB6B.toInt(), 0xFF4DA6FF.toInt())
    private val bulbGlow = Array(4) { unit(bulbColors[it]) }
    private val fireGlow = unit(0xFFFF7A1A.toInt())
    private val goldGlow = unit(0xFFFFC857.toInt())

    private val leaf = Path().apply {
        moveTo(0f, -1f)
        quadTo(1.1f, -0.3f, 0f, 1f)
        quadTo(-1.1f, -0.3f, 0f, -1f)
        close()
    }
    private val crescent = Path().apply {
        val a = Path().apply { addCircle(0f, 0f, 1f, Path.Direction.CW) }
        val b = Path().apply { addCircle(0.4f, -0.12f, 0.86f, Path.Direction.CW) }
        op(a, b, Path.Op.DIFFERENCE)
    }
    private val bigWing = Path().apply {
        moveTo(0f, 0f)
        quadTo(0.6f, -0.9f, 1.7f, -0.55f)
        quadTo(1.3f, -0.2f, 1.1f, 0.15f)
        quadTo(0.75f, -0.05f, 0.45f, 0.25f)
        quadTo(0.25f, 0.05f, 0f, 0.35f)
        close()
    }
    private val ghost = Path().apply {
        moveTo(-1f, 0f)
        arcTo(RectF(-1f, -1f, 1f, 1f), 180f, 180f)
        lineTo(1f, 1f)
        quadTo(0.7f, 0.7f, 0.5f, 1f)
        quadTo(0.25f, 0.7f, 0f, 1f)
        quadTo(-0.25f, 0.7f, -0.5f, 1f)
        quadTo(-0.7f, 0.7f, -1f, 1f)
        close()
    }
    private val tmp = Path()
    private val rect = RectF()

    /** Bayram təbriki (varsa) və anım günü olub-olmaması. */
    var greeting: String? = null
        private set
    var mourning = false
        private set

    /** Test üçün: "leaves", "petals", "novruz", "flag", "newyear", "religious", "halloween", "off" və ya "auto". */
    fun preview(name: String?) {
        forced = when {
            name == null || name == "auto" -> null
            name.isBlank() || name == "off" -> emptySet()
            else -> runCatching { setOf(Fx.valueOf(name.uppercase())) }.getOrNull()
        }
        val f = forced
        if (f != null) {
            active = f
            mourning = false
            greeting = when {
                Fx.NOVRUZ in f -> "Novruz bayramınız mübarək!"
                Fx.NEWYEAR in f -> "Yeni iliniz mübarək!"
                Fx.FLAG in f || Fx.RELIGIOUS in f -> "Bayramınız mübarək!"
                else -> null
            }
        } else lastKey = -1
    }

    fun refresh(cal: Calendar) {
        if (forced != null) return
        val key = cal.get(Calendar.YEAR) * 400 + cal.get(Calendar.DAY_OF_YEAR)
        if (key == lastKey) return
        lastKey = key
        val md = (cal.get(Calendar.MONTH) + 1) * 100 + cal.get(Calendar.DAY_OF_MONTH)

        // Anım günlərində effekt yoxdur, yalnız hörmət mesajı
        if (md == 120 || md == 226 || md == 331 || md == 927) {
            mourning = true
            greeting = when (md) {
                120 -> "20 Yanvar şəhidlərinin əziz xatirəsi anılır"
                226 -> "Xocalı soyqırımı qurbanlarının əziz xatirəsi anılır"
                331 -> "31 Mart – Azərbaycanlıların Soyqırımı Günü: qurbanların xatirəsi anılır"
                else -> "27 Sentyabr – Anım Günü: şəhidlərimizin xatirəsi anılır"
            }
            active = emptySet()
            return
        }
        mourning = false

        val hj = hijri()
        val hm = hj?.first ?: 0
        val hd = hj?.second ?: 0
        val s = mutableSetOf<Fx>()
        if (md in 915..1130) s += Fx.LEAVES
        if (md in 401..520) s += Fx.PETALS
        if (md in 310..326) s += Fx.NOVRUZ
        if (md == 528 || md == 615 || md == 1018 || md == 1108 || md == 1109) s += Fx.FLAG
        if (md >= 1220 || md <= 108) s += Fx.NEWYEAR
        if (md in 1025..1101) s += Fx.HALLOWEEN
        // Ramazan ayı (9), Ramazan bayramı (10-cu ayın 1–3-ü), Qurban bayramı (12-ci ayın 9–13-ü).
        // Hicri təqvim cihazın hesablamasıdır, Azərbaycanda elan olunan tarixdən ±1 gün fərqlənə bilər.
        if (hm == 9 || (hm == 10 && hd <= 3) || (hm == 12 && hd in 9..13)) s += Fx.RELIGIOUS
        active = s

        greeting = when {
            md == 1231 || md == 101 || md == 102 -> "Yeni iliniz mübarək!"
            md == 308 -> "8 Mart – Beynəlxalq Qadınlar Günü mübarək!"
            md in 320..324 -> "Novruz bayramınız mübarək!"
            md in 310..319 -> "Novruz bayramı yaxınlaşır"
            md == 528 -> "28 May – Respublika Günü mübarək!"
            md == 615 -> "15 İyun – Milli Qurtuluş Günü mübarək!"
            md == 626 -> "26 İyun – Silahlı Qüvvələr Günü mübarək!"
            md == 1018 -> "18 Oktyabr – Müstəqilliyin Bərpası Günü mübarək!"
            md == 1108 -> "8 Noyabr – Zəfər Günümüz mübarək!"
            md == 1109 -> "9 Noyabr – Dövlət Bayrağı Günü mübarək!"
            md == 1112 -> "12 Noyabr – Konstitusiya Günü mübarək!"
            md == 1117 -> "17 Noyabr – Milli Dirçəliş Günü mübarək!"
            hm == 10 && hd <= 3 -> "Ramazan bayramınız mübarək!"
            hm == 12 && hd in 10..13 -> "Qurban bayramınız mübarək!"
            hm == 9 -> "Ramazan ayınız mübarək!"
            else -> null
        }
    }

    private fun hijri(): Pair<Int, Int>? {
        if (Build.VERSION.SDK_INT < 26) return null
        return try {
            val hd = java.time.chrono.HijrahDate.from(java.time.LocalDate.now())
            hd.get(java.time.temporal.ChronoField.MONTH_OF_YEAR) to hd.get(java.time.temporal.ChronoField.DAY_OF_MONTH)
        } catch (e: Exception) {
            null
        }
    }

    fun draw(cv: Canvas, w: Float, h: Float, t: Float) {
        if (active.isEmpty()) return
        if (Fx.NOVRUZ in active) { embers(cv, w, h, t); bunting(cv, w, t, novruzColors) }
        if (Fx.FLAG in active) { bunting(cv, w, t, flagColors); confetti(cv, w, h, t) }
        if (Fx.NEWYEAR in active) { snow(cv, w, h, t); lights(cv, w, t) }
        if (Fx.RELIGIOUS in active) lanterns(cv, w, h, t)
        if (Fx.HALLOWEEN in active) halloween(cv, w, h, t)
        if (Fx.LEAVES in active) flutter(cv, w, h, t, leafColors, 26, 10f, 0.05f)
        if (Fx.PETALS in active) flutter(cv, w, h, t, petalColors, 22, 6f, 0.04f)
        p.shader = null
    }

    // ---------- köməkçilər ----------

    private fun blob(cv: Canvas, x: Float, y: Float, r: Float) {
        cv.save(); cv.translate(x, y); cv.scale(r, r); cv.drawCircle(0f, 0f, 1f, p); cv.restore()
    }

    /** Üstdən sallanan zəncirin y-i (segmentlər üzrə parabola). */
    private fun gy(x: Float, w: Float, top: Float, sag: Float, segs: Int): Float {
        val sw = w / segs
        val u = (x % sw) / sw
        return top + sag * 4f * u * (1f - u)
    }

    private fun string(cv: Canvas, w: Float, top: Float, sag: Float, segs: Int, color: Int) {
        tmp.reset()
        tmp.moveTo(0f, gy(0f, w, top, sag, segs))
        var x = 6f * d
        while (x < w) {
            tmp.lineTo(x, gy(x, w, top, sag, segs))
            x += 6f * d
        }
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.3f * d
        p.color = color
        cv.drawPath(tmp, p)
        p.style = Paint.Style.FILL
    }

    // ---------- bəzək bayraqcıqları (Novruz, milli bayramlar) ----------

    private fun bunting(cv: Canvas, w: Float, t: Float, colors: IntArray) {
        val segs = 5
        val top = 2f * d
        val sag = 20f * d
        string(cv, w, top, sag, segs, 0x99FFFFFF.toInt())
        val step = 26f * d
        val cnt = (w / step).toInt()
        p.style = Paint.Style.FILL
        p.shader = null
        for (i in 0 until cnt) {
            val x = (i + 0.5f) * step
            val y = gy(x, w, top, sag, segs)
            val sz = 8f * d
            val sway = sin(t * 1.3f + i * 0.7f) * 2f * d
            tmp.reset()
            tmp.moveTo(x - sz, y)
            tmp.lineTo(x + sz, y)
            tmp.lineTo(x + sway, y + sz * 2.1f)
            tmp.close()
            p.color = colors[i % colors.size]
            p.alpha = 215
            cv.drawPath(tmp, p)
        }
    }

    // ---------- Novruz: tonqal qığılcımları ----------

    private fun embers(cv: Canvas, w: Float, h: Float, t: Float) {
        p.style = Paint.Style.FILL
        for (side in 0..1) {
            val bx = if (side == 0) w * 0.05f else w * 0.95f
            p.shader = fireGlow
            p.alpha = (70 + 30 * sin(t * 2.3f + side * 1.7f)).toInt().coerceIn(0, 255)
            blob(cv, bx, h, 170f * d)
            p.shader = null
            for (i in 0 until 28) {
                val j = i + 32 * side
                val u = (ry[j] + t * 0.16f * (0.6f + rs[j] * 0.5f)) % 1f
                val x = bx + (rx[j] - 0.5f) * 70f * d * (0.3f + u) + sin(t * rs[j] * 2f + rp[j]) * 12f * d * u
                val y = h - u * h * 0.5f
                p.color = if (j % 2 == 0) 0xFFFF8A3D.toInt() else 0xFFFFD04D.toInt()
                p.alpha = (230 * (1f - u)).toInt().coerceIn(0, 255)
                cv.drawCircle(x, y, (0.7f + 2.2f * (1f - u)) * d, p)
            }
        }
    }

    // ---------- milli bayramlar: konfeti ----------

    private fun confetti(cv: Canvas, w: Float, h: Float, t: Float) {
        p.style = Paint.Style.FILL
        p.shader = null
        for (i in 0 until 46) {
            val yy = (ry[i] + t * 0.09f * (0.6f + rs[i] * 0.5f)) % 1f
            val y = yy * (h + 30f * d) - 15f * d
            val x = ((rx[i] * w + sin(t * rs[i] + rp[i]) * 26f * d) % w + w) % w
            val flip = 0.25f + 0.75f * abs(cos(t * 1.6f * rs[i] + rp[i]))
            cv.save()
            cv.translate(x, y)
            cv.rotate((t * 50f * rs[i] + rp[i] * 57f) % 360f)
            cv.scale(4f * d, 6f * d * flip)
            p.color = flagColors[i % flagColors.size]
            p.alpha = 225
            cv.drawRect(-0.5f, -0.8f, 0.5f, 0.8f, p)
            cv.restore()
        }
    }

    // ---------- Yeni il: qar + işıq zənciri ----------

    private fun snow(cv: Canvas, w: Float, h: Float, t: Float) {
        p.style = Paint.Style.FILL
        p.shader = null
        p.color = 0xFFFFFFFF.toInt()
        for (i in 0 until 60) {
            val y = ((ry[i] + t * (0.05f + 0.07f * rs[i])) % 1f) * h
            val x = ((rx[i] * w + sin(t * rs[i] * 0.8f + rp[i]) * 24f * d) % w + w) % w
            p.alpha = (140 + 60 * rs[i]).toInt().coerceIn(0, 255)
            cv.drawCircle(x, y, (1.2f + rs[i] * 1.8f) * d, p)
        }
    }

    private fun lights(cv: Canvas, w: Float, t: Float) {
        val segs = 6
        val top = 4f * d
        val sag = 26f * d
        string(cv, w, top, sag, segs, 0x99A0A0A0.toInt())
        val step = 24f * d
        val cnt = (w / step).toInt()
        p.style = Paint.Style.FILL
        for (i in 0 until cnt) {
            val x = (i + 0.5f) * step
            val y = gy(x, w, top, sag, segs) + 5f * d
            val k = i % 4
            val a = 0.45f + 0.55f * (0.5f + 0.5f * sin(t * 2.2f + i * 1.7f))
            p.shader = bulbGlow[k]
            p.alpha = (210 * a).toInt().coerceIn(0, 255)
            blob(cv, x, y, 13f * d)
            p.shader = null
            p.color = bulbColors[k]
            p.alpha = (255 * a).toInt().coerceIn(0, 255)
            cv.drawCircle(x, y, 3.3f * d, p)
        }
    }

    // ---------- Yarpaq / ləçək ----------

    private fun flutter(cv: Canvas, w: Float, h: Float, t: Float, colors: IntArray, count: Int, size: Float, speed: Float) {
        p.style = Paint.Style.FILL
        p.shader = null
        for (i in 0 until count) {
            val yy = (ry[i] + t * speed * (0.6f + 0.5f * rs[i])) % 1f
            val y = yy * (h + 40f * d) - 20f * d
            val x = ((rx[i] * w + sin(t * 0.7f * rs[i] + rp[i]) * 40f * d + yy * 70f * d) % w + w) % w
            val s = size * d * (0.7f + 0.4f * rs[i])
            val flip = 0.35f + 0.65f * abs(cos(t * 0.8f * rs[i] + rp[i]))
            cv.save()
            cv.translate(x, y)
            cv.rotate((t * 30f * rs[i] + rp[i] * 57f) % 360f)
            cv.scale(s * flip * 0.8f, s)
            p.color = colors[i % colors.size]
            p.alpha = 220
            cv.drawPath(leaf, p)
            cv.restore()
        }
    }

    // ---------- Dini bayramlar: aypara, ulduzlar, fənərlər ----------

    private fun lanterns(cv: Canvas, w: Float, h: Float, t: Float) {
        p.style = Paint.Style.FILL
        p.shader = null

        // aypara
        cv.save()
        cv.translate(w * 0.5f, 74f * d)
        cv.rotate(-18f)
        cv.scale(24f * d, 24f * d)
        p.color = 0xFFFFD36B.toInt()
        p.alpha = 235
        cv.drawPath(crescent, p)
        cv.restore()
        // yanıb-sönən ulduzlar
        for (i in 0 until 6) {
            val sx = w * 0.5f + (-60f + i * 26f) * d
            val sy = (36f + 34f * ((i * 7) % 5) / 4f) * d
            p.color = 0xFFFFF1B0.toInt()
            p.alpha = (120 + 120 * sin(t * 2f * rs[i] + rp[i])).toInt().coerceIn(40, 255)
            cv.drawCircle(sx, sy, (1.3f + rs[i]) * d, p)
        }
        // sallanan fənərlər
        for (i in 0 until 4) {
            val x = w * (0.22f + 0.19f * i) + sin(t * 0.9f + i * 1.7f) * 5f * d
            val len = (46f + 34f * (i % 2)) * d
            p.color = 0xFFC9B37E.toInt()
            p.alpha = 160
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1.2f * d
            cv.drawLine(w * (0.22f + 0.19f * i), 0f, x, len, p)
            p.style = Paint.Style.FILL
            p.shader = goldGlow
            p.alpha = (95 + 55 * sin(t * 1.6f + i)).toInt().coerceIn(0, 255)
            blob(cv, x, len + 16f * d, 48f * d)
            p.shader = null
            p.color = 0xFF8A5A1A.toInt(); p.alpha = 240
            cv.drawRect(x - 6f * d, len - 4f * d, x + 6f * d, len, p)
            rect.set(x - 9f * d, len, x + 9f * d, len + 32f * d)
            p.color = 0xFFE8B04A.toInt(); p.alpha = 240
            cv.drawRoundRect(rect, 6f * d, 6f * d, p)
            rect.set(x - 4f * d, len + 6f * d, x + 4f * d, len + 26f * d)
            p.color = 0xFFFFF1B0.toInt()
            p.alpha = (190 + 60 * sin(t * 2.4f + i)).toInt().coerceIn(0, 255)
            cv.drawRoundRect(rect, 3f * d, 3f * d, p)
        }
    }

    // ---------- Halloween: yarasalar, balqabaqlar, kabuslar ----------

    private fun halloween(cv: Canvas, w: Float, h: Float, t: Float) {
        p.style = Paint.Style.FILL
        p.shader = null

        // kabuslar (yavaş üzür)
        for (i in 0 until 2) {
            val x = ((rx[i + 40] + t * 0.012f * (0.6f + rs[i + 40])) % 1.2f - 0.1f) * w
            val y = h * (0.38f + 0.2f * i) + sin(t * 0.8f + rp[i + 40]) * 16f * d
            val sz = (16f + 6f * i) * d
            cv.save(); cv.translate(x, y); cv.scale(sz, sz)
            p.color = 0xFFFFFFFF.toInt(); p.alpha = (95 + 30 * sin(t * 1.1f + i)).toInt().coerceIn(0, 255)
            cv.drawPath(ghost, p)
            p.color = 0xFF202030.toInt(); p.alpha = 190
            cv.drawCircle(-0.35f, -0.15f, 0.15f, p)
            cv.drawCircle(0.35f, -0.15f, 0.15f, p)
            cv.drawOval(-0.14f, 0.12f, 0.14f, 0.45f, p)
            cv.restore()
        }

        // yarasalar (qanad çırpır)
        for (i in 0 until 6) {
            val x = ((rx[i + 10] + t * 0.05f * (0.6f + rs[i + 10])) % 1.3f - 0.15f) * w
            val y = (0.12f + 0.5f * ry[i + 10]) * h + sin(t * 1.3f + rp[i + 10]) * 22f * d
            val s = (9f + 5f * rs[i + 10]) * d
            val flap = 0.25f + 0.75f * abs(sin(t * 8f * rs[i + 10] + rp[i + 10]))
            p.color = 0xFF3A2552.toInt(); p.alpha = 240
            cv.save(); cv.translate(x, y); cv.scale(s, s)
            cv.save(); cv.scale(1f, flap); cv.drawPath(bigWing, p); cv.restore()
            cv.save(); cv.scale(-1f, flap); cv.drawPath(bigWing, p); cv.restore()
            cv.drawOval(-0.3f, -0.25f, 0.3f, 0.55f, p)
            tmp.reset(); tmp.moveTo(-0.28f, -0.15f); tmp.lineTo(-0.2f, -0.55f); tmp.lineTo(-0.05f, -0.25f); tmp.close()
            cv.drawPath(tmp, p)
            tmp.reset(); tmp.moveTo(0.28f, -0.15f); tmp.lineTo(0.2f, -0.55f); tmp.lineTo(0.05f, -0.25f); tmp.close()
            cv.drawPath(tmp, p)
            p.color = 0xFFFF5040.toInt(); p.alpha = 255
            cv.drawCircle(-0.12f, -0.05f, 0.06f, p); cv.drawCircle(0.12f, -0.05f, 0.06f, p)
            cv.restore()
        }

        // sallanan balqabaqlar
        for (i in 0 until 3) {
            val bx = w * (0.30f + 0.28f * i)
            val len = (40f + 26f * ((i + 1) % 3)) * d
            val x = bx + sin(t * 0.8f + i * 2f) * 6f * d
            val y = len
            p.color = 0xFF6B5A3A.toInt(); p.alpha = 170
            p.style = Paint.Style.STROKE; p.strokeWidth = 1.3f * d
            cv.drawLine(bx, 0f, x, y - 16f * d, p)
            p.style = Paint.Style.FILL
            val flick = 0.75f + 0.25f * sin(t * 7f + i * 3.1f) * sin(t * 3.3f + i)
            p.shader = fireGlow; p.alpha = (110 * flick).toInt().coerceIn(0, 255)
            blob(cv, x, y, 52f * d)
            p.shader = null
            // gövdə: üç dilim
            p.color = 0xFFE8731A.toInt(); p.alpha = 255
            cv.drawOval(x - 24f * d, y - 17f * d, x + 24f * d, y + 17f * d, p)
            p.color = 0xFFF28A2E.toInt()
            cv.drawOval(x - 15f * d, y - 18f * d, x + 15f * d, y + 18f * d, p)
            p.color = 0xFFFFA04A.toInt()
            cv.drawOval(x - 6f * d, y - 18f * d, x + 6f * d, y + 18f * d, p)
            // gövdə
            p.color = 0xFF3F7A2A.toInt()
            cv.drawRect(x - 2.5f * d, y - 24f * d, x + 2.5f * d, y - 16f * d, p)
            // üz
            p.color = 0xFFFFD04D.toInt(); p.alpha = (255 * flick).toInt().coerceIn(0, 255)
            tmp.reset(); tmp.moveTo(x - 13f * d, y - 5f * d); tmp.lineTo(x - 5f * d, y - 5f * d); tmp.lineTo(x - 9f * d, y - 12f * d); tmp.close()
            cv.drawPath(tmp, p)
            tmp.reset(); tmp.moveTo(x + 13f * d, y - 5f * d); tmp.lineTo(x + 5f * d, y - 5f * d); tmp.lineTo(x + 9f * d, y - 12f * d); tmp.close()
            cv.drawPath(tmp, p)
            tmp.reset()
            tmp.moveTo(x - 14f * d, y + 3f * d)
            tmp.lineTo(x - 9f * d, y + 11f * d); tmp.lineTo(x - 4f * d, y + 5f * d)
            tmp.lineTo(x, y + 12f * d); tmp.lineTo(x + 4f * d, y + 5f * d)
            tmp.lineTo(x + 9f * d, y + 11f * d); tmp.lineTo(x + 14f * d, y + 3f * d)
            tmp.close()
            cv.drawPath(tmp, p)
        }
    }
}
