package az.keymapper;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;

public class CoreService extends Service {

    @Override
    public void onCreate() {
        super.onCreate();
        try {
            Notification n;
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                nm.createNotificationChannel(new NotificationChannel("km", "Key Mapper", NotificationManager.IMPORTANCE_MIN));
                n = new Notification.Builder(this, "km").setContentTitle("Key Mapper işləyir")
                        .setSmallIcon(android.R.drawable.ic_menu_manage).build();
            } else {
                n = new Notification.Builder(this).setContentTitle("Key Mapper işləyir")
                        .setSmallIcon(android.R.drawable.ic_menu_manage).build();
            }
            startForeground(1, n);
        } catch (Throwable ignored) { }
        Core.start(getApplicationContext());
        schedule(this, 60000);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Core.start(getApplicationContext());
        return START_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        schedule(this, 1500);
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        schedule(this, 1500);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    /** Xidməti (yenidən) başladır və növbəti yoxlamanı planlaşdırır. */
    static void begin(Context c) {
        Core.start(c);
        try {
            Intent i = new Intent(c, CoreService.class);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
            else c.startService(i);
        } catch (Throwable ignored) { }
        schedule(c, 60000);
    }

    static void schedule(Context c, long ms) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(ALARM_SERVICE);
            Intent i = new Intent(c, BootReceiver.class).setAction("az.keymapper.PING");
            int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
            PendingIntent pi = PendingIntent.getBroadcast(c, 1, i, fl);
            long at = SystemClock.elapsedRealtime() + ms;
            if (Build.VERSION.SDK_INT >= 23) {
                try { am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pi); }
                catch (Throwable t) { am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pi); }
            }
            else am.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pi);
        } catch (Throwable ignored) { }
    }
}
