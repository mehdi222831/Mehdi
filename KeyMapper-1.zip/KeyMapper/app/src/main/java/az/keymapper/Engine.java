package az.keymapper;

import android.util.SparseArray;
import android.view.KeyEvent;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

/** Düymə qaydalarının məntiqi. */
final class Engine {
    private static final ScheduledExecutorService T = Executors.newSingleThreadScheduledExecutor(new ThreadFactory() {
        @Override public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "km-timer");
            t.setPriority(Thread.MAX_PRIORITY);
            t.setDaemon(true);
            return t;
        }
    });

    private static final SparseArray<St> S = new SparseArray<>();

    private static final class St {
        boolean down, longFired, second;
        int rep;
        ScheduledFuture<?> hold, lng, click;
    }

    /** true qaytarırsa hadisə udulur (sistemə keçmir). */
    static boolean onKey(KeyEvent e) {
        if (KeyService.capture) return false;
        if (e.getDeviceId() == -1) return false; // bizim yeritdiyimiz hadisələr
        Rule r = Prefs.find(e.getKeyCode());
        if (r == null || !Core.ready()) return false;
        int a = e.getAction();
        if (a != KeyEvent.ACTION_DOWN && a != KeyEvent.ACTION_UP) return true;
        boolean down = a == KeyEvent.ACTION_DOWN;
        synchronized (Engine.class) {
            St st = S.get(r.source);
            if (st == null) {
                st = new St();
                S.put(r.source, st);
            }
            if (r.type == Rule.APP) appRule(r, st, down);
            else if (r.type == Rule.KEY) keyRule(r, st, down);
            else multi(r, st, down);
        }
        return true;
    }

    private static void appRule(Rule r, St s, boolean down) {
        if (down) {
            if (s.down) return;
            s.down = true;
            Core.switchApp(r.pkg, r.kill);
        } else {
            s.down = false;
        }
    }

    private static void keyRule(Rule r, final St s, boolean down) {
        final int tgt = r.target;
        if (down) {
            if (s.down) return; // fiziki təkrarları yoxla-at
            s.down = true;
            s.rep = 0;
            Injector.key(0, tgt, 0, 0);
            if (Prefs.selfRepeat) {
                s.hold = T.scheduleAtFixedRate(new Runnable() {
                    @Override public void run() {
                        int n;
                        synchronized (Engine.class) {
                            if (!s.down) return;
                            n = ++s.rep;
                        }
                        Injector.key(0, tgt, n, 0);
                    }
                }, Prefs.holdDelay, Prefs.holdInt, TimeUnit.MILLISECONDS);
            }
        } else {
            if (!s.down) return;
            s.down = false;
            cancel(s.hold);
            s.hold = null;
            Injector.key(1, tgt, 0, 0);
        }
    }

    private static void multi(Rule r, final St s, boolean down) {
        final int tgt = r.target;
        if (down) {
            if (s.down) return;
            s.down = true;
            s.longFired = false;
            s.second = (s.click != null && s.click.cancel(false));
            s.click = null;
            if (r.pkg != null && !r.pkg.isEmpty()) {
                final String pkg = r.pkg;
                s.lng = T.schedule(new Runnable() {
                    @Override public void run() {
                        synchronized (Engine.class) {
                            if (!s.down || s.longFired) return;
                            s.longFired = true;
                            s.second = false;
                        }
                        Core.launch(pkg);
                    }
                }, Prefs.longMs, TimeUnit.MILLISECONDS);
            }
        } else {
            if (!s.down) return;
            s.down = false;
            cancel(s.lng);
            s.lng = null;
            if (s.longFired) return;
            if (s.second) {
                s.second = false;
                longPress(tgt);
            } else {
                s.click = T.schedule(new Runnable() {
                    @Override public void run() { Injector.tap(tgt); }
                }, Prefs.dblMs, TimeUnit.MILLISECONDS);
            }
        }
    }

    /** DPAD_CENTER-in uzun basılması: down, 600ms-dən sonra repeat=1, sonra up. */
    private static void longPress(final int tgt) {
        Injector.key(0, tgt, 0, 0);
        T.schedule(new Runnable() {
            @Override public void run() { Injector.key(0, tgt, 1, 0); }
        }, 600, TimeUnit.MILLISECONDS);
        T.schedule(new Runnable() {
            @Override public void run() { Injector.key(1, tgt, 0, 0); }
        }, 720, TimeUnit.MILLISECONDS);
    }

    private static void cancel(ScheduledFuture<?> f) {
        if (f != null) f.cancel(false);
    }
}
