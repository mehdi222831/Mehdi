package az.keymapper;

import org.json.JSONObject;

final class Rule {
    static final int KEY = 0;    // başqa düymə kimi apar (basılı saxla = davamlı)
    static final int MULTI = 1;  // tək / ikiqat / uzun basma
    static final int APP = 2;    // tək klik: tətbiq aç + başqa tətbiqi məcburi dayandır

    int source;
    int type = KEY;
    int target;
    String pkg = "";
    String kill = "";

    static Rule make(int source, int type, int target) {
        Rule r = new Rule();
        r.source = source;
        r.type = type;
        r.target = target;
        return r;
    }

    Rule copy() {
        Rule r = make(source, type, target);
        r.pkg = pkg;
        r.kill = kill;
        return r;
    }

    JSONObject toJson() throws Exception {
        JSONObject o = new JSONObject();
        o.put("s", source);
        o.put("t", type);
        o.put("g", target);
        o.put("p", pkg);
        o.put("k", kill);
        return o;
    }

    static Rule fromJson(JSONObject o) {
        Rule r = new Rule();
        r.source = o.optInt("s");
        r.type = o.optInt("t");
        r.target = o.optInt("g");
        r.pkg = o.optString("p", "");
        r.kill = o.optString("k", "");
        return r;
    }
}
