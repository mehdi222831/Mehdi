package az.nowtv

import android.content.Context
import android.util.Base64
import android.webkit.CookieManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLDecoder
import java.util.concurrent.TimeUnit

data class StreamLink(
    val url: String,
    val headers: Map<String, String>,
    val hls: Boolean,
    val verified: Boolean
)

object LinkExtractor {

    const val UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private val IC = RegexOption.IGNORE_CASE

    // tam link: https://host/path/x.m3u8?tkn=...  və ya //host/...
    private val RE_FULL = Regex(
        """(?:https?:)?//[A-Za-z0-9.\-]+(?::\d+)?/[^\s"'<>\\`]*?\.(?:m3u8|ts)(?![A-Za-z0-9_])(?:\?[^\s"'<>\\`]*)?""", IC
    )
    // sxemsiz link: maden.canlitvizle.tv/foxtv-114994.ts?tkn=...
    private val RE_BARE = Regex(
        """[A-Za-z0-9\-]+(?:\.[A-Za-z0-9\-]+)*\.canlitvizle\.tv/[^\s"'<>\\`]*?\.(?:m3u8|ts)(?![A-Za-z0-9_])(?:\?[^\s"'<>\\`]*)?""", IC
    )
    private val RE_ENC = Regex("""https?%3A%2F%2F[^\s"'&<>]+""", IC)
    private val RE_B64 = Regex("""["']([A-Za-z0-9+/]{40,}={0,2})["']""")
    private val RE_SRC = Regex("""<(?:script|iframe)[^>]+src\s*=\s*["']([^"']+)["']""", IC)
    private val RE_ENDPOINT = Regex(
        """["']((?:https?:)?//[^"'\s<>]+|/[^"'\s<>]*)["']""", IC
    )
    private val ENDPOINT_HINT = Regex("""(api|token|stream|player|embed|source|getlink|m3u8|live)""", IC)
    private val STATIC_EXT = Regex("""\.(css|png|jpe?g|gif|svg|webp|ico|woff2?|ttf|eot|map|mp4)(\?|$)""", IC)
    private val SKIP_HOSTS = listOf(
        "google", "gstatic", "facebook", "doubleclick", "cloudflareinsights", "jquery",
        "bootstrap", "fontawesome", "adsbygoogle", "yandex", "clarity.ms", "histats", "twitter"
    )

    fun short(u: String) = if (u.length > 90) u.take(90) + "…" else u

    private fun unescape(s: String) = s
        .replace("\\/", "/")
        .replace("\\u002F", "/", true)
        .replace("\\u0026", "&", true)
        .replace("\\u003D", "=", true)
        .replace("\\u003F", "?", true)
        .replace("\\x2F", "/", true)
        .replace("&#x2F;", "/", true)
        .replace("&amp;", "&")

    private fun norm(u: String): String {
        val s = u.trim().trimEnd(')', ';', ',', '.', '\\')
        return when {
            s.startsWith("//") -> "https:$s"
            s.startsWith("http", true) -> s
            else -> "https://$s"
        }
    }

    private fun valid(u: String): Boolean {
        val l = u.lowercase()
        return l.contains(".m3u8") || (l.contains("tkn=") && l.contains(".ts"))
    }

    private fun score(u: String): Int {
        val l = u.lowercase()
        return (if (l.contains(".m3u8")) 2 else 0) + (if (l.contains("tkn=")) 1 else 0)
    }

    fun rank(urls: List<String>) = urls.distinct().sortedByDescending { score(it) }

    /** Mətn içində (HTML / JS / JSON) bütün m3u8 / tokenli .ts linklərini axtarır. */
    fun scan(raw: String): List<String> {
        val texts = mutableListOf(unescape(raw))
        // %2F ilə kodlanmış linklər
        RE_ENC.findAll(raw).take(100).forEach { m ->
            runCatching { texts += unescape(URLDecoder.decode(m.value, "UTF-8")) }
        }
        // base64 içində gizlədilmiş linklər (atob("..."))
        RE_B64.findAll(raw).take(300).forEach { m ->
            runCatching {
                val d = String(Base64.decode(m.groupValues[1], Base64.DEFAULT))
                if (d.contains("m3u8") || d.contains("tkn=") || d.contains("http")) texts += unescape(d)
            }
        }
        val out = LinkedHashSet<String>()
        for (t in texts) {
            RE_FULL.findAll(t).forEach { out += norm(it.value) }
            RE_BARE.findAll(t).forEach { out += norm(it.value) }
        }
        return out.filter { valid(it) }
    }

    private fun httpGet(url: String, referer: String): String? = try {
        val req = Request.Builder().url(url)
            .header("User-Agent", UA)
            .header("Referer", referer)
            .header("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.8")
            .build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) null else r.body?.string()?.take(3_000_000)
        }
    } catch (e: Exception) {
        null
    }

    private fun staticScan(pageUrl: String, log: (String) -> Unit): List<String> {
        val found = LinkedHashSet<String>()
        val visited = HashSet<String>()
        var endpointBudget = 6

        fun crawl(url: String, depth: Int, referer: String) {
            if (depth > 2 || visited.size >= 40 || !visited.add(url)) return
            val body = httpGet(url, referer) ?: return
            log("   skan: ${short(url)} (${body.length / 1024} KB)")
            found += scan(body)
            val base = url.toHttpUrlOrNull() ?: return

            // script və iframe src
            RE_SRC.findAll(body).map { it.groupValues[1] }.forEach { href ->
                val abs = base.resolve(unescape(href))?.toString() ?: return@forEach
                if (SKIP_HOSTS.none { abs.contains(it, true) }) crawl(abs, depth + 1, url)
            }

            // JS içindəki API / token endpoint-ləri
            if (depth >= 1) {
                RE_ENDPOINT.findAll(unescape(body)).map { it.groupValues[1] }.forEach { e ->
                    if (endpointBudget <= 0) return@forEach
                    if (!ENDPOINT_HINT.containsMatchIn(e) || STATIC_EXT.containsMatchIn(e) || e.endsWith(".js")) return@forEach
                    val abs = (if (e.startsWith("//")) "https:$e" else base.resolve(e)?.toString()) ?: return@forEach
                    val host = abs.toHttpUrlOrNull()?.host ?: return@forEach
                    if (!host.endsWith("canlitvizle.tv")) return@forEach
                    if (visited.contains(abs)) return@forEach
                    endpointBudget--
                    crawl(abs, depth + 1, url)
                }
            }
        }

        crawl(pageUrl, 0, pageUrl)
        return found.toList()
    }

    fun headersFor(pageUrl: String, streamUrl: String?): Map<String, String> {
        val b = pageUrl.toHttpUrlOrNull()
        val origin = if (b != null) "${b.scheme}://${b.host}" else "https://blog.canlitvizle.tv"
        val m = linkedMapOf("Referer" to "$origin/", "Origin" to origin)
        val cookie = runCatching { streamUrl?.let { CookieManager.getInstance().getCookie(it) } }.getOrNull()
        if (!cookie.isNullOrBlank()) m["Cookie"] = cookie
        return m
    }

    /** (ok, hls) qaytarır */
    private fun probe(url: String, headers: Map<String, String>): Pair<Boolean, Boolean> = try {
        val rb = Request.Builder().url(url).header("User-Agent", UA)
        headers.forEach { (k, v) -> rb.header(k, v) }
        client.newCall(rb.build()).execute().use { r ->
            if (!r.isSuccessful) {
                Pair(false, false)
            } else {
                val src = r.body?.source()
                if (src == null) {
                    Pair(true, false)
                } else {
                    src.request(64)
                    val head = src.buffer.snapshot().utf8()
                    Pair(true, head.trimStart().startsWith("#EXTM3U"))
                }
            }
        }
    } catch (e: Exception) {
        Pair(false, false)
    }

    // .ts linkinin m3u8 variantını da yoxla
    private fun expand(urls: List<String>): List<String> {
        val out = LinkedHashSet<String>()
        val tsRe = Regex("""\.ts(?=\?|$)""", IC)
        for (u in urls) {
            val alt = u.replaceFirst(tsRe, ".m3u8")
            if (alt != u) out += alt
            out += u
        }
        return out.toList()
    }

    private suspend fun pick(pageUrl: String, urls: List<String>, log: (String) -> Unit): StreamLink? =
        withContext(Dispatchers.IO) {
            for (u in expand(rank(urls)).take(10)) {
                val h = headersFor(pageUrl, u)
                val (ok, hls) = probe(u, h)
                log("   yoxlama ${if (ok) "✅" else "❌"} ${short(u)}")
                if (ok) return@withContext StreamLink(u, h, hls || u.lowercase().contains(".m3u8"), true)
            }
            null
        }

    suspend fun run(ctx: Context, pageUrl: String, log: (String) -> Unit): StreamLink? {
        log("1/2 Səhifə və JS faylları skan edilir…")
        val staticFound = withContext(Dispatchers.IO) { staticScan(pageUrl, log) }
        log("   statik tapıntı: ${staticFound.size}")
        pick(pageUrl, staticFound, log)?.let { return it }

        log("2/2 WebView ilə şəbəkə sorğuları dinlənir (maks. 30 san)…")
        val sniffed = WebViewSniffer(ctx).sniff(pageUrl, 30_000, log)
        log("   şəbəkə tapıntısı: ${sniffed.size}")
        pick(pageUrl, sniffed, log)?.let { return it }

        val first = rank(sniffed + staticFound).firstOrNull() ?: return null
        log("⚠ Link tapıldı, amma yoxlama keçmədi (403 / IP uyğunsuzluğu ola bilər).")
        return StreamLink(first, headersFor(pageUrl, first), first.lowercase().contains(".m3u8"), false)
    }
}
