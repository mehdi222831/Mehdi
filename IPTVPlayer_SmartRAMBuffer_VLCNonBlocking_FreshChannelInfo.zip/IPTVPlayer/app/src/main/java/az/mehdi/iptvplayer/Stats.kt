package az.mehdi.iptvplayer

import android.net.TrafficStats
import android.os.Process
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URI
import java.util.Locale

/** Ekranda göstərilən yayım məlumatı. level: 0 = 🟢, 1 = 🟡, 2 = 🔴. Naməlum dəyərlər: width/height 0, bufferMs/bps -1. */
class PlayerStats(
    val width: Int, val height: Int, val bufferMs: Long, val level: Int, val bps: Long,
    val player: String = "",
    val bitrate: Long = -1L
)

/** Endirmə sürəti: yığılan bayt sayğacından son ~5 saniyənin orta sürəti (bit/san). Yalnız UI thread-i. */
class SpeedMeter(private val windowMs: Long = 5_000L) {
    private val times = ArrayDeque<Long>()
    private val totals = ArrayDeque<Long>()

    fun reset() { times.clear(); totals.clear() }

    fun sample(total: Long, now: Long): Long {
        if (total < 0) return -1
        times.addLast(now); totals.addLast(total)
        while (times.size > 2 && now - times.first() > windowMs) { times.removeFirst(); totals.removeFirst() }
        val dt = now - times.first()
        if (times.size < 2 || dt < 900) return -1
        return ((total - totals.first()) * 8000L / dt).coerceAtLeast(0L)
    }
}

/** Bu tətbiqin şəbəkədən qəbul etdiyi ümumi bayt (cihaz dəstəkləmirsə -1). */
fun uidRxBytes(): Long {
    val v = TrafficStats.getUidRxBytes(Process.myUid())
    return if (v == TrafficStats.UNSUPPORTED.toLong()) -1L else v
}

/** Kanal adının yanında göstərilən pleyer işarəsi: 💙 = Media3 (ExoPlayer), 🧡 = VLC. */
fun playerIcon(s: PlayerStats): String = s.player

private fun fmtRate(bps: Long): String = when {
    bps < 0 -> "–"
    bps >= 1_000_000 -> String.format(Locale.US, "%.1f Mbit/s", bps / 1_000_000.0)
    else -> "${bps / 1000} kbit/s"
}

/**
 * Pinq: yayım serverinə TCP qoşulma vaxtı (ms), ~5 s-dən bir ölçülür. Ayrıca thread-də işləyir.
 * Server ünvanı yayım linkindən götürülür; udp/rtp kimi bağlantısız linklərdə -1 ("–").
 */
class PingMeter {
    @Volatile var ms: Long = -1L
        private set
    @Volatile private var gen = 0

    fun start(url: String) {
        val g = ++gen
        ms = -1L
        Thread {
          try {
            val addr = runCatching {
                val u = URI(url.trim())
                val host = u.host ?: return@runCatching null
                val port = if (u.port > 0) u.port else when (u.scheme?.lowercase()) {
                    "http" -> 80; "https" -> 443; "rtsp" -> 554; "rtmp" -> 1935; else -> -1
                }
                if (port <= 0) null else InetSocketAddress(InetAddress.getByName(host), port)
            }.getOrNull()
            while (g == gen) {
                if (addr == null) { ms = -1L; return@Thread }
                val t0 = System.nanoTime()
                val ok = runCatching { Socket().use { it.connect(addr, 2_500) } }.isSuccess
                if (g != gen) return@Thread
                ms = if (ok) ((System.nanoTime() - t0) / 1_000_000L).coerceAtLeast(1L) else -1L
                try { Thread.sleep(5_000L) } catch (_: InterruptedException) { return@Thread }
            }
          } catch (_: Throwable) { ms = -1L }
        }.apply { isDaemon = true; start() }
    }

    fun stop() { gen++; ms = -1L }
}

/** Başlıq sətri üçün: pleyer işarəsi (💙 Media3, 🧡 VLC). */
fun playerIconOf(s: PlayerStats): String = s.player.ifBlank { "\uD83E\uDDE1" }

/** Başlıq sətri üçün: bufer vəziyyəti 🟢🟡🔴. */
fun bufferDot(s: PlayerStats): String = when (s.level) { 0 -> "🟢"; 1 -> "🟡"; else -> "🔴" }

/** Başlıq sətri üçün: ölçü (məs. 1920x1080), məlum deyilsə "–". */
fun resText(s: PlayerStats): String = if (s.width > 0 && s.height > 0) "${s.width}x${s.height}" else "–"

/** EPG sətri ilə üzbəüz, sağda, bir sətirdə: endirmə sürəti 🛰️ pinq */
fun formatRes(s: PlayerStats, pingMs: Long): String {
    val ping = if (pingMs < 0) "–" else "$pingMs ms"
    return "${fmtRate(s.bps)}  \uD83D\uDEF0\uFE0F $ping"
}
