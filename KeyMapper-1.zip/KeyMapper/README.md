# Key Mapper (TV box)

Quraşdırma: APK-nı qurun → Developer options-da USB debugging (və varsa "ADB over network") açın →
Key Mapper-i açın → TV-də çıxan "USB debugging icazəsi" pəncərəsində "Həmişə icazə ver" seçin.
Tətbiq ADB ilə 127.0.0.1:5555 və ya öz IP:5555-ə qoşulur, Əlçatanlıq xidmətini özü aktiv edir,
batareya optimallaşdırmasından çıxarır və düymə serverini işə salır.

Build: `gradle assembleDebug` (və ya GitHub Actions: .github/workflows/build.yml).
