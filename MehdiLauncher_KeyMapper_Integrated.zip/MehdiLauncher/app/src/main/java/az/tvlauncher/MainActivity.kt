package az.tvlauncher

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.media.tv.TvContract
import android.media.tv.TvInputInfo
import android.media.tv.TvInputManager
import android.net.ConnectivityManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.content.pm.ApplicationInfo
import android.content.pm.ResolveInfo
import android.text.SpannableString
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import android.view.KeyEvent
import java.util.Calendar
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.app.ActivityManager
import android.net.TrafficStats
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.widget.HorizontalScrollView
import android.widget.ProgressBar
import android.widget.Toast
import java.util.TimeZone
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Hour(val label: String, val code: Int, val day: Boolean, val temp: Int, val pop: Int)

class ExcItem(val label: String, val pkg: String, val icon: Drawable?)

class Tile(val label: String, val image: Drawable?, val banner: Boolean, val key: String = "", val action: () -> Unit)

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var temp: TextView
    private lateinit var desc: TextView
    private lateinit var details: TextView
    private lateinit var wifi: ImageView
    private lateinit var apps: RecyclerView
    private lateinit var shortcuts: RecyclerView
    private lateinit var wIcon: ImageView
    private lateinit var bg: WeatherBackground
    private lateinit var forecast: LinearLayout
    private lateinit var weatherBox: View
    private lateinit var hint: TextView
    private lateinit var overlay: View
    private lateinit var hourScroll: HorizontalScrollView
    private lateinit var hourRow: LinearLayout
    private lateinit var sunInfo: TextView
    private lateinit var banner: TextView
    private lateinit var warnInfo: TextView
    private lateinit var sysOverlay: View
    private lateinit var ramText: TextView
    private lateinit var ramBar: ProgressBar
    private lateinit var storText: TextView
    private lateinit var storBar: ProgressBar
    private lateinit var netText: TextView
    private lateinit var devText: TextView
    private var warnings: List<String> = emptyList()
    private var lastRx = -1L
    private var lastTx = -1L
    private var lastT = 0L
    private var lastPollAt = 0L
    private var lastStorageAt = 0L
    private var ramTotal = 0L
    private var ramAvail = 0L
    private var stTotal = 0L
    private var stFree = 0L
    private var downMbps = 0.0
    private var upMbps = 0.0
    private var netType = ""
    private lateinit var content: ViewGroup
    private lateinit var sysMini: TextView
    private lateinit var btnClean: TextView
    private lateinit var btnExc: TextView
    private lateinit var nextHoliday: TextView
    private lateinit var excOverlay: View
    private lateinit var excList: RecyclerView
    private var excSet: MutableSet<String> = mutableSetOf()
    private var prevFocus: View? = null
    private var hours: List<Hour> = emptyList()
    private var sunText = ""
    private var adbRunning = false
    private var cleaningRam = false
    private var lastAutoCleanAt = 0L
    private val autoCleanThreshold = 90
    private val autoCleanCooldownMs = 10 * 60_000L
    private var wCode = 0
    private var wDay: Boolean? = null
    private var moving = false
    private var ignoreUp = false
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }

    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private val dateFmt = SimpleDateFormat("EEEE, d MMMM", Locale("az", "AZ"))

    private val ticker = object : Runnable {
        override fun run() {
            val now = Date()
            val ts = timeFmt.format(now)
            clock.text = ts
            date.text = dateFmt.format(now).replaceFirstChar { it.uppercase() }
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            @Suppress("DEPRECATION")
            wifi.visibility = if (cm.activeNetworkInfo?.isConnected == true) View.VISIBLE else View.INVISIBLE
            val cal = Calendar.getInstance()
            val hf = cal.get(Calendar.HOUR_OF_DAY) + cal.get(Calendar.MINUTE) / 60f
            bg.set(wCode, wDay ?: (hf in 6f..19f), hf)
            updateBanner()
            updateHolidayCountdown()
            pollSys()
            h.postDelayed(this, 1000)
        }
    }
    private val weatherLoop = object : Runnable {
        override fun run() {
            loadWeather()
            h.postDelayed(this, 15 * 60_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        clock = findViewById(R.id.clock)
        date = findViewById(R.id.date)
        nextHoliday = findViewById(R.id.nextHoliday)
        temp = findViewById(R.id.temp)
        desc = findViewById(R.id.desc)
        details = findViewById(R.id.details)
        wifi = findViewById(R.id.wifi)
        wIcon = findViewById(R.id.wicon)
        bg = findViewById(R.id.bg)
        forecast = findViewById(R.id.forecast)
        wIcon.setImageResource(if (Calendar.getInstance().get(Calendar.HOUR_OF_DAY) in 6..18) R.drawable.ic_w_clear_day else R.drawable.ic_w_clear_night)
        weatherBox = findViewById(R.id.weatherBox)
        hint = findViewById(R.id.hint)
        overlay = findViewById(R.id.hourlyOverlay)
        hourScroll = findViewById(R.id.hourScroll)
        hourRow = findViewById(R.id.hourRow)
        sunInfo = findViewById(R.id.sunInfo)
        banner = findViewById(R.id.banner)
        warnInfo = findViewById(R.id.warnInfo)
        sysOverlay = findViewById(R.id.sysOverlay)
        ramText = findViewById(R.id.ramText)
        ramBar = findViewById(R.id.ramBar)
        storText = findViewById(R.id.storText)
        storBar = findViewById(R.id.storBar)
        netText = findViewById(R.id.netText)
        devText = findViewById(R.id.devText)
        sysOverlay.setOnClickListener { closeSys() }
        content = findViewById(R.id.content)
        sysMini = findViewById(R.id.sysMini)
        btnClean = findViewById(R.id.btnClean)
        btnExc = findViewById(R.id.btnExc)
        excOverlay = findViewById(R.id.excOverlay)
        excList = findViewById(R.id.excList)
        excOverlay.setOnClickListener { closeExc() }
        sysMini.setOnClickListener { openSys() }
        btnClean.setOnClickListener { cleanRam() }
        btnExc.setOnClickListener { openExc() }
        excSet = HashSet(prefs.getStringSet("ram_exc", emptySet()) ?: emptySet())
        updateExcButton()
        weatherBox.setOnClickListener { openHourly() }
        weatherBox.setOnFocusChangeListener { _, f -> hint.visibility = if (f) View.VISIBLE else View.INVISIBLE }
        overlay.setOnClickListener { closeHourly() }
        apps = findViewById(R.id.apps)
        shortcuts = findViewById(R.id.shortcuts)
        apps.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        shortcuts.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    // Test üçün (adb): am start -n az.tvlauncher/.MainActivity --es fx newyear   (leaves, petals, novruz, flag, newyear, religious, off, auto)
    //                  am start -n az.tvlauncher/.MainActivity --ei adb_port 5555
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        if (i.hasExtra("fx")) bg.previewFx(i.getStringExtra("fx"))
        if (i.hasExtra("adb_port")) prefs.edit().putInt("adb_port", i.getIntExtra("adb_port", 5555)).remove("adb_fail_at").apply()
    }

    override fun onResume() {
        super.onResume()
        moving = false
        apps.adapter = TileAdapter(appTiles().toMutableList(), R.layout.item_app)
        shortcuts.adapter = TileAdapter(shortcutTiles().toMutableList(), R.layout.item_shortcut)
        h.removeCallbacks(ticker)
        h.post(ticker)
        h.post(weatherLoop)
        ensureDefaultLauncher()
        if (currentFocus == null) apps.post { (apps.getChildAt(0) ?: shortcuts.getChildAt(0))?.requestFocus() }
    }

    override fun onPause() {
        super.onPause()
        // Saat/RAM monitoru arxa planda da işləsin ki, başqa tətbiq açıq olarkən 90% həddi izlənə bilsin.
        h.removeCallbacks(weatherLoop)
        closeSys()
    }

    override fun onDestroy() {
        h.removeCallbacks(ticker)
        h.removeCallbacks(weatherLoop)
        super.onDestroy()
    }

    @Deprecated("Launcher-dən çıxmasın")
    override fun onBackPressed() {}

    // OK düyməsini basılı saxla -> köçürmə rejimi; sol/sağ -> yer dəyiş; OK/Geri -> saxla
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (overlay.visibility == View.VISIBLE) {
            if (e.action == KeyEvent.ACTION_DOWN) {
                when (e.keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> hourScroll.smoothScrollBy(-dp(240), 0)
                    KeyEvent.KEYCODE_DPAD_RIGHT -> hourScroll.smoothScrollBy(dp(240), 0)
                }
            } else if (e.action == KeyEvent.ACTION_UP) {
                when (e.keyCode) {
                    KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> closeHourly()
                }
            }
            return true
        }
        if (sysOverlay.visibility == View.VISIBLE || excOverlay.visibility == View.VISIBLE) {
            if (e.keyCode == KeyEvent.KEYCODE_BACK) {
                if (e.action == KeyEvent.ACTION_UP) { if (excOverlay.visibility == View.VISIBLE) closeExc() else closeSys() }
                return true
            }
            return super.dispatchKeyEvent(e)
        }
        if (!moving) return super.dispatchKeyEvent(e)
        val down = e.action == KeyEvent.ACTION_DOWN
        when (e.keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> { if (down) moveFocused(-1); return true }
            KeyEvent.KEYCODE_DPAD_RIGHT -> { if (down) moveFocused(1); return true }
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> return true
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_BACK -> {
                if (!down) {
                    if (ignoreUp && e.keyCode != KeyEvent.KEYCODE_BACK) { ignoreUp = false; return super.dispatchKeyEvent(e) }
                    endMove()
                }
                return true
            }
        }
        return super.dispatchKeyEvent(e)
    }

    private fun startMove(vh: TileAdapter.VH) {
        moving = true
        ignoreUp = true
        vh.label.text = "‹  Köçür  ›"
        vh.itemView.animate().scaleX(1.2f).scaleY(1.2f).setDuration(120).start()
    }

    private fun moveFocused(d: Int) {
        val child = apps.focusedChild ?: return
        val a = apps.adapter as? TileAdapter ?: return
        val pos = apps.getChildAdapterPosition(child)
        val to = pos + d
        if (pos < 0 || to !in 0 until a.itemCount) return
        a.swap(pos, to)
        apps.scrollToPosition(to)
    }

    private fun endMove() {
        moving = false
        val a = apps.adapter as? TileAdapter ?: return
        prefs.edit().putString("order", a.items.joinToString("\n") { it.key }).apply()
        val child = apps.focusedChild
        val pos = if (child != null) apps.getChildAdapterPosition(child) else -1
        child?.findViewById<TextView>(R.id.label)?.text = a.items.getOrNull(pos)?.label
        child?.animate()?.scaleX(1.1f)?.scaleY(1.1f)?.setDuration(120)?.start()
    }

    private fun launch(i: Intent) {
        try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {}
    }

    private fun appTiles(): List<Tile> {
        val skip = setOf(packageName, "com.android.vending", "com.android.settings", "com.android.tv.settings")
        fun query(cat: String) = packageManager.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(cat), 0
        ).filter { it.activityInfo.packageName !in skip }
        val list = query(Intent.CATEGORY_LEANBACK_LAUNCHER).ifEmpty { query(Intent.CATEGORY_LAUNCHER) }
        val idx = (prefs.getString("order", "") ?: "").split("\n").withIndex().associate { it.value to it.index }
        return list.sortedWith(compareBy<ResolveInfo>({ idx["${it.activityInfo.packageName}/${it.activityInfo.name}"] ?: Int.MAX_VALUE }, { it.loadLabel(packageManager).toString().lowercase() })).map { ri ->
            val ai = ri.activityInfo
            val banner = ai.loadBanner(packageManager) ?: ai.applicationInfo.loadBanner(packageManager)
            Tile(ri.loadLabel(packageManager).toString(), banner ?: ri.loadIcon(packageManager), banner != null, "${ai.packageName}/${ai.name}") {
                launch(Intent(Intent.ACTION_MAIN).setClassName(ai.packageName, ai.name))
            }
        }
    }

    private fun shortcutTiles(): List<Tile> {
        val t = mutableListOf<Tile>()
        t += Tile("Play Store", getDrawable(R.drawable.ic_play), false) {
            (packageManager.getLeanbackLaunchIntentForPackage("com.android.vending")
                ?: packageManager.getLaunchIntentForPackage("com.android.vending"))?.let { launch(it) }
        }
        try {
            val tim = getSystemService(Context.TV_INPUT_SERVICE) as TvInputManager
            tim.tvInputList.filter { it.type == TvInputInfo.TYPE_HDMI }.forEachIndexed { i, info ->
                val name = info.loadCustomLabel(this)?.toString()?.ifBlank { null } ?: "HDMI ${i + 1}"
                t += Tile(name, getDrawable(R.drawable.ic_hdmi), false) {
                    launch(Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput(info.id)))
                }
            }
        } catch (e: Exception) {}
        t += Tile("Key Mapper", null, false) {
            try {
                startActivity(Intent().setClassName(this, "com.mehdi.keymappertv.KeyMapperActivity"))
            } catch (e: Exception) {
                Toast.makeText(this, "Key Mapper açıla bilmədi", Toast.LENGTH_SHORT).show()
            }
        }
        t += Tile("Sistem", getDrawable(R.drawable.ic_system), false) { openSys() }
        t += Tile("Ayarlar", getDrawable(R.drawable.ic_settings), false) { launch(Intent(Settings.ACTION_SETTINGS)) }
        return t
    }

    // ---------- Azərbaycanda növbəti rəsmi bayram / qeyri-iş günü sayğacı ----------
    private data class Holiday(val name: String, val month: Int, val day: Int, val year: Int)

    private fun upcomingHolidays(year: Int): List<Holiday> {
        val items = mutableListOf<Holiday>()
        fun add(name: String, month: Int, day: Int) { items += Holiday(name, month, day, year) }
        add("Yeni il", Calendar.JANUARY, 1)
        add("Yeni il", Calendar.JANUARY, 2)
        add("Ümumxalq Hüzn Günü", Calendar.JANUARY, 20)
        add("Xocalı Soyqırımı Günü", Calendar.FEBRUARY, 26)
        add("Qadınlar Günü", Calendar.MARCH, 8)
        for (d in 20..24) add("Novruz bayramı", Calendar.MARCH, d)
        add("Azərbaycanlıların Soyqırımı Günü", Calendar.MARCH, 31)
        add("Faşizm üzərində Qələbə Günü", Calendar.MAY, 9)
        add("Heydər Əliyevin doğum günü", Calendar.MAY, 10)
        add("Müstəqillik Günü", Calendar.MAY, 28)
        add("Milli Qurtuluş Günü", Calendar.JUNE, 15)
        add("Silahlı Qüvvələr Günü", Calendar.JUNE, 26)
        add("Halloween", Calendar.OCTOBER, 31) // Qeyri-rəsmi tematik gün
        add("Zəfər Günü", Calendar.NOVEMBER, 8)
        add("Dövlət Bayrağı Günü", Calendar.NOVEMBER, 9)
        add("Konstitusiya Günü", Calendar.NOVEMBER, 12)
        add("Milli Dirçəliş Günü", Calendar.NOVEMBER, 17)
        add("Dünya Azərbaycanlılarının Həmrəyliyi Günü", Calendar.DECEMBER, 31)

        // Dini bayramlar hicri təqvimi ilə (Umm əl-Qura) hesablanır.
        if (Build.VERSION.SDK_INT >= 24) {
            try {
                val tz = android.icu.util.TimeZone.getTimeZone("Asia/Baku")
                val hijri = android.icu.util.IslamicCalendar(tz)
                hijri.timeInMillis = System.currentTimeMillis()
                val currentHijriYear = hijri.get(android.icu.util.Calendar.YEAR)
                for (hy in currentHijriYear..(currentHijriYear + 2)) {
                    fun addIslamic(label: String, hm: Int, hd: Int) {
                        val ic = android.icu.util.IslamicCalendar(tz)
                        ic.clear()
                        ic.set(android.icu.util.Calendar.YEAR, hy)
                        ic.set(android.icu.util.Calendar.MONTH, hm)
                        ic.set(android.icu.util.Calendar.DAY_OF_MONTH, hd)
                        val gc = Calendar.getInstance(TimeZone.getTimeZone("Asia/Baku"))
                        gc.timeInMillis = ic.timeInMillis
                        items += Holiday(label, gc.get(Calendar.MONTH), gc.get(Calendar.DAY_OF_MONTH), gc.get(Calendar.YEAR))
                    }
                    addIslamic("Ramazan bayramı", 9, 1) // 1 Şəvval
                    addIslamic("Qurban bayramı", 11, 10) // 10 Zilhiccə
                }
            } catch (_: Exception) { }
        }
        return items
    }

    private fun updateHolidayCountdown() {
        val tz = TimeZone.getTimeZone("Asia/Baku")
        val today = Calendar.getInstance(tz).apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val candidates = (today.get(Calendar.YEAR)..today.get(Calendar.YEAR) + 2)
            .flatMap { upcomingHolidays(it) }
            .mapNotNull { holiday ->
                Calendar.getInstance(tz).apply {
                    clear()
                    set(holiday.year, holiday.month, holiday.day, 0, 0, 0)
                }.takeIf { !it.before(today) }?.let { holiday to it }
            }
            .sortedBy { it.second.timeInMillis }
        val next = candidates.firstOrNull() ?: return
        val days = ((next.second.timeInMillis - today.timeInMillis) / 86_400_000L).toInt()
        val label = if (days == 0) "${next.first.name} bu gündür!" else "${next.first.name} – $days gün qalıb"
        if (nextHoliday.text.toString() != label) {
            nextHoliday.text = label
            nextHoliday.alpha = 0.45f
            nextHoliday.animate().alpha(1f).translationY(0f).setDuration(650).start()
        }
    }

    // ---------- bayram təbriki + hava xəbərdarlığı (dövri banner) ----------

    private fun updateBanner() {
        val greet = bg.greeting()
        val hasG = greet != null
        val n = (if (hasG) 1 else 0) + warnings.size
        if (n == 0) {
            if (banner.visibility != View.GONE) banner.visibility = View.GONE
            return
        }
        val idx = ((SystemClock.uptimeMillis() / 6000L) % n).toInt()
        val txt: String
        val color: Int
        if (hasG && idx == 0) {
            txt = greet!!
            color = if (bg.mourning()) 0xFFFFFFFF.toInt() else 0xFFFFD36B.toInt()
        } else {
            txt = "Xəbərdarlıq: " + warnings[idx - (if (hasG) 1 else 0)]
            color = 0xFFFFA040.toInt()
        }
        if (banner.text.toString() != txt) banner.text = txt
        banner.setTextColor(color)
        if (banner.visibility != View.VISIBLE) banner.visibility = View.VISIBLE
    }

    // ---------- sistem məlumatı (canlı) ----------

    private fun gb(b: Long) = "%.1f".format(b / 1073741824.0)
    private fun mb(b: Long) = if (b >= 1073741824L) "${gb(b)} GB" else "${b / 1048576L} MB"

    @Suppress("DEPRECATION")
    private fun pollSys() {
        val now = SystemClock.elapsedRealtime()
        if (lastPollAt != 0L && now - lastPollAt < 2000L) return
        lastPollAt = now
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        ramTotal = mi.totalMem
        ramAvail = mi.availMem
        val ramPctNow = if (ramTotal > 0) ((ramTotal - ramAvail) * 100 / ramTotal).toInt() else 0
        if (ramPctNow >= autoCleanThreshold && now - lastAutoCleanAt >= autoCleanCooldownMs && !cleaningRam) {
            lastAutoCleanAt = now
            cleanRam(automatic = true)
        }
        if (now - lastStorageAt > 30_000L) {
            lastStorageAt = now
            try {
                val st = StatFs(Environment.getDataDirectory().path)
                stTotal = st.totalBytes
                stFree = st.availableBytes
            } catch (e: Exception) {
            }
        }
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val ni = cm.activeNetworkInfo
        netType = when {
            ni == null || !ni.isConnected -> "Şəbəkə yoxdur"
            ni.type == ConnectivityManager.TYPE_WIFI -> "Wi-Fi"
            ni.type == ConnectivityManager.TYPE_ETHERNET -> "Ethernet"
            else -> ni.typeName
        }
        val dt = (now - lastT).coerceAtLeast(1L) / 1000.0
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        downMbps = if (rx >= 0 && lastRx >= 0) (rx - lastRx) * 8 / 1e6 / dt else 0.0
        upMbps = if (tx >= 0 && lastTx >= 0) (tx - lastTx) * 8 / 1e6 / dt else 0.0
        lastRx = rx; lastTx = tx; lastT = now
        renderMini()
        if (sysOverlay.visibility == View.VISIBLE) renderSys()
    }

    private fun renderMini() {
        val ramPct = if (ramTotal > 0) ((ramTotal - ramAvail) * 100 / ramTotal).toInt() else 0
        val stPct = if (stTotal > 0) ((stTotal - stFree) * 100 / stTotal).toInt() else 0
        sysMini.text = "RAM $ramPct%  •  boş ${mb(ramAvail)}\n" +
            "Yaddaş $stPct%  •  boş ${gb(stFree)} GB\n" +
            (if (netType == "Şəbəkə yoxdur") netType else "$netType  ↓${"%.1f".format(downMbps)}  ↑${"%.1f".format(upMbps)} Mb/s")
        sysMini.setTextColor(if (ramPct >= 85) 0xFFFFA040.toInt() else 0xFFE6E1E3.toInt())
    }

    private fun renderSys() {
        if (ramTotal > 0) {
            val used = ramTotal - ramAvail
            ramText.text = "${gb(used)} / ${gb(ramTotal)} GB istifadədə  •  boş ${mb(ramAvail)}"
            ramBar.progress = (used * 100 / ramTotal).toInt()
        }
        if (stTotal > 0) {
            storText.text = "${gb(stTotal - stFree)} / ${gb(stTotal)} GB istifadədə  •  boş ${gb(stFree)} GB"
            storBar.progress = ((stTotal - stFree) * 100 / stTotal).toInt()
        }
        netText.text = if (netType == "Şəbəkə yoxdur") netType
        else "$netType  •  ↓ ${"%.1f".format(downMbps)} Mb/s   ↑ ${"%.1f".format(upMbps)} Mb/s"
        val sec = SystemClock.elapsedRealtime() / 1000
        devText.text = "${Build.MANUFACTURER} ${Build.MODEL}  •  Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
            "İşləmə müddəti: ${sec / 3600} saat ${sec % 3600 / 60} dəq  •  Default launcher: ${if (DefaultLauncher.isDefault(this)) "bəli" else "xeyr"}"
    }

    private fun openSys() {
        if (sysOverlay.visibility == View.VISIBLE) return
        prevFocus = currentFocus
        lastPollAt = 0L
        pollSys()
        renderSys()
        content.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        sysOverlay.visibility = View.VISIBLE
        btnClean.requestFocus()
    }

    private fun closeSys() {
        if (!::sysOverlay.isInitialized) return
        if (sysOverlay.visibility != View.VISIBLE && excOverlay.visibility != View.VISIBLE) return
        excOverlay.visibility = View.GONE
        sysOverlay.visibility = View.GONE
        content.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        prevFocus?.requestFocus()
    }

    // ---------- RAM təmizləmə + istisna tətbiqlər ----------

    private fun launchableApps(): List<ResolveInfo> {
        fun query(cat: String) = packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0)
        return (query(Intent.CATEGORY_LEANBACK_LAUNCHER) + query(Intent.CATEGORY_LAUNCHER))
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
    }

    // Yalnız istifadəçi tətbiqləri və yenilənmiş sistem tətbiqləri (YouTube, Netflix və s.) dayandırıla bilər
    private fun killable(ri: ResolveInfo): Boolean {
        val a = ri.activityInfo.applicationInfo
        val sys = (a.flags and ApplicationInfo.FLAG_SYSTEM) != 0
        val upd = (a.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
        return (!sys || upd) && ri.activityInfo.packageName != "com.android.vending"
    }

    private fun updateExcButton() {
        btnExc.text = if (excSet.isEmpty()) "İstisna tətbiqlər" else "İstisna tətbiqlər (${excSet.size})"
    }

    private fun saveExc() {
        prefs.edit().putStringSet("ram_exc", HashSet(excSet)).apply()
        updateExcButton()
    }

    private fun cleanRam(automatic: Boolean = false) {
        if (cleaningRam) return
        cleaningRam = true
        if (!automatic) {
            btnClean.isEnabled = false
            btnClean.text = "ADB ilə təmizlənir…"
        }
        val targets = launchableApps().filter { killable(it) && it.activityInfo.packageName !in excSet }
            .map { it.activityInfo.packageName }
        val port = prefs.getInt("adb_port", 5555)
        Thread {
            val stopped = DefaultLauncher.forceStopViaAdb(applicationContext, port, targets)
            runOnUiThread {
                cleaningRam = false
                btnClean.isEnabled = true
                btnClean.text = "Sərt RAM təmizlə"
                lastPollAt = 0L
                pollSys()
                if (stopped < 0) {
                    if (!automatic) Toast.makeText(this,
                        "ADB bağlantısı alınmadı. Developer options-da Wireless debugging (TCP 5555) aktiv edin və ADB icazəsi verin.",
                        Toast.LENGTH_LONG).show()
                } else if (!automatic) {
                    Toast.makeText(this, "$stopped tətbiq force-stop edildi (istisnalar qorundu)", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun openExc() {
        val items = launchableApps().filter { killable(it) }
            .map { ExcItem(it.loadLabel(packageManager).toString(), it.activityInfo.packageName, it.loadIcon(packageManager)) }
            .sortedBy { it.label.lowercase() }
        if (items.isEmpty()) {
            Toast.makeText(this, "Siyahıya əlavə ediləcək tətbiq tapılmadı", Toast.LENGTH_SHORT).show()
            return
        }
        excList.layoutManager = LinearLayoutManager(this)
        excList.adapter = ExcAdapter(items)
        sysOverlay.visibility = View.GONE
        excOverlay.visibility = View.VISIBLE
        excList.post { excList.getChildAt(0)?.requestFocus() }
    }

    private fun closeExc() {
        excOverlay.visibility = View.GONE
        sysOverlay.visibility = View.VISIBLE
        btnExc.requestFocus()
    }

    inner class ExcAdapter(private val items: List<ExcItem>) : RecyclerView.Adapter<ExcAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val icon: ImageView = v.findViewById(R.id.eicon)
            val label: TextView = v.findViewById(R.id.elabel)
            val check: TextView = v.findViewById(R.id.echeck)
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int) =
            VH(LayoutInflater.from(p.context).inflate(R.layout.item_exc, p, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(vh: VH, i: Int) {
            val x = items[i]
            vh.icon.setImageDrawable(x.icon)
            vh.label.text = x.label
            fun paint() {
                val on = x.pkg in excSet
                vh.check.text = if (on) "İSTİSNA" else "dayandırılır"
                vh.check.setTextColor(if (on) 0xFF7FD67F.toInt() else 0xFF8F8888.toInt())
            }
            paint()
            vh.itemView.setOnClickListener {
                if (!excSet.remove(x.pkg)) excSet.add(x.pkg)
                saveExc()
                paint()
            }
        }
    }

    // ---------- default launcher (ADB ilə) ----------

    private fun ensureDefaultLauncher() {
        if (adbRunning || DefaultLauncher.isDefault(this)) return
        if (System.currentTimeMillis() - prefs.getLong("adb_fail_at", 0L) < 30 * 60_000L) return
        adbRunning = true
        val port = prefs.getInt("adb_port", 5555)
        Thread {
            val ok = DefaultLauncher.setViaAdb(applicationContext, port)
            runOnUiThread {
                adbRunning = false
                if (ok) {
                    Toast.makeText(this, "Mehdi Launcher əsas ekran (default launcher) təyin olundu", Toast.LENGTH_LONG).show()
                } else if (!DefaultLauncher.isDefault(this)) {
                    prefs.edit().putLong("adb_fail_at", System.currentTimeMillis()).apply()
                    Toast.makeText(this, "ADB ilə təyin alınmadı. Ayarlarda USB/Network debugging (5555) açıq olmalıdır", Toast.LENGTH_LONG).show()
                    DefaultLauncher.askSystem(this)
                }
            }
        }.start()
    }

    // ---------- 24 saatlıq proqnoz ----------

    private fun openHourly() {
        if (hours.isEmpty()) {
            Toast.makeText(this, "Hava məlumatı hələ yüklənməyib", Toast.LENGTH_SHORT).show()
            return
        }
        hourRow.removeAllViews()
        hours.forEachIndexed { i, hr ->
            val v = LayoutInflater.from(this).inflate(R.layout.item_hour, hourRow, false)
            v.findViewById<TextView>(R.id.htime).text = if (i == 0) "İndi" else hr.label
            v.findViewById<ImageView>(R.id.hicon).setImageResource(iconFor(hr.code, hr.day))
            v.findViewById<TextView>(R.id.htemp).text = "${hr.temp}°"
            v.findViewById<TextView>(R.id.hpop).text = "${hr.pop}%"
            hourRow.addView(v)
        }
        sunInfo.text = sunText
        warnInfo.text = warnings.joinToString("\n") { "Xəbərdarlıq: $it" }
        warnInfo.visibility = if (warnings.isEmpty()) View.GONE else View.VISIBLE
        hourScroll.scrollTo(0, 0)
        overlay.visibility = View.VISIBLE
    }

    private fun closeHourly() {
        overlay.visibility = View.GONE
        weatherBox.requestFocus()
    }

    private fun parseHourly(root: JSONObject): Triple<List<Hour>, String, List<String>> {
        val baku = TimeZone.getTimeZone("Asia/Baku")
        val f = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).apply { timeZone = baku }
        val hm = SimpleDateFormat("HH:mm", Locale.US).apply { timeZone = baku }
        val dly = root.getJSONObject("daily")
        val dTimes = dly.getJSONArray("time")
        val rise = dly.getJSONArray("sunrise")
        val sset = dly.getJSONArray("sunset")
        val ris = LongArray(rise.length()) { f.parse(rise.getString(it))!!.time }
        val sts = LongArray(sset.length()) { f.parse(sset.getString(it))!!.time }
        val hr = root.getJSONObject("hourly")
        val times = hr.getJSONArray("time")
        val tmp = hr.getJSONArray("temperature_2m")
        val pop = hr.getJSONArray("precipitation_probability")
        val codes = hr.getJSONArray("weather_code")
        val gust = hr.optJSONArray("wind_gusts_10m")
        val prec = hr.optJSONArray("precipitation")
        val now = System.currentTimeMillis()
        var start = 0
        while (start < times.length() - 1 && f.parse(times.getString(start))!!.time + 3_600_000L <= now) start++

        var maxGust = 0.0; var gustAt = ""
        var thunderAt: String? = null
        var rainAt: String? = null
        var snowAt: String? = null
        var fogAt: String? = null
        var fogHours = 0
        var total = 0.0
        var maxT = -100; var minT = 100

        val out = ArrayList<Hour>()
        var i = start
        while (i < times.length() && out.size < 24) {
            val ts = times.getString(i)
            val tm = f.parse(ts)!!.time
            val date = ts.substring(0, 10)
            var di = 0
            for (k in 0 until dTimes.length()) if (dTimes.getString(k) == date) { di = k; break }
            val day = di < ris.size && di < sts.size && tm >= ris[di] && tm < sts[di]
            val label = ts.substring(11, 16)
            val c = codes.optInt(i, 0)
            val t = Math.round(tmp.optDouble(i, 0.0)).toInt()
            out += Hour(label, c, day, t, pop.optInt(i, 0))

            val g = gust?.optDouble(i, 0.0) ?: 0.0
            if (g > maxGust) { maxGust = g; gustAt = label }
            val pr = prec?.optDouble(i, 0.0) ?: 0.0
            total += pr
            if (c in 95..99 && thunderAt == null) thunderAt = label
            if ((pr >= 4.0 || c == 65 || c == 67 || c == 82) && rainAt == null) rainAt = label
            if ((c in 71..77 || c in 85..86) && snowAt == null) snowAt = label
            if (c == 45 || c == 48) { fogHours++; if (fogAt == null) fogAt = label }
            if (t > maxT) maxT = t
            if (t < minT) minT = t
            i++
        }

        val w = ArrayList<String>()
        thunderAt?.let { w += "Ildırım və tufan ehtimalı ($it)" }
        if (maxGust >= 15.0) w += (if (maxGust >= 20.0) "Çox güclü külək" else "Güclü külək") + ": ${Math.round(maxGust)} m/s-ə qədər ($gustAt)"
        if (rainAt != null || total >= 20.0) w += "Güclü yağış gözlənilir" + (rainAt?.let { " ($it)" } ?: "")
        snowAt?.let { w += "Qar gözlənilir ($it)" }
        if (maxT >= 35) w += "Çox isti hava: $maxT°"
        if (minT <= 0) w += "Şaxta: $minT°"
        if (fogHours >= 2) w += "Dumanlı hava, görünüş zəifdir (${fogAt ?: ""})"

        val k = if (sts.isNotEmpty() && now > sts[0] && sts.size > 1) 1 else 0
        val sun = if (ris.isEmpty() || sts.isEmpty()) "" else
            (if (k == 1) "Sabah: " else "") + "Gün çıxır ${hm.format(Date(ris[k]))}  •  Gün batır ${hm.format(Date(sts[k]))}"
        return Triple(out, sun, w)
    }

    private fun loadWeather() {
        Thread {
            try {
                val url = URL(
                    "https://api.open-meteo.com/v1/forecast?latitude=40.4093&longitude=49.8671" +
                        "&current=temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m,weather_code,is_day" +
                        "&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset" +
                        "&hourly=temperature_2m,precipitation_probability,weather_code,wind_gusts_10m,precipitation&forecast_days=5" +
                        "&wind_speed_unit=ms&timezone=Asia%2FBaku"
                )
                val c = url.openConnection() as HttpURLConnection
                c.connectTimeout = 10000
                c.readTimeout = 10000
                val root = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                val cur = root.getJSONObject("current")
                val dly = root.getJSONObject("daily")
                val t = Math.round(cur.getDouble("temperature_2m"))
                val feels = Math.round(cur.getDouble("apparent_temperature"))
                val hum = cur.getInt("relative_humidity_2m")
                val wind = cur.getDouble("wind_speed_10m")
                val code = cur.getInt("weather_code")
                val day = cur.getInt("is_day") == 1
                val text = codeText(code)
                val currentPop = try {
                    val ht = root.getJSONObject("hourly").getJSONArray("time")
                    val hp = root.getJSONObject("hourly").getJSONArray("precipitation_probability")
                    val nowBaku = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).apply { timeZone = TimeZone.getTimeZone("Asia/Baku") }
                    val nowMs = System.currentTimeMillis()
                    var best = 0; var delta = Long.MAX_VALUE
                    for (j in 0 until ht.length()) {
                        val d = kotlin.math.abs(nowBaku.parse(ht.getString(j))!!.time - nowMs)
                        if (d < delta) { delta = d; best = j }
                    }
                    hp.optInt(best, 0)
                } catch (_: Exception) { -1 }
                val (hl, sun, wn) = try { parseHourly(root) } catch (e: Exception) { Triple(emptyList<Hour>(), "", emptyList<String>()) }
                runOnUiThread {
                    temp.text = "$t°"
                    wIcon.setImageResource(iconFor(code, day))
                    wCode = code
                    wDay = day
                    showForecast(dly)
                    desc.text = text
                    hours = hl
                    sunText = sun
                    warnings = wn
                    details.text = "Hiss olunan $feels°\nRütubət $hum%  •  Külək ${"%.1f".format(wind)} m/s" +
                        (if (currentPop >= 0) "\nYağış ehtimalı $currentPop%" else "") +
                        (if (sun.isNotEmpty()) "\n$sun" else "")
                }
            } catch (e: Exception) {
                runOnUiThread { if (desc.text.isNullOrEmpty()) desc.text = "Hava məlumatı alınmadı" }
            }
        }.start()
    }

    private fun codeText(c: Int) = when (c) {
        0 -> "Aydın"
        1 -> "Əsasən aydın"
        2 -> "Az buludlu"
        3 -> "Buludlu"
        45, 48 -> "Dumanlı"
        in 51..57 -> "Çiskin"
        in 61..67 -> "Yağışlı"
        in 71..77 -> "Qarlı"
        in 80..82 -> "Leysan"
        in 95..99 -> "Tufan"
        else -> "—"
    }

    private fun showForecast(d: JSONObject) {
        val times = d.getJSONArray("time")
        val codes = d.getJSONArray("weather_code")
        val mx = d.getJSONArray("temperature_2m_max")
        val mn = d.getJSONArray("temperature_2m_min")
        val names = arrayOf("B", "B.e", "Ç.a", "Ç", "C.a", "C", "Ş")
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        forecast.removeAllViews()
        for (i in 0 until times.length()) {
            val v = LayoutInflater.from(this).inflate(R.layout.item_day, forecast, false)
            val cal = Calendar.getInstance().apply { time = fmt.parse(times.getString(i))!! }
            v.findViewById<TextView>(R.id.day).text = if (i == 0) "Bu gün" else names[cal.get(Calendar.DAY_OF_WEEK) - 1]
            v.findViewById<ImageView>(R.id.dicon).setImageResource(iconFor(codes.getInt(i), true))
            v.findViewById<TextView>(R.id.dtemp).text = "${Math.round(mx.getDouble(i))}°/${Math.round(mn.getDouble(i))}°"
            forecast.addView(v)
        }
    }

    private fun iconFor(c: Int, day: Boolean) = when (c) {
        0 -> if (day) R.drawable.ic_w_clear_day else R.drawable.ic_w_clear_night
        1, 2 -> if (day) R.drawable.ic_w_partly_day else R.drawable.ic_w_partly_night
        3 -> R.drawable.ic_w_cloudy
        45, 48 -> R.drawable.ic_w_fog
        in 51..67, in 80..82 -> R.drawable.ic_w_rain
        in 71..77, in 85..86 -> R.drawable.ic_w_snow
        in 95..99 -> R.drawable.ic_w_storm
        else -> R.drawable.ic_w_cloudy
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    inner class TileAdapter(val items: MutableList<Tile>, private val layout: Int) :
        RecyclerView.Adapter<TileAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val icon: ImageView = v.findViewById(R.id.icon)
            val label: TextView = v.findViewById(R.id.label)
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int) =
            VH(LayoutInflater.from(p.context).inflate(layout, p, false))

        override fun getItemCount() = items.size

        fun swap(a: Int, b: Int) {
            items.add(b, items.removeAt(a))
            notifyItemMoved(a, b)
        }

        override fun onBindViewHolder(vh: VH, i: Int) {
            val t = items[i]
            val wide = layout == R.layout.item_app
            vh.icon.setImageDrawable(t.image)
            vh.icon.scaleType = if (t.banner) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.FIT_CENTER
            val pad = if (wide && !t.banner) dp(14) else 0
            vh.icon.setPadding(pad, pad, pad, pad)
            vh.label.text = t.label
            if (wide) vh.label.visibility = View.INVISIBLE
            vh.itemView.setOnClickListener { t.action() }
            if (wide) vh.itemView.setOnLongClickListener { startMove(vh); true }
            vh.itemView.setOnFocusChangeListener { v, f ->
                val s = if (f) 1.1f else 1f
                v.animate().scaleX(s).scaleY(s).setDuration(120).start()
                if (wide) vh.label.visibility = if (f) View.VISIBLE else View.INVISIBLE
            }
        }
    }
}
