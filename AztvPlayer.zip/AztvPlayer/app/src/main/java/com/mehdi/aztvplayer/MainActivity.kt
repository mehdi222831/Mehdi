package com.mehdi.aztvplayer

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import org.json.JSONObject

data class Channel(
    val name: String,
    val page: String,
    val referer: String,
    val origin: String,
    val match: (String) -> Boolean
)

class MainActivity : AppCompatActivity() {

    companion object {
        const val FIND_TIMEOUT_MS = 20000L
        const val MAX_RETRIES = 5

        // Səhifədəki pleyeri avtomatik başladır (səssiz), ki stream sorğusu getsin
        const val AUTOPLAY_JS = """
(function(){
  function go(){
    try{ document.querySelectorAll('video').forEach(function(v){ v.muted=true; var p=v.play(); if(p&&p.catch)p.catch(function(){}); }); }catch(e){}
    try{ var b=document.querySelector('.vjs-big-play-button,.jw-icon-display,.plyr__control--overlaid,.play-button,[class*="big-play"],[class*="PlayButton"]'); if(b) b.click(); }catch(e){}
  }
  go(); setTimeout(go,1500); setTimeout(go,4000); setTimeout(go,8000);
})();
"""
    }

    private val channels = listOf(
        Channel(
            "AZ TV",
            "https://yodaplayer.yodacdn.net/aztv/index.php",
            "https://yodaplayer.yodacdn.net/",
            "https://yodaplayer.yodacdn.net"
        ) { it.contains("str.yodacdn.net/azertv/index.m3u8") && it.contains("token=") },
        Channel(
            "ATV",
            "https://de.livestream.ad/atv-live/1",
            "https://de.livestream.ad/",
            "https://de.livestream.ad"
        ) { it.substringBefore("?").endsWith(".m3u8") }
    )
    private var current = 0

    private lateinit var webView: WebView
    private lateinit var playerView: PlayerView
    private lateinit var status: TextView
    private lateinit var menu: LinearLayout
    private lateinit var btnAz: Button
    private lateinit var btnAtv: Button
    private lateinit var btnReload: Button

    private val handler = Handler(Looper.getMainLooper())
    private var player: ExoPlayer? = null

    @Volatile
    private var captured = false
    private var userAgent = ""
    private var retries = 0
    private var tokenExpMs = 0L

    private val timeoutRunnable = Runnable {
        if (!captured) {
            status.text = "Link tapılmadı, yenidən cəhd edilir..."
            status.visibility = View.VISIBLE
            handler.postDelayed({ fetchLink() }, 3000)
        }
    }
    private val hideMenuRunnable = Runnable { menu.visibility = View.GONE }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        webView = findViewById(R.id.webView)
        playerView = findViewById(R.id.playerView)
        status = findViewById(R.id.status)
        menu = findViewById(R.id.menu)
        btnAz = findViewById(R.id.btnAz)
        btnAtv = findViewById(R.id.btnAtv)
        btnReload = findViewById(R.id.btnReload)

        current = getSharedPreferences("prefs", MODE_PRIVATE).getInt("ch", 0)
            .coerceIn(0, channels.size - 1)

        btnAz.setOnClickListener { setChannel(0) }
        btnAtv.setOnClickListener { setChannel(1) }
        btnReload.setOnClickListener {
            retries = 0
            hideMenu()
            fetchLink()
        }
        playerView.setOnClickListener { showMenu() }
        updateMenu()

        setupWebView()
        fetchLink()
    }

    private fun setupWebView() {
        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.cacheMode = WebSettings.LOAD_NO_CACHE
        // Token User-Agent-ə bağlı ola bilər: pleyer də eyni UA-nı istifadə edəcək
        userAgent = s.userAgentString

        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val url = request?.url?.toString() ?: return null
                if (!captured && channels[current].match(url)) {
                    captured = true
                    runOnUiThread { onLinkFound(url) }
                }
                return null
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (!captured && url != null && url != "about:blank") {
                    view?.evaluateJavascript(AUTOPLAY_JS, null)
                }
            }
        }
    }

    private fun setChannel(i: Int) {
        current = (i + channels.size) % channels.size
        getSharedPreferences("prefs", MODE_PRIVATE).edit().putInt("ch", current).apply()
        retries = 0
        tokenExpMs = 0L
        player?.stop()
        updateMenu()
        hideMenu()
        fetchLink()
    }

    private fun updateMenu() {
        btnAz.text = if (current == 0) "● AZ TV" else "AZ TV"
        btnAtv.text = if (current == 1) "● ATV" else "ATV"
    }

    private fun fetchLink() {
        captured = false
        status.text = "${channels[current].name}: link alınır..."
        status.visibility = View.VISIBLE
        handler.removeCallbacks(timeoutRunnable)
        handler.postDelayed(timeoutRunnable, FIND_TIMEOUT_MS)
        webView.loadUrl(channels[current].page)
    }

    private fun onLinkFound(url: String) {
        handler.removeCallbacks(timeoutRunnable)
        // Səhifənin öz pleyerini dayandır (səs ikiqat olmasın)
        webView.loadUrl("about:blank")
        tokenExpMs = parseExpMs(url)
        play(url)
    }

    private fun parseExpMs(url: String): Long {
        if (!url.contains("token=")) return 0L
        return try {
            val token = url.substringAfter("token=").substringBefore("&")
            val payload = token.split(".")[1]
            val json = String(
                Base64.decode(payload, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
            )
            JSONObject(json).optLong("exp", 0L) * 1000L
        } catch (e: Exception) {
            0L
        }
    }

    private fun play(url: String) {
        player?.release()
        val ch = channels[current]

        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent(userAgent)
            .setAllowCrossProtocolRedirects(true)
            .setDefaultRequestProperties(
                mapOf(
                    "Referer" to ch.referer,
                    "Origin" to ch.origin
                )
            )

        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(httpFactory))
            .build()
        player = p
        playerView.player = p

        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                when (state) {
                    Player.STATE_BUFFERING -> {
                        status.text = "Yüklənir..."
                        status.visibility = View.VISIBLE
                    }
                    Player.STATE_READY -> {
                        status.visibility = View.GONE
                        retries = 0
                    }
                    else -> {}
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                retries++
                if (retries <= MAX_RETRIES) {
                    status.text = "Xəta, link yenilənir ($retries/$MAX_RETRIES)..."
                    status.visibility = View.VISIBLE
                    handler.postDelayed({ fetchLink() }, 1500)
                } else {
                    status.text = "Xəta: ${error.errorCodeName}\nYenilə düyməsini basın"
                    status.visibility = View.VISIBLE
                    showMenu()
                }
            }
        })

        p.setMediaItem(
            MediaItem.Builder()
                .setUri(url)
                .setMimeType(MimeTypes.APPLICATION_M3U8)
                .build()
        )
        p.playWhenReady = true
        p.prepare()
    }

    private fun showMenu() {
        menu.visibility = View.VISIBLE
        (if (current == 0) btnAz else btnAtv).requestFocus()
        handler.removeCallbacks(hideMenuRunnable)
        handler.postDelayed(hideMenuRunnable, 6000)
    }

    private fun hideMenu() {
        handler.removeCallbacks(hideMenuRunnable)
        menu.visibility = View.GONE
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val menuVisible = menu.visibility == View.VISIBLE
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_MENU -> {
                if (!menuVisible) {
                    showMenu()
                    return true
                }
            }
            KeyEvent.KEYCODE_CHANNEL_UP -> {
                setChannel(current + 1)
                return true
            }
            KeyEvent.KEYCODE_CHANNEL_DOWN -> {
                setChannel(current - 1)
                return true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> if (!menuVisible) {
                setChannel(current + 1)
                return true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> if (!menuVisible) {
                setChannel(current - 1)
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onStart() {
        super.onStart()
        val expired = tokenExpMs > 0 && System.currentTimeMillis() > tokenExpMs - 5 * 60 * 1000
        if (expired) {
            retries = 0
            fetchLink()
        } else {
            player?.let {
                it.seekToDefaultPosition()
                it.playWhenReady = true
            }
        }
    }

    override fun onStop() {
        super.onStop()
        player?.playWhenReady = false
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
        webView.destroy()
        super.onDestroy()
    }
}
