package az.nowtv

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var etUrl: EditText
    private lateinit var btnFetch: Button
    private lateinit var tvLink: TextView
    private lateinit var tvLog: TextView
    private lateinit var playerView: PlayerView

    private var player: ExoPlayer? = null
    private var current: StreamLink? = null
    private var job: Job? = null
    private var retries = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etUrl = findViewById(R.id.etUrl)
        btnFetch = findViewById(R.id.btnFetch)
        tvLink = findViewById(R.id.tvLink)
        tvLog = findViewById(R.id.tvLog)
        playerView = findViewById(R.id.playerView)

        etUrl.setText(DEFAULT_URL)

        btnFetch.setOnClickListener { fetch(autoPlay = false) }

        findViewById<Button>(R.id.btnCopy).setOnClickListener {
            val link = current?.url
            if (link == null) {
                toast("Əvvəlcə linki çəkin")
            } else {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("m3u8", link))
                toast("Link kopyalandı")
            }
        }

        findViewById<Button>(R.id.btnPlay).setOnClickListener {
            if (current == null) fetch(autoPlay = true) else play()
        }

        findViewById<Button>(R.id.btnExternal).setOnClickListener {
            val link = current
            if (link == null) {
                toast("Əvvəlcə linki çəkin")
            } else {
                val i = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(Uri.parse(link.url), if (link.hls) "application/x-mpegURL" else "video/*")
                    // MX Player / VLC üçün başlıqlar
                    putExtra("headers", link.headers.flatMap { listOf(it.key, it.value) }.toTypedArray())
                }
                startActivity(Intent.createChooser(i, "Player seç"))
            }
        }
    }

    private fun log(s: String) = runOnUiThread { tvLog.append(s + "\n") }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun fetch(autoPlay: Boolean) {
        job?.cancel()
        val page = etUrl.text.toString().trim()
        if (page.isEmpty()) {
            toast("Səhifə linkini yazın")
            return
        }
        tvLog.text = ""
        tvLink.text = "Axtarılır…"
        btnFetch.isEnabled = false
        job = lifecycleScope.launch {
            val res = LinkExtractor.run(this@MainActivity, page) { log(it) }
            btnFetch.isEnabled = true
            if (res == null) {
                current = null
                tvLink.text = "❌ Link tapılmadı"
                log("Link tapılmadı. Səhifə JS-i linki başqa üsulla yaradır ola bilər.")
            } else {
                current = res
                tvLink.text = res.url
                log(if (res.verified) "✅ Link tapıldı və yoxlandı" else "⚠ Link tapıldı (yoxlanmadı)")
                if (autoPlay) play()
            }
        }
    }

    private fun play() {
        val link = current ?: return
        releasePlayer()

        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(LinkExtractor.UA)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(15_000)
            .setDefaultRequestProperties(link.headers)

        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .build()

        val item = MediaItem.Builder().setUri(link.url).apply {
            if (link.hls) setMimeType(MimeTypes.APPLICATION_M3U8)
        }.build()

        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) retries = 0
            }

            override fun onPlayerError(error: PlaybackException) {
                log("Player xətası: ${error.errorCodeName}")
                // Token bitmiş ola bilər – yeni link çəkib davam et
                if (retries < 3) {
                    retries++
                    log("Token yenilənir (cəhd $retries/3)…")
                    fetch(autoPlay = true)
                } else {
                    log("❌ 3 cəhd uğursuz oldu.")
                }
            }
        })

        player = p
        playerView.player = p
        playerView.visibility = android.view.View.VISIBLE
        p.setMediaItem(item)
        p.prepare()
        p.playWhenReady = true
    }

    private fun releasePlayer() {
        playerView.player = null
        player?.release()
        player = null
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        releasePlayer()
        super.onDestroy()
    }

    companion object {
        const val DEFAULT_URL = "https://blog.canlitvizle.tv/now-tv/1"
    }
}
