package com.mehdi.keymapper;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;

/** Pultun düymələrini tutur (udur) və Server-ə yönləndirir. */
public class KeyService extends AccessibilityService {
    static volatile KeyService instance;

    private static final int HOLD_MS = 400;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final SparseArray<State> states = new SparseArray<>();

    private static class State {
        boolean down, holdFired, doubleActive;
        Runnable single, hold;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        Store.reload(this);
        try {
            AccessibilityServiceInfo i = getServiceInfo();
            if (i != null) {
                i.flags |= AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS;
                setServiceInfo(i);
            }
        } catch (Throwable ignored) {
        }
        KeepAliveService.start(this);
        KeepAliveService.kick = true;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        instance = null;
        Bridge.send(Bridge.CMD_RELEASE_ALL, 0);
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    }

    @Override
    public void onInterrupt() {
    }

    private State state(int key) {
        State s = states.get(key);
        if (s == null) {
            s = new State();
            states.put(key, s);
        }
        return s;
    }

    @Override
    protected boolean onKeyEvent(KeyEvent e) {
        if (Store.capturing) return false;
        final Mapping m = Store.active.get(e.getKeyCode());
        if (m == null || !Bridge.isConnected()) return false;
        final int target = m.target;
        int act = e.getAction();

        // Sadə rejim: tam eyni davranış, gecikmə yoxdur (basıb saxlama = sonsuz təkrar Server-də)
        if (!m.doubleLong) {
            if (act == KeyEvent.ACTION_DOWN) {
                if (e.getRepeatCount() == 0) Bridge.send(Bridge.CMD_DOWN, target);
            } else if (act == KeyEvent.ACTION_UP) {
                Bridge.send(Bridge.CMD_UP, target);
            }
            return true;
        }

        // İkiqat klik rejimi
        final State s = state(e.getKeyCode());
        if (act == KeyEvent.ACTION_DOWN) {
            if (e.getRepeatCount() > 0 || s.down) return true;
            s.down = true;
            s.holdFired = false;
            s.doubleActive = false;
            if (s.single != null) {
                // pəncərə içində ikinci basış -> uzun basış
                h.removeCallbacks(s.single);
                s.single = null;
                s.doubleActive = true;
                Bridge.send(Bridge.CMD_LONG, target);
            } else {
                s.hold = new Runnable() {
                    @Override
                    public void run() {
                        s.hold = null;
                        s.holdFired = true;
                        Bridge.send(Bridge.CMD_DOWN, target);
                    }
                };
                h.postDelayed(s.hold, HOLD_MS);
            }
            return true;
        } else if (act == KeyEvent.ACTION_UP) {
            if (!s.down) return true;
            s.down = false;
            if (s.doubleActive) {
                s.doubleActive = false;
                return true;
            }
            if (s.holdFired) {
                s.holdFired = false;
                Bridge.send(Bridge.CMD_UP, target);
                return true;
            }
            if (s.hold != null) {
                h.removeCallbacks(s.hold);
                s.hold = null;
            }
            s.single = new Runnable() {
                @Override
                public void run() {
                    s.single = null;
                    Bridge.send(Bridge.CMD_CLICK, target);
                }
            };
            h.postDelayed(s.single, Store.doubleWindow);
            return true;
        }
        return true;
    }
}
