package az.yvok.app;

import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;

import java.io.ByteArrayInputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Hidden checker pages' shared lightweight resource filter.
 * Images, fonts, media, downloads, tracking and chat widgets are returned as empty responses.
 * The normal policy is intentionally shared by e-belediyye and hesab.az; Portmanat uses the
 * stricter interceptPortmanat() policy below so unrelated third-party assets do not load.
 */
public final class SiteBlocker {
    private SiteBlocker() { }

    private static final String[] BAD_EXT = {
            ".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp", ".avif", ".bmp", ".ico", ".cur", ".tif", ".tiff", ".heic", ".apng",
            ".woff", ".woff2", ".ttf", ".otf", ".eot",
            ".mp4", ".webm", ".mp3", ".ogg", ".wav", ".m4a", ".avi", ".mov", ".m3u8", ".mpd",
            ".pdf", ".zip", ".rar", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
            ".map", ".webmanifest"};

    private static final String[] BAD_PATH = {
            "/images/", "/image/", "/img/", "/fonts/", "/font/", "/icons/", "/icon/", "/media/", "/video/", "/videos/",
            "/photos/", "/gallery/", "/banners/", "favicon", "manifest.json"};

    private static final String[] BAD_HOST = {
            "google-analytics", "googletagmanager", "googlesyndication", "googleadservices", "doubleclick", "analytics",
            "facebook", "fbcdn", "instagram", "twitter", "tiktok", "linkedin", "youtube", "ytimg", "vimeo",
            "yandex", "hotjar", "clarity.ms", "fonts.googleapis", "fonts.gstatic", "gravatar",
            "tawk", "jivo", "livechat", "intercom", "crisp.chat", "hubspot", "sentry", "newrelic", "mixpanel", "segment"};

    private static WebResourceResponse empty() {
        return new WebResourceResponse("text/plain", "utf-8", 204, "No Content",
                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
    }

    private static String lower(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT);
    }

    private static String header(WebResourceRequest r, String name) {
        if (r == null || r.getRequestHeaders() == null) return "";
        for (Map.Entry<String, String> e : r.getRequestHeaders().entrySet()) {
            if (e.getKey() != null && e.getKey().equalsIgnoreCase(name)) return lower(e.getValue());
        }
        return "";
    }

    private static boolean isSiteHost(String host) {
        return host.endsWith(".az") || host.equals("az");
    }

    private static boolean isPortmanatHost(String host) {
        return host.equals("portmanat.az") || host.endsWith(".portmanat.az");
    }

    private static boolean hasAny(String value, String[] needles) {
        for (String n : needles) if (value.contains(n)) return true;
        return false;
    }

    /** Common policy used for the e-belediyye and hesab.az checkers. */
    public static WebResourceResponse intercept(WebResourceRequest r) {
        return interceptCommon(r);
    }

    /**
     * Portmanat policy: retain its own app bundle, styles and service requests. For other hosts,
     * only likely data/API traffic is allowed; external JS/CSS, documents, embeds and other assets
     * are blocked. Common image/font/media/tracker filtering is applied first.
     */
    public static WebResourceResponse interceptPortmanat(WebResourceRequest r) {
        if (r == null || r.getUrl() == null || r.isForMainFrame()) return null;
        WebResourceResponse common = interceptHeavy(r);
        if (common != null) return common;

        String host = lower(r.getUrl().getHost());
        String path = lower(r.getUrl().getPath());
        boolean ownHost = isPortmanatHost(host);

        // Keep only the site's functional bundle/styles. Other images, fonts and trackers were
        // already removed by interceptHeavy(). External CSS/JS is not needed by this page flow.
        if (ownHost && (path.endsWith(".js") || path.endsWith(".mjs") || path.endsWith(".css"))) return null;

        String method = lower(r.getMethod());
        String accept = header(r, "Accept");
        String contentType = header(r, "Content-Type");
        String requestedWith = header(r, "X-Requested-With");

        // API calls are commonly POSTs, XHR requests and/or advertise a structured response.
        if (!method.isEmpty() && !"get".equals(method) && !"head".equals(method)) return null;
        if ("xmlhttprequest".equals(requestedWith) || accept.contains("application/json") || accept.contains("+json") || accept.contains("text/plain")
                || accept.contains("application/xml") || accept.contains("text/xml")
                || contentType.contains("application/json") || contentType.contains("application/x-www-form-urlencoded")) return null;

        // Fetch/XHR APIs often use Accept: */*. Permit endpoint-like URLs without a file extension,
        // and conventional API paths. HTML documents, external JS/CSS and non-API assets are blocked.
        if (accept.contains("text/html") && !accept.contains("application/json")) return empty();
        String last = path;
        int slash = last.lastIndexOf('/');
        if (slash >= 0) last = last.substring(slash + 1);
        boolean hasExtension = last.contains(".");
        boolean apiPath = path.contains("/api/") || path.contains("/graphql") || path.contains("/service/")
                || path.contains("/payment/") || path.contains("/project/") || path.contains("/lookup/")
                || path.contains("/search/") || path.contains("/query/");
        if (apiPath || (!hasExtension && !path.isEmpty() && !"/".equals(path))) return null;

        return empty();
    }

    /** null means continue normally; non-null means replace the request with an empty response. */
    private static WebResourceResponse interceptCommon(WebResourceRequest r) {
        WebResourceResponse heavy = interceptHeavy(r);
        if (heavy != null || r == null || r.getUrl() == null || r.isForMainFrame()) return heavy;
        String path = lower(r.getUrl().getPath());
        String host = lower(r.getUrl().getHost());
        if (!isSiteHost(host)) {
            // Shared policy: external script/style can be required by e-belediyye or hesab.az.
            boolean ok = path.endsWith(".js") || path.endsWith(".mjs") || path.endsWith(".css");
            if (!ok) return empty();
        }
        return null;
    }

    /** Common heavy/tracker filter, separated so Portmanat can still permit cross-origin API calls. */
    private static WebResourceResponse interceptHeavy(WebResourceRequest r) {
        if (r == null || r.getUrl() == null || r.isForMainFrame()) return null;
        String path = lower(r.getUrl().getPath());
        String host = lower(r.getUrl().getHost());
        String accept = header(r, "Accept");

        if (accept.startsWith("image/") || accept.startsWith("video/") || accept.startsWith("audio/") || accept.startsWith("font/")
                || accept.startsWith("application/font") || accept.startsWith("application/pdf")) return empty();
        for (String e : BAD_EXT) if (path.endsWith(e)) return empty();
        if (hasAny(path, BAD_PATH)) return empty();
        if (hasAny(host, BAD_HOST)) return empty();
        return null;
    }
}
