package com.mehdi.keymapper

import android.util.Base64
import java.io.*
import java.math.BigInteger
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.*
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec

/** Minimal ADB protocol client (CNXN / AUTH / OPEN shell). */
class AdbClient(private val dir: File) {
    companion object {
        const val CNXN = 0x4e584e43
        const val AUTH = 0x48545541
        const val OPEN = 0x4e45504f
        const val OKAY = 0x59414b4f
        const val CLSE = 0x45534c43
        const val WRTE = 0x45545257
        private val SHA1_PREFIX = byteArrayOf(
            0x30, 0x21, 0x30, 0x09, 0x06, 0x05, 0x2b, 0x0e, 0x03, 0x02, 0x1a, 0x05, 0x00, 0x04, 0x14
        )
    }

    class Msg(val cmd: Int, val a0: Int, val a1: Int, val data: ByteArray)

    private var socket: Socket? = null
    private var inp: DataInputStream? = null
    private var out: OutputStream? = null
    private var nextId = 1
    @Volatile var alive = false

    fun connect(host: String, port: Int, authWaitMs: Int = 60000) {
        close()
        val s = Socket()
        s.tcpNoDelay = true
        s.connect(InetSocketAddress(host, port), 2500)
        s.soTimeout = authWaitMs
        socket = s
        inp = DataInputStream(BufferedInputStream(s.getInputStream()))
        out = s.getOutputStream()
        val kp = keyPair()
        send(CNXN, 0x01000000, 256 * 1024, "host::keymapper\u0000".toByteArray())
        var sentSig = false
        var sentKey = false
        while (true) {
            val m = readMsg()
            when (m.cmd) {
                CNXN -> { s.soTimeout = 6000; alive = true; return }
                AUTH -> if (m.a0 == 1) {
                    if (!sentSig) { send(AUTH, 2, 0, sign(kp, m.data)); sentSig = true }
                    else if (!sentKey) { send(AUTH, 3, 0, pubKeyBytes(kp)); sentKey = true }
                    else throw IOException("auth rejected")
                }
            }
        }
    }

    @Synchronized
    fun shell(cmd: String): String {
        if (!alive) throw IOException("not connected")
        try {
            val id = nextId++
            send(OPEN, id, 0, "shell:$cmd\u0000".toByteArray())
            val buf = ByteArrayOutputStream()
            while (true) {
                val m = readMsg()
                when (m.cmd) {
                    WRTE -> if (m.a1 == id) { buf.write(m.data); send(OKAY, id, m.a0, ByteArray(0)) }
                    CLSE -> if (m.a1 == id || m.a1 == 0) return buf.toString("UTF-8")
                }
            }
        } catch (e: Exception) {
            close()
            throw e
        }
    }

    fun close() {
        alive = false
        try { socket?.close() } catch (e: Exception) {}
        socket = null
    }

    private fun readMsg(): Msg {
        val h = ByteArray(24)
        inp!!.readFully(h)
        val b = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN)
        val cmd = b.int; val a0 = b.int; val a1 = b.int; val len = b.int
        if (len < 0 || len > 1_048_576) throw IOException("bad length")
        val data = ByteArray(len)
        if (len > 0) inp!!.readFully(data)
        return Msg(cmd, a0, a1, data)
    }

    @Synchronized
    private fun send(cmd: Int, a0: Int, a1: Int, data: ByteArray) {
        var sum = 0L
        for (x in data) sum += (x.toInt() and 0xff)
        val b = ByteBuffer.allocate(24 + data.size).order(ByteOrder.LITTLE_ENDIAN)
        b.putInt(cmd).putInt(a0).putInt(a1).putInt(data.size).putInt(sum.toInt()).putInt(cmd.inv()).put(data)
        out!!.write(b.array())
        out!!.flush()
    }

    private fun keyPair(): KeyPair {
        val pf = File(dir, "priv"); val uf = File(dir, "pub")
        val kf = KeyFactory.getInstance("RSA")
        if (pf.exists() && uf.exists()) {
            try {
                return KeyPair(
                    kf.generatePublic(X509EncodedKeySpec(uf.readBytes())),
                    kf.generatePrivate(PKCS8EncodedKeySpec(pf.readBytes()))
                )
            } catch (ignored: Exception) {}
        }
        dir.mkdirs()
        val g = KeyPairGenerator.getInstance("RSA")
        g.initialize(2048)
        val kp = g.generateKeyPair()
        pf.writeBytes(kp.private.encoded)
        uf.writeBytes(kp.public.encoded)
        return kp
    }

    private fun sign(kp: KeyPair, token: ByteArray): ByteArray {
        val sig = Signature.getInstance("NONEwithRSA")
        sig.initSign(kp.private)
        sig.update(SHA1_PREFIX + token)
        return sig.sign()
    }

    private fun le(x: BigInteger, len: Int): ByteArray {
        val be = x.toByteArray()
        val o = ByteArray(len)
        var i = be.size - 1
        var j = 0
        while (i >= 0 && j < len) { o[j++] = be[i--] }
        return o
    }

    private fun pubKeyBytes(kp: KeyPair): ByteArray {
        val pub = kp.public as RSAPublicKey
        val n = pub.modulus
        val r32 = BigInteger.ONE.shiftLeft(32)
        val n0inv = r32.subtract(n.mod(r32).modInverse(r32)).toInt()
        val rr = BigInteger.ONE.shiftLeft(4096).mod(n)
        val bb = ByteBuffer.allocate(524).order(ByteOrder.LITTLE_ENDIAN)
        bb.putInt(64).putInt(n0inv).put(le(n, 256)).put(le(rr, 256)).putInt(pub.publicExponent.toInt())
        val s = Base64.encodeToString(bb.array(), Base64.NO_WRAP) + " keymapper@tvbox\u0000"
        return s.toByteArray()
    }
}
