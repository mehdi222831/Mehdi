package az.tvlauncher

import android.animation.ArgbEvaluator
import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import java.util.Random
import kotlin.math.sin

/** Saata və havaya görə dəyişən animasiyalı fon: ulduz, bulud, yağış, qar, şimşək. */
class WeatherBackground @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = Random(7)
    private val n = 90
    private val rx = FloatArray(n) { rnd.nextFloat() }
    private val ry = FloatArray(n) { rnd.nextFloat() }
    private val rs = FloatArray(n) { 0.6f + rnd.nextFloat() }
    private val d = resources.displayMetrics.density
    private val t0 = SystemClock.uptimeMillis()
    private var code = 0
    private var night = false
    private var c1 = 0xFF24507F.toInt()
    private var c2 = 0xFF060A12.toInt()
    private var grad: LinearGradient? = null
    private var sunSh: RadialGradient? = null
    private var moonSh: RadialGradient? = null
    private val cloudSh = RadialGradient(0f, 0f, 1f, Color.WHITE, 0x00FFFFFF, Shader.TileMode.CLAMP)
    private var flash = 0f
    private val ccx = floatArrayOf(0.1f, 0.35f, 0.6f, 0.85f, 0.5f)
    private val ccy = floatArrayOf(0.12f, 0.25f, 0.08f, 0.3f, 0.18f)
    private val csz = floatArrayOf(0.28f, 0.22f, 0.3f, 0.2f, 0.25f)
    private val csp = floatArrayOf(0.006f, 0.009f, 0.005f, 0.011f, 0.008f)

    fun set(code: Int, day: Boolean, hour: Int) {
        val (a, b) = when (hour) {
            in 5..7 -> 0xFF4A2B3A.toInt() to 0xFF0A0608.toInt()
            in 8..16 -> 0xFF24507F.toInt() to 0xFF060A12.toInt()
            in 17..19 -> 0xFF4D2A1E.toInt() to 0xFF0A0504.toInt()
            else -> 0xFF0E1630.toInt() to 0xFF000000.toInt()
        }
        val g = when {
            code == 0 -> 0f
            code == 1 -> 0.15f
            code == 2 -> 0.3f
            code == 3 -> 0.55f
            code in 95..99 -> 0.75f
            else -> 0.6f
        }
        val gray = if (day) 0xFF3A4048.toInt() else 0xFF1A1D24.toInt()
        val n1 = ArgbEvaluator().evaluate(g, a, gray) as Int
        val nt = !day
        if (n1 == c1 && b == c2 && code == this.code && nt == night) return
        c1 = n1; c2 = b; this.code = code; night = nt
        rebuild()
    }

    private fun rebuild() {
        val w = width.toFloat(); val h = height.toFloat()
        if (w == 0f) return
        grad = LinearGradient(0f, 0f, w, h, c1, c2, Shader.TileMode.CLAMP)
        sunSh = RadialGradient(w * 0.8f, h * 0.05f, w * 0.45f, 0x40FFB347, 0x00FFB347, Shader.TileMode.CLAMP)
        moonSh = RadialGradient(w * 0.82f, h * 0.1f, w * 0.25f, 0x30AEC6FF, 0x00AEC6FF, Shader.TileMode.CLAMP)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) = rebuild()

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val t = (SystemClock.uptimeMillis() - t0) / 1000f
        p.style = Paint.Style.FILL
        p.shader = grad; p.alpha = 255
        cv.drawRect(0f, 0f, w, h, p)

        if (code <= 2) {                       // günəş / ay parıltısı
            p.shader = if (night) moonSh else sunSh
            cv.drawRect(0f, 0f, w, h, p)
        }
        p.shader = null
        if (night && code <= 2) {              // ulduzlar
            for (i in 0 until 60) {
                p.color = Color.WHITE
                p.alpha = (110 + 100 * sin(t * rs[i] * 2f + i)).toInt().coerceIn(0, 255)
                cv.drawCircle(rx[i] * w, ry[i] * h * 0.55f, (0.7f + rs[i]) * d, p)
            }
        }
        if (code >= 1) {                       // buludlar
            p.shader = cloudSh
            p.alpha = if (code >= 3) 120 else 60
            for (i in 0 until 5) {
                val x = (((ccx[i] + t * csp[i]) % 1.5f) - 0.25f) * w
                cv.save()
                cv.translate(x, ccy[i] * h)
                cv.scale(csz[i] * w, csz[i] * w * 0.4f)
                cv.drawCircle(0f, 0f, 1f, p)
                cv.restore()
            }
            p.shader = null
        }
        if (code == 45 || code == 48) cv.drawColor(0x18C8D0D8)
        val rain = code in 51..67 || code in 80..82 || code in 95..99
        if (rain) {
            val cnt = if (code in 61..67 || code in 80..82 || code >= 95) 90 else 50
            p.color = 0xFF9CC4FF.toInt(); p.alpha = 110; p.strokeWidth = 1.6f * d
            for (i in 0 until cnt) {
                val y = ((ry[i] + t * (0.9f + rs[i] * 0.5f)) % 1f) * h
                val x = (rx[i] * w + y * 0.12f) % w
                cv.drawLine(x, y, x + 3 * d, y + 18 * d, p)
            }
        }
        if (code in 71..77 || code in 85..86) {
            for (i in 0 until 70) {
                p.color = Color.WHITE; p.alpha = 190
                val y = ((ry[i] + t * 0.06f * (0.5f + rs[i])) % 1f) * h
                val x = rx[i] * w + sin(t * rs[i] + i) * 20 * d
                cv.drawCircle(x, y, (1.5f + rs[i] * 1.5f) * d, p)
            }
        }
        if (code in 95..99) {                  // şimşək
            if (rnd.nextFloat() < 0.012f) flash = 1f
            if (flash > 0f) {
                p.color = Color.WHITE; p.alpha = (flash * 70).toInt()
                cv.drawRect(0f, 0f, w, h, p)
                flash -= 0.12f
            }
        }
        postInvalidateDelayed(40)
    }
}
