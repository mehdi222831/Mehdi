package az.tvlauncher

import android.app.Activity
import android.content.Intent
import android.content.pm.ResolveInfo
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var temp: TextView
    private lateinit var desc: TextView
    private lateinit var details: TextView
    private lateinit var apps: RecyclerView

    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private val dateFmt = SimpleDateFormat("d MMMM yyyy, EEEE", Locale("az", "AZ"))

    private val ticker = object : Runnable {
        override fun run() {
            val now = Date()
            clock.text = timeFmt.format(now)
            date.text = dateFmt.format(now)
            h.postDelayed(this, 1000)
        }
    }
    private val weatherLoop = object : Runnable {
        override fun run() {
            loadWeather()
            h.postDelayed(this, 15 * 60_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        clock = findViewById(R.id.clock)
        date = findViewById(R.id.date)
        temp = findViewById(R.id.temp)
        desc = findViewById(R.id.desc)
        details = findViewById(R.id.details)
        apps = findViewById(R.id.apps)
        apps.layoutManager = GridLayoutManager(this, 5)
    }

    override fun onResume() {
        super.onResume()
        apps.adapter = AppAdapter(loadApps())
        h.post(ticker)
        h.post(weatherLoop)
    }

    override fun onPause() {
        super.onPause()
        h.removeCallbacks(ticker)
        h.removeCallbacks(weatherLoop)
    }

    @Deprecated("Launcher-dən çıxmasın")
    override fun onBackPressed() {}

    private fun loadApps(): List<ResolveInfo> {
        fun query(cat: String) = packageManager.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(cat), 0
        ).filter { it.activityInfo.packageName != packageName }
        val list = query(Intent.CATEGORY_LEANBACK_LAUNCHER).ifEmpty { query(Intent.CATEGORY_LAUNCHER) }
        return list.sortedBy { it.loadLabel(packageManager).toString().lowercase() }
    }

    private fun loadWeather() {
        Thread {
            try {
                val url = URL(
                    "https://api.open-meteo.com/v1/forecast?latitude=40.4093&longitude=49.8671" +
                        "&current=temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m,weather_code" +
                        "&wind_speed_unit=ms&timezone=Asia%2FBaku"
                )
                val c = url.openConnection() as HttpURLConnection
                c.connectTimeout = 10000
                c.readTimeout = 10000
                val cur = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                    .getJSONObject("current")
                val t = Math.round(cur.getDouble("temperature_2m"))
                val feels = Math.round(cur.getDouble("apparent_temperature"))
                val hum = cur.getInt("relative_humidity_2m")
                val wind = cur.getDouble("wind_speed_10m")
                val text = codeText(cur.getInt("weather_code"))
                runOnUiThread {
                    temp.text = "$t°C"
                    desc.text = text
                    details.text = "Hiss olunan $feels°  •  Rütubət $hum%  •  Külək ${"%.1f".format(wind)} m/s"
                }
            } catch (e: Exception) {
                runOnUiThread { if (desc.text.isNullOrEmpty()) desc.text = "Hava məlumatı alınmadı" }
            }
        }.start()
    }

    private fun codeText(c: Int) = when (c) {
        0 -> "Aydın"
        1, 2 -> "Az buludlu"
        3 -> "Buludlu"
        45, 48 -> "Dumanlı"
        in 51..57 -> "Çiskin"
        in 61..67 -> "Yağışlı"
        in 71..77 -> "Qarlı"
        in 80..82 -> "Leysan"
        in 95..99 -> "Tufan"
        else -> "—"
    }

    inner class AppAdapter(private val items: List<ResolveInfo>) : RecyclerView.Adapter<AppAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val icon: ImageView = v.findViewById(R.id.icon)
            val label: TextView = v.findViewById(R.id.label)
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int) =
            VH(LayoutInflater.from(p.context).inflate(R.layout.item_app, p, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(vh: VH, i: Int) {
            val ri = items[i]
            vh.icon.setImageDrawable(ri.loadIcon(packageManager))
            vh.label.text = ri.loadLabel(packageManager)
            vh.itemView.setOnFocusChangeListener { v, focus ->
                v.setBackgroundColor(if (focus) 0x40FFFFFF else 0)
                v.animate().scaleX(if (focus) 1.1f else 1f).scaleY(if (focus) 1.1f else 1f).setDuration(120).start()
            }
            vh.itemView.setOnClickListener {
                packageManager.getLeanbackLaunchIntentForPackage(ri.activityInfo.packageName)
                    ?.let { startActivity(it) }
                    ?: packageManager.getLaunchIntentForPackage(ri.activityInfo.packageName)
                        ?.let { startActivity(it) }
            }
        }
    }
}
