package com.mehdi.keymapper

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder

class KeepAliveService : Service() {
    companion object {
        fun start(c: Context) {
            try {
                val i = Intent(c, KeepAliveService::class.java)
                if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
            } catch (e: Exception) {}
        }

        fun scheduleWatchdog(c: Context) {
            try {
                val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
                val pi = PendingIntent.getBroadcast(c, 1, Intent(c, BootReceiver::class.java).setAction("keymapper.WATCHDOG"), flags)
                val t = System.currentTimeMillis() + 60_000
                if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
                else am.setExact(AlarmManager.RTC_WAKEUP, t, pi)
            } catch (e: Exception) {}
        }
    }

    @Volatile private var running = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        Adb.init(this)
        val nb: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("km", "Key Mapper", NotificationManager.IMPORTANCE_LOW))
            nb = Notification.Builder(this, "km")
        } else {
            nb = Notification.Builder(this)
        }
        val n = nb.setContentTitle("Key Mapper işləyir")
            .setContentText("Düymə təyinatları aktivdir")
            .setSmallIcon(R.drawable.ic_notif)
            .setOngoing(true)
            .build()
        startForeground(1, n)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        scheduleWatchdog(this)
        if (!running) {
            running = true
            Thread {
                while (running) {
                    try {
                        if (!Adb.connected) Adb.connectBlocking()
                        Adb.enableAccessibility()
                        InputClient.warmUp()
                    } catch (e: Exception) {}
                    try { Thread.sleep(15000) } catch (e: InterruptedException) {}
                }
            }.apply { isDaemon = true; start() }
        }
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        start(this)
        scheduleWatchdog(this)
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        running = false
        try { sendBroadcast(Intent(this, BootReceiver::class.java).setAction("keymapper.WATCHDOG")) } catch (e: Exception) {}
        super.onDestroy()
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        Store.init(context)
        Adb.init(context)
        KeepAliveService.start(context)
    }
}
