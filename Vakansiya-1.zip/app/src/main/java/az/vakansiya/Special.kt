package az.vakansiya

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Yadda saxlanılan "Xüsusi Vakansiya" qeydi. ts = ilk dəfə tapıldığı vaxt, seen = "baxıldı" basılıb. */
data class Sp(val siteName: String, val siteUrl: String, val hit: Hit, val ts: Long, var seen: Boolean)

/**
 * Xüsusi vakansiyalar "baxıldı" ikonuna basılana qədər qalır (tətbiq bağlansa da, yenilənsə də).
 * Həm tətbiq, həm də arxa plan yoxlaması (CheckWorker) bura yazır.
 */
object SpecialStore {
    private const val KEEP_SEEN_MS = 14L * 24 * 3600 * 1000
    private const val MAX = 300

    private fun p(c: Context) = c.getSharedPreferences("special", Context.MODE_PRIVATE)

    fun startOfToday(): Long = java.util.Calendar.getInstance().apply {
        set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0)
        set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
    }.timeInMillis

    @Synchronized
    fun load(c: Context): MutableList<Sp> {
        val l = mutableListOf<Sp>()
        val s = p(c).getString("list", null) ?: return l
        try {
            val a = JSONArray(s)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                l.add(Sp(o.optString("sn"), o.optString("su"),
                    Hit(Hit.cleanTitle(o.optString("t")), o.optString("u"), o.optInt("k"), 0, o.optInt("p")),
                    o.optLong("ts"), o.optBoolean("v")))
            }
        } catch (e: Exception) { }
        return l
    }

    private fun save(c: Context, l: List<Sp>) {
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("sn", it.siteName).put("su", it.siteUrl).put("t", it.hit.title)
                .put("u", it.hit.url).put("k", it.hit.kind).put("p", it.hit.dup).put("ts", it.ts).put("v", it.seen))
        }
        p(c).edit().putString("list", a.toString()).apply()
    }

    /** Yeni tapılanları əlavə edir (artıq olanlar, o cümlədən "baxıldı" olanlar təkrar əlavə olunmur). */
    @Synchronized
    fun add(c: Context, found: List<Pair<Site, Hit>>) {
        val l = load(c)
        val now = System.currentTimeMillis()
        var changed = false
        val dayStart = startOfToday()
        val have = HashMap<String, Sp>()
        // açar saytla birlikdir: eyni elan həm adi saytda, həm də Staj saytında çıxsa, hər ikisi öz adı ilə ayrıca qalır
        fun sk(site: String, h: Hit) = site + "||" + h.key
        l.forEach { have[sk(it.siteUrl, it.hit)] = it }
        for ((s, h) in found) {
            if (h.url.isEmpty()) continue
            val ex = have[sk(s.url, h)]
            if (ex == null) {
                val n = Sp(s.name, s.url, h, now, false)
                l.add(n); have[sk(s.url, h)] = n
                changed = true
            } else if (ex.seen && ex.ts < dayStart) {
                // əvvəlki gün baxılmış elan bu gün yenidən paylaşılıb: yenidən siyahıya qayıdır
                val idx = l.indexOf(ex)
                l[idx] = Sp(s.name, s.url, h, now, false); have[sk(s.url, h)] = l[idx]
                changed = true
            }
        }
        // köhnə "baxıldı" qeydlərini təmizlə (təkrar çıxmasın deyə 14 gün saxlanır)
        if (l.removeAll { it.seen && now - it.ts > KEEP_SEEN_MS }) changed = true
        while (l.size > MAX) {
            val idx = l.indexOfFirst { it.seen }.let { if (it >= 0) it else 0 }
            l.removeAt(idx); changed = true
        }
        if (changed) save(c, l)
    }

    /** "Baxıldı": siteUrl == null → hamısı, əks halda yalnız həmin saytın qeydləri. */
    @Synchronized
    fun markSeen(c: Context, siteUrl: String?) {
        val l = load(c)
        var changed = false
        for (x in l) if (!x.seen && (siteUrl == null || x.siteUrl == siteUrl)) { x.seen = true; changed = true }
        if (changed) save(c, l)
    }

    /** Tək elanı (açarına görə) "baxıldı" kimi qeyd edir. */
    @Synchronized
    fun markSeenKey(c: Context, key: String, siteUrl: String? = null) {
        val l = load(c)
        var changed = false
        for (x in l) if (!x.seen && x.hit.key == key && (siteUrl == null || x.siteUrl == siteUrl)) { x.seen = true; changed = true }
        if (changed) save(c, l)
    }
}

/** Xüsusi olmayan elanlar üçün "baxıldı" qeydləri (link əsasında, 14 gün saxlanır). */
object SeenStore {
    private const val KEEP_MS = 14L * 24 * 3600 * 1000
    private fun p(c: Context) = c.getSharedPreferences("seenhits", Context.MODE_PRIVATE)

    @Synchronized
    fun all(c: Context): Set<String> {
        val dayStart = SpecialStore.startOfToday()
        // yalnız bu gün baxılanlar sayılır: sabah eyni elan yenidən paylaşılsa yenə görünür
        return p(c).all.filter { (it.value as? Long ?: 0L) >= dayStart }.keys
    }

    @Synchronized
    fun add(c: Context, urls: Collection<String>) {
        if (urls.isEmpty()) return
        val e = p(c).edit()
        val now = System.currentTimeMillis()
        urls.forEach { if (it.isNotEmpty()) e.putLong(it, now) }
        // köhnələri təmizlə
        p(c).all.forEach { (k, v) -> if ((v as? Long ?: 0L) <= now - KEEP_MS) e.remove(k) }
        e.apply()
    }
}
