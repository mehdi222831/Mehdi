package az.yvok.app;

import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;

import java.io.ByteArrayInputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Hidden checker pages' shared lightweight resource filter.
 * Images, fonts, media, downloads, tracking and chat widgets are returned as empty responses.
 * The common policy is shared by e-bələdiyyə, hesab.az and Yelo; Portmanat uses a stricter
 * API-oriented filter so only scripts/styles and data requests are allowed across hosts.
 */
public final class SiteBlocker {
    private SiteBlocker() { }

    private static final String[] BAD_EXT = {
            ".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp", ".avif", ".bmp", ".ico", ".cur", ".tif", ".tiff", ".heic", ".apng",
            ".woff", ".woff2", ".ttf", ".otf", ".eot",
            ".mp4", ".webm", ".mp3", ".ogg", ".wav", ".m4a", ".avi", ".mov", ".m3u8", ".mpd",
            ".pdf", ".zip", ".rar", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
            ".map", ".webmanifest"};

    private static final String[] BAD_PATH = {
            "/images/", "/image/", "/img/", "/fonts/", "/font/", "/icons/", "/icon/", "/media/", "/video/", "/videos/",
            "/photos/", "/gallery/", "/banners/", "favicon", "manifest.json", "/analytics", "/collect", "/tracking",
            "/track", "/metrics", "/pixel", "/beacon", "/telemetry", "/gtag", "/gtm", "/ads/", "/chat", "/widget"};

    private static final String[] BAD_HOST = {
            "google-analytics", "googletagmanager", "googlesyndication", "googleadservices", "doubleclick", "analytics",
            "facebook", "fbcdn", "instagram", "twitter", "tiktok", "linkedin", "youtube", "ytimg", "vimeo",
            "yandex", "hotjar", "clarity.ms", "fonts.googleapis", "fonts.gstatic", "gravatar",
            "tawk", "jivo", "livechat", "intercom", "crisp.chat", "hubspot", "sentry", "newrelic", "mixpanel", "segment"};

    private static WebResourceResponse empty() {
        return new WebResourceResponse("text/plain", "utf-8", 204, "No Content",
                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
    }

    private static String lower(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT);
    }

    private static String header(WebResourceRequest r, String name) {
        if (r == null || r.getRequestHeaders() == null) return "";
        for (Map.Entry<String, String> e : r.getRequestHeaders().entrySet()) {
            if (e.getKey() != null && e.getKey().equalsIgnoreCase(name)) return lower(e.getValue());
        }
        return "";
    }

    private static boolean isSiteHost(String host) {
        return host.endsWith(".az") || host.equals("az");
    }

    private static boolean isPortmanatHost(String host) {
        return host.equals("portmanat.az") || host.endsWith(".portmanat.az");
    }

    private static boolean hasAny(String value, String[] needles) {
        for (String n : needles) if (value.contains(n)) return true;
        return false;
    }

    /** Common policy used for the e-belediyye and hesab.az checkers. */
    public static WebResourceResponse intercept(WebResourceRequest r) {
        return interceptCommon(r);
    }

    /**
     * true  -> yalnız portmanat.az ve alt domenləri açıqdır, digər bütün hostlara sorğu bloklanır.
     * false -> başqa hostlara yalnız aydın API sorğuları (XHR/JSON/POST) icazəlidir.
     */
    private static final boolean PORTMANAT_OWN_HOST_ONLY = false; // zəruri xarici API sorğularına icazə ver, səhifə/asset yükləmələrini yox

    private static final String[] PM_BAD_PATH = {
            "/analytics", "/collect", "/track", "/tracking", "/metrics", "/pixel", "/beacon", "/telemetry",
            "/gtag", "/gtm", "/ads/", "/ad/", "/banner", "/chat", "/widget", "/sw.js", "/service-worker",
            "/workbox", "/sitemap", "/robots.txt", "/rss", "/feed", "/embed", "/iframe", "/share", "/social"};

    private static final String[] PM_BAD_EXT = {".html", ".htm", ".xml", ".txt", ".php", ".asp", ".aspx", ".swf", ".jsp"};

    /** Portmanat üçün sərt siyahı (allowlist): yalnız saytın öz JS/CSS faylları və məlumat (API) sorğuları. */
    public static WebResourceResponse interceptPortmanat(WebResourceRequest r) {
        if (r == null || r.getUrl() == null || r.isForMainFrame()) return null;
        WebResourceResponse common = interceptHeavy(r);
        if (common != null) return common;

        String scheme = lower(r.getUrl().getScheme());
        String host = lower(r.getUrl().getHost());
        String path = lower(r.getUrl().getPath());
        boolean ownHost = isPortmanatHost(host);

        // Yalnız https; data:/blob: sorğularına toxunulmur (daxili), qalan sxemlər (http, ws, ftp ...) bloklanır
        if (!"https".equals(scheme)) return ("data".equals(scheme) || "blob".equals(scheme)) ? null : empty();

        String accept = header(r, "Accept");
        String method = lower(r.getMethod());
        String contentType = header(r, "Content-Type");
        String requestedWith = header(r, "X-Requested-With");
        boolean apiLike = (!method.isEmpty() && !"get".equals(method) && !"head".equals(method))
                || "xmlhttprequest".equals(requestedWith)
                || accept.contains("application/json") || accept.contains("+json")
                || contentType.contains("application/json") || contentType.contains("application/x-www-form-urlencoded");
        boolean apiPath = path.contains("/api/") || path.contains("/graphql") || path.contains("/service/")
                || path.contains("/payment/") || path.contains("/project/") || path.contains("/lookup/")
                || path.contains("/search/") || path.contains("/query/");

        // Başqa host: yalnız API/məlumat sorğuları icazəlidir, xarici səhifələr və statik fayllar bloklanır.
        if (!ownHost) {
            if (PORTMANAT_OWN_HOST_ONLY) return empty();
            return (apiLike || apiPath) ? null : empty();
        }

        // Öz host: izləmə/reklam/vidjet yollarını blokla; API sorğularının .php kimi uzantısı keçə bilər.
        if (hasAny(path, PM_BAD_PATH)) return empty();
        if (accept.contains("text/html") && !accept.contains("application/json")) return empty();   // iframe / sənəd
        if (!apiLike && !apiPath) for (String e : PM_BAD_EXT) if (path.endsWith(e)) return empty();

        // Funksional JS/CSS və API-lər qalır
        if (path.endsWith(".js") || path.endsWith(".mjs") || path.endsWith(".css") || path.endsWith(".json")) return null;
        if (apiLike) return null;

        String last = path;
        int slash = last.lastIndexOf('/');
        if (slash >= 0) last = last.substring(slash + 1);
        boolean hasExtension = last.contains(".");
        if (apiPath || (!hasExtension && !path.isEmpty() && !"/".equals(path))) return null;

        return empty();   // qalan hər şey (naməlum fayl tipləri) bloklanır
    }

    /** Portmanat WebView-də portmanat.az-dan kənara naviqasiya (yönləndirmə, reklam, xarici link) qadağandır. */
    public static boolean allowPortmanatNavigation(String url) {
        if (url == null) return false;
        try {
            android.net.Uri u = android.net.Uri.parse(url);
            return "https".equals(lower(u.getScheme())) && isPortmanatHost(lower(u.getHost()));
        } catch (Exception e) { return false; }
    }

    /** null means continue normally; non-null means replace the request with an empty response.
     * Keep only scripts/styles, small JSON/config files, and API/XHR traffic; block other subresources. */
    private static WebResourceResponse interceptCommon(WebResourceRequest r) {
        WebResourceResponse heavy = interceptHeavy(r);
        if (heavy != null || r == null || r.getUrl() == null || r.isForMainFrame()) return heavy;
        String path = lower(r.getUrl().getPath());
        String method = lower(r.getMethod());
        String accept = header(r, "Accept");
        String contentType = header(r, "Content-Type");
        String requestedWith = header(r, "X-Requested-With");

        boolean scriptOrStyle = path.endsWith(".js") || path.endsWith(".mjs") || path.endsWith(".css");
        boolean jsonData = path.endsWith(".json") || accept.contains("application/json") || accept.contains("+json")
                || contentType.contains("application/json");
        boolean apiLike = (!method.isEmpty() && !"get".equals(method) && !"head".equals(method))
                || "xmlhttprequest".equals(requestedWith)
                || contentType.contains("application/x-www-form-urlencoded");
        boolean apiPath = path.contains("/api/") || path.contains("/graphql") || path.contains("/service/")
                || path.contains("/lookup/") || path.contains("/search/") || path.contains("/query/")
                || path.contains("/tax-debts") || path.contains("/payment/");

        if (scriptOrStyle || jsonData || apiLike || apiPath) return null;
        return empty();
    }

    /** Common heavy/tracker filter, separated so Portmanat can still permit cross-origin API calls. */
    private static WebResourceResponse interceptHeavy(WebResourceRequest r) {
        if (r == null || r.getUrl() == null || r.isForMainFrame()) return null;
        String path = lower(r.getUrl().getPath());
        String host = lower(r.getUrl().getHost());
        String accept = header(r, "Accept");

        if (accept.startsWith("image/") || accept.startsWith("video/") || accept.startsWith("audio/") || accept.startsWith("font/")
                || accept.startsWith("application/font") || accept.startsWith("application/pdf")) return empty();
        for (String e : BAD_EXT) if (path.endsWith(e)) return empty();
        if (hasAny(path, BAD_PATH)) return empty();
        if (hasAny(host, BAD_HOST)) return empty();
        return null;
    }
}
