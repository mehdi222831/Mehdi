# IPTVPlayer — Media3 + VLC

Əsas pleyer Media3 ExoPlayer, ehtiyat pleyer libVLC-dir. Keçid avtomatikdir:

1. **Media3 ExoPlayer** — 7 s
2. Codec dəstəklənmirsə, xəta olarsa və ya açılmasa → **VLC** — 10 s
3. O da açmasa xəta göstərilir.

Alt məlumat zolağında endirmə sürətinin altında pleyer adı göstərilir (`Media3` və ya `VLC`).

## 2 GB RAM TV box
Kiçik bufer, 1080p limiti, libVLC lazım olanda yaradılır və Media3 işləyəndə yaddaşdan boşaldılır. Ətraflı: `PLAYBACK_OPTIMIZATION.md`.

## Toolchain
- JDK 17, Gradle 8.7, AGP 8.6.1, Kotlin 2.0.21, compileSdk/targetSdk 35
- Media3 1.5.1: exoplayer, hls, dash, smoothstreaming, rtsp, datasource-okhttp + okhttp 4.12.0
- VLC: `org.videolan.android:libvlc-all:3.6.0`

## Debug APK
```bash
gradle assembleDebug --no-daemon
```

## Yadda saxlama
Kanal hansı pleyerlə açılıbsa (Media3 və ya VLC), tətbiq bunu yadda saxlayır və növbəti dəfə həmin pleyerlə birbaşa açır. Yadda saxlanılan pleyer artıq açmırsa, digəri yoxlanılır və yaddaş yenilənir.

## Telefon / planşet idarəetməsi (toxunma)
- Videoya **tək toxunuş**: yuxarıda kanallar siyahısı, kanal zolağı və proqram cədvəli düymələri çıxır (4 s sonra gizlənir). Alt EPG zolağı kanal dəyişəndə çıxır və 4 s sonra gizlənir.
- **İki dəfə toxunuş**: pauza / davam.
- **Sağa/sola sürüşdür**: əvvəlki / növbəti kanal.
- **Sağ yarıda yuxarı/aşağı sürüşdür**: səs; **sol yarıda**: ekran parlaqlığı.
- Kanallar siyahısı və proqram cədvəlində sağ yuxarıda ✕ düyməsi var; sistem "geri" jesti də işləyir.
- TV pultu işləməyə davam edir (pult düyməsi basılanda toxunma düymələri gizlənir).

## Playlist mənbəsi
Yalnız `m3u8.mehdimyev.workers.dev` playlisti istifadə olunur (`Data.kt` → `PLAYLIST_URL`). Keş faylı `playlist_mehdimyev.m3u`-dur; köhnə mənbədən qalan `playlist.m3u` ilk açılışda silinir.

## VLC sabitliyi
Bütün libVLC native əməliyyatları tək `vlc-ctl` thread-ində ardıcıl icra olunur; kanal sürətlə dəyişəndə yalnız sonuncu istək açılır; əvvəlki yayımın gecikmiş hadisələri ignor edilir; VLC yaddaşdan yalnız Media3 2 dəqiqə işləyəndən sonra boşaldılır.

## EPG əl ilə əlaqələndirmə
`Epg.kt` → `EPG_ALIASES`: cbc-sport, ictimai-tv, muztv, kanal-7-hd-tr, show-hd-tr, star-tv-hd-tr, tv8-tr, tv85-tr, trt-1/2/3-hd, trt-avaz, trt-cocuk-tr, trt-haber-hd, trt-muzik-tr, trt-spor-yild-tr, trt-turk-tr, trt4k-tr, dmax-tr XML kanalları playlistdəki uyğun adlarla (hd/tr/boşluq/diakritikdən asılı olmayaraq) bağlanır.

## Pleyer ardıcıllığı
Əsas pleyer Media3 ExoPlayer, ehtiyat pleyer VLC. Media3 açmasa/codec dəstəklənməsə VLC-yə keçilir və kanal VLC ilə yadda saxlanılır. VLC yalnız lazım olanda yaradılır.
