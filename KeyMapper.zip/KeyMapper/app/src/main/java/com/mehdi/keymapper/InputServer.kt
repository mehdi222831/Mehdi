package com.mehdi.keymapper

import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyEvent
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket

/** Runs as shell uid via app_process (started over ADB). Injects key events with ~0 latency. */
object InputServer {
    private lateinit var im: Any
    private lateinit var method: java.lang.reflect.Method

    @JvmStatic
    fun main(args: Array<String>) {
        val token = args[0]
        val port = args[1].toInt()
        setup()
        val ss = ServerSocket(port, 8, InetAddress.getByName("127.0.0.1"))
        while (true) {
            val s = ss.accept()
            Thread { handle(s, token) }.start()
        }
    }

    private fun setup() {
        im = try {
            val c = Class.forName("android.hardware.input.InputManager")
            c.getDeclaredMethod("getInstance").apply { isAccessible = true }.invoke(null)!!
        } catch (e: Exception) {
            Class.forName("android.hardware.input.InputManagerGlobal").getMethod("getInstance").invoke(null)!!
        }
        method = im.javaClass.methods.first {
            it.name == "injectInputEvent" && it.parameterTypes.size >= 2 && it.parameterTypes[0] == InputEvent::class.java
        }
    }

    private fun inject(action: Int, code: Int, repeat: Int, downTime: Long, now: Long, flags: Int = 0) {
        val scan = when (code) {
            KeyEvent.KEYCODE_DPAD_UP -> 103
            KeyEvent.KEYCODE_DPAD_LEFT -> 105
            KeyEvent.KEYCODE_DPAD_RIGHT -> 106
            KeyEvent.KEYCODE_DPAD_DOWN -> 108
            KeyEvent.KEYCODE_DPAD_CENTER -> 232
            KeyEvent.KEYCODE_ENTER -> 28
            else -> 0
        }
        val src = InputDevice.SOURCE_KEYBOARD or InputDevice.SOURCE_DPAD
        val ev = KeyEvent(downTime, now, action, code, repeat, 0, -1, scan, flags, src)
        if (method.parameterTypes.size == 2) method.invoke(im, ev, 0) else method.invoke(im, ev, 0, -1)
    }

    private fun handle(s: Socket, token: String) {
        try {
            s.tcpNoDelay = true
            val inp = DataInputStream(BufferedInputStream(s.getInputStream()))
            if (inp.readUTF() != token) { s.close(); return }
            val downTimes = HashMap<Int, Long>()
            while (true) {
                val code = inp.readInt()
                val act = inp.readByte().toInt()
                val rep = inp.readInt()
                val now = SystemClock.uptimeMillis()
                when (act) {
                    0 -> {
                        if (rep == 0 || !downTimes.containsKey(code)) downTimes[code] = now
                        // First repeat carries FLAG_LONG_PRESS, exactly like a real held remote key.
                        val fl = if (rep == 1) KeyEvent.FLAG_LONG_PRESS else 0
                        inject(KeyEvent.ACTION_DOWN, code, rep, downTimes[code]!!, now, fl)
                    }
                    1 -> {
                        inject(KeyEvent.ACTION_UP, code, 0, downTimes[code] ?: now, now)
                        downTimes.remove(code)
                    }
                    3 -> {
                        // "Cancelled" up: the focused view will NOT treat it as a click.
                        inject(KeyEvent.ACTION_UP, code, 0, downTimes[code] ?: now, now, KeyEvent.FLAG_CANCELED)
                        downTimes.remove(code)
                    }
                    2 -> {
                        inject(KeyEvent.ACTION_DOWN, code, 0, now, now)
                        inject(KeyEvent.ACTION_UP, code, 0, now, SystemClock.uptimeMillis())
                    }
                }
            }
        } catch (e: Exception) {
            try { s.close() } catch (x: Exception) {}
        }
    }
}
