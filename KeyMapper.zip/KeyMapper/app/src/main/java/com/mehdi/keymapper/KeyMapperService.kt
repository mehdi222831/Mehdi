package com.mehdi.keymapper

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class KeyMapperService : AccessibilityService() {
    companion object {
        @Volatile var instance: KeyMapperService? = null
        const val LONG_MS = 450L
        const val DOUBLE_MS = 220L
        private const val INJ_WINDOW = 400L
    }

    private class St {
        var down = false
        var longFired = false
        var longR: Runnable? = null
        var singleR: Runnable? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private val states = HashMap<Int, St>()
    private val injUntil = HashMap<Int, Long>()
    private val injHeld = HashSet<Int>()
    private var lastPkg: String? = null

    private val ignore: Set<String> by lazy {
        val s = HashSet<String>(listOf(packageName, "com.android.systemui", "android"))
        try {
            packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
                .forEach { s.add(it.activityInfo.packageName) }
        } catch (e: Exception) {}
        s
    }

    override fun onServiceConnected() {
        instance = this
        Store.init(this)
        Adb.init(this)
        KeepAliveService.start(this)
        Adb.connectAsync()
        InputClient.warmUp()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val p = e.packageName?.toString()
            if (p != null && p !in ignore) lastPkg = p
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    private fun isGlobalKey(k: Int) =
        k == KeyEvent.KEYCODE_BACK || k == KeyEvent.KEYCODE_HOME || k == KeyEvent.KEYCODE_APP_SWITCH

    /** Zero-latency injection through the shell-uid InputServer. */
    private fun inject(k: Int, action: Int, repeat: Int) {
        injUntil[k] = SystemClock.uptimeMillis() + INJ_WINDOW
        if (action == 0) injHeld.add(k) else if (action == 1 || action == 2) injHeld.remove(k)
        InputClient.send(k, action, repeat)
    }

    override fun onKeyEvent(e: KeyEvent): Boolean {
        val code = e.keyCode
        if (code in injHeld) return false
        val until = injUntil[code]
        if (until != null && SystemClock.uptimeMillis() < until) return false

        val l = CaptureHub.listener
        if (l != null) {
            if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) l(code)
            return true
        }

        val maps = Store.forKey(code)
        if (maps.isEmpty()) return false
        val single = maps.firstOrNull { it.gesture == Gesture.SINGLE }
        val dbl = maps.firstOrNull { it.gesture == Gesture.DOUBLE }
        val lng = maps.firstOrNull { it.gesture == Gesture.LONG }
        val st = states.getOrPut(code) { St() }
        val plain = dbl == null && lng == null
        val plainKey = if (plain && single != null && single.action == Act.SEND_KEY) single.arg.toIntOrNull() else null
        val direct = plainKey != null && !isGlobalKey(plainKey)

        if (e.action == KeyEvent.ACTION_DOWN) {
            if (e.repeatCount > 0) {
                return true
            }
            st.down = true
            st.longFired = false
            if (plain) {
                if (direct) inject(plainKey!!, 0, 0)
                else if (single != null) run(single)
                return true
            }
            if (lng != null) {
                val r = Runnable { st.longFired = true; run(lng) }
                st.longR = r
                handler.postDelayed(r, LONG_MS)
            }
            return true
        }

        if (e.action == KeyEvent.ACTION_UP) {
            if (!st.down) return true
            st.down = false
            st.longR?.let { handler.removeCallbacks(it) }
            st.longR = null
            if (plain) {
                if (direct) inject(plainKey!!, 1, 0)
                return true
            }
            if (st.longFired) { st.longFired = false; return true }
            val tap = single ?: Mapping(code, Gesture.SINGLE, Act.SEND_KEY, code.toString())
            if (dbl != null) {
                val p = st.singleR
                if (p != null) {
                    handler.removeCallbacks(p)
                    st.singleR = null
                    run(dbl)
                } else {
                    val r = Runnable { st.singleR = null; run(tap) }
                    st.singleR = r
                    handler.postDelayed(r, DOUBLE_MS)
                }
            } else {
                run(tap)
            }
            return true
        }
        return false
    }

    private fun run(m: Mapping) {
        when (m.action) {
            Act.SEND_KEY -> {
                val k = m.arg.toIntOrNull() ?: return
                when (k) {
                    KeyEvent.KEYCODE_BACK -> performGlobalAction(GLOBAL_ACTION_BACK)
                    KeyEvent.KEYCODE_HOME -> performGlobalAction(GLOBAL_ACTION_HOME)
                    KeyEvent.KEYCODE_APP_SWITCH -> performGlobalAction(GLOBAL_ACTION_RECENTS)
                    else -> inject(k, 2, 0)
                }
            }
            Act.LAUNCH -> launch(m.arg)
            Act.KILL_FG -> killForeground()
            Act.HOME -> performGlobalAction(GLOBAL_ACTION_HOME)
            Act.BACK -> performGlobalAction(GLOBAL_ACTION_BACK)
            Act.RECENTS -> performGlobalAction(GLOBAL_ACTION_RECENTS)
        }
    }

    private fun launch(pkg: String) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
            ?: packageManager.getLeanbackLaunchIntentForPackage(pkg)
        if (i == null) { toast("Tətbiq tapılmadı: $pkg"); return }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try { startActivity(i) } catch (e: Exception) { toast("Açıla bilmədi") }
    }

    private fun killForeground() {
        val pkg = (rootInActiveWindow?.packageName?.toString() ?: lastPkg)?.takeIf { it !in ignore }
        performGlobalAction(GLOBAL_ACTION_HOME)
        val cmds = ArrayList<String>()
        if (pkg != null) cmds.add("am force-stop $pkg")
        cmds.add("am kill-all")
        cmds.add("sync")
        Adb.runAsync(cmds)
        toast(if (pkg != null) "Bağlandı + RAM təmizləndi: $pkg" else "RAM təmizləndi")
    }

    private fun toast(s: String) { Toast.makeText(applicationContext, s, Toast.LENGTH_SHORT).show() }
}
